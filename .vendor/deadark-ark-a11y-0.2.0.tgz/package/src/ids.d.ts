/** Every Ark-generated DOM id starts with this. Never author an id with it. */
export declare const ARK_GENERATED_ID_PREFIX: "ark-r-";

/** Separates a generated id's scope from its counter; never produced by a runtime slug. */
export declare const ARK_GENERATED_ID_SEPARATOR: "--";

/** A fresh page-unique id: `ark-r-<slug(scope)>--<n>`. */
export declare function createArkGeneratedId(scope?: string): string;

/** True when `id` starts with the reserved generated-id prefix. */
export declare function isArkGeneratedId(id: unknown): boolean;

export type ArkAuthoredIdCheck =
  | { ok: true }
  | { ok: false; failure: string; needs: string; remedy: string };

/** Checks a hand-written id; refuses empty ids and ids using the reserved prefix. */
export declare function checkAuthoredId(id: unknown): ArkAuthoredIdCheck;

/** Returns `id` when it is a valid authored id; throws the refusal otherwise. */
export declare function assertAuthoredId(id: unknown): string;
