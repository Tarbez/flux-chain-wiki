# @deadark/ark-syntax

Tokenization, parsing, AST validation, pattern references, and diagnostics
for ARK's F/R/S/D/M/A/X/C/T/P pattern language.

Currently owns:

- `./tokenizer` — the maximal-munch word lexer (`tokenizeFlux`, `splitFluxWord`,
  `splitFluxWordViaTokenizer`, `ARK_UI_OPERATOR_SYMBOLS`).
- `./tree` — the `.`-fence tokenizer/tree builder (`tokenizePattern`,
  `buildTree`, the `FluxNode` shape). `attrs`/`arbitraryStyle` are left
  generic — this package builds the tree structure only; a consumer (e.g.
  `@deadark/ark-ui`) owns the F/R/S/D/M/A/X/C/T/P key/value grammar and any
  style resolution built on top of the same nodes.

Ark UI keeps compatibility exports (`ark-ui.flux-tokenizer.ts`) for existing
consumers, but tokenizer/tree ownership lives here.
