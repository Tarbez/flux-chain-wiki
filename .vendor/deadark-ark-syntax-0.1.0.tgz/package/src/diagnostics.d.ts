export type FluxSyntaxDiagnosticSeverity = "error" | "warning";

export type FluxSyntaxDiagnosticCode =
  | "unterminated-bracket"
  | "unbalanced-fence-close"
  | "unclosed-fence"
  | "empty-pattern";

/**
 * A stable, structured description of one syntax problem found in a
 * pattern string. Always plain, serializable data -- never thrown -- so a
 * caller can collect every issue in one pass instead of stopping at the
 * first one.
 */
export declare class FluxSyntaxDiagnostic {
  constructor(
    code: FluxSyntaxDiagnosticCode,
    message: string,
    severity: FluxSyntaxDiagnosticSeverity,
    index: number,
    token?: string,
  );
  code: FluxSyntaxDiagnosticCode;
  message: string;
  severity: FluxSyntaxDiagnosticSeverity;
  index: number;
  token?: string;
}

/**
 * Walks a pattern string the same way `buildTree()` does, but instead of
 * producing a node tree it collects every structural problem found:
 * unterminated `[...]` brackets (error), fence-close imbalance, unclosed
 * trailing fences, and empty patterns (warnings). Returns an empty array
 * for a well-formed pattern. Never throws -- `buildTree()` itself stays
 * fully permissive and is unaffected by what this function reports.
 */
export declare function collectFluxSyntaxDiagnostics(pattern: string): FluxSyntaxDiagnostic[];

/** True if {@link collectFluxSyntaxDiagnostics} would report at least one
 * `"error"`-severity diagnostic (as opposed to only warnings, or none). */
export declare function hasFluxSyntaxErrors(pattern: string): boolean;
