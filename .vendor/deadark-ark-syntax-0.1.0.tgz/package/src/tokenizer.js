// Vendored from Trust-language-models' `scripts/flux-algebra/tokenizer.mjs`
// (maximal-munch lexer, iterates Unicode code points so emoji/combining
// marks stay intact as single atoms). ark-syntax has no package dependency
// on that repo, so this is a direct port rather than an import -- keep it in
// sync by hand if the source tokenizer changes shape.
//
// This module's one job: splitting a Flux word (e.g. "F-DASHBOARD-X-DARK")
// into its hyphen-delimited segments the same way the JS Flux algebra
// engine would lex them, instead of a from-scratch `word.split("-")`. The
// F/R/S/D/M/A/X/C/T/P key/value grammar itself (parseWord et al.) is owned
// by the consumer (ark-ui's runtime); this module only owns the lexing.

function matchesAt(chars, position, symbolChars) {
  if (position + symbolChars.length > chars.length) return false;
  for (let k = 0; k < symbolChars.length; k += 1) {
    if (chars[position + k] !== symbolChars[k]) return false;
  }
  return true;
}

/** Default symbol set for word-lexing: "-" is the only structural separator
 * in the F/R/S/D/M/A/X/C/T/P grammar. */
export const ARK_UI_OPERATOR_SYMBOLS = ["-"];

/**
 * Symbol-table prep (sorting by length, splitting each symbol into code
 * points) is a pure function of `symbols` and identical on every call for a
 * fixed table, so it's memoized per array reference here rather than redone
 * per tokenize() call. The default `ARK_UI_OPERATOR_SYMBOLS` table -- the
 * one every `splitFluxWord()` call hits -- is prepared exactly once at
 * module load, not once per word.
 */
const preparedSymbolCache = new WeakMap();

function prepareSymbols(symbols) {
  const cached = preparedSymbolCache.get(symbols);
  if (cached) return cached;
  const prepared = [...symbols]
    .sort((a, b) => b.length - a.length)
    .map((symbol) => ({ symbol, chars: Array.from(symbol) }));
  preparedSymbolCache.set(symbols, prepared);
  return prepared;
}

export function tokenizeFlux(text, symbols = ARK_UI_OPERATOR_SYMBOLS) {
  const chars = Array.from(String(text));
  const orderedSymbols = prepareSymbols(symbols);

  const stream = [];
  let i = 0;
  let position = 0;

  while (i < chars.length) {
    if (/\s/.test(chars[i])) {
      i += 1;
      continue;
    }

    const matched = orderedSymbols.find((entry) => matchesAt(chars, i, entry.chars));
    if (matched) {
      stream.push({ type: "operator", value: matched.symbol, raw: matched.symbol, index: position });
      i += matched.chars.length;
      position += 1;
      continue;
    }

    let j = i;
    while (
      j < chars.length &&
      !/\s/.test(chars[j]) &&
      !orderedSymbols.some((entry) => matchesAt(chars, j, entry.chars))
    ) {
      j += 1;
    }

    const raw = chars.slice(i, j).join("");
    stream.push({ type: "token", value: raw, raw, index: position });
    position += 1;
    i = j;
  }

  return stream;
}

/** Same output shape as `word.split("-")`, but produced by the shared
 * maximal-munch tokenizer instead of an ad hoc split. Empty segments
 * (consecutive "-", e.g. the negative-polarity marker "--VALUE") are
 * preserved as "" to match `split("-")`'s behavior exactly, since callers
 * (e.g. ark-ui's `parseWord`) depend on that empty-string sentinel for
 * negative polarity. */
// A surrogate pair (astral-plane character, e.g. most emoji) is the one case
// where `String.split("-")` and the codepoint-aware tokenizer can disagree:
// `split` indexes UTF-16 code units, so it can never itself sever a
// surrogate pair (a lone "-" would have to sit between two code units of the
// same character to matter, which can't happen for a real separator byte),
// but a caller reading `.length`/indexing the *result* of a naive split can
// still miscount an astral character as two units. Detecting the pair here
// and routing through the codepoint-safe tokenizer only in that case keeps
// the common (pure-ASCII, the overwhelming majority of Flux words) path at
// native `split()` speed while still giving Unicode-bearing words the real
// engine's codepoint safety -- the actual reason the shared tokenizer
// exists, per flux-algebra-engine.md's design notes.
const HAS_SURROGATE_PAIR = /[\uD800-\uDBFF][\uDC00-\uDFFF]/;

export function splitFluxWord(word) {
  if (!HAS_SURROGATE_PAIR.test(word)) return word.split("-");
  return splitFluxWordViaTokenizer(word);
}

/** Always routed through the generic maximal-munch tokenizer
 * (Unicode-codepoint-safe, honors a custom operator table) -- what
 * {@link splitFluxWord} falls back to for Unicode-bearing words, and
 * available directly for callers that need more than a single "-"
 * separator. */
export function splitFluxWordViaTokenizer(word, symbols = ARK_UI_OPERATOR_SYMBOLS) {
  const tokens = tokenizeFlux(word, symbols);
  const segs = [];
  let pendingEmpty = true;
  for (const tok of tokens) {
    if (tok.type === "operator") {
      if (pendingEmpty) segs.push("");
      pendingEmpty = true;
      continue;
    }
    segs.push(tok.value);
    pendingEmpty = false;
  }
  if (pendingEmpty) segs.push("");
  return segs;
}
