// AST validation and diagnostics for ARK's F/R/S/D/M/A/X/C/T/P pattern
// language (ARK_UI_EVOLUTION_PLAN.md 3.3 Batch 2 deliverable: "stable error
// objects for malformed patterns"). `buildTree()` in tree.js stays fully
// permissive by design -- the rendering path must never throw on bad input,
// matching the rest of the parser's fail-soft posture (see
// ark-ui.runtime.ts's `parseInlineDecl` comment: "Malformed brackets are
// dropped silently, never thrown"). This module is the opt-in AST validator
// tooling (editors, linters, dev-mode warnings) can call *alongside*
// buildTree() to get structured diagnostics for the same input, without
// changing what buildTree() itself returns or how rendering behaves.

/** @typedef {"unterminated-bracket"|"unbalanced-fence-close"|"unclosed-fence"|"empty-pattern"} FluxSyntaxDiagnosticCode */

/**
 * A stable, structured description of one syntax problem found in a
 * pattern string. Always plain, serializable data -- never thrown -- so a
 * caller can collect every issue in one pass instead of stopping at the
 * first one.
 */
export class FluxSyntaxDiagnostic {
  constructor(code, message, severity, index, token) {
    this.code = code;
    this.message = message;
    this.severity = severity;
    this.index = index;
    this.token = token;
  }
}

function tokenizeWithBracketCheck(pattern) {
  const tokens = [];
  let current = "";
  let bracketDepth = 0;
  let unterminatedBracketAt = -1;
  let tokenIndex = 0;
  for (const ch of pattern.trim()) {
    if (ch === "[") {
      if (bracketDepth === 0) unterminatedBracketAt = tokenIndex;
      bracketDepth++;
    }
    if (ch === "]") bracketDepth = Math.max(0, bracketDepth - 1);
    if (/\s/.test(ch) && bracketDepth === 0) {
      if (current) { tokens.push({ value: current, index: tokenIndex }); tokenIndex++; }
      current = "";
      continue;
    }
    current += ch;
  }
  if (current) tokens.push({ value: current, index: tokenIndex });
  return { tokens, unterminatedBracket: bracketDepth > 0, unterminatedBracketAt };
}

/**
 * Walks a pattern string the same way {@link buildTree} does, but instead of
 * producing a node tree it collects every structural problem it finds:
 *
 * - `empty-pattern` (warning): the pattern is blank/whitespace-only.
 * - `unterminated-bracket` (error): a `[...]` arbitrary-value escape was
 *   opened but never closed.
 * - `unbalanced-fence-close` (warning): a token's trailing "."s try to close
 *   more isolation-fence levels than are open; the extra closes are dropped
 *   (buildTree()'s existing, unchanged behavior) rather than erroring, so
 *   this is a warning, not an error -- rendering still proceeds.
 * - `unclosed-fence` (warning): the pattern ends with one or more
 *   isolation-fence levels still open (a leading "." that was never
 *   balanced by a matching trailing "."). buildTree() treats every node
 *   still on the stack as implicitly closed at end-of-input, so this is
 *   also a warning, not an error.
 *
 * Returns an empty array for a well-formed pattern. Never throws.
 */
export function collectFluxSyntaxDiagnostics(pattern) {
  const diagnostics = [];

  if (typeof pattern !== "string" || pattern.trim() === "") {
    diagnostics.push(new FluxSyntaxDiagnostic(
      "empty-pattern",
      "Pattern is empty or whitespace-only; it will render as an empty root node.",
      "warning",
      0,
      pattern ?? "",
    ));
    return diagnostics;
  }

  const { tokens, unterminatedBracket, unterminatedBracketAt } = tokenizeWithBracketCheck(pattern);
  if (unterminatedBracket) {
    diagnostics.push(new FluxSyntaxDiagnostic(
      "unterminated-bracket",
      "An arbitrary-value \"[...]\" escape was opened but never closed.",
      "error",
      unterminatedBracketAt,
      tokens[unterminatedBracketAt]?.value,
    ));
  }

  let depth = 1; // root counts as depth 1, matching buildTree()'s `stack` starting at [root]
  for (const { value: token, index } of tokens) {
    let i = 0;
    while (i < token.length && token[i] === ".") i++;
    const leading = i;
    let j = token.length;
    while (j > i && token[j - 1] === ".") j--;
    const trailing = token.length - j;

    depth += leading;
    if (trailing > depth - 1) {
      diagnostics.push(new FluxSyntaxDiagnostic(
        "unbalanced-fence-close",
        `Token "${token}" closes ${trailing} isolation-fence level(s), but only ${depth - 1} are open; the extra close(s) are ignored.`,
        "warning",
        index,
        token,
      ));
      depth = 1;
    } else {
      depth -= trailing;
    }
  }

  if (depth > 1) {
    diagnostics.push(new FluxSyntaxDiagnostic(
      "unclosed-fence",
      `Pattern ends with ${depth - 1} isolation-fence level(s) still open; they are implicitly closed at end of input.`,
      "warning",
      pattern.length,
      undefined,
    ));
  }

  return diagnostics;
}

/** True if {@link collectFluxSyntaxDiagnostics} would report at least one
 * `"error"`-severity diagnostic (as opposed to only warnings, or none). */
export function hasFluxSyntaxErrors(pattern) {
  return collectFluxSyntaxDiagnostics(pattern).some((diagnostic) => diagnostic.severity === "error");
}
