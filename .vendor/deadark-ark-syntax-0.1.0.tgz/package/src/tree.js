// Fence tokenizer / tree builder for ARK's F/R/S/D/M/A/X/C/T/P pattern
// language. Walks ". ... ." isolation fences into a tree of FluxNode
// objects; each node carries its own raw (unparsed) words plus an `attrs`
// slot and an `arbitraryStyle` slot for a consumer to fill in later. This
// module knows nothing about what goes in those slots -- word/key-value
// parsing (e.g. "F-DASHBOARD-X-DARK" -> { F: ..., X: ... }) and style
// resolution are the consuming application's job, not this package's.
//
// Deliberately not unified with Trust-language-models' `scripts/flux-algebra/`
// fence grammar (`.` as a mirror/toggle token) -- this is a decided
// divergence, not an unaddressed TODO. flux-algebra's mirror fence cannot
// express same-symbol nesting (two adjacent `.` close what the first one
// opened rather than opening a nested level), so `"..X.."` there parses as
// two empty isolated fences flanking an unisolated `X` -- flat, not
// depth-2 nested. This module's per-word leading/trailing dot *count* is
// what lets `"..X.."` actually nest `X` two components deep, which is the
// whole point of a UI tree. Adopting flux-algebra's grammar here would be a
// capability regression. See docs/architecture/flux-algebra-vs-arkui-fences.md
// (Trust-language-models repo) for the full decision record.

export function tokenizePattern(pattern) {
  const tokens = [];
  let current = "";
  let bracketDepth = 0;
  for (const ch of pattern.trim()) {
    if (ch === "[") bracketDepth++;
    if (ch === "]") bracketDepth = Math.max(0, bracketDepth - 1);
    if (/\s/.test(ch) && bracketDepth === 0) {
      if (current) tokens.push(current);
      current = "";
      continue;
    }
    current += ch;
  }
  if (current) tokens.push(current);
  return tokens;
}

// ---------------------------------------------------------------------------
// Parse-once/cache behavior (ARK_UI_EVOLUTION_PLAN.md 3.3 Batch 2 deliverable
// + performance target: "pattern parsing is cached by source"). The same
// pattern string renders repeatedly across list items/instances, so caching
// the tokenize+fence-walk work (the O(chars) part) pays off directly.
//
// What's cached is a plain, *immutable* shape tree -- never the FluxNode
// objects buildTree() hands back. Consumers (e.g. ark-ui's `annotate()`)
// mutate a returned node's `attrs`/`arbitraryStyle` in place, and
// `arbitraryStyle` is merged (accumulated), not overwritten -- returning the
// same node object on a second call for the same pattern would silently
// double-merge style state and corrupt every other holder of that cache
// entry. materialize() always allocates a fresh node tree from the cached
// shape, so every buildTree() call gets its own independent, empty-`attrs`
// objects while skipping the repeated string walk.
// ---------------------------------------------------------------------------

const PARSE_CACHE_LIMIT = 500;
const shapeCache = new Map();

function buildShape(pattern) {
  const root = { raw: [], children: [] };
  const stack = [root];
  const tokens = tokenizePattern(pattern);

  for (const token of tokens) {
    let i = 0;
    while (i < token.length && token[i] === ".") i++;
    const leading = i;
    let j = token.length;
    while (j > i && token[j - 1] === ".") j--;
    const trailing = token.length - j;
    const core = token.slice(i, j);

    for (let k = 0; k < leading; k++) {
      const child = { raw: [], children: [] };
      stack[stack.length - 1].children.push(child);
      stack.push(child);
    }
    if (core) stack[stack.length - 1].raw.push(core);
    for (let k = 0; k < trailing && stack.length > 1; k++) stack.pop();
  }

  return root;
}

function materialize(shape) {
  return {
    raw: shape.raw.slice(),
    attrs: {},
    children: shape.children.map(materialize),
  };
}

function cachedShape(pattern) {
  let shape = shapeCache.get(pattern);
  if (shape) return shape;
  shape = buildShape(pattern);
  if (shapeCache.size >= PARSE_CACHE_LIMIT) {
    // Simple FIFO eviction -- Map preserves insertion order, and pattern
    // strings are drawn from a small, repeating vocabulary per app, so exact
    // LRU accounting isn't worth the extra bookkeeping here.
    const oldestKey = shapeCache.keys().next().value;
    shapeCache.delete(oldestKey);
  }
  shapeCache.set(pattern, shape);
  return shape;
}

export function buildTree(pattern) {
  return materialize(cachedShape(pattern));
}

/** Clears the pattern-shape cache. Exposed for tests and for hosts that
 * hot-reload/redefine pattern sources under the same string (rare -- pattern
 * strings are normally treated as immutable source, per "cached by source"
 * in the performance target). Not part of ordinary rendering paths. */
export function clearFluxTreeCache() {
  shapeCache.clear();
}
