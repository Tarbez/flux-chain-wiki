/**
 * A node in the F/R/S/D/M/A/X/C/T/P pattern tree. `Attrs` and `Style` are
 * left generic (default to a loose record) because this package does not
 * own the key/value attribute grammar or the style representation -- only
 * the fence/tree structure. A consumer (e.g. ark-ui's runtime) specializes
 * both type parameters locally: `type FluxNode = BaseFluxNode<Attrs, StyleObject>`.
 */
export interface FluxNode<Attrs = Record<string, unknown>, Style = Record<string, unknown>> {
  raw: string[];
  attrs: Attrs;
  children: FluxNode<Attrs, Style>[];
  /** One-off style payload a consumer may attach to this node (e.g. from a
   * `[prop:value;...]` bracket escape hatch found in the node's raw words).
   * This package never populates it -- it exists purely so a consumer can
   * annotate the same node object this package built, without needing a
   * second parallel tree. */
  arbitraryStyle?: Style;
}

/**
 * Splits a pattern string into whitespace-delimited tokens, respecting
 * `[...]` bracket nesting (whitespace inside a bracket does not split a
 * token).
 */
export declare function tokenizePattern(pattern: string): string[];

/**
 * Builds a FluxNode tree from a pattern string. Leading/trailing "."
 * characters on a token open/close isolation-fence nesting levels -- e.g.
 * "..FOO.." nests FOO two levels deep. Each node's `raw` array holds its
 * own (still-unparsed) words; `attrs` starts as an empty object for the
 * consumer to fill in.
 */
export declare function buildTree<Attrs = Record<string, unknown>, Style = Record<string, unknown>>(
  pattern: string
): FluxNode<Attrs, Style>;

/**
 * Clears the internal pattern-shape cache used by {@link buildTree} to avoid
 * re-walking a previously-seen pattern string. Each `buildTree()` call
 * always returns a fresh, independently-mutable node tree regardless of
 * caching -- this only clears the cached parse *shape*, not any tree a
 * caller already holds. Exposed for tests; not needed in ordinary use.
 */
export declare function clearFluxTreeCache(): void;
