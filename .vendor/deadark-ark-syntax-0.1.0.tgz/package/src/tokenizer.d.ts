export interface FluxToken {
  type: "token" | "operator";
  value: string;
  raw: string;
  index: number;
}

/** Default symbol set for word-lexing: "-" is the only structural separator
 * in the F/R/S/D/M/A/X/C/T/P grammar. */
export declare const ARK_UI_OPERATOR_SYMBOLS: readonly string[];

export declare function tokenizeFlux(text: string, symbols?: readonly string[]): FluxToken[];

/** Same output shape as `word.split("-")`, but produced by the shared
 * maximal-munch tokenizer instead of an ad hoc split. Empty segments
 * (consecutive "-") are preserved as "" to match `split("-")`'s behavior
 * exactly. */
export declare function splitFluxWord(word: string): string[];

/** Always routed through the generic maximal-munch tokenizer
 * (Unicode-codepoint-safe, honors a custom operator table). */
export declare function splitFluxWordViaTokenizer(word: string, symbols?: readonly string[]): string[];
