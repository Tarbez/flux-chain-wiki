# Ark UI skins

This page is for a product developer who wants to reskin Ark UI parts with a recipe, such as an NFT card's colours, drawn frame and layout rules. A skin sits at layer 3 of the [style precedence](STYLE_RECIPES.md#precedence): after the provider theme and starter recipe, before local overrides.

```js
import { applyArkSkin, removeArkSkin } from "@deadark/ark-ui/skin";

const result = applyArkSkin(document.querySelector("#app"), skin, { locks: ["--accent"] });
// result.ok, result.applied, result.skipped, result.errors
removeArkSkin(document.querySelector("#app")); // exact undo
```

## API

| Export | What it does |
| --- | --- |
| `applyArkSkin(root, skin, options)` | Validates the whole skin, then applies it under `root`. A refused skin changes nothing and returns `{ ok: false, errors }`. Applying to a root that already has a skin removes the old one first. |
| `removeArkSkin(root)` | Restores `root` and every touched element, attribute for attribute. Returns `false` when there was no skin. |
| `getArkSkinReport(root)` | A structured report of what the skin did, part by part (see Report). `applyArkSkin` returns it too, as `result.report`. |
| `getArkSkin(root)` | The applied skin's `{ id, name, tokens }`, or `undefined`. |
| `validateArkSkin(skin)` | The list of problems, empty when the skin is valid. No DOM needed. |
| `layoutArkChrome(piece, width, height)` | The one band-stretch function (below). Returns SVG markup, or `null` when the piece is refused. |
| `sanitizeArkSvg(markup, idPrefix?)` | The SVG allow-list. Returns `{ ok, inner }` or `{ ok: false, error }`. |
| `arkSchemaKeys()`, `arkSkinPartKeys()` | The schema keys, and every name a rule may use, both read from the component schema. |
| `arkSkinFamilyOfName(name)`, `arkSkinFamilyOfKey(key)`, `ARK_SKIN_FAMILY_RULES` | Which rules a part kind takes (below). |
| `ARK_SKIN_RULES`, `ARK_SKIN_LAYOUTS`, `ARK_SKIN_MEANING_TOKENS`, `DEFAULT_ARK_CHROME` | The closed sets and the built-in chrome. |

A skin is `{ name, tokens, chrome?, rules?, locks? }`. `version` and `record` are accepted and ignored, so a product recipe can be passed as it is.

`options` is `{ locks?, event?, contrast? }`. `locks` takes token names (`--accent`) and part keys (`POPOVER`). `event` renames the event below (default `ark:skin`). `contrast` is a product's own contrast rules, described under the contrast gate.

## Tokens

Tokens are written once, into one stylesheet scoped to `[data-ark-skin="<id>"]`. The stylesheet is adopted when the host supports `adoptedStyleSheets` and is an owned `<style data-ark-skin-style>` in the document head (or shadow root) otherwise. Ark UI never writes an inline style on `root` or on any element.

A token is skipped, with a `console.info` line that names the token and the reason, when it is:
- one of the meaning tokens `--live --trust --drift --warning --danger --hidden --success`. Their colour says what a thing is.
- listed in `options.locks` or `skin.locks`.
- dropped by the contrast gate.

`--reference` is a role token, not a meaning token. A product that needs it fixed locks it. Tokens the skin does not carry, such as `--reference-100` to `--reference-700`, `--secondary`, `--secondary-ink`, `--secondary-600` and `--border-control`, come from `deriveSkinTokens(palette)` in `@deadark/sdk/theme`. Merge its result into `skin.tokens` before applying.

Block type and focus hooks. The block stylesheet reads these, and a skin may set them. With none set, every block looks as it did before.
- `--type-heading-case`, `--type-heading-tracking`, `--type-heading-weight`: the hero, section header, quote and pager titles. They default to `none`, each title's own tracking (`normal` for the pager title) and each title's own weight.
- `--font-numeric`: the stat number, meter value, hero meta values and numeric table cells. Each keeps its own font when this is unset.
- `--type-eyebrow-case`, `--type-eyebrow-tracking`: `.ark-eyebrow`. They default to `uppercase` and `0.12em`.
- `--focus-radius`: the focus ring on blocks and on the tabs panel. It defaults to `4px`.

Any `--w-*` token is accepted. The chrome SVG reads these as its colours: `--w-ink --w-dim --w-line --w-faint --w-rule --w-acc --w-acc2 --w-state`. Values may be `rgba()` strings.

### Contrast gate

The skin's colour tokens are checked before they are written. A product can add its own rules with `options.contrast`, a list of `{ fg, bg, min }` where `fg` and `bg` are token names and `min` is a ratio from 1 to 21:

```js
applyArkSkin(root, skin, { locks, contrast: [{ fg: ["--text-strong", "--text", "--text-muted", "--text-faint"], bg: ["--canvas", "--surface"], min: 4.5 }] });
```

A foreground that falls below `min` on any listed background has its OKLCH lightness stepped, with hue kept and chroma kept as far as the gamut allows, until it clears every background. The new value is written in the notation it came in (`H S% L%` channels or hex). When no lightness can reach `min`, the token is dropped and the site's own value stays. Each change is logged and listed in `result.adjusted` (`token`, `from`, `to`, `before`, `after`, `min`). Product rules run before the defaults below, so a token a rule repairs is not dropped by the default gate. The built-in rules only drop a failing token.

The gate uses `contrastRatio` from `ark-ui.components.ts`. Ark UI has no second implementation. It converts the skin's colour strings (`H S% L%`, `hsl()`, `rgb()`, `rgba()`, hex) to hex first, and composites any alpha over the surface.

| Foreground | Against | Minimum |
| --- | --- | --- |
| `--text-strong`, `--text`, `--text-muted` | `--canvas --surface --raised --nested --overlay` | 4.5 (AA body text) |
| `--w-ink` | the same surfaces | 4.5 |
| `--w-dim`, `--w-line` | the same surfaces | 3 |
| `--text-inverse` | `--primary`, `--accent` | 4.5 |

A surface the skin does not set is read from the site's computed style when the browser can resolve it. A failing foreground is dropped, the site's own value stays, and the console names the pair. The chrome SVG gives every `var(--w-*)` a fallback to a site token (`--w-ink` to `--text-strong`, `--w-dim` to `--text-muted`, `--w-line` to `--border-strong`, `--w-faint` to `--border-subtle`, `--w-rule` to `--border-default`, `--w-acc` to `--primary`, `--w-acc2` to `--complement`, `--w-state` to `--text-muted`), so a dropped colour still draws in a legible one.

## Names

The pieces are named for what they are in an interface, so a site, a game or an app can use them: `frame`, `corner`, `nameplate`, `accent-strip`, `divider` and `icon`. The rule keys do not change (`frame`, `edge`, `ornament`, `density`, `marker`, `header`, `layout`). Three rule values do.

| Old name | Name now | Where |
| --- | --- | --- |
| `tag` | `nameplate` | the chrome piece, and the value `header: nameplate` |
| `ornament` | `accent-strip` | the chrome piece (the rule key `ornament` stays, with the values `strip` and `icon`) |
| `emblem` | `icon` | the chrome piece, and the values `marker: icon` and `ornament: icon` |

A skin written with the old names reads as the new ones, applies identically, and shows the new names in the report. The console says so once per name. `normalizeArkSkin(skin)` does the same reading on its own and returns the old names it found. The aliases are `ARK_SKIN_CHROME_ALIASES` and `ARK_SKIN_VALUE_ALIASES`.

The decoration nodes carry the new names in `data-ark-skin-deco`: `nameplate`, `accent-strip`, `accent-strip-title`, `icon-center`, `icon-title`, `divider`, `divider-rule`, `frame`, `corners`, `notches`. The marker attribute on an item is `data-ark-skin-item="icon"` or `"index"`, and the header attribute is `data-ark-skin-header="nameplate"`. The CSS variable for the nameplate's height is `--ark-skin-nameplate`.

## Rules

`rules` is `{ [partKey]: ruleSet }`. A part key is a key of the component schema, such as `POPOVER`, `CARD`, `MEGAMENUPANEL`, `MEGAMENUCOLUMN`, `MENUBAR`, `NAVMENU`, `TABSLIST`, `MODAL`, `BUTTON` or `HEADING|TEXT`. Each side of a compound key also works (`LINK` for `LINK|BUTTON`). The allowed names are read from the schema (`arkSkinPartKeys()`), never from a list in this file.

An unknown key or value is refused with a `console.error` that names the allowed values. The whole skin is validated before the DOM is touched.

| Rule | Values | Effect |
| --- | --- | --- |
| `frame` | `none` `corners` `full` `ticket` `bracket` | `corners`: four corner pieces. `bracket`: top-left and bottom-right only. `full`: the frame piece, stretched. `ticket`: `full` plus a notch on each side. |
| `edge` | `keep` `square` `cut` `soft` | Radius: unchanged, 0, bevelled corners (`border-radius` with `corner-shape: bevel`, 8px, where the browser supports it, else square), or `--ark-skin-soft` (12px). Nothing is clipped, so a dropdown or tooltip hanging outside the part stays visible. |
| `ornament` | `none` `strip` `icon` | The accent strip on the part's bottom edge, or the icon on its top edge, both centred on the line. On a separator or divider part the divider piece is drawn over the line instead. |
| `density` | `keep` `compact` `airy` | Padding and gap of container parts. Buttons, links, inputs and tabs keep their own padding. |
| `marker` | `none` `icon` `index` | A mark before each item of the part, drawn as a CSS `::before` on the item, so no node is added to it. `index` is a CSS counter (`01`, `02`, ...). `icon` is the icon piece used as a mask, painted with `--w-acc`. The skin stamps `data-ark-skin-item` on each leaf item (a `li` that holds a link leaves the mark to the link and drops its own bullet), so a plain `ul` shows no second bullet. An item is marked once, by the nearest part: a descendant list that has its own part is never marked by an ancestor's rule. |
| `header` | `none` `nameplate` | The nameplate piece sits on the part's top edge, at most half its height outside it, scaled uniformly to its height and never wider than the part. It takes no room. It carries the part's own words: its `title` field takes the part's title and its `index` field the part's index (see "Nameplate words"). |
| `layout` | `keep`, plus the per-part values below | The part's arrangement, by CSS only. |
| `button` `badge` `menu` `popover` `dropdown` `line` `link` `grid` | `none` `drawn` | `drawn` draws the skin's piece of the same name on the parts that take it (`ARK_SKIN_WORN_PIECES`, see "Worn pieces"). |

Layouts per part:

| Part key | Layouts |
| --- | --- |
| `MEGAMENUPANEL` | `columns` `tiles` `list` |
| `POPOVER`, `LIST` (menu items) | `list` `tiles` |
| `TABSLIST` | `pills` `rail` `underline` |
| `CARD` | `plain` `framed` `ticket` |
| `MODAL` | `centered` `sheet` |
| `hero` `section-header` `card-grid` `stats` `facts` `list-rows` `stepper` `alert` | see "Section layouts" |

### Which rules fit which part

One rule set is often sent to many parts, so each part kind takes only the rules that make sense on it. A rule that does not fit is skipped, and the console names the rule and the part. It never refuses the skin. Nothing is ever added inside or around a link or a line of text.

| Kind | Parts | Rules taken |
| --- | --- | --- |
| `wrapper` | a block root that holds its trigger and a `<name>-panel` part, such as the `popover` block's root | none: the rules go to the panel |
| `surface` | `POPOVER MODAL SHEET DRAWER CARD PANEL MEGAMENUPANEL ASIDE SECTION` | all |
| `list` | `LIST ITEM MEGAMENUCOLUMN` | `frame edge density marker layout` |
| `other` | structure with no surface of its own: `ROOT TABS TABSLIST MENUBAR NAVMENU` and similar | `frame edge density layout` |
| `control` | keys ending in `\|BUTTON`, and `button`, `input`, `select`, `textarea` elements | `frame edge` |
| `panel` | block panels with no surface of their own: `disclosure-panel`, `accordion-content`, `tabs-content` | `frame edge ornament` (no nameplate, which would hang over the trigger above) |
| `heading` | block heading holders: `hero`, `section-header` | `frame`, and `ornament`: the strip under the title's last line, starting at the title's left edge. `hero` and `section-header` also take `layout` (by part name, so no other heading does) |
| `rule` | block parts that draw a rule line: `hero-meta`, `pager`, `list-row`, `fact`, `tabs-list` | `ornament`: the divider piece on that line |
| `link` | `LINK\|BUTTON` | `edge` |
| `divider` | `SEPARATOR`, `DIVIDER\|TEXT` | `ornament`: the divider piece is drawn as a sibling after the line, since an `hr` takes no children |
| `text` | keys ending in `\|TEXT`, and inline elements (`a span label p h1-h6 code kbd`...) | none |

The `text` and `control` kinds come from the schema (a key's role, a definition's tag). The `surface` and `list` name lists are `ARK_SKIN_SURFACE_PARTS` and `ARK_SKIN_LIST_PARTS`, and the tests check every name is a schema key. A part named `popover-panel` answers to rules for `POPOVER`, and the `popover` root around it is a wrapper that takes nothing, so a frame or edge never lands on the wrapper. A part gets the tightest kind that any of its names gives: a plain `LINK` is `LINK\|BUTTON` and `LINK\|TEXT`, so it is `text`.

A rule set with only `frame`, `edge`, `ornament`, `marker` and `header` works by itself. Leave `layout` and `density` at `keep` (or omit them) until you have reviewed them.

An element matches a rule key when its `data-ark-part` (the primitive's own part name, such as `mega-menu` or `popover`), its `data-ark-foundation` (the `F-` schema key) or its `data-ark-meaning` plus role equals the key, ignoring case and punctuation. Hand-built site parts add `data-ark-part="MENUBAR"` and so on, and need no other change. They get chrome and rules, but never the theme colour rules below: those reach only elements the runtime styled, so a hand-built `.ark-cta` keeps its own CSS, which can read the skin's tokens.

Rules for locked parts, and for the covenant mark (`ARKMARK|TEXT`), are skipped and named on the console.

## Runtime-rendered parts

Ark UI's own parts (those `ui.render()` builds) take their colours from the theme object, not from custom properties, so tokens alone cannot reach them. A skin therefore also resolves a theme: the guest theme with the skin's colours on top. It maps the skin tokens onto the theme's fields in one place (`arkSkinThemeField`): a token whose camel-cased name is a theme colour field maps to it (`--canvas`, `--surface`, `--raised`, `--overlay`, `--text`, `--text-muted`, `--text-inverse`, `--border-strong`, `--primary`), plus three explicit names (`--nested` to `surfaceMuted`, `--text-faint` to `textSubtle`, `--border-default` to `border`). The semantic accent (primary buttons, links, focus) comes from `--accent`, else `--primary`. Meaning tokens are never mapped, so success, danger and warning parts keep their colours.

The component registration is run against a recording stub for both themes, and only the declarations that differ are emitted. They are scoped to the skinned root and selected by the schema key the runtime styled each element with (`getArkSchemaKey(el)` from `@deadark/ark-ui/runtime`), which the skin stamps as `data-ark-skin-key` and removes with the rest. Hover, focus and other state rules come along. The emitted rules sit in the skin's stylesheet at a higher specificity than the runtime's classes. A style a product sets on one ref with `cfg.styles` loses to the skin for the colours the skin changes.

A part whose own base style is coloured by a meaning token (`SAVE|BUTTON`, `DELETE|BUTTON`, `DANGER|BUTTON`, `ERROR|TEXT` and the like) keeps its colours as a pair: the skin changes neither its background nor its text. The set is derived from the schema (`arkSkinMeaningKeys()` builds the theme twice with different meaning colours and keeps the keys whose base rule differs).

Nothing is emitted without a skin, so the guest look is unchanged, and removing the skin removes the sheet. `result.themedKeys` lists the schema keys that were re-coloured. The browser test `tests/browser-skin.mjs` reads the computed colours of every part kind its page renders (39 schema keys, including menus, overlays, tabs, cards, forms and buttons). It reads them before the skin, with it, and after removal, for all three NFT recipes.

### Decoration takes no room

Every decoration node is absolutely positioned inside its part, so it never becomes a flex or grid item and moves no content. A part whose computed position is static gets `position: relative` from the skin's stylesheet (`data-ark-skin-rel`). A browser test checks that frame, edge, ornament and header move no child of a flex, grid or block container by more than 1px. Markers add an inline `::before` to each item, and `density` and `layout` change the part by design.

### Contrast check

After the rules settle, every re-coloured part that carries text is measured: its text colour against the first opaque background up its tree, the page's own, and white when nothing is opaque. A part behind a gradient or image is skipped. Below AA (4.5:1, or 3:1 for large text), the skin takes back that part's theme colours and logs `[ark-skin] "<name>": reverted colours on <key> (contrast 2.9:1)`. If the guest look is no better, the skin keeps its colours. The check runs once on apply and once for each batch of late-mounted parts, and colour transitions are held off during it so it reads final values. A page that paints its backdrop with a literal colour, not a token, is the usual cause of a revert.

### Cover check

A decoration is never drawn over text or a control, inside the part or next to it. After each decoration is placed, the skin samples the piece's drawn points (along each shape with `getPointAtLength`, plus filled areas and text boxes), maps them to the screen the way the piece is laid out, and compares them with the boxes of the text and controls around the part (those in the part's grandparent that lie within 64px of it). The points come from the piece itself, never from the `<defs>` template of a drawn instance: a nine-slice cell maps only the points that lie inside that cell's source rectangle, and a piece that scales whole drops points outside its viewBox, so a line the piece never draws cannot cover anything. A control's own box counts 3px smaller, so a line drawn on the edge it sits against is not a hit. The check works off layout, so parts below the fold are checked too. It needs a rendered page and is skipped in a headless DOM.

When a decoration covers content:
- `frame: full` or `ticket` falls back to `corners` if the corners fit. If they do not, the frame is taken back.
- `header: nameplate` is taken back. A part shorter than twice the nameplate's height gets "no room for the tag inside the part"; otherwise the reason is "it covers the part's content".
- An accent strip, icon or divider is taken back. A heading's strip after the title falls back to the heading's bottom edge first.

Each is listed in the report as `reverted` with its reason (`frame` is listed with "drew corners instead" when the fallback holds), and logged on the console.

### Checks again when a part changes size

A part that is closed when the skin is applied (a popover, a disclosure) has no content to check, so its decorations are placed and the checks wait. Every decorated part is watched with a `ResizeObserver`. When its size changes by 1px or more (it opens, a title wraps, a column resizes), the skin takes back that part's rules and places them again, so the cover and fit checks run on the content that is there now. A take-back is reported and logged like any other. Decorations are absolutely positioned and change no size, so placing them again cannot start a loop; a part is placed again at most once per 150ms. A heading's title is watched too, so the strip follows it. This needs `ResizeObserver`, so it does not run in a headless DOM.

### Edge decorations stay inside the part

A frame, corners or ticket notches are clipped to the part's padding box (`overflow: hidden` on their layer), so a piece that draws outside its viewBox, or a part with its own border or a fixed position, cannot paint beyond the part. The tag, the ornament strip, the emblem and the divider are the pieces that straddle an edge by design (at most half their height).

### Own border, clipping containers and the drawing behind the words

- **Own border.** A part that already draws a border of its own (any side, with a visible colour) takes corners where a full or ticket frame was asked for, never a second outline beside its own. The report lists the frame as reverted with "the part has its own border; drew corners instead".
- **A container that clips.** The nameplate shows whole or is taken back ("its container would clip the nameplate"). The checks look up the part's own overflow and every ancestor's. An accent strip, icon or divider that would be clipped moves just inside the edge (`data-inset`), and is taken back if even that is clipped.
- **A drawing behind the words.** A page can have a drawing under its parts that no skin piece made: a WebGL scene or a video, in a `canvas` or `video` element. A surface or panel that carries text, has a see-through background and sits over such an element gets a scrim: a frosted layer (`data-ark-skin-scrim`, a `::before` in `--surface` at 82%, blurred 8px) behind its text. A fixed drawing counts as under every part that scrolls over it. The report lists `backdrop: scrim` in the part's applied rules. A part that uses its own `::before` should keep its text opaque.

### Cost: one layout per phase, and slices

A batch of parts is dressed in phases, so the browser lays the page out a handful of times and never once per rule: every part's geometry and style is read first, then every rule's first attempt is written, then every deferred check (cover, clip, room) is read against that one layout, then each failed check gets its next attempt (a frame falls back to corners, a strip moves inside the edge) or is taken back, and the checks are read again. Only density, layout and a marker's items are measured on the spot, since they are the rules that can move content. The checks themselves are cheap first: the text and control boxes around a part are read once per layout, a decoration whose box touches none is passed without sampling, and a frame is tested against the ring it draws in before any point is sampled. Sanitised pieces and their sampled shapes are cached per piece. A key's theme rules go into the stylesheet when the first element of that key is stamped, so a page with a dozen keys restyles against a short sheet.

A browser dresses a page of more than 16 parts in slices of about 8 ms. Parts in view come first, then the rest, and a part that scrolls near moves to the front. The call returns after the first slice. The report from `getArkSkinReport(root)` and `result.report` has a `pending` count of the parts still waiting, and drops the key when none are left. `ark:skin-report` is sent once, when the queue is empty and every contrast check has run. `removeArkSkin` cancels what is waiting, and `slice: false` dresses everything before the call returns. A re-check after a resize is rate-limited and runs only for a part whose box changed size.

`tests/browser-skin-bench.mjs` measures a page of 120 parts with a full rule set (best of three fresh pages, since the machine is shared): the apply call, the longest task, and that the final DOM and report equal the recorded ones.

### Nothing goes inside a void element

An `input`, `img`, `hr`, `br`, `textarea`, `select`, `video`, `canvas`, `iframe` or similar element has no inside. A frame, nameplate or strip for such a part goes on its wrapper when the wrapper holds that element alone and is its size. Otherwise the rule is taken back, and the report says "its element has no inside to hold a decoration ... and no wrapper of its size does". Attribute rules (an edge) still reach the element itself.

### Fit check

After each rule is applied to a measured part, the skin compares the part before and after. A rule is taken back, with a `console.info` line naming the rule, the part and the reason, when it makes the part's content overflow its box (a child extends more than 1px past the part's right or bottom edge) or grows the part's box by more than 4px. `density` may grow the box, since that is its job, and so may a section layout (below), since a section may get taller; neither may widen it. Rules are checked one at a time, so only the rule that broke the part is reverted. Layout rules that set `display` skip `[hidden]` parts, so a closed panel stays closed. A part with no measured size (a headless DOM, or `display: none`) skips the check.

## Block parts

Pages built from Ark blocks (`@deadark/ark-ui/blocks`) mark their parts with `data-ark-part` (`hero-meta`, `fact`, `tabs-list`). Most have no schema key, so a rule may name a block part by its part name, in any case and with or without hyphens (`hero-meta` and `HEROMETA` are the same key). The names come from one table, `ARK_SKIN_BLOCK_PARTS`, which also gives each part its kind. I chose the table over mapping each block part to a schema key, because the schema keys describe runtime parts with other shapes (`TABSLIST` in the schema is a runtime tab strip, not the block's `tabs-list`). A block part is read as a block part only when it sits inside a `[data-ark-block]` and the runtime did not style it, so a rule keyed `CARD` or `TABSLIST` reaches both, each with the kind it has. `tests/test-skin.mjs` checks every part of every registered block is in the table, and checks each kind against `ark-ui.blocks.css`: a `surface` has a border and a background, a `rule` has its border on the edge the table names, a `panel` has no surface.

| Kind | Block parts (use these as rule keys) | Where each element goes |
| --- | --- | --- |
| `surface` | `card` `stat` `alert` `figure-frame` `list-empty` `term-tip` `popover-panel` | frame around the part, nameplate on its top edge, accent strip centred on its bottom edge, iconm on its top edge, edge on the box |
| `panel` | `disclosure-panel` `accordion-content` `tabs-content` | frame, accent strip, edge; no nameplate |
| `heading` | `hero` `section-header` | the accent strip, as a decoration after the title, hung from the title's last line and starting at its left edge with CSS anchor positioning, taking no room and following the title when it reflows. If it would cover the text under the title it moves to the bottom edge, then is taken back. Where anchor positioning is missing it sits on the bottom edge, left-aligned |
| `rule` | `hero-meta` (top) `pager` (top) `list-row` (top) `tabs-list` (bottom) `fact` (top) | the divider piece, centred on the part's own rule line. A row of a `dl` (`fact`) takes no node: the divider is a `::after` drawn with the divider piece as a mask in `--w-rule`, so it is one colour and scaled whole |
| `list` | `list-rows` | markers on its items, frame, edge, density |
| `control` | `button` `tabs-trigger` `accordion-trigger` `disclosure-trigger` `popover-trigger` `field-control` `choice-input` | frame and edge |
| `wrapper` | `popover` | nothing; its `popover-panel` takes the `POPOVER` rules |
| `text` | titles, ledes, labels, values, captions, icons, badges, links | nothing |
| `other` | roots and grids (`facts` `figure` `tabs` `card-grid` `stats` `form` `list`...) | frame, edge, density, layout |

Markers go on the items of a `list` or `surface` part only, never on facts rows. A `section-header` takes the strip after its title, not a divider on its underline, because one `ornament` value cannot say both. Every placement sits out of flow and is inert. Removing the skin undoes each one exactly, and the report lists each part with its kind.

## Section layouts

A worn card can give each section of a page its own arrangement. Name the block part as the rule key and give it a `layout` value from this table. The first value of most parts is the block's own arrangement, so naming it changes nothing. A value the part does not offer is refused, and the error names the values it offers.

| Part | Values | What each does |
| --- | --- | --- |
| `hero` | `stacked` | As the block draws it: eyebrow, title, lede, actions, details, one under the other. |
| | `centered` | The same stack, centred. |
| | `split` | The words on the left, the details in a column on the right. With no details it stays one column. |
| | `banner` | A wider and larger title, the actions at the right end of the title's rows, the details across the foot. |
| | `offset` | Everything moves in by one indent. A rule line runs from the left edge to the title's first line. |
| `section-header` | `stacked` | The note and actions go under the heading, not beside it. |
| | `inline` | The title and the lede share one row. The note and actions stay at the right. |
| | `centered` | One centred column. |
| | `ruled` | The line under the header moves to the right of the title. |
| `card-grid` | `grid` | As the block draws it. |
| | `list` | One card per row. |
| | `feature` | The first card spans two columns and two rows, with a larger title. The grid has two columns, three from 900px. |
| | `compact` | Smaller gaps and padding, narrower columns. |
| `stats` | `row` | All tiles in one row. |
| | `grid` | Two columns (2 by 2 for four tiles). |
| | `ticker` | One line between two rules: each tile's words in a row, a line between tiles, no tile box. |
| | `stacked` | One tile per row: the label on the left, the value on the right. |
| `facts` | `table` | As the block draws it. |
| | `columns` | Two columns. |
| | `inline` | One run of text: `term: value · term: value`. |
| `list-rows` | `rows` | As the block draws it. |
| | `cards` | Each row is a small card in a grid. |
| | `compact` | Less padding in each row, smaller titles. |
| `stepper` | `line` | As the block draws it: numbered circles joined by a line. |
| | `cards` | Each step is a card, side by side. |
| | `numbered` | Large numbers, no circles and no line. |
| `alert` | `bar` | As the block draws it: a box with a thick left edge. |
| | `boxed` | An even edge all round, the icon above the words. |
| | `banner` | A strip with lines on its top and bottom edges only, the words on one line where they fit. |

The rules:

- Every layout is CSS. No node moves, so reading order, focus order and names stay the block's.
- Every layout applies from 640px wide. A narrower screen gets the block's own stack.
- A layout is taken back when the part's content overflows its box or the part gets wider (the fit check). A section may get taller. `row` and `ticker` keep each tile at its least width, so a row with too little room overflows and is taken back.
- A layout that removes a line also removes the drawing on it. A `facts` row in `inline` and a `list-rows` row in `cards` drop their divider and their worn line.
- A framed hero keeps its frame room (2rem inside each side and at the foot) in every layout. The frame and the dividers inside a section are drawn again at the size the layout gives them.
- `alert` `banner` spans the width of its container. It does not break out of the column it sits in.

## Chrome data format

`chrome` holds up to six pieces: `frame`, `corner`, `nameplate`, `accent-strip`, `divider`, `icon`. A piece is plain data:

```js
{ name?: string, svg: "<svg ...>...</svg>", viewBox: [x, y, width, height],
  keep?: { x?: number[], y?: number[],      // frame, divider: nine-slice cut lines
           tile?: { x?: number[][], y?: number[][] } }, // stretch bands that repeat instead of stretching
  mirror?: boolean,                         // corner
  fields?: unknown[] }                      // nameplate: descriptors for the product, ignored by Ark UI
```

Typical viewBoxes: frame `[0,0,1000,700]`, corner `[0,0,120,120]`, nameplate `[0,0,360,50]`, accent-strip `[0,0,360,80]`, divider `[0,0,360,24]`, icon `[0,0,30,34]`. A piece the skin does not carry falls back to `DEFAULT_ARK_CHROME`. Ark UI depends on no 3D library and no NFT file.

The SVG is checked against an allow-list and re-serialised, so the markup that reaches the DOM is Ark UI's own. Allowed elements: `svg g path rect circle ellipse line polyline polygon defs use linearGradient radialGradient stop clipPath mask pattern symbol text tspan`. Allowed attributes are the drawing and text attributes (`d`, `x`, `y`, `fill`, `stroke`, `transform`, `font-family`, `data-field` and similar). `text` and `tspan` may hold plain text. Anything else refuses the whole piece with a `console.error`: scripts, event attributes, `style`, `class`, comments, entities, `href` other than `#id`, `url()` other than `url(#id)`. Ids inside a piece are renamed per instance so two skins never collide.

### Band stretching

`layoutArkChrome(piece, width, height)` is the one implementation of the multi-band nine-slice. `keep.x` and `keep.y` are cut lines from one viewBox edge to the other, such as `[0,120,380,620,880,1000]`. Bands alternate keep, stretch, keep, stretch, keep. Keep bands keep their size and shape. Stretch bands share the difference in proportion to their source size. A box smaller than the keep bands scales the keep bands down together. A piece with no `keep` scales whole.

Words are never stretched. A piece that contains `<text>` scales whole and uniformly (`preserveAspectRatio` meet), whatever its `keep` bands say. The nameplate is anchored to the part's left edge; other pieces are centred. `layoutArkChrome(piece, width, height, idPrefix?, align?)` takes `align` of `xMidYMid` (default) or `xMinYMid`.

`keep.tile` names stretch bands that repeat instead of stretching, for rows of dots or ticks that must keep their own size. Each entry is a `[from, to]` pair equal to one stretch band of the same axis (the 2nd, 4th, ... band between the cut lines), such as `keep: { x: [0, 40, 60, 300, 320, 360], tile: { x: [[40, 60], [300, 320]] } }`. A tile band draws as many whole copies of its source slice as fit, at the source size, centred: the leftover is split between both ends. A band narrower than one copy draws one copy clipped to the band. A pair that is not a stretch band is refused.

Frames are drawn at the part's measured size and redrawn on resize where `ResizeObserver` exists. Where the size is unknown (a headless DOM) the frame scales whole.

## Invariants

Each has a test in `tests/test-skin.mjs`.
1. **No reorder.** DOM order, roles, accessible names and focus order never change. Layouts are CSS only and move no nodes.
2. **Decoration stays decoration.** Every added node is `aria-hidden="true"`, `inert`, `pointer-events: none`, and has no inline style.
3. **Exact undo.** `outerHTML` of the root before apply and after remove is identical, character for character.
4. **No inline styles** on `root`. Tokens live in the stylesheet.
5. **Hit areas stay.** Decoration takes no pointer events, and no rule clips a part's descendants.
6. **Fit.** A rule that overflows or grows its part is taken back and named on the console (see Fit check). The check needs a measured size, so it does not run in a headless DOM.

`layout: "sheet"` on `MODAL` uses `!important`, because the runtime positions overlays with inline styles.

## Report

`getArkSkinReport(root)` returns plain data (no DOM nodes), or `undefined` when no skin is applied. It is refreshed after the contrast and fit checks and after late-mounted parts.

```js
{ name,
  parts: [{ key, family, selector, count,
            rules: { applied: { frame: "full", ... },
                     skipped:  [{ rule, why }],
                     reverted: [{ rule, why, contrast? }] },   // rule is a rule name, or "colours"
            themed }],
  tokens: { applied: ["--canvas", ...],
            skipped: [{ token, why }],
            adjusted: [{ token, from, to, why }] } }
```

- `key` is the schema key the runtime styled the part with, or the `data-ark-part` of a hand-built part. Every part present under the root is listed, with or without rules.
- `family` is the part kind from the table above.
- `selector` is a short CSS path to one example element (at most three levels, ending at the first id), for a tool to highlight.
- `count` is the number of connected elements of that part.
- `rules.applied` holds the rules that stayed on. `skipped` holds rules a part kind does not take, locked parts and the covenant mark. `reverted` holds rules the fit check took back, and the contrast check's `colours`, with the measured `contrast`.
- `themed` is true while the skin's theme colours still reach at least one element of the part.

The report fires `ark:skin-report` on `root` (bubbling) with the report as `detail`, whenever it differs from the last one sent. It is sent after a settle, never on a timer, so a page that changes nothing does no report work.

## Events

`ark:skin` is dispatched on `root`, bubbling, on apply and on remove: `detail = { on, name, tokens }`. On remove, `tokens` is empty. Products re-dispatch their own event; the DEFXN NFT engine fires `defxn:skin`. Pass `options.event` to dispatch under another name.

## Late content and portals

One `MutationObserver` watches `root` for added nodes (`childList`, `subtree`). Any added element with a matching key gets its rules, so a panel mounted on open is skinned when it appears. The runtime replaces an element when it updates it; the replacement is skinned the same way.

A popover, dialog or menu that the runtime moves into `[data-ark-portal]` leaves `root`. The observer also watches `document.body` (children only) for new portal roots, and each portal root for new children. A portal child belongs to the skin when its `id` is named by an `aria-controls` or `aria-owns` on an element inside `root`, which is how the trigger points at it. That child gets `data-ark-skin-for="<id>"`. The stylesheet applies the tokens and rules to `[data-ark-skin-for]` as well as to `[data-ark-skin]`, so the portal child looks the same as one inside the root. `removeArkSkin` removes the attribute and the decoration there too. Portals inside a different shadow root are not followed.

## Coverage

`tests/test-skin.mjs` and `tests/browser-skin.mjs` check the skin layer. `tests/test-skin.mjs` reads the helper list from the "Included Helpers" bullets of [PRIMITIVES.md](PRIMITIVES.md). For each helper it mounts the helper in jsdom through `tests/skin-mount-specs.mjs`, applies a sample skin, checks the root sits inside the skin's scope, and checks exact undo. A helper with no mount spec fails the test. Badge, Kbd, Switch and Skeleton are mounted through the pattern alone. The test prints, as a report, the helpers whose root carries no `data-ark-part`; a rule still reaches them through their `data-ark-foundation`. The test also applies three snapshot recipes captured from the NFT engine (`tests/fixtures/nft-skin-recipes.mjs`).

## Nameplate words

A nameplate is not a label of the skin. It carries the words of the part it sits on (owner, 2026-10-27).

- A nameplate drawing marks its text slots with `data-field`. The slot `title` takes the part's title, and the slot `index` takes the part's index. Any other field keeps the drawing's own text.
- The part's title is the first of these that belongs to the part, and not to a descendant part this skin also dresses: an element marked `data-ark-skin-title`, a block part named `*-title`, or a heading `h1` to `h6`. The index is an element marked `data-ark-skin-index`, or a block part named `*-index`.
- A word is fitted to its slot. A slot ends where the next field on its line starts, or at the drawing's edge. A word too long for it ends in an ellipsis. Words are never squeezed.
- The header the plate took is absorbed with `data-ark-skin-absorbed`: its ink goes (opacity 0) but it keeps its place, so nothing on the page moves, and assistive technology still reads it. The plate itself is `aria-hidden`, so the words are read once. A title that is, or holds, a link or another control is not absorbed. Hiding it would leave focus on something nobody sees.
- The title comes first. When the title is cut short by the index's slot, the plate drops the index and gives the title that room; the index then stays where it was on the part.
- A part with no title gets no nameplate when the drawing has a title slot: a nameplate carries a header, and the report says "the part has no title for its nameplate to carry". A plate never shows a word that is not the part's.
- Removing the skin brings every absorbed header back exactly.

## Worn pieces

A product's wear-only pieces are drawn by the rule of the same name. An outline is the part's edge, under its content, in place of its border. A line runs along the part's bottom edge, a link's underline sits just below it, and a grid tile repeats behind the content.

A panel that opens wears exactly one of the three panel outlines. Names decide first (`ARK_SKIN_PART_EXTRA_RULES`). A runtime panel with no part name is read by its role and the trigger whose `aria-controls` names it (`arkSkinWornByRole`).

| Outline | Parts |
| --- | --- |
| `menu` | `MEGAMENUPANEL`, `command-surface`; a `role="menu"` panel opened from a menu bar's item, or with no trigger (a context menu) |
| `popover` | `popover-panel`, `POPOVER`, `popover` (the runtime popover), `tooltip`, `term-tip`, `chart-tooltip`; any `role="tooltip"` |
| `dropdown` | `combobox-popup`; a `role="listbox"` a trigger opens (a select); a `role="menu"` a button opens (a dropdown menu) |

A submenu wears what its menu wears. A listbox on the page itself takes none. A wrapper (`popover`, around its `popover-panel`) takes none of them, so an outline never wraps the trigger.

## One drawing per edge

A part's edge carries one drawing (owner, 2026-10-27, from the DEFXN category audit):

- A part that wears a drawn outline (`button`, `badge`, `menu`, `popover` or `dropdown` set to `drawn`) takes no frame and no corners. The outline is its edge. The report says "the part wears a drawn outline: one drawing per edge".
- A row that wears a drawn `line` takes no divider (`ornament` on a rule or divider part). The line is the row's line.
- A part that wears a nameplate has no top-left corner. That corner is where the plate sits.

## Meaning distance

A skin's role colours keep their distance from the site's meaning colours (owner, 2026-10-27).

- The role colours are `--primary`, `--secondary`, `--accent` and `--complement`, with their ladders. Each keeps at least `MEANING_DISTANCE` degrees of hue (12) from every meaning colour the site sets: `--danger`, `--warning`, `--live`, `--trust`, `--success`, `--drift` and `--hidden`.
- A role colour closer than that turns away by the smallest angle that clears them all. Its whole ladder turns by the same angle, so its shades stay one family. Lightness and saturation do not change. The contrast gate runs after it.
- A grey (saturation under 30 %) is not turned, and neither is a meaning colour.
- The report lists each turned token under `adjusted`, with the angle.

