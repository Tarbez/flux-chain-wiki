export interface ArkFocusScopeConfig {
  containerRef: string;
  /** `false` means base-ui's `initialFocus={false}` — don't move focus at all on activation. */
  initialFocusRef?: string | false;
  trap?: boolean;
  restore?: boolean;
}

export interface ArkDismissableLayerConfig {
  containerRef: string;
  branchRefs?: string[];
  dismissAction?: string;
  dismissRef?: string;
  restoreFocusRef?: string;
  outsidePointer?: boolean;
  outsideFocus?: boolean;
  escapeKey?: boolean;
}

export interface ArkPresenceConfig {
  unmountOnExit?: boolean;
  ariaHidden?: boolean;
  animateOut?: boolean;
}

export interface ArkA11yOverlayHost {
  createFocusScope(id: string, config: ArkFocusScopeConfig): void;
  createDismissableLayer(id: string, config: ArkDismissableLayerConfig): void;
  createPresence(ref: string, config?: ArkPresenceConfig): void;
  activateFocusScope(scopeId: string): void;
  openOverlay(ref: string): void;
  closeOverlay(ref: string): void;
}

/** Composes a focus scope for an overlay's content container. */
export declare function configureFocusScope(ui: ArkA11yOverlayHost, id: string, config: ArkFocusScopeConfig): void;

/** Composes a dismissable layer (outside-pointer / outside-focus / escape) for an overlay. */
export declare function configureDismissableLayer(ui: ArkA11yOverlayHost, id: string, config: ArkDismissableLayerConfig): void;

/** Composes presence (mount/unmount + aria-hidden) tracking for an overlay's content. */
export declare function configurePresence(ui: ArkA11yOverlayHost, id: string, config?: ArkPresenceConfig): void;

/** Opens (portals, positions, activates focus scope + dismissable layer for) an overlay ref. */
export declare function openOverlay(ui: ArkA11yOverlayHost, ref: string): void;

/** Closes an overlay ref, deactivating its focus scope and dismissable layer. */
export declare function closeOverlay(ui: ArkA11yOverlayHost, ref: string): void;

/**
 * Activates an already-configured focus scope without opening an overlay —
 * for a popup that is already mounted and only needs focus moved into it.
 */
export declare function activateFocusScope(ui: ArkA11yOverlayHost, scopeId: string): void;

/**
 * Updates a trigger/content pair's open state together and opens or closes the
 * overlay, so a trigger's `aria-expanded` can never drift out of sync with
 * what is actually on screen. Shared by every disclosure-shaped primitive that
 * is not a full dialog (menu, submenu, sheet, sidebar, navigation menu).
 */
export declare function setOverlayOpen(
  ui: ArkA11yOverlayHost & { get(ref: string): unknown; update(ref: string, value: unknown): void },
  triggerRef: string,
  contentRef: string,
  open: boolean,
): void;
