/**
 * Markup-structure inference over ARK's rendered `data-flx` (ref name) and
 * `data-ark-foundation` (foundation symbol) attributes — how a factory given
 * only a `rootRef` recovers which ref plays which part. Shared by the
 * accordion's and the tab list's structure inference.
 */

/** The ref name a rendered element was bound to — `undefined` if it isn't ARK-rendered. */
export declare function readElementRef(el: HTMLElement | undefined): string | undefined;

/** The foundation symbol an element was rendered from (`ACCORDIONTRIGGER`, ...). */
export declare function readFoundation(el: HTMLElement | undefined): string | undefined;

/** Depth-first list of `root` and every element descendant, in document order. */
export declare function walkElementTree(root: HTMLElement): HTMLElement[];

/** The first element in `root`'s subtree rendered from `foundation`. */
export declare function findFirstFoundation(root: HTMLElement, foundation: string): HTMLElement | undefined;
