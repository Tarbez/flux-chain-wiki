/**
 * CSP-safe imperative style writing. Single owner of the
 * `data-ark-dynamic-style` rule registry — `ark-ui.csp.ts` re-exports these
 * rather than keeping a second copy, so the per-element rule ids can never
 * collide between packages.
 */

/** Writes one CSP-safe property (custom properties included) onto an element. */
export declare function setArkElementStyle(el: HTMLElement, property: string, value: string | number | null | undefined): void;

/** Reads a property back, preferring this module's dynamic rule over `el.style`. */
export declare function getArkElementStyle(el: HTMLElement, property: string): string;

/** `setArkElementStyle()` for a whole bag of properties. */
export declare function setArkElementStyles(el: HTMLElement, styles: Readonly<Record<string, string | number | null | undefined>>): void;

/**
 * Hides/shows an element through the CSP-safe dynamic-rule mechanism as well
 * as the `hidden`/`aria-hidden` attributes, so an author `display` rule can't
 * out-cascade `[hidden]` and leave a hidden element on screen.
 */
export declare function setArkElementHidden(el: HTMLElement, hidden: boolean): void;
