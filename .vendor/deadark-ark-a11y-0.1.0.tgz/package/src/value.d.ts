/** Clamps `value` into the inclusive `[min, max]` range. */
export declare function clampNumber(value: number, min: number, max: number): number;

/** Stable `YYYY-M-D` identity for a date, ignoring the time component. */
export declare function dateKey(value: Date): string;

/** True when both dates are present and fall on the same calendar day. */
export declare function sameDay(left: Date | undefined, right: Date | undefined): boolean;

/** Midnight-normalized copy of a date, so day comparisons ignore the clock. */
export declare function dayOnly(value: Date): Date;

/** Localized "March 2026"-style label for a calendar month header. */
export declare function formatCalendarLabel(month: number, year: number, locale?: string): string;
