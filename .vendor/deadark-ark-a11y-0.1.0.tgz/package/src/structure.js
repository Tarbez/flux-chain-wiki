/**
 * Markup-structure inference: reading a rendered subtree back to find which
 * ref plays which part, so a factory can be handed a single root ref instead
 * of a hand-maintained parallel array of trigger/panel/header refs.
 *
 * ARK's renderer stamps two attributes on every element it writes: `data-flx`
 * carries the ref name, `data-ark-foundation` carries the foundation symbol
 * (`ACCORDIONTRIGGER`, `TABSCONTENT`, ...) the element was rendered from.
 * Together they are enough to recover the whole widget shape from the DOM,
 * which is exactly what `createArkAccordion({ rootRef })` and
 * `createArkTabs({ rootRef })` both do — they were each carrying their own
 * copy of these four helpers in `ark-ui.components.ts`, so this module is the
 * single home for them, moved verbatim.
 *
 * Every read is defensive (`?.`, `|| []`): inference runs against whatever is
 * mounted at call time, which in a headless render or a test harness may be a
 * partial element with no `children` and no `getAttribute` at all.
 */

/** The ref name a rendered element was bound to — `undefined` if it isn't ARK-rendered. */
export function readElementRef(el) {
  const next = el?.getAttribute?.("data-flx");
  return typeof next === "string" && next ? next : undefined;
}

/** The foundation symbol an element was rendered from (`ACCORDIONTRIGGER`, ...). */
export function readFoundation(el) {
  const next = el?.getAttribute?.("data-ark-foundation");
  return typeof next === "string" && next ? next : undefined;
}

/** Depth-first list of `root` and every element descendant, in document order. */
export function walkElementTree(root) {
  const out = [];
  const visit = (node) => {
    out.push(node);
    Array.from(node.children || []).forEach((child) => visit(child));
  };
  visit(root);
  return out;
}

/** The first element in `root`'s subtree rendered from `foundation`. */
export function findFirstFoundation(root, foundation) {
  return walkElementTree(root).find((node) => readFoundation(node) === foundation);
}
