export interface ArkCollectionConfig {
  refs: string[];
  orientation?: "horizontal" | "vertical" | "both";
  loop?: boolean;
  typeahead?: boolean;
}

/**
 * Structural surface needed for roving-tabindex composition. Declared, not
 * imported from `@deadark/ark-ui` — the object `createArkUI()` returns already
 * satisfies it.
 */
export interface ArkA11yCollectionHost {
  createRovingFocusGroup(id: string, config: ArkCollectionConfig): void;
}

/** The collection id a container ref's roving group is registered under. */
export declare function collectionIdFor(containerRef: string): string;

/** Registers a roving focus group with an explicit orientation/loop/typeahead recipe. */
export declare function configureRovingFocusGroup(ui: ArkA11yCollectionHost, collectionId: string, config: ArkCollectionConfig): void;

/** The vertical/looping/typeahead recipe shared by menu-like popups. */
export declare function configureMenuFocusGroup(
  ui: ArkA11yCollectionHost,
  collectionId: string,
  refs: string[],
  config?: { loop?: boolean; typeahead?: boolean },
): void;

/** The single-axis, no-typeahead recipe shared by tab lists, toggle groups, and pagination. */
export declare function configureStripFocusGroup(
  ui: ArkA11yCollectionHost,
  collectionId: string,
  refs: string[],
  config?: { orientation?: "horizontal" | "vertical" | "both"; loop?: boolean; typeahead?: boolean },
): void;
