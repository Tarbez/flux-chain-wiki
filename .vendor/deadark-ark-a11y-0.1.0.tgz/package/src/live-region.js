/**
 * Live-region composition — the ARIA announcement channel that every
 * status-shaped ARK primitive (spinner, loading mark, toast region, alert,
 * combobox result counts, form validation summaries) wires the same way.
 *
 * As with `overlay.js`, the *mechanism* (the polite/assertive region element,
 * the announcement queue, the `aria-live` bookkeeping) is implemented once in
 * `@deadark/ark-ui`'s runtime — `createLiveRegion()`/`announce()` in
 * ark-ui.runtime.ts. What lives here is the composition call site, lifted
 * unchanged out of `ark-ui.components.ts`, so the primitives share one
 * spelling of "this ref is a status region" instead of each re-deriving the
 * politeness/role pairing.
 */

/** Declares `ref` as an ARIA live region with the given politeness/role. */
export function configureLiveRegion(ui, targetRef, config) {
  ui.createLiveRegion(targetRef, config);
}

/** Declares a polite `role="status"` region — the default for loading/progress copy. */
export function configureStatusRegion(ui, targetRef) {
  ui.createLiveRegion(targetRef, { politeness: "polite", role: "status" });
}

/** Declares an assertive `role="alert"` region — for errors that interrupt. */
export function configureAlertRegion(ui, targetRef) {
  ui.createLiveRegion(targetRef, { politeness: "assertive", role: "alert" });
}

/** Pushes `text` into an already-configured live region. */
export function announce(ui, targetRef, text) {
  ui.announce(targetRef, text);
}
