# @deadark/ark-a11y

Reusable, framework-neutral accessibility wiring shared across `@deadark/ark-primitives`
factories: ref normalization, ARIA/attribute sync helpers (`./dom`), and the
focus-scope/dismissable-layer/presence *composition* recipes overlay
primitives (dialog, popover, ...) build on (`./overlay`).

## Scope note

The low-level focus-trap, outside-click/escape dismissal, and mount/unmount
presence *mechanics* remain implemented once, in `@deadark/ark-ui`'s runtime
(`createFocusScope`/`activateFocusScope`, `createDismissableLayer`/
`handleOutsidePointer`/`handleOutsideFocus`, `createPresence`) — that engine
is tightly coupled to the runtime's ref table, portal stack, and DOM writer,
and extracting it is a larger, separate piece of work than this package
takes on. What this package owns is the smaller, genuinely reusable layer
above that: normalizing ref names, syncing ARIA/data attributes onto a ref
consistently, and the *configuration recipe* (what a modal dialog's focus
scope should look like vs. a non-modal popover's) that primitive factories
were previously duplicating inline.

## Usage

```js
import { normalizeRef, setAttrs, syncModelRef } from "@deadark/ark-a11y/dom";
import { configureFocusScope, configureDismissableLayer, configurePresence } from "@deadark/ark-a11y/overlay";
```

Both modules are structurally typed against a minimal host interface
(`ArkA11yHost` / `ArkA11yOverlayHost`) rather than importing `@deadark/ark-ui`
directly — any object exposing the small subset of methods used (as ARK UI's
`createArkUI()` instance already does) satisfies them.
