# ARK UI Primitive Contract

## Purpose

This document closes Batch 0 by defining the contract every future ARK UI primitive must follow.

## Primitive Shape

Every primitive should be described in terms of parts, refs, and shared infra.

- `trigger`: the element that opens, toggles, or invokes the primitive
- `content`: the primary surface or body
- `item`: repeated interactive child inside a collection
- `label`: naming element for `aria-labelledby`
- `description`: helper copy for `aria-describedby`
- `value`: display node for selected or current value
- `viewport`: scrollable or clipped content region when relevant

## Ref Model

- Refs remain the stable identity boundary.
- Primitive-local behavior should still resolve through `R-*` refs so `update()` remains the single control path.
- Generated ids for ARIA relationships come from refs, not ad hoc DOM ids.

## State Model

- String values are still shorthand for simple state flags.
- Object state is the preferred model for composites and may include:
  - `state`
  - `text`
  - `items`
  - `open`
  - `selected`
  - `checked`
  - `expanded`
  - `activeDescendant`
  - `hidden`
  - `disabled`

## Accessibility Rules

- Primitive semantics must be expressed through shared helpers, not handwritten one-offs.
- `configureRef()` owns ARIA role and relationship wiring.
- `createRovingFocusGroup()` owns grouped keyboard navigation.
- `createFocusScope()` owns trap and restore behavior.
- `createDismissableLayer()` owns outside-dismiss and Escape rules.
- `createPresence()` owns mount and hidden lifecycle.
- `createLiveRegion()` owns status and alert semantics.

## Controlled vs Uncontrolled

- Controlled usage means external code drives `update(ref, value)`.
- Uncontrolled behavior may exist inside helpers, but must still synchronize back to ref state.
- New primitives should not invent side stores that bypass the ref/state system.

## Keyboard Rules

- Native elements keep native keyboard behavior whenever possible.
- Non-native interactive parts must support Enter and Space activation where appropriate.
- Collections must use roving tabindex or active-descendant patterns, not random tab order.
- Escape belongs to dismissable surfaces and temporary UI.

## Dismiss Rules

- Temporary surfaces should dismiss through shared dismissable-layer APIs.
- Outside interaction must respect nested branches and trigger exceptions.
- Focus restoration must be explicit.

## Styling Rules

- Overlay backdrops (`[data-ark-backdrop]`) ship with position/inset/pointer-events only — never a forced `background`. A visible scrim is an application choice, applied by the consumer via `[data-ark-backdrop]`, not a default the primitive imposes.
- This applies to every overlay-backed primitive (dialog, alert dialog, sheet, drawer, popover, menu, …) since they all share the same `openOverlay()` backdrop path in `ark-ui.runtime.ts` — fix it once there, not per component.

## Testing Minimum

Every primitive must ship with:

- ARIA assertions
- Keyboard behavior assertions
- Focus behavior assertions
- Dismiss behavior assertions if temporary
- State attribute assertions for selected, checked, open, or disabled behavior

## Non-Negotiables

- No primitive ships with styling only if its behavior is composite.
- No primitive hand-rolls focus or dismiss logic without a written exception.
- No primitive skips accessibility tests because it “looks right.”
