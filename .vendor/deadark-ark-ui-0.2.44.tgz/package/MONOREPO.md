# ARK UI In Monorepos

## Recommended Layout

- Keep `@deadark/ark-ui` as a workspace dependency, not copied source.
- Place `ark-ui.components.json` in each app that consumes ARK.
- Centralize visual foundation through the Dead Ark SDK theme layer, then use ARK config as a consumer shim where needed.

## Workspace Rules

1. Import runtime, components, adapters, and utilities from package entry points only.
2. Do not deep-import `dist/` from apps.
3. Treat `ark-ui.components.json` as the app-local contract for imports and starter collections.
4. If multiple apps need shared wrappers, publish them from a workspace package instead of duplicating snippets.

## Consumer Refresh

Before a production build, refresh Dead Ark SDK surfaces so theme drift does not accumulate silently:

```bash
deadark-theme sync-consumer .
```

## Example

```json
{
  "dependencies": {
    "@deadark/ark-ui": "workspace:*",
    "@deadark/sdk": "workspace:*"
  }
}
```
