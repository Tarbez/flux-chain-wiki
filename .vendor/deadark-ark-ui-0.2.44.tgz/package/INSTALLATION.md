# ARK UI Installation

Install `ark-ui` according to the way you want to adopt it.

For most teams evaluating the system today, the right first move is not “install a package and start coding.” It is “run the browser-native flow and see the architecture working end to end.”

## Option 1: Evaluate The System From This Repo

```bash
cd /path/to/ark-ui
npm install
npm run build
ark dev examples/todo --port 4173
ark build examples/todo --out-dir dist/todo
ark verify dist/todo/app.flx --pretty
```

Then open `http://127.0.0.1:4173/`.

This is the recommended install path if you want to verify:

- native ESM delivery
- `flux-dom` binding
- `flux-router` route swaps
- `flux-*` custom elements
- `.flx` packaging via `ark build`

After that, continue with [docs/GOLDEN_PATH.md](docs/GOLDEN_PATH.md).

## Option 2: Consume The Package In Another Project

```bash
npm install @deadark/ark-ui
```

If you want the project-local registry contract too:

```bash
npx ark-ui init
```

That writes `ark-ui.components.json` into the current project.

## Common Imports

```ts
import { createArkUI } from "@deadark/ark-ui/runtime";
import { FluxDOM } from "@deadark/ark-ui/flux-dom";
import { FluxRouter } from "@deadark/ark-ui/flux-router";
import { defineFluxElements } from "@deadark/ark-ui/elements";
import { createArkDialog, createArkForm } from "@deadark/ark-ui/components";
```

## Browser-Native CLI

The main CLI flow is:

```bash
ark dev examples/todo --port 4173
ark build examples/todo --out-dir dist/todo
ark inspect dist/todo/app.flx
ark verify dist/todo/app.flx
ark serve dist/todo/app.flx --port 4174
ark unpack dist/todo/app.flx dist/todo-unpacked
ark verify dist/todo/app.flx --dir dist/todo-unpacked
```

What each command does:

- `ark dev`: serves HTML and ESM directly without bundling
- `ark build`: compacts assets, vendors required runtime modules, and emits `app.flx`
- `ark inspect`: prints package metadata for verification
- `ark verify`: validates checksum integrity for packaged and unpacked artifacts
- `ark serve`: serves a packaged `.flx` app directly without unpacking
- `ark unpack`: reconstructs a runnable artifact from the `.flx` package

## Build Expectations

- `npm run build` compiles the TypeScript package to `dist/`
- `node tests/run-browser-all.mjs` runs the browser verification sweep
- `npm run test:browser:golden` runs the canonical end-to-end product proof
- `npm test` runs compile plus node and browser suites
- `npm run docs` serves the documentation surface on port `4180`; `npm run studio` remains available as a compatibility alias

## Recommended Next Steps

1. [GETTING_STARTED.md](GETTING_STARTED.md)
2. [docs/GOLDEN_PATH.md](docs/GOLDEN_PATH.md)
3. [docs/MIGRATING_FROM_REACT_NEXT.md](docs/MIGRATING_FROM_REACT_NEXT.md)
4. [examples/react-migration/index.html](examples/react-migration/index.html)
