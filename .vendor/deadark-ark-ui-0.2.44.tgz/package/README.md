# ark-ui + flux-dom

Write HTML. Get reactivity. No build step.

`ark-ui` is the ARK-native interface engine. It resolves semantic UI intent into standard DOM, governed styling, and reusable primitives. `flux-dom` is the reactive binder that connects `.flx` state to the DOM without a virtual DOM, JSX, or a frontend bundler.

For AI-heavy flows, the browser is now treated as a thin client. `ark-ui` ships the UI/runtime side, while a native `flxd` sidecar does the reasoning work over HTTP and can stay alive independently of the tab.

This repository currently contains the `ark-ui` engine and its primitive, styling, config, and tooling layers. The target architecture upgrades that engine into a zero-build frontend system based on native ESM, `data-flx` bindings, and Web Components.

## Ten-Line Start

```html
<!doctype html>
<script type="importmap">
{ "imports": { "flux-dom": "/lib/flux-dom.mjs", "ark-ui": "/lib/ark-ui.mjs" } }
</script>
<body>
  <h1 data-flx="$I.N">Hello</h1>
  <flux-button data-flx="$UI.btn">Click me</flux-button>
  <script type="module">
    import { FluxDOM } from "flux-dom"; window.flux = new FluxDOM();
  </script>
</body>
```

## What ark-ui Is

- A semantic runtime that resolves UI intent into DOM, styles, and behavior.
- A primitive system for dialogs, menus, tabs, select, combobox, tables, navigation, and more.
- A governed design system with tokens, brand templates, recipes, and an auto-styler.
- A headless composition layer for teams that want slot-first control.

## Settings source of truth

Import settings contracts from `@deadark/ark-ui/settings`. `ARK_SETTINGS` owns
global and theme defaults, paths, control types, ranges, and options;
`ARK_DESIGN_SETTINGS` is the Studio-ready subset; and
`ARK_COMPONENT_SETTINGS` owns component parameters, hooks, methods, and parts.
Use `normalizeArkSettings`, `getArkSettingValue`, and `setArkSettingValue` in
runtime or persistence adapters instead of defining local config shapes.

## What ark-ui Is Becoming

- A zero-build frontend system for ARK-native applications.
- A DOM-first runtime that outputs standard HTML plus `data-flx` bindings.
- A Web Component surface (`<flux-dialog>`, `<flux-menu>`, `<flux-tabs>`, etc.) that works in any browser with native ESM.
- A buildless dev and packaging workflow driven by `ark` CLI, import maps, and `.flx` manifests.

## Core Rule Set

- No new language.
- No JSX.
- No custom transpiler.
- No frontend bundler requirement.
- Web Components are the primary component model.
- All state is represented as `.flx` streams and bound through `data-flx`.
- Browser clients should hand AI/agent work to native `flxd`, not run local inference in the render path.

## Native Sidecar Path

The preferred Flux pipeline is now:

1. `flux-dom` captures a UI action and shapes it into a `.flx`-backed request.
2. `@deadark/ark-ui/flux-client` sends that request to a local or nearby `flxd` daemon.
3. `flxd` runs the real reasoning or scheduler work natively and returns JSON or `.flx`-derived state.
4. `flux-dom` applies the result back into the DOM.

The browser stays responsive, while the daemon owns the CPU-heavy work and can keep running background loops even when the tab is gone.

## Repo Map

- [GETTING_STARTED.md](./GETTING_STARTED.md): fastest browser-native path from clone to working app
- [INSTALLATION.md](./INSTALLATION.md): install paths for repo evaluation vs package consumption
- [docs/GOLDEN_PATH.md](./docs/GOLDEN_PATH.md): canonical build -> demo -> package -> serve -> unpack flow
- [docs/compression/README.md](./docs/compression/README.md): standalone Flux compression planning and project boundary
- [docs/compression/FLX_CODEC_SPEC.md](./docs/compression/FLX_CODEC_SPEC.md): Batch 0 spec freeze for the standalone `flx-archive-v2` codec
- [docs/compression/FLX_CODEC_BATCH_3_5_PUNCH_LIST.md](./docs/compression/FLX_CODEC_BATCH_3_5_PUNCH_LIST.md): historical closeout ledger for stable block IDs, binary framing, and delta-by-block-id migration
- [docs/SOLYRUNNERS_ICONS.md](./docs/SOLYRUNNERS_ICONS.md): first 30 pure SVG SolyRunners icons, export flow, and docs gallery
- [PRIMITIVES.md](./PRIMITIVES.md): shipped primitive helpers
- [HEADLESS.md](./HEADLESS.md): slot-first composition layer
- [FLUX_ANIMATE.md](./FLUX_ANIMATE.md): declarative Web Animations API orchestration for Flux state and primitives
- [docs/ROUTING.md](./docs/ROUTING.md): dynamic patterns, route head metadata, caching, progressive streams, and static route generation
- [docs/DENSE_FLUX_PATTERNS.md](./docs/DENSE_FLUX_PATTERNS.md): consume and validate Dense Flux patterns using the current 0.4.1 specification
- `@deadark/ark-ui/server`: optional streamed SSR, authenticated route guards, CSRF enforcement, and parameterized SQL contracts
- `@deadark/ark-ui/primitives`: unstyled, accessible behavior factories (`createArkDialog`, `createArkTabs`, ...) — see [PRIMITIVES.md](./PRIMITIVES.md)
- `@deadark/ark-ui/components`: themed, single-concept components — tokens, recipes, parts, brand templates
- `@deadark/ark-ui/core`: product-grade composites (`DataTable`, `CommandPalette`, `AppNav`, ...) built from Layered Components — see [CORE_COMPONENTS.md](./CORE_COMPONENTS.md)
- `@deadark/ark-ui/page-builders`: schema-driven full-page assemblers (`buildArkDashboardPage`/`buildArkSettingsPage`/`buildArkAdminTablePage`) — see [docs/architecture/PAGE_BUILDER_SCHEMA.md](./docs/architecture/PAGE_BUILDER_SCHEMA.md)
- [examples/admin-console/index.html](./examples/admin-console/index.html): a full admin page assembled entirely from `buildArkAdminTablePage(schema)`
- [docs/MIGRATING_FROM_REACT_NEXT.md](./docs/MIGRATING_FROM_REACT_NEXT.md): concrete React/Next to browser-native migration path
- [examples/react-migration/index.html](./examples/react-migration/index.html): runnable migration workflow example
- [examples/package-inspector/index.html](./examples/package-inspector/index.html): browser-native package and manifest inspector
- [examples/engine-lab/index.html](./examples/engine-lab/index.html): persistent offline queue, conflict resolution, timeline inspection, and virtualized list proof surface
- [examples/generative-components/index.html](./examples/generative-components/index.html): Flux-powered generative canvas components animated by the ark-ui engine
- [examples/background/index.html](./examples/background/index.html): config-driven atmospheric backgrounds built from shared sub, base, and complementary layers
- [examples/background-002/index.html](./examples/background-002/index.html): a procedural contour-field background with twenty-four generated paths and a restrained signal arc
- [examples/background-003/index.html](./examples/background-003/index.html): a deterministic, reduced-resolution Canvas field with FLX-controlled folds, grain, palettes, and motion
- [examples/background-004/index.html](./examples/background-004/index.html): a cyberish cipher lattice with seeded orthogonal routes, active packets, scan motion, and FLX controls
- [examples/background-005/index.html](./examples/background-005/index.html): a diagonal data-rift composition with layered bands, transmission cuts, moving packets, and protected negative space
- [examples/background-006/index.html](./examples/background-006/index.html): a kinetic typefield that turns bounded user text into deterministic lanes, ghost type, signal cuts, and controllable motion
- `@deadark/ark-ui/backgrounds/component`: one theme-aware `<ark-background>` Web Component spanning experiments 001–006, with fixed, live theme-linked, and locked color modes
- [examples/mobile-ui-experiments/index.html](./examples/mobile-ui-experiments/index.html): fifteen mobile-ready FUI splash, authentication, and profile concepts on a strict 8pt grid
- [examples/flux-devtools/index.html](./examples/flux-devtools/index.html): standalone devtools window for live flux snapshots, topology, queue, and timeline state
- [examples/router-state/index.html](./examples/router-state/index.html): focused two-page routing, shared persistence, and per-route snapshot demo
- [ROADMAP.md](./ROADMAP.md): current batch roadmap
- [SHADCN_REPLACEMENT_MATRIX.md](./SHADCN_REPLACEMENT_MATRIX.md): internal parity tracking
- [docs/architecture/ARK_UI_FLUX_FRONTEND_UNIFIED.md](./docs/architecture/ARK_UI_FLUX_FRONTEND_UNIFIED.md): unified architecture and phased upgrade path
- [docs/architecture/DECISION_LOG_2026-08-11.md](./docs/architecture/DECISION_LOG_2026-08-11.md): formal decision record
- [docs/architecture/COMPONENT_LAYER_MODEL.md](./docs/architecture/COMPONENT_LAYER_MODEL.md): primitives -> layered components -> core components -> page builders, and the migration path off the current monolith
- [docs/architecture/COMPONENT_LAYER_BATCH_PLAN.md](./docs/architecture/COMPONENT_LAYER_BATCH_PLAN.md): batch-by-batch shipping plan (deliverables + definition of done) for the layer model above
- [docs/architecture/ARK_UI_EVOLUTION_PLAN.md](./docs/architecture/ARK_UI_EVOLUTION_PLAN.md): parent execution plan for Flux state, DOM binding, ARK layers, adapters, tooling, and cross-repository boundaries

## Demo

The canonical adoption flow is documented in [docs/GOLDEN_PATH.md](./docs/GOLDEN_PATH.md). If someone asks "what is the one path I should run?", this is it:

```bash
cd /path/to/ark-ui
npm install
npm run build
ark dev examples/todo --port 4173
ark build examples/todo --out-dir dist/todo
ark inspect dist/todo/app.flx --pretty
ark verify dist/todo/app.flx --pretty
ark serve dist/todo/app.flx --port 4174
ark build examples/todo --out-dir dist/todo-archive --format archive
ark inspect dist/todo-archive/app.flx --pretty
ark profile dist/todo-archive/app.flx --pretty
ark unpack dist/todo-archive/app.flx dist/todo-archive-unpacked
```

Then visit:

- `http://127.0.0.1:4173/` for the buildless planner demo
- `http://127.0.0.1:4174/` for the served `.flx` package

If you want the single strongest proof in one command, run:

```bash
npm run test:browser:golden
```

The demo shows:

- `flux-router` swapping routes without a framework
- guarded and nested route swaps through manifest metadata
- route-specific state restoration for returning screens
- `flux-dom` binding state into plain DOM
- fine-grained nested field subscriptions and collection rendering
- computed state, optimistic writes, and offline/conflict groundwork in the store layer
- `flux-dialog`, `flux-menu`, `flux-popover`, `flux-drawer`, and `flux-command`
- `flux-select`, `flux-combobox`, `flux-datepicker`, and `flux-calendar`
- a richer planner workflow instead of a primitive-only sandbox

For a focused two-page route/state test, run:

```bash
ark dev . --port 4179
```

Open `http://127.0.0.1:4179/examples/router-state/index.html`, edit both state cards, move between Page one and Page two, and then reload. Shared workspace state follows both pages and survives reloads; `$page.*` state is restored independently per route during the current app session.

There is also a browser-native packaging proof surface:

```bash
ark dev examples/package-inspector --port 4175
```

Then choose `dist/todo/app.flx`, `dist/todo/app.flx.json`, or `dist/todo-archive/app.flx` with the file picker, or copy one into `examples/package-inspector/sample/` and open `http://127.0.0.1:4175/?src=/sample/app.flx`.

There is also a deeper engine-state proof surface:

```bash
ark dev examples/engine-lab --port 4176
```

That lab proves:

- persisted local-first state through `localStorage`
- offline queue replay
- conflict recording plus explicit resolution actions
- richer merge-aware conflict resolution in the runtime
- live timeline / inspector state
- virtualized `data-flx-list` rendering for large collections
- sync-topology metadata for peers, relays, and gateways

There is now also a standalone devtools surface:

```bash
ark dev examples/flux-devtools --port 4178
```

Open that in one tab, then open the engine lab in another tab. The devtools window receives live snapshots over `BroadcastChannel` and shows:

- route and binding metrics
- queued writes and conflicts
- sync topology
- timeline events
- tracked application state

## CLI Flow

The package now exposes both `ark-ui` and `ark` as browser-native tooling entrypoints.

```bash
ark dev examples/todo --port 4173
ark build examples/todo --out-dir dist/todo
ark inspect dist/todo/app.flx
ark profile dist/todo/app.flx --pretty
ark verify dist/todo/app.flx
ark serve dist/todo/app.flx --port 4174
ark unpack dist/todo/app.flx dist/todo-unpacked
ark verify dist/todo/app.flx --dir dist/todo-unpacked
```

`ark dev` serves HTML and ESM directly from a project root without bundling. `ark build` copies browser assets into a deployable output, compacts text assets, writes an `app.flx.json` manifest, and emits a single-file `app.flx` package with embedded assets for Block 13 style delivery. `ark inspect` summarizes either the package or the raw manifest. `ark profile` adds route-density and asset-size reporting for package analysis. `ark verify` validates packaged asset checksums and can also verify an unpacked directory against the manifest. `ark serve` runs the package directly as an app, and `ark unpack` reconstructs the shipped files from the package artifact.

`ark build --format archive` now emits a standalone `flx-archive-v2` artifact through the codec layer while keeping the manifest sidecar for compatibility. `ark inspect`, `ark profile`, `ark verify`, and `ark unpack` all understand that archive mode explicitly, including archive block counts, compression metrics, dictionary stats, and reconstruction back into runnable files.

`ark build --format delta --base <archive.flx>` now emits delta archives, `ark verify --base <archive.flx>` validates archive lineage, `--continuation-chunk-size` writes continuation metadata sidecars, and `ark reconstruct <base> <delta...>` rebuilds a full archive chain.

For the browser-level product proof, use `npm run test:browser:golden`. For the full browser sweep, use `npm run test:browser`.

## Current Status

`ark-ui` ships today as a browser-native system: a semantic runtime, a `flux-dom` reactive binder
with nested-path subscriptions and batched DOM application, a `flux-router` route layer with
guards and route-state restoration, a real `flux-*` Web Component surface, a buildless dev flow,
and a `.flx` package build/inspect/verify/serve/unpack pipeline with a profiling command and a
browser-matrix test runner. In plain terms: you can build an app UI in HTML and JavaScript with no
React, no Next.js, and no bundler, get a reactive DOM layer through `data-flx`, reach for a full
set of browser-native primitives (dialogs, menus, tabs, selects, comboboxes, date pickers, drawers,
command surfaces), route between screens without a framework, and ship the result as a single-file
`.flx` package.

The archive codec (`flx-archive-v2`) is past its wire-format freeze — stable block IDs, binary
framing, and block-addressed deltas are implemented, not planned. For the detailed batch-by-batch
status of the compression subsystem (codec, delta/lineage, recovery, transport wrappers), see
[docs/compression/README.md](./docs/compression/README.md) rather than this file; that folder is
the source of truth and is kept current independently of this README.

The next integration surface is the native sidecar path: `ark-ui` talks to `flxd`; `flxd` owns
reasoning, Stash scheduling, and mesh-adjacent coordination; the browser remains a client and
renderer.

## Direction

Do not market this as "shadcn parity." Market it as a different, better model:

- reactive by default
- semantic by design
- local-first
- zero-build
- brand-governed

## Next Read

Start with [GETTING_STARTED.md](./GETTING_STARTED.md) for the practical path, then [docs/architecture/ARK_UI_FLUX_FRONTEND_UNIFIED.md](./docs/architecture/ARK_UI_FLUX_FRONTEND_UNIFIED.md) for the full system plan.

To reskin parts with a recipe (colour tokens, drawn chrome, per-part rules), read [SKINS.md](./SKINS.md). The module is `@deadark/ark-ui/skin`.
