# React Hook Form Integration

ARK keeps this package dependency-free, so the adapter surface uses structural typing instead of importing React Hook Form directly.

## Adapter

```ts
import { createArkReactHookFormAdapter } from "@deadark/ark-ui/adapters";

const email = createArkReactHookFormAdapter({
  field,
  fieldState,
  helperText: "Used for account notices.",
  descriptionId: "email-help",
  errorId: "email-error",
  required: true,
});
```

Use `email.binding` on the input control and `email.presentation` for helper/error rendering state.

## Why This Exists

- standard `aria-invalid` and `aria-describedby` wiring
- consistent `data-invalid`, `data-touched`, and `data-dirty` attributes
- one adapter shape that can feed ARK field primitives or app wrappers
