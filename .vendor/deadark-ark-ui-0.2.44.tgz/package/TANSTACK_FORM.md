# TanStack Form Integration

ARK ships a thin bridge for TanStack Form field APIs without taking a runtime dependency on TanStack packages.

## Adapter

```ts
import { createArkTanStackFormAdapter } from "@deadark/ark-ui/adapters";

const username = createArkTanStackFormAdapter({
  field,
  helperText: "Public handle",
  descriptionId: "username-help",
  errorId: "username-error",
  required: true,
});
```

Use `username.binding` for control props and `username.presentation` for helper/error state.

## Bridge Utility

For custom form systems or normalized app state:

```ts
import { createArkFormBridge } from "@deadark/ark-ui/adapters";
```

That produces ARK field adapter results from plain `values`, `errors`, `touched`, and `dirty` maps.
