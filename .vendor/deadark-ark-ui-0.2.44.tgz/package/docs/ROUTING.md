# Routing, SEO, Cache, and Streams

`FluxRouter` supports exact routes, named parameters, named splats, managed route metadata, bounded route-data caching, and progressive route payloads.

## Dynamic routes

Manifest paths use `:name` for one segment and `*name` for the remaining path.

```js
import { defineFluxRoute } from "@deadark/ark-ui/flux-router";

const router = new FluxRouter({
  root: document.querySelector("#app"),
  manifest: [
    defineFluxRoute({
      path: "/projects/:projectId",
      routeId: "project",
      paramTypes: { projectId: "uuid" },
    }),
    { path: "/docs/*slug", routeId: "docs" },
  ],
  resolver: (path, { params, search, signal, pattern }) => {
    return loadProject(params.projectId, {
      tab: search.get("tab"),
      signal,
      pattern,
    });
  },
});
```

`FluxRouteContext` contains:

- `path`: the concrete pathname, without the query string
- `pattern`: the matched manifest pattern
- `params`: decoded named route parameters
- `search`: `URLSearchParams` for the current query
- `signal`: aborted when a newer navigation supersedes this resolver

Static routes outrank dynamic routes, named parameters outrank splats, and ties retain manifest order. Keep resolvers side-effect-free because prefetch can execute them before navigation.

A route such as `/:slug` matches `/test`, `/1`, and `/any`. Named parameters use the safe `slug` validator by default; splats use `string`. Available validators are `string`, `slug`, `integer`, `number`, `boolean`, and `uuid`, plus `RegExp` and predicate functions. `defineFluxRoute()` preserves the literal path so TypeScript infers the exact `params` keys in `head` functions.

When a manifest is present, unmatched paths render a safe `404` with `noindex,nofollow` and never call the resolver. Declare `/*path` for an intentional catch-all, or set `unmatched: "resolve"` only when arbitrary paths are expected. Route URLs, query counts, query values, decoded parameters, malformed encodings, duplicate params, and misplaced splats are bounded or rejected before resolution.

## Route head

Use a static head object or a function when metadata depends on route params.

```js
{
  path: "/projects/:projectId",
  head: ({ params }) => ({
    title: `Project ${params.projectId}`,
    description: `Workspace for ${params.projectId}`,
    canonical: "https://example.com/projects/{{projectId}}",
    robots: "index,follow",
    openGraph: {
      title: "Project {{projectId}}",
      type: "website",
    },
    jsonLd: {
      "@context": "https://schema.org",
      "@type": "SoftwareApplication",
      name: "{{projectId}}",
    },
    sitemap: { changefreq: "weekly", priority: 0.8 },
  }),
}
```

The router owns and replaces its managed description, robots, canonical, Open Graph, and JSON-LD nodes on every navigation. Legacy manifest `title` and `description` fields still work. `{{param}}` and `{{path}}` placeholders are interpolated recursively.

## Route cache

The built-in cache deduplicates concurrent loads and supports TTL, stale-while-revalidate, tags, a bounded LRU, explicit invalidation, and retry after rejected promises.

```js
const cache = new FluxRouteCache({
  ttlMs: 30_000,
  staleWhileRevalidateMs: 120_000,
  maxEntries: 100,
});

const router = new FluxRouter({
  root,
  cache,
  manifest: [{
    path: "/projects/:projectId",
    cache: { ttlMs: 10_000, staleWhileRevalidateMs: 60_000, tags: ["projects"] },
  }],
  resolver,
});

router.invalidateCache({ tags: ["projects"] });
router.invalidateCache({ path: "/projects/alpha?tab=activity" });
```

This cache stores route resolver payloads. `FluxMemoryStore` remains the reactive application-state layer. Stream payloads are evicted when consumed because streams are single-use.

Routes marked `requiresAuth` bypass caching by default. To cache protected data, opt into a private scope and partition every entry by the current stable identity:

```js
const router = new FluxRouter({
  root,
  resolver,
  isAuthorized: () => Boolean(session.user),
  cachePartition: () => session.user.id,
  manifest: [{
    path: "/account",
    requiresAuth: true,
    redirectTo: "/login",
    cache: { scope: "private", ttlMs: 10_000 },
  }],
});
```

Navigation and hover/focus prefetch use the same authorization guard. A denied protected route without a redirect does not invoke its resolver. Route guards improve client UX, but APIs must still authenticate and authorize every request.

## Progressive streams

A resolver may return a `ReadableStream`, an async iterable, or `{ stream, head }`. The router commits history, route metadata, state defaults, and an empty outlet before reading the first chunk.

```js
async function* projectRoute({ signal }) {
  yield { html: "<header><h1>Project</h1></header>" };
  const details = await loadDetails({ signal });
  yield { element: renderDetails(details) };
}

const resolver = (_path, context) => ({
  stream: projectRoute(context),
  head: { title: "Loading project" },
});
```

Each string or `{ html }` chunk must be a complete HTML fragment. A chunk can use `replace: true` to clear the outlet before mounting, and can carry a `head` patch. Starting another navigation aborts reading and calls `cancel()` or `return()` on the stream when available.

String and `{ html }` results receive baseline sanitization before mounting. Scripts, embedded documents, inline event handlers, unsafe URL protocols, `srcdoc`, `srcset`, and direct `innerHTML` property bindings are removed or blocked. Do not treat HTML strings as a trust boundary: untrusted values should be rendered with `textContent`, and host applications should add a Content Security Policy and Trusted Types as defense-in-depth.

## Database safety

Ark UI does not include a SQL client or execute database statements. Param schemas reject malformed route values early and make resolver code type-safe, but they are not a substitute for parameterized queries. Never interpolate `context.params`, search values, or form state into SQL strings; bind values through the server-side driver or use a type-safe query builder. Database authorization, least-privilege credentials, query timeouts, and row-level policies remain server responsibilities.

The optional server entry point provides a tagged parameterized-query contract. Dynamic values always remain outside the SQL text:

```js
import { executeFluxSql, fluxSql } from "@deadark/ark-ui/server";

const query = fluxSql`SELECT * FROM projects WHERE id = ${projectId} AND owner_id = ${user.id}`;
const projects = await executeFluxSql((bound, signal) => database.query(bound, { signal }), query, signal);
```

Only values belong in `${...}` positions. Table names, column names, sort directions, and other SQL syntax must come from a static application allowlist.

## Optional server rendering

Use `createFluxServerHandler()` for unbounded routes that cannot be statically generated. Every route must explicitly declare `security: "public"` or `security: "authenticated"`; missing declarations fail during startup. Omitted methods mean `GET` and `HEAD`, never every method.

Unsafe methods require a valid same-origin `Origin` by default and reject cross-site Fetch Metadata. Cookie/session requests receive CSRF protection regardless of whether the route is public or authenticated. Bearer-only requests do not need CSRF proof. Use `isSessionRequest` when session authentication is not represented by a `Cookie` header, and use `origin: "none"` or `csrf: false` only for a deliberately reviewed non-browser endpoint.

```js
import { createFluxServerHandler, defineFluxServerRoute, defineFluxServerSchema } from "@deadark/ark-ui/server";

export default createFluxServerHandler({
  resolveIdentity: ({ headers }) => sessions.verify(headers.authorization),
  verifyCsrf: ({ headers, identity }) => csrf.verify(headers["x-csrf-token"], identity),
  routes: [defineFluxServerRoute({
    path: "/projects/:projectId",
    methods: ["POST"],
    paramTypes: { projectId: "uuid" },
    security: "authenticated",
    contentTypes: ["application/json"],
    schemas: {
      body: defineFluxServerSchema((value) => projectUpdateSchema.parse(value)),
      search: defineFluxServerSchema((value) => updateSearchSchema.parse(value)),
      headers: defineFluxServerSchema((value) => requestHeaderSchema.parse(value)),
    },
    authorize: ({ identity, params }) => permissions.canRead(identity, params.projectId),
    render: async ({ params, validated, signal }) => {
      await updateProject(params.projectId, validated.body, { signal });
      return { status: 204 };
    },
  })],
});
```

Serve the static package with that fallback:

```bash
ark serve dist/app/app.flx --ssr-module ./server/routes.mjs \
  --request-timeout-ms 10000 --render-timeout-ms 15000 \
  --max-ssr-concurrency 64 --max-request-bytes 1048576 \
  --max-stream-bytes 8388608 --max-stream-chunks 2048 \
  --csp-report-uri /csp-report --hsts --hsts-include-subdomains
```

Known generated assets remain static; only unresolved URLs reach the SSR module. Production serving always enforces Trusted Types with the `ark-ui` policy and emits a strict CSP, frame, MIME-sniffing, permissions, referrer, COOP, and CORP policy. Inline static script/style blocks receive exact hashes and per-response nonces; inline style attributes and event handlers remain blocked. Streamed SSR receives `cspNonce` in its request context and must place that nonce on any emitted `<script>` or `<style>` element. `createArkUI({ cspNonce })` also applies it to Ark's generated stylesheet; under the Ark CLI host the runtime discovers the injected nonce automatically.

`--csp-report-uri` adds both legacy `report-uri` and current Reporting API headers. The target must be a same-origin absolute path or HTTPS URL. `--hsts` is opt-in because HSTS is valid only on a real HTTPS deployment; `--hsts-max-age`, `--hsts-include-subdomains`, and `--hsts-preload` configure it. Do not use preload until every subdomain is permanently HTTPS-capable.

SSR has separate request and render deadlines, bounded request/response bytes and chunk counts, backpressure, disconnect cancellation, concurrency shedding, and graceful signal-driven shutdown. Response headers from an SSR module cannot replace host security headers or inject hop-by-hop framing headers. If streaming fails after headers begin, the host closes the response instead of appending an unsafe or ambiguous error document.

Schemas receive a normalized null-prototype search record, the parsed request body, and normalized lowercase headers. Their return values are available under `context.validated`. A thrown schema error becomes a JSON `VALIDATION_FAILED` response with bounded `{ location, path, message }` issues; validation runs before identity resolution, authorization, CSRF, or rendering.

## Static dynamic routes

For a finite set of dynamic URLs, declare the route pattern and concrete paths in the template HTML:

```html
<meta name="ark-route-pattern" content="/projects/:projectId" />
<meta name="ark-static-paths" content='["/projects/alpha", "/projects/beta"]' />
<meta name="ark-sitemap-changefreq" content="weekly" />
<meta name="ark-sitemap-priority" content="0.8" />
<link rel="canonical" href="https://example.com/projects/{{projectId}}" />
<title>Project {{projectId}}</title>
```

Then build normally:

```bash
ark build . --out-dir dist/app --site-url https://example.com
```

The CLI validates each static path, emits files such as `projects/alpha/index.html`, interpolates placeholders, rewrites relative asset references for the generated depth, records the pattern and static paths in `app.flx.json`, and emits `sitemap.xml`. Dynamic paths not listed in `ark-static-paths` remain client/server-resolved and are not prerendered.

Supported SEO source metadata includes `<title>`, description and robots meta tags, canonical links, `og:*` meta tags, JSON-LD scripts, and the `ark-sitemap-*` fields.
