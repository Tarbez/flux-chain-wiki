# Dense Flux Patterns (spec 0.4.1)

Use `@deadark/flux-algebra` when an ARK UI surface needs to read or validate
Dense Flux patterns. Do not add a second parser to `ark-ui`: the algebra
package is the JavaScript implementation, while
`shared/flux-spec/spec/dense-encoding-v4.md` is the canonical grammar.

> `0.4.1` is the **Dense Encoding specification version** (v4.1). It is not
> the npm version of `@deadark/flux-algebra` or `@deadark/ark-ui`.

## Add the engine

Inside this workspace, add the sibling package to the consuming application:

```json
{
  "dependencies": {
    "@deadark/ark-ui": "file:../../shared/ark-ui",
    "@deadark/flux-algebra": "file:../../shared/flux-algebra"
  }
}
```

Adjust the relative paths for the application. `@deadark/flux-algebra` is
currently a private workspace package, so do not document it as a public npm
install until it is published.

## Decode a pattern

The parser only finds top-level `-`-separated blocks. Resolve every block to
validate its Dense meaning:

```js
import {
  DenseEncodingError,
  resolveDenseBlock,
  tokenize,
} from "@deadark/flux-algebra";

export function decodeDensePattern(source) {
  try {
    return {
      ok: true,
      blocks: tokenize(source).map(resolveDenseBlock),
    };
  } catch (error) {
    if (error instanceof DenseEncodingError) {
      return { ok: false, error: error.message };
    }
    throw error;
  }
}

decodeDensePattern("I302E2A1-B10P5S1-ASENDX-TMSGHELLO");
// {
//   ok: true,
//   blocks: [
//     { Identity: 302, Environment: 2, Agency: 1 },
//     { Budget: 10, Priority: 5, Consistency: 1 },
//     { Action: "SEND", Encrypted: true },
//     { Target: "MSGHELLO" }
//   ]
// }
```

Do not treat successful tokenization as successful validation. `tokenize()`
deliberately preserves raw blocks; `resolveDenseBlock()` enforces registered
roles and packed formats.

## Use the 0.4.1 manifest type wire form

Dense 0.4.1 assigns compact base-36 codes to registered manifest types. Put
the code in the signed/transmitted `Y` block and expand it only when resolving
the manifest:

```js
import {
  encodeManifestType,
  resolveDenseBlock,
} from "@deadark/flux-algebra";

const typeBlock = `Y${encodeManifestType("GHOST")}`;
// "Y0" -- the v0.4.1 wire form

resolveDenseBlock(typeBlock);
// { Type: "GHOST" } -- normalized application/storage form
```

The resolver still accepts legacy word forms such as `YGHOST` for
migrate-on-touch compatibility. New or touched wire data should use the coded
form returned by `encodeManifestType()`.

## Rules UI code must preserve

- `-` is the only delimiter and the only punctuation allowed in a Dense
  pattern. There is no escaping.
- A block is one role letter followed by its packed payload.
- Base64 and base64url are invalid wire encodings. Use lowercase hex for short
  arbitrary UTF-8 text and hex or Bitcoin-base58 for opaque key material.
- Whole-number amounts use their smallest unit; decimal points are invalid.
- Long or open-ended content belongs behind a `C` reference instead of being
  hex-encoded inline.
- Do not invent role letters, action verbs, or manifest type codes in UI code.
  Update `flux-spec` first, then update the engine implementation.

## ARK UI boundary

Keep Dense data as application state and render the resolved result through
normal ARK UI/Flux DOM bindings. UI components should not infer semantics from
raw character positions or silently accept a partially resolved pattern.

For the complete authority, read
`shared/flux-spec/spec/dense-encoding-v4.md` and the registries under
`shared/flux-spec/registry/`.
