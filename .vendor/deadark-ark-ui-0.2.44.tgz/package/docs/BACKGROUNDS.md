# Configurable backgrounds

## Website component and theme binding

All six generators are available through one framework-free Web Component. Register it once, then choose the experiment, preset, and color behavior in markup.

```js
import {
  registerArkBackgroundElement,
} from "@deadark/ark-ui/backgrounds/component";

registerArkBackgroundElement();
```

```html
<ark-background kind="atmosphere" preset="quiet" color-mode="theme">
  <main>Your site content</main>
</ark-background>
```

`kind` accepts `atmosphere`, `contours`, `fabric`, `lattice`, `rift`, or `typefield`. Color behavior is explicit:

- `fixed` keeps the preset or configuration colors regardless of site theme changes.
- `theme` reads the live ARK semantic tokens and automatically repaints when the document theme changes.
- `locked` captures the current theme palette when selected and keeps that snapshot even if the site theme changes later.

The component exposes its resolved palette as `--ark-background-canvas`, `--ark-background-surface`, `--ark-background-primary`, `--ark-background-complement`, `--ark-background-accent`, `--ark-background-text`, `--ark-background-muted`, and `--ark-background-border`. Slotted website content can deliberately coordinate with the generated surface without overwriting the SDK theme tokens.

For imperative use, `mountArkGenerativeBackground(host, options)` returns the same controller contract with `update()`, `regenerate()`, `setColorMode()`, and `destroy()`. `exportArkBackgroundComponent(options)` produces portable component markup for saved builders or visual editors.

`@deadark/ark-ui/backgrounds` generates atmospheric site backgrounds from one small configuration. The renderer always derives the lower-opacity base pose from the source shapes, then places a full-screen complementary fill above both layers.

```js
import {
  ARK_BACKGROUND_PRESETS,
  mountArkBackground,
} from "@deadark/ark-ui/backgrounds";

const background = mountArkBackground(document.querySelector("#background"), {
  ...ARK_BACKGROUND_PRESETS.tide,
  sub: { blur: 40 },
  base: { scale: 1.3 },
  complementary: { opacity: 0.05 },
});
```

The global defaults own the full structure:

- `shapes`: the source pose rendered in the lowest `sub` layer.
- `base`: derives the same source pose, with configurable scale, opacity, and blur; `extras` exist only here.
- `complementary`: a circle-free, full-container color fill with backdrop blur and saturation.
- `grain`: a lightweight procedural texture over the complete result.

Use `createArkBackgroundConfig()` when a consumer needs normalized configuration without mounting it. Use the controller returned by `mountArkBackground()` to update a live background without rebuilding application code.

## Contour fields

`@deadark/ark-ui/backgrounds/contours` owns the SVG-based contour experiment. SVG is used for the generated geometry; CSS remains responsible for the canvas and procedural grain. This keeps a small path field inspectable and directly configurable while avoiding a canvas animation loop.

```js
import {
  mountArkContourBackground,
} from "@deadark/ark-ui/backgrounds/contours";

const contour = mountArkContourBackground(document.querySelector("#background"), {
  pathCount: 24,
  bend: 118,
  lineWidth: 0.72,
  lineOpacity: 0.46,
  motion: { enabled: true, distance: 8, duration: 18 },
});

contour.update({ pathCount: 40, bend: 160 });
```

The normalizer bounds path count at 96 to keep the intended SVG workload predictable. For hundreds or thousands of continuously changing marks, use a canvas renderer instead.

## Spectral fabric

`@deadark/ark-ui/backgrounds/fabric` renders a deterministic pixel field to a reduced-resolution Canvas and lets CSS upscale it to the host. It is the appropriate renderer when every pixel participates in the pattern and DOM or SVG node counts would no longer describe the work efficiently.

```js
import {
  ARK_FABRIC_BACKGROUND_PRESETS,
  mountArkFabricBackground,
} from "@deadark/ark-ui/backgrounds/fabric";

const fabric = mountArkFabricBackground(document.querySelector("#background"), {
  ...ARK_FABRIC_BACKGROUND_PRESETS.fog,
  seed: 31003,
  fieldScale: 1.2,
  warp: 0.42,
  softness: 0.68,
  motion: { enabled: true, drift: 0.12, fps: 18 },
});
```

The default internal resolution is 28% of the host dimensions and animation is throttled to 18 FPS. Motion stops under `prefers-reduced-motion`; configuration changes still render a fresh static frame.

## Cipher lattice

`@deadark/ark-ui/backgrounds/lattice` generates a deterministic SVG network from orthogonal traces, sparse terminal nodes, animated signal packets, and a CSS grid/scan layer.

```js
import {
  mountArkLatticeBackground,
} from "@deadark/ark-ui/backgrounds/lattice";

const lattice = mountArkLatticeBackground(document.querySelector("#background"), {
  seed: 404019,
  traceCount: 16,
  complexity: 8,
  lineWidth: 0.72,
  signalDensity: 4,
  glow: 12,
  motion: { enabled: true, duration: 14 },
});
```

Trace count is capped at 40 and complexity at 18. The generated geometry is static until configuration changes; only dash offset and the scan band animate, which keeps the cyber surface inexpensive behind application content.

## Data rift

`@deadark/ark-ui/backgrounds/rift` generates an angled transmission field from layered bands, sparse packet blocks, data cuts, and coordinate fragments. Unlike the lattice, its composition is directional and preserves a quieter center for application content.

```js
import {
  mountArkRiftBackground,
} from "@deadark/ark-ui/backgrounds/rift";

const rift = mountArkRiftBackground(document.querySelector("#background"), {
  seed: 505027,
  bandCount: 14,
  angle: -17,
  spread: 340,
  cutDensity: 7,
  packetCount: 14,
  presence: 0.44,
  motion: { enabled: true, duration: 11, travel: 260 },
});
```

Only the packet group moves. The bands, cuts, telemetry, and negative space remain stable until the configuration or seed changes.

## Kinetic typefield

`@deadark/ark-ui/backgrounds/typefield` converts user-controlled text into a deterministic SVG typography field. The text is material rather than content: generated lanes, a large outline word, and signal cuts compose a cyber surface while live controls adjust density, scale, tracking, opacity, and motion.

```js
import {
  ARK_TYPEFIELD_LIMITS,
  mountArkTypefieldBackground,
} from "@deadark/ark-ui/backgrounds/typefield";

const typefield = mountArkTypefieldBackground(document.querySelector("#background"), {
  text: "SIGNAL MEMORY IDENTITY RELAY",
  itemLimit: 42,
  laneCount: 7,
  fontSize: 34,
  tracking: 5,
  glitch: 0.22,
  motion: { enabled: true, duration: 20, travel: 180, direction: 1 },
});
```

The normalizer caps source text at 160 characters, generated items at 96, lanes at 12, type scale at 120px, and animation cycles between 4 and 60 seconds. Consumers can expose the exported `ARK_TYPEFIELD_LIMITS` directly in their own controls.
