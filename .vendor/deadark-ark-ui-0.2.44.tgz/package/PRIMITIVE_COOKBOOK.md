# ARK UI Primitive Cookbook

This file complements [PRIMITIVES.md](PRIMITIVES.md) with guided composition patterns.

## 1. Stacked Modal Workflow

Use this when one modal can legally launch another and only the top layer should stay interactive.

```ts
const ui = createArkUI();
registerArkComponents(ui);

ui.render(
  'F-ROOT-D-COLUMN .R-OPENPROFILE-M-SAVE-A-CLICK. .R-PROFILE-F-MODAL-D-COLUMN .R-PTITLE-M-TITLE. .R-PBODY-M-CONTENT. .R-OPENCONFIRM-M-DELETE-A-CLICK.. .R-CONFIRM-F-MODAL-D-COLUMN .R-CTITLE-M-TITLE. .R-CBODY-M-CONTENT. .R-CCLOSE-M-CANCEL-A-CLICK..',
  app,
);

createArkDialog(ui, {
  triggerRef: 'R-OPENPROFILE',
  contentRef: 'R-PROFILE',
  labelRef: 'R-PTITLE',
  descriptionRef: 'R-PBODY',
});

createArkDialog(ui, {
  triggerRef: 'R-OPENCONFIRM',
  contentRef: 'R-CONFIRM',
  labelRef: 'R-CTITLE',
  descriptionRef: 'R-CBODY',
  initialFocusRef: 'R-CCLOSE',
});
```

What you get:

- portal mounting with backdrops
- body scroll lock
- inert and `aria-hidden` shielding on app roots
- covered modals marked as background-only while a higher modal is open

## 2. Production Menu Surface

Use menu state plus composition helpers when a simple list of actions is not enough.

```ts
createArkMenu(ui, {
  triggerRef: 'R-ACTIONS',
  contentRef: 'R-ACTIONSMENU',
  itemRefs: ['R-OPEN', 'R-RENAME', 'R-DELETE'],
  stateRef: 'R-ACTIONSMODEL',
  disabledItemRefs: ['R-DELETE'],
});

createArkMenuLabel(ui, { labelRef: 'R-MENULABEL' });
createArkMenuGroup(ui, { groupRef: 'R-FILEGROUP', labelRef: 'R-MENULABEL' });
createArkMenuSeparator(ui, { separatorRef: 'R-DIVIDER' });
createArkMenuItem(ui, {
  itemRef: 'R-RENAME',
  menuRef: 'R-ACTIONSMENU',
  onSelect: (ref) => console.log('selected', ref),
});
createArkMenuCheckboxItem(ui, {
  itemRef: 'R-SHOWHIDDEN',
  checked: true,
  onCheckedChange: (checked) => console.log('show hidden', checked),
});
createArkMenuRadioGroup(ui, {
  itemRefs: ['R-SORTNAME', 'R-SORTDATE'],
  selectedRef: 'R-SORTDATE',
  onValueChange: (ref) => console.log('sort mode', ref),
});
```

The `stateRef` receives a live object with:

- `open`
- `activeRef`
- `itemRefs`
- `disabledItemRefs`

## 3. App-Scale Tabs

Use a `stateRef` when tabs need to coordinate with the rest of an app shell.

```ts
const tabs = createArkTabs(ui, {
  listRef: 'R-SETTINGS_TABS',
  tabRefs: ['R-GENERAL_TAB', 'R-TEAM_TAB', 'R-BILLING_TAB'],
  panelRefs: ['R-GENERAL_PANEL', 'R-TEAM_PANEL', 'R-BILLING_PANEL'],
  disabledTabRefs: ['R-BILLING_TAB'],
  stateRef: 'R-SETTINGS_TABS_MODEL',
});

tabs.select('R-TEAM_TAB');
```

The `stateRef` receives:

- `selectedRef`
- `selectedIndex`
- `tabRefs`
- `panelRefs`
- `activationMode`

## 4. Select With Highlight State

Use this when you need both committed value and current keyboard highlight.

```ts
const select = createArkSelect(ui, {
  triggerRef: 'R-ASSIGNEE_TRIGGER',
  contentRef: 'R-ASSIGNEE_LIST',
  valueRef: 'R-ASSIGNEE_VALUE',
  optionRefs: ['R-USER_A', 'R-USER_B', 'R-USER_C'],
  disabledOptionRefs: ['R-USER_C'],
  stateRef: 'R-ASSIGNEE_MODEL',
});

select.open();
select.highlight('R-USER_B');
select.select('R-USER_B');
```

The `stateRef` receives:

- `open`
- `selectedRef`
- `selectedText`
- `highlightedRef`
- `optionRefs`
- `disabledOptionRefs`

## 5. Combobox With Empty State

Use this when a searchable surface needs to show “no results” without losing the last committed choice.

```ts
const combo = createArkCombobox(ui, {
  inputRef: 'R-CMD_INPUT',
  contentRef: 'R-CMD_RESULTS',
  optionRefs: ['R-CMD_OPEN', 'R-CMD_SHARE', 'R-CMD_ARCHIVE'],
  disabledOptionRefs: ['R-CMD_ARCHIVE'],
  emptyRef: 'R-CMD_EMPTY',
  stateRef: 'R-CMD_MODEL',
});

combo.setQuery('share');
combo.select('R-CMD_SHARE');
combo.setQuery('missing');
```

The `stateRef` receives:

- `open`
- `committedRef`
- `committedText`
- `highlightedRef`
- `inputValue`
- `visibleRefs`

## 6. Breadcrumbs, Pagination, And Disclosure

Use these together when a screen needs wayfinding plus inline progressive reveal.

```ts
createArkBreadcrumbs(ui, {
  navRef: 'R-BREAD',
  itemRefs: ['R-HOME', 'R-PROJECT', 'R-SETTINGS'],
  separatorRefs: ['R-SEP1', 'R-SEP2'],
  currentRef: 'R-SETTINGS',
});

createArkPagination(ui, {
  navRef: 'R-PAGER',
  pageRefs: ['R-PAGE1', 'R-PAGE2', 'R-PAGE3'],
  previousRef: 'R-PREV',
  nextRef: 'R-NEXT',
  currentRef: 'R-PAGE1',
});

createArkDisclosure(ui, {
  triggerRef: 'R-FILTERS_TRIGGER',
  contentRef: 'R-FILTERS_PANEL',
});
```

What you get:

- `aria-current="page"` semantics for active path and current page
- hidden breadcrumb separators for punctuation-only nodes
- boundary disabling for previous/next page controls
- button-driven inline reveal with `aria-expanded` and labelled region content

## 7. Form Flow With Error Summary And Success Surface

Use `createArkForm(...)` when a screen needs a first-class submit lifecycle instead of one-off field wiring.

```ts
createArkForm(ui, {
  formRef: 'R-PROFILE_FORM',
  submitRef: 'R-SAVE',
  statusRef: 'R-FORM_STATUS',
  errorSummaryRef: 'R-FORM_SUMMARY',
  successRef: 'R-FORM_SUCCESS',
  fields: [{
    name: 'email',
    fieldRef: 'R-EMAIL_FIELD',
    labelRef: 'R-EMAIL_LABEL',
    controlRef: 'R-EMAIL_INPUT',
    helperRef: 'R-EMAIL_HELPER',
    errorRef: 'R-EMAIL_ERROR',
    required: true,
    validate: (value) => String(value).includes('@') ? undefined : 'Enter a valid email address',
  }],
  onSubmit: async (values) => saveProfile(values),
});
```

What you get:

- `aria-invalid` management on failing controls
- assertive summary messaging for submission-blocking errors
- polite status messaging for submission progress
- success-surface toggling after valid submission
- required-field enforcement plus custom validators

## 8. Command, Collection, And Table Surfaces

Use these when selection and search should be first-class state rather than ad hoc click handlers.

```ts
createArkCommandSurface(ui, {
  inputRef: 'R-CMD',
  contentRef: 'R-CMD_LIST',
  optionRefs: ['R-CMD_OPEN', 'R-CMD_SHARE', 'R-CMD_ARCHIVE'],
  emptyRef: 'R-CMD_EMPTY',
  loadingRef: 'R-CMD_LOADING',
  onCommand: (ref, value) => runCommand(ref, value),
});

createArkCollection(ui, {
  containerRef: 'R-COLLECTION',
  itemRefs: ['R-I1', 'R-I2', 'R-I3'],
  selectionMode: 'multiple',
  detailRef: 'R-DETAIL',
});

createArkTable(ui, {
  tableRef: 'R-TABLE',
  itemRefs: ['R-ROW1', 'R-ROW2', 'R-ROW3'],
  selectionMode: 'single',
});
```

What you get:

- command-surface filtering and committed command callbacks
- empty/loading state coordination
- single or multiple selection models for list-like surfaces
- detail-panel visibility driven by selection state
- table rows that participate in the same collection semantics as list items

## 9. FAQ Accordion With Disabled Items

Use the `ACCORDIONITEM` / `ACCORDIONHEADER` / `ACCORDIONTRIGGER` / `ACCORDIONCONTENT` parts when you want the shadcn/Base UI-style chevron and open/close animation for free instead of styling a bare trigger + panel pair yourself. Give each panel's text child its own `F-ACCORDIONCONTENTBODY` so its padding survives the height animation instead of jumping with the collapsing track.

If your app also binds `FluxAnimate`, let the primitive stamp the animation attrs for you with `animation: true` or a custom animation object. Accordion then uses a layered model:

- `createPresence()` still owns mounted vs hidden state, height collapse, and aria-hidden behavior
- `createArkAccordion()` writes a conditional `data-flx-animate` expression onto each panel ref
- `FluxAnimate` adds transform/opacity motion on top of the existing presence/layout rules

Leave `M` off the trigger and body refs. Pairing an `F` shape with an `M` meaning on the *same* ref makes schema resolution use the `M` value and silently drop the `F`-specific style (`resolveSchema()` in `ark-ui.runtime.ts` only falls back to `F` when `M` is absent) — you'd get a plain default button instead of the chevron trigger. Set the label/body text with `ui.update(ref, { text })` instead.

```ts
ui.render(
  'F-ACCORDION-D-COLUMN ' +
  '.R-IT0-F-ACCORDIONITEM-D-COLUMN .R-TR0-F-ACCORDIONTRIGGER-A-CLICK. .R-PN0-F-ACCORDIONCONTENT .R-BD0-F-ACCORDIONCONTENTBODY... ' +
  '.R-IT1-F-ACCORDIONITEM-D-COLUMN .R-TR1-F-ACCORDIONTRIGGER-A-CLICK. .R-PN1-F-ACCORDIONCONTENT .R-BD1-F-ACCORDIONCONTENTBODY...',
  app,
);
ui.update('R-TR0', { text: 'What is ArkUI?' });
ui.update('R-BD0', { text: 'A meaning-first rendering engine.' });
ui.update('R-TR1', { text: 'Does it animate?' });
ui.update('R-BD1', { text: 'Yes — the panel height transitions on open/close.' });

createArkAccordion(ui, {
  listRef: 'R-TR0',
  itemRefs: ['R-IT0', 'R-IT1'],
  triggerRefs: ['R-TR0', 'R-TR1'],
  panelRefs: ['R-PN0', 'R-PN1'],
  values: ['what-is-ark', 'does-it-animate'],
  type: 'single',        // or 'multiple' — mirrors shadcn/Base UI's `type` prop
  collapsible: true,     // single mode only: can the open item close back to none
  defaultValue: 'what-is-ark',
  disabledItemRefs: ['R-IT1'],
  animation: {
    enterPreset: 'accordion:enter',
    exitPreset: 'accordion:exit',
    duration: '220ms',
    stagger: '40ms',
  },
  hiddenUntilFound: true,
  stateRef: 'R-ACCSTATE',
  onValueChange: (openValues, detail) => console.log(openValues, detail.openIndexes),
});
```

If you do not want to construct `FluxAnimate` yourself, let ArkUI own it:

```ts
const ui = createArkUI({
  animations: { globalName: 'fluxAnimate' },
});
```

or:

```ts
ui.enableAnimations({ globalName: 'fluxAnimate' });
```

What you get:

- single- or multi-open modes, plus `collapsible: false` for "always one open" settings-style groups
- stable item values for Base UI / shadcn-style state instead of only positional indexes
- root-level `disabled`, plus per-item `disabledRefs` / `disabledItemRefs` — the trigger gets `aria-disabled`, is skipped on click, and is dimmed by the shipped `ACCORDIONTRIGGER` style
- a chevron indicator that rotates purely off `aria-expanded`, no extra DOM node
- grid-row open/close animation driven by the `createPresence()` `data-presence` attribute, with optional `hiddenUntilFound` searchability or `keepMounted: false` unmounting
- optional Flux-native enter/exit motion on the same panel refs when `animation` is enabled and your app binds `FluxAnimate`
- item / trigger / panel state attrs like `data-state`, `data-value`, and `data-index` for styling wrappers as well as leaf nodes
- roving-tabindex keyboard nav (Up/Down/Home/End) across triggers via `createRovingFocusGroup()`
- `stateRef`/`onValueChange` for reading or reacting to the open value set from outside, with index/ref details included

## 10. App Shell With Persistent Rail

Use `createArkAppShell(...)` for a desktop/dashboard product shell where the icon rail should never fully disappear, only the labeled nav strip beside it.

```ts
ui.render(
  'F-ROOT-D-ROW .R-RAIL-F-SECTION-D-COLUMN. .R-NAV-F-SECTION-D-COLUMN. .R-MAIN-F-SECTION-D-COLUMN.',
  app,
);

const shell = createArkAppShell(ui, {
  shellRef: 'R-ROOT',
  railRef: 'R-RAIL',
  navRef: 'R-NAV',
  mainRef: 'R-MAIN',
  triggerRef: 'R-NAVTOGGLE',
  stateRef: 'R-SHELLSTATE',
});

shell.collapse(); // nav strip closes, rail stays put, main grows
```

What you get:

- rail stays mounted and visible at all times — only `navRef`'s column collapses to `0px`
- `navRef` gets `hidden` toggled in sync with the collapse, dropping it from the a11y tree while closed
- `mainRef` always fills the remaining grid column, no manual width math
- `stateRef`/`onExpandedChange` for app-scale state, same shape as `createArkSidebar(...)`

Cards nested inside the shell's main region use `radiusSm` (the card-radius law: a card is a quiet step, never a new shape) — see the `CARD`/`CARDHEADER`/`CARDTITLE`/`CARDDESCRIPTION`/`CARDBODY`/`CARDFOOTER`/`CARDACTIONS` parts in `ark-ui.components.ts`.

## 11. Stat Tile, Readiness Card, And Journey Step

Use these for operator dashboards — an app-shell main region that needs "what's the current state" surfaces without a data-table.

```ts
ui.render(
  'F-SECTION-D-ROW ' +
  '.R-S1-F-STAT-D-COLUMN .R-S1V-M-STATVALUE. .R-S1L-M-STATLABEL. .R-S1T-X-UP-M-STATTREND... ' +
  '.R-READY1-X-READY-F-CARD-D-COLUMN .R-READY1H-F-CARDHEADER-D-COLUMN .R-READY1T-M-CARDTITLE. .R-READY1D-M-CARDDESCRIPTION... ' +
  '.R-STEP1-X-DONE-F-STEP. .R-STEP2-X-CURRENT-F-STEP. .R-STEP3-X-PENDING-F-STEP.',
  app,
);
ui.update('R-S1V', { text: '3' });
ui.update('R-S1L', { text: 'peers connected' });
ui.update('R-S1T', { text: '+2 today' });
ui.update('R-READY1T', { text: 'Identity' });
ui.update('R-READY1D', { text: 'Self-sovereign key created on this device.' });
```

What you get:

- `X-READY`/`X-PENDING`/`X-BLOCKED` on `F-CARD` — the readiness-card tones. `READY` is success, `PENDING` ("not ready yet", ordinary) is warning/honey, `BLOCKED` (danger) is reserved for genuine failures — never use `BLOCKED` for routine setup-in-progress states, that is exactly the red-for-ordinary-drift the honey law forbids.
- `X-DONE`/`X-CURRENT`/`X-PENDING` on `F-STEP` — journey/timeline step states. `PENDING` here means "not reached yet" (future work) and stays quiet/muted, not honey — that tone is for review-needed drift, not for steps nobody has gotten to.
- `M-STATVALUE`/`M-STATLABEL`/`M-STATTREND` (plus `X-UP`/`X-DOWN` on the trend) inside `F-STAT` for a labeled metric with an optional success/danger-toned delta.

All three compose from Batch-1 `CARD` parts and existing `Badge`/`Progress` — no new interaction primitives, just recipe composition.

## 12. Dismissible Alert And A Destructive Alert Dialog

Use `createArkAlert(...)` for inline, dismissible product messaging and `createArkAlertDialog(...)` when the user must explicitly confirm or cancel before a destructive action proceeds.

```ts
ui.render(
  'F-ROOT-D-COLUMN ' +
  '.R-ALERT-F-ALERT-D-COLUMN .R-AT-M-TITLE. .R-AB-M-CONTENT. .R-AD-M-CANCEL-A-CLICK.. ' +
  '.R-DELTRIG-M-DELETE-A-CLICK. ' +
  '.R-DELDLG-F-MODAL-D-COLUMN .R-DELT-M-TITLE. .R-DELB-M-CONTENT. .R-DELCANCEL-M-CANCEL-A-CLICK. .R-DELACTION-M-DELETE-A-CLICK..',
  app,
);

createArkAlert(ui, {
  rootRef: 'R-ALERT',
  titleRef: 'R-AT',
  descriptionRef: 'R-AB',
  dismissRef: 'R-AD',
  tone: 'warning',
});
ui.update('R-AT', { text: 'Sync degraded' });
ui.update('R-AB', { text: 'Some peers are unreachable. Retrying in the background.' });

createArkAlertDialog(ui, {
  triggerRef: 'R-DELTRIG',
  contentRef: 'R-DELDLG',
  labelRef: 'R-DELT',
  descriptionRef: 'R-DELB',
  cancelRef: 'R-DELCANCEL',
  actionRef: 'R-DELACTION',
  tone: 'danger',
  onAction: () => deleteRecord(),
});
ui.update('R-DELT', { text: 'Delete this record?' });
ui.update('R-DELB', { text: 'This cannot be undone.' });
```

What you get:

- `createArkAlert(...)`: `role="status"`/`role="alert"` live-region announcing tied to `tone` (`danger`/`warning` announce assertively, everything else politely), a dismiss action, and a `stateRef` model for app-level orchestration
- `createArkAlertDialog(...)`: `role="alertdialog"`, the same focus-trap/portal/scroll-lock machinery as `createArkDialog(...)`, plus **light-dismiss turned off** — clicking the overlay does not close it, only `Action`/`Cancel` (or Escape) do, matching the Radix/Base UI AlertDialog contract that a destructive choice can't be dismissed by accident
- `data-tone` on the alert dialog's content ref so styling can react to `danger` vs a softer confirmation tone

## 13. Sidebar And Direction

Use `createArkSidebar(...)` for a panel that collapses to a width (or to a rail via `closedWidth`), and `createArkDirection(...)` when a subtree — often that same panel — needs to flip to RTL for a locale.

```ts
ui.render(
  'F-ROOT-D-ROW .R-SIDEBAR-F-PANEL-D-COLUMN .R-SLABEL-M-CONTENT.. .R-MAIN-F-PANEL-D-COLUMN .R-TRIGGER-M-ACTION-A-CLICK. .R-MAINTXT-M-CONTENT..',
  app,
);
ui.update('R-SLABEL', { text: 'Navigation' });
ui.update('R-TRIGGER', { text: 'Toggle sidebar' });

const sidebar = createArkSidebar(ui, {
  sidebarRef: 'R-SIDEBAR',
  triggerRef: 'R-TRIGGER',
  openWidth: '240px',
  closedWidth: '72px', // condensed rail, not fully hidden
});

createArkDirection(ui, { rootRef: 'R-SIDEBAR', dir: 'rtl' });

sidebar.toggle();
```

What you get:

- open/closed width animation with `open`/`hidden` kept in sync — pass `closedWidth` for a condensed-but-still-mounted rail instead of the default fully-hidden `0px`
- `stateRef`/`onOpenChange` for app-scale state
- `dir` applied to the whole subtree, so descendant text flow, alignment, and logical CSS properties (`margin-inline-start`, etc.) follow it without per-node overrides

## 14. Scroll Area With Custom Thumb

Use `createArkScrollArea(...)` when the native scrollbar should be hidden in favor of a themed thumb that still tracks real scroll position.

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-VIEWPORT-F-PANEL .R-CONTENT-F-PANEL-D-COLUMN .R-I1-M-CONTENT. .R-I2-M-CONTENT. .R-I3-M-CONTENT.. .R-THUMBY-M-CONTENT.',
  app,
);
ui.style('R-VIEWPORT', { height: '240px' }, { mode: 'merge' });

createArkScrollArea(ui, {
  viewportRef: 'R-VIEWPORT',
  contentRef: 'R-CONTENT',
  thumbYRef: 'R-THUMBY',
});
```

What you get:

- the native scrollbar hidden (`scrollbarWidth: none` plus the `::-webkit-scrollbar` rule) while `overflow: auto` keeps real scrolling intact
- `thumbYRef`/`thumbXRef` size and offset recalculated on `scroll` and `mouseenter`, so a themed thumb tracks the real viewport ratio
- no scroll-position state to manage yourself — it reads straight from the DOM each time

## 15. Menubar And Navigation Menu

Use `createArkMenubar(...)` for desktop-style top-level chrome (File/Edit-style menus, mutually exclusive open state) and `createArkNavigationMenu(...)` for primary destinations that swap an inline panel instead of opening an overlay.

```ts
createArkMenubar(ui, {
  rootRef: 'R-MENUBAR',
  menus: [
    { triggerRef: 'R-FILETRIG', contentRef: 'R-FILEMENU', itemRefs: ['R-NEW', 'R-OPEN'] },
    { triggerRef: 'R-EDITTRIG', contentRef: 'R-EDITMENU', itemRefs: ['R-UNDO', 'R-REDO'] },
  ],
  stateRef: 'R-MENUBAR_MODEL',
});

const nav = createArkNavigationMenu(ui, {
  listRef: 'R-NLIST',
  triggerRefs: ['R-PRODUCT', 'R-DOCS', 'R-PRICING'],
  contentRefs: ['R-PRODUCT_PANEL', 'R-DOCS_PANEL', 'R-PRICING_PANEL'],
});

nav.select('R-DOCS');
```

What you get:

- menubar: roving focus across top-level triggers, `role="menubar"`/`role="menuitem"`, and one-open-branch coordination — opening File closes Edit automatically
- navigation menu: the same tab substrate as `createArkTabs(...)`, so panel switching, disabled destinations, and `stateRef`/`onValueChange` all behave identically — this is a semantic wrapper, not a second implementation

## 16. Field And Attachment

Use `createArkField(...)` directly (outside `createArkForm(...)`) for a single labeled control that doesn't need a full submit lifecycle, and `createArkAttachment(...)` for file-input state.

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-FIELD-F-FIELD .R-LABEL-M-LABEL. .R-CONTROL-M-INPUT. .R-HELPER-M-CONTENT.. .R-INPUT-M-INPUT. .R-LIST-M-CONTENT. .R-EMPTY-M-CONTENT.',
  app,
);
ui.update('R-LABEL', { text: 'Email' });
ui.update('R-HELPER', { text: "We'll only use this to send receipts." });
ui.update('R-EMPTY', { text: 'No files attached yet.' });

createArkField(ui, {
  fieldRef: 'R-FIELD',
  labelRef: 'R-LABEL',
  controlRef: 'R-CONTROL',
  helperRef: 'R-HELPER',
  required: true,
});

const attachment = createArkAttachment(ui, {
  inputRef: 'R-INPUT',
  listRef: 'R-LIST',
  emptyRef: 'R-EMPTY',
  dropzoneRef: 'R-DROPZONE',
  multiple: true,
  onFilesChange: (files) => uploadAll(files),
});

// attachment.removeFile(0) drops one selected file and keeps the rest.
```

What you get:

- `createArkField(...)`: `aria-labelledby`/`aria-describedby` wired from `labelRef` to `controlRef`, a `*` appended to the label when `required`, and `aria-invalid` plus a live-region error when `invalid`/`errorRef` are set — this is exactly what `createArkForm(...)` calls per-field internally, available standalone
- `createArkAttachment(...)`: a live `stateRef`/`getState()` snapshot of `{ name, size, type }` per selected file, an empty-state toggle, `clear()` to reset the input, and — with `dropzoneRef` — drag-and-drop that feeds the same file state as the native picker (single-file mode replaces on drop, `multiple` appends), plus `removeFile(index)` for a per-file remove button

## 17. Data Table With Sortable Columns And Pagination

Use `createArkDataTable(...)` — a thin layer over `createArkTable(...)` — when a table needs client-side sort and simple prev/next paging on top of selection semantics.

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-TABLE-F-TABLE .F-THEAD .F-ROW .F-HEADERCELL .R-H1-M-LABEL-A-CLICK.. .F-HEADERCELL .R-H2-M-LABEL... ' +
  '.F-TBODY .R-ROW1-F-ROW .F-CELL .R-T1-M-CONTENT.. .F-CELL .R-T1B-M-CONTENT... .R-ROW2-F-ROW .F-CELL .R-T2-M-CONTENT.. .F-CELL .R-T2B-M-CONTENT..... ' +
  '.R-PREV-M-CANCEL-A-CLICK. .R-NEXT-M-SAVE-A-CLICK.',
  app,
);
ui.update('R-H1', { text: 'Invoice' });
ui.update('R-H2', { text: 'Status' });

const invoiceByRow = { 'R-ROW1': 'INV002', 'R-ROW2': 'INV001' };
const table = createArkDataTable(ui, {
  tableRef: 'R-TABLE',
  itemRefs: ['R-ROW1', 'R-ROW2'],
  columns: [{ headerRef: 'R-H1', accessor: (rowRef) => invoiceByRow[rowRef] }],
  prevRef: 'R-PREV',
  nextRef: 'R-NEXT',
  pageSize: 1,
  stateRef: 'R-TABLE_MODEL',
});

table.sortBy('R-H1');
```

What you get:

- click-to-sort on any `columns[].headerRef`, toggling `asc`/`desc` and re-appending rows in sorted DOM order
- prev/next paging over `pageSize` rows at a time, with boundary-aware `page`/`pageCount` in `stateRef`
- everything `createArkTable(...)`/`createArkCollection(...)` already give you — roving focus, selection, empty/loading state — since `createArkDataTable(...)` calls `createArkTable(...)` internally rather than reimplementing it

## 18. Loading Mark For Branded Async States

Use `createArkLoadingMark(...)` instead of a bare spinner when an async wait should carry a logo, headline, and description as one accessible unit.

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-MARK-F-PANEL-D-ROW .R-LOGO-M-CONTENT. .R-LABEL-M-CONTENT...',
  app,
);
ui.update('R-LOGO', { text: '◐' });
ui.update('R-LABEL', { text: 'Loading workspace…' });

const mark = createArkLoadingMark(ui, {
  rootRef: 'R-MARK',
  logoRef: 'R-LOGO',
  labelRef: 'R-LABEL',
  spinning: true,
});

fetchWorkspace().finally(() => mark.stop());
```

What you get:

- a `role="status"` polite live region with `aria-busy`/`data-loading` reflecting `spinning`
- `start()`/`stop()`/`setSpinning(...)` plus `setLabel(...)`/`setDescription(...)` to update copy without re-rendering the pattern
- one accessible unit instead of a spinner icon and a text node the screen reader announces separately

## 19. Theme, Style Recipe, Style Library Pack, And Brand Template

Use these together to compose the theme every `createArkX(...)` call above reads from. Unlike the rest of this cookbook, none of them take a `ui` instance — they're pure data factories.

```ts
const recipe = createArkStyleRecipe({
  name: 'compact',
  tokens: { radius: '4px' },
  slots: { surface: { padding: '8px' } },
});

const theme = createArkTheme({
  mode: 'dark',
  semantic: { accent: '#7c5cff' },
  recipeTokens: recipe.recipeTokens,
});

const brand = createArkBrandTemplate({
  name: 'acme',
  tokens: { primary: '#ff5a1f' },
});

let pack = createArkStyleLibraryPack();
pack = upsertArkStyleLibraryRecipe(pack, recipe);

registerArkComponents(ui, theme);
```

What you get:

- `createArkStyleRecipe(...)`: a named, composable override bundle another recipe or theme can `extends`, validated with `validateArkStyleRecipe(...)`
- `createArkTheme(...)` / `extendArkTheme(...)`: the resolved `ArkTheme` object — tokens, semantic colors, presets, slots — that `registerArkComponents(ui, theme)` reads to style every primitive
- `createArkBrandTemplate(...)` / `resolveArkBrandTemplate(...)`: a normalized brand definition resolvable by name from the built-in registry, the shape behind the Design tab's brand-theme picker
- `createArkStyleLibraryPack(...)`: the versioned, exportable container (`version`, `schemaVersion`, `recipes`) for a set of saved recipes, built up with `upsertArkStyleLibraryRecipe(...)`

## 20. Avatar With Image, Fallback, And Status Dot

```ts
ui.render(
  'F-ROOT-D-ROW .R-AV-F-AVATAR .R-AVIMG-F-AVATARIMAGE. .R-AVFB-M-CONTENT. .R-AVSTATUS-F-AVATARSTATUS...',
  app,
);
ui.update('R-AVFB', { text: 'AL' }); // initials shown until the image loads (or if it fails)

createArkAvatar(ui, {
  rootRef: 'R-AV',
  imageRef: 'R-AVIMG',
  fallbackRef: 'R-AVFB',
  statusRef: 'R-AVSTATUS',
  src: user.avatarUrl,
  alt: user.name,
  status: user.isOnline ? 'online' : 'offline',
  fallbackDelay: 200, // holds the initials back briefly so a fast image never flashes them
});
```

What you get:

- automatic fallback on a missing `src` or a failed `<img>` load
- `fallbackDelay` to avoid a fallback->image flash on normal-speed connections (matches Radix/Base UI Avatar's `delayMs`)
- a `statusRef` presence dot styled by `data-status` (`online`/`away`/`busy`/`offline`)
- `setSrc(...)` to swap the image later and `getState()` for the current `idle`/`loading`/`loaded`/`error` status

## 21. Badge Tone Variants

```ts
ui.render(
  'F-ROOT-D-ROW .R-B1-M-BADGE. .R-B2-X-SECONDARY-M-BADGE. .R-B3-X-OUTLINE-M-BADGE. .R-B4-X-DANGER-M-BADGE. .R-B5-X-SUCCESS-M-BADGE. .R-B6-X-WARNING-M-BADGE.',
  app,
);
ui.update('R-B1', { text: 'Default' });
ui.update('R-B4', { text: 'Failed' });
```

No `createArkX(...)` call needed — Badge is a pure style-schema primitive. Pick a tone with the `X-` modifier the same way `X-DARK` or `X-SECONDARY` work anywhere else in the pattern grammar.

## 22. Breadcrumb Overflow Collapsing

```ts
ui.render(
  'F-ROOT-D-ROW .R-BC1-M-LINK-A-CLICK. .R-BC2-M-LINK-A-CLICK. .R-BC3-M-LINK-A-CLICK. .R-BC4-M-LINK-A-CLICK. .R-ELLIPSIS-F-BREADCRUMBELLIPSIS-A-CLICK..',
  app,
);

const trail = createArkBreadcrumbs(ui, {
  navRef: 'R-BREAD',
  itemRefs: ['R-BC1', 'R-BC2', 'R-BC3', 'R-BC4'],
  ellipsisRef: 'R-ELLIPSIS',
  maxVisible: 3,
  currentRef: 'R-BC4',
});

trail.expand(); // same effect as the user clicking the ellipsis
```

Past `maxVisible` items, everything except the root item and the trailing run collapses behind `R-ELLIPSIS`, which expands the full trail on click (shadcn's `BreadcrumbEllipsis`).

## 23. Button Group Of Independent Buttons

```ts
ui.render(
  'F-ROOT-D-ROW .R-BG-F-BUTTONGROUP-D-ROW .R-LIST-M-VIEW-A-CLICK. .R-GRID-M-VIEW-A-CLICK. .R-MAP-M-VIEW-A-CLICK...',
  app,
);

createArkButtonGroup(ui, {
  rootRef: 'R-BG',
  itemRefs: ['R-LIST', 'R-GRID', 'R-MAP'],
});
```

Each button stays independent (its own click handler, its own disabled state) — the primitive only adds `role="group"`, joined-border styling, and arrow-key roving focus across the three. For a set where exactly one (or a fixed multiple) should read as *pressed*, use `createArkToggleGroup(...)` instead — that's the shared-selection version of this shape.

## 24. Message Bubble Thread And A Notification Dot

```ts
ui.render(
  'F-ROOT-D-COLUMN ' +
  '.R-MSG1-F-MESSAGEBUBBLE .R-MSG1TXT-M-CONTENT. .R-MSG1TS-M-CAPTION.. ' +
  '.R-MSG2-F-MESSAGEBUBBLE .R-MSG2TXT-M-CONTENT. .R-MSG2TS-M-CAPTION.. ' +
  '.R-BELL-M-CONTENT. .R-UNREAD-M-BADGE.',
  app,
);
ui.update('R-MSG1TXT', { text: 'Sync finished.' });
ui.update('R-MSG1TS', { text: '2:40 PM' });
ui.update('R-MSG2TXT', { text: 'Thanks!' });
ui.update('R-MSG2TS', { text: '2:41 PM' });

createArkMessageBubble(ui, { rootRef: 'R-MSG1', align: 'other', timestampRef: 'R-MSG1TS' });
createArkMessageBubble(ui, { rootRef: 'R-MSG2', align: 'own', timestampRef: 'R-MSG2TS', grouped: true });

const unread = createArkOverlayIndicator(ui, {
  anchorRef: 'R-BELL',
  indicatorRef: 'R-UNREAD',
  count: 3,
});
unread.setCount(0); // hides itself again once read
```

What you get:

- `data-align` (`own`/`other`) tail-side styling on each bubble, and `data-grouped` to collapse the treatment for a burst of consecutive messages from the same sender
- an overlay indicator that shows a capped count (`max`, default 99, renders "9+" past it) or a plain `dot: true` marker, positioned at any of the four corners, and hides itself automatically at a zero count

Both `timestampRef`/`statusRef` and `indicatorRef` need a real `M-` meaning in your markup (not a bare `F-` shape) — see the note above the `MESSAGEBUBBLE` schema entry in `ark-ui.components.ts` for why.

## 25. Calendar With Bounds And Locale

```ts
createArkCalendar(ui, {
  gridRef: 'R-GRID',
  dayRefs: dayRefs, // 42 refs for a 6-week grid
  labelRef: 'R-LABEL',
  prevRef: 'R-PREV',
  nextRef: 'R-NEXT',
  month: 2,
  year: 2026,
  minDate: new Date(2026, 2, 1),
  maxDate: new Date(2026, 5, 30),
  locale: 'fr-FR', // "mars 2026" instead of "March 2026"
  onDateChange: (date) => bookAppointment(date),
});
```

Dates outside `minDate`/`maxDate` are disabled the same as an explicit `disabledDates` entry. Focus a day cell and press PageUp/PageDown to step a month (Shift+PageUp/PageDown steps a year instead) — both clamp to the target month's real length, so paging from Mar 31 into February lands on Feb 28/29, not an overflow into March.

## 26. Aspect Ratio Media Shell

```ts
ui.render('F-ROOT-D-COLUMN .R-SHELL-F-CONTAINER .R-IMG-M-CONTENT..', app);

createArkAspectRatio(ui, {
  containerRef: 'R-SHELL',
  ratio: 16 / 9,
});
```

A thin CSS wrapper — locks `R-SHELL` to the given ratio and makes any child (an image, a video, a map embed) fill it via `object-fit: cover`. Matches what Radix/Base UI's own AspectRatio does; there's no imperative state to manage.

## 27. Checkbox With Indeterminate "Select All"

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-ALL-M-CHECKBOX. .R-I1-M-CHECKBOX. .R-I2-M-CHECKBOX. .R-I3-M-CHECKBOX.',
  app,
);

const allRefs = ['R-I1', 'R-I2', 'R-I3'];

const selectAll = createArkCheckbox(ui, {
  triggerRef: 'R-ALL',
  onCheckedChange: (checked) => items.setValue(checked ? allRefs : []),
});

const items = createArkCheckboxGroup(ui, {
  itemRefs: allRefs,
  stateRef: 'R-ITEMSSTATE',
  onValueChange: (selectedRefs) => {
    // Re-derive R-ALL's tri-state from the group every time it changes.
    const allEl = ui.getElement('R-ALL');
    if (!allEl) return;
    if (selectedRefs.length === 0) { allEl.checked = false; allEl.indeterminate = false; }
    else if (selectedRefs.length === allRefs.length) { allEl.checked = true; allEl.indeterminate = false; }
    else { allEl.indeterminate = true; }
  },
});
```

What you get from `createArkCheckboxGroup(...)`: independent per-item `checked` state (each item stays its own Tab stop — no roving focus, unlike a radio group), a live `stateRef.selectedRefs` list, and `check()`/`uncheck()`/`toggle()`/`setValue()`. `createArkCheckbox(...)` only exposes `indeterminate` as an initial/reset value through its options, not a setter on the handle — for a derived tri-state like "select all," write `.indeterminate` on the live element directly, same as the primitive itself does internally.

## 28. Right-Click Context Menu

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-SURFACE-F-PANEL .R-SURFACETXT-M-CONTENT.. ' +
  '.R-CMANCHOR-M-CONTENT. ' +
  '.R-CMENU-F-MODAL-D-COLUMN .R-COPY-M-ALPHA-A-CLICK. .R-PASTE-M-BETA-A-CLICK. .R-DELETE-X-DANGER-M-DELETE-A-CLICK...',
  app,
);

createArkContextMenu(ui, {
  targetRef: 'R-SURFACE',
  anchorRef: 'R-CMANCHOR',
  contentRef: 'R-CMENU',
  itemRefs: ['R-COPY', 'R-PASTE', 'R-DELETE'],
});
```

Right-clicking anywhere inside `R-SURFACE` opens `R-CMENU` at the pointer — `R-CMANCHOR` never needs its own visible markup; the primitive keeps it at zero size and moves it to the click point behind the scenes. Everything else (Escape to close, outside-click dismiss, roving focus across items, disabled items) is `createArkMenu(...)`'s existing behavior, reused as-is.

## 29. Autoplaying Carousel With Keyboard Nav

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-CVIEW-F-SECTION .R-CTRACK-F-SECTION-D-ROW .R-S1-M-CONTENT. .R-S2-M-CONTENT. .R-S3-M-CONTENT... ' +
  '.R-CPREV-M-CANCEL-A-CLICK. .R-CNEXT-M-SAVE-A-CLICK.',
  app,
);

const carousel = createArkCarousel(ui, {
  viewportRef: 'R-CVIEW',
  trackRef: 'R-CTRACK',
  slideRefs: ['R-S1', 'R-S2', 'R-S3'],
  prevRef: 'R-CPREV',
  nextRef: 'R-CNEXT',
  loop: true,
  autoplay: 6000,
  label: 'Featured items',
});
```

Autoplay pauses the moment a pointer enters the viewport or focus lands inside it (e.g. a slide's own link), and resumes on pointer-leave/blur — the same default every production carousel ships. Focus anything inside `R-CVIEW` and press Arrow Left/Right (or Up/Down for a `orientation: 'vertical'` carousel) to step manually; `carousel.pauseAutoplay()`/`resumeAutoplay()` are there for an explicit play/pause control too.

## 30. IdentityAuth — Create/Unlock Gate For A Local, On-Device Identity

Use `createArkIdentityAuth(...)` for a full-screen (or modal) sign-in gate in front of an app whose identity lives only on the device — a "choose" panel (create/recover), a "create" panel (callsign + PIN[+password]), and an "unlock" panel (PIN[+password] for an identity already bound on this device). Unlike every other entry in this cookbook, it does **not** take a `ui.render(...)` pattern string — hand it a mount element and it builds and styles its own markup from `ArkTokens`, the same "hand it a mount point, get back an element" shape most apps already use for hand-rolled chrome. It owns markup, inline theming, client-side validation, and one shared status line; it has no opinion on vault crypto, IPC, or persistence.

```ts
const identityAuth = createArkIdentityAuth(ui, {
  mount: document.getElementById('lockScreenMount'),
  tokens: darkTokens,
  onCreate: async (callsign, pin, password) => {
    await myVault.provision(callsign, pin, password); // throw to surface an error status
  },
  onUnlock: async (pin, password) => {
    await myVault.unlock(pin, password);
  },
  onRecover: () => openMyOwnRecoveryFlow(),
});

identityAuth.setMode('unlock');
identityAuth.setUnlockIdentityLabel('night-owl');
```

What you get:

- three panels (`choose`/`create`/`unlock`) toggled by `setMode(...)`, each with its own copy (fully overridable via `options.copy`)
- client-side validation on submit: callsign required, PIN must match `/^\d{6,12}$/`, PIN must be at least 8 digits when no password is set, PIN must equal its confirmation — all surfaced through one status line (`setStatus(text, tone)`), not per-field tooltips
- `onCreate`/`onUnlock` are only called once validation passes, and may return a promise — `setBusy(true)` runs automatically for the duration, disabling every control, and a thrown/rejected error is written to the status line for you
- `onRecover`/`onBack` hooks with no opinion on what recovery UI looks like — that's a separate, app-owned flow (see ark-tlm-desktop's `openIdentityRecovery()`)

## 31. Resizable Split-Pane Layout

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-SPLIT-F-SECTION-D-ROW .R-SIDEBAR-F-SECTION. .R-HANDLE-F-SECTION. .R-CONTENT-F-SECTION...',
  app,
);

const split = createArkResizablePanels(ui, {
  containerRef: 'R-SPLIT',
  panelRefs: ['R-SIDEBAR', 'R-CONTENT'],
  handleRefs: ['R-HANDLE'],
  sizes: [0.25, 0.75],
  minSizes: [0.15, 0.4],
  stateRef: 'R-SPLITSTATE',
});

split.setSizes([0.3, 0.7]); // e.g. restoring a saved layout
```

Drag `R-HANDLE` (pointer) or focus it and press Arrow Left/Right (or Up/Down for `orientation: 'vertical'`) to resize. `minSizes` clamps each panel's share — if the sidebar hits its floor, the extra drag distance simply doesn't move it further rather than overshooting into the content pane.

## 32. Message Thread With Auto-Scroll And Unread Indicator

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-THREAD-F-SECTION-D-COLUMN .R-MSG1-F-MESSAGEBUBBLE .R-MSG1TXT-M-CONTENT... . .R-UNREAD-M-BADGE-A-CLICK.',
  app,
);

const scroller = createArkMessageScroller(ui, {
  viewportRef: 'R-THREAD',
  unreadRef: 'R-UNREAD',
  stateRef: 'R-SCROLLSTATE',
});

function appendMessage(text) {
  // ...append a new createArkMessageBubble() row into R-THREAD...
  scroller.notifyNewContent();
}
```

If the reader is at the bottom of the thread, `notifyNewContent()` scrolls the new message into view automatically. If they've scrolled up to read history, it increments the count on `R-UNREAD` instead of yanking their scroll position — clicking `R-UNREAD` jumps to the bottom and clears the count.

## 33. Custom Scrollbar With Draggable Thumbs

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-VIEWPORT-F-SECTION. .R-SBY-F-SECTION. .R-THUMBY-F-SECTION. .R-CORNER-F-SECTION.',
  app,
);

createArkScrollArea(ui, {
  viewportRef: 'R-VIEWPORT',
  scrollbarYRef: 'R-SBY',
  thumbYRef: 'R-THUMBY',
  cornerRef: 'R-CORNER', // only shown when both an X and a Y scrollbar are wired
});
```

The thumb resizes/repositions on every `scroll`/`mouseenter` and once immediately at setup. Dragging `R-THUMBY` scrolls the viewport proportionally — the drag tracks the pointer's *delta* from where it started, not its live position, so a fast flick past the track's edge clamps cleanly instead of overshooting.

## 34. Sortable, Sticky-Header Table With A Footer Total

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-TBL-F-TABLE .R-CAP-F-TABLECAPTION. .R-THEAD-F-THEAD .R-HNAME-F-HEADERCELL-A-CLICK. .R-HTOTAL-F-HEADERCELL-A-CLICK.. .R-ROW1-F-ROW .R-NAME1-F-CELL.. .R-ROW2-F-ROW .R-NAME2-F-CELL.. .R-TFOOT-F-TABLEFOOTER...',
  app,
);

const table = createArkTable(ui, {
  tableRef: 'R-TBL',
  captionRef: 'R-CAP',
  theadRef: 'R-THEAD',
  footerRef: 'R-TFOOT',
  itemRefs: ['R-ROW1', 'R-ROW2'],
  sortableHeaderRefs: ['R-HNAME', 'R-HTOTAL'],
  stickyHeader: true,
  stickyFirstColumnRefs: ['R-NAME1', 'R-NAME2'],
  onSortChange: (headerRef, direction) => {
    // direction is 'asc' | 'desc' | undefined — reorder your row data and
    // re-render R-ROW1/R-ROW2 in the new order (this primitive marks the
    // sorted column via aria-sort; it doesn't reorder rows for you)
  },
});

table.sortBy('R-HTOTAL', 'desc'); // e.g. restoring a saved sort
```

Clicking a sortable header cycles none → asc → desc → none, clearing any other column's `aria-sort` marker. This is the lightweight, single-column version — for sorting that also reorders row data and paginates, use `createArkDataTable(...)` instead.

## 35. Verification Code Input

```ts
ui.render(
  'F-ROOT-D-COLUMN .R-OTP-F-OTP .R-S0-F-OTPSLOT. .R-S1-F-OTPSLOT. .R-S2-F-OTPSLOT. .R-S3-F-OTPSLOT...',
  app,
);

const otp = createArkInputOtp(ui, {
  rootRef: 'R-OTP',
  slotRefs: ['R-S0', 'R-S1', 'R-S2', 'R-S3'],
  onComplete: (code) => submitVerificationCode(code),
});

otp.clear(); // e.g. after a failed verification attempt
```

Typing in any slot auto-advances to the next one; Backspace on an empty slot clears and refocuses the previous slot; pasting a full code into any slot fans it out across the remaining slots from that point. `onComplete` fires the moment every slot has a character — the natural place to auto-submit.

## 36. RTL Language Switch

```ts
ui.render('F-ROOT-D-COLUMN .R-APP-F-SECTION.', app);

const direction = createArkDirection(ui, { rootRef: 'R-APP', dir: 'ltr' });

languageSwitcher.onChange((locale) => {
  direction.setDirection(isRtlLocale(locale) ? 'rtl' : 'ltr');
});
```

Every horizontal collection nested under `R-APP` — accordion, tabs, menubar, carousel, anything built on `createRovingFocusGroup(...)` — reads this `dir` attribute at Arrow-key time via `isRtlContext()` and flips Left/Right automatically. There's no separate RTL wiring needed per component; owning this one provider is the whole job.

## 37. Date-Range Picker

```ts
const datePicker = createArkDatePicker(ui, {
  triggerRef: 'R-DPTRIGGER',
  contentRef: 'R-DPCONTENT',
  valueRef: 'R-DPVALUE',
  gridRef: 'R-DPGRID',
  dayRefs, // your 42 day-cell refs
  labelRef: 'R-DPLABEL',
  mode: 'range',
  formatDate: (date) => date.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
  onRangeChange: (range) => {
    // range.end is undefined between the first and second pick
    if (range.start && range.end) applyDateFilter(range.start, range.end);
  },
});
```

Style the highlighted band with the day cells' `data-range-start` / `data-range-middle` / `data-range-end` attributes — e.g. square corners on the middle days and rounded caps only at the two ends. The popover stays open after the first pick (there'd be no way to ever choose an end date otherwise) and only closes once the range is complete; `valueRef` gets `formatRange(range)` (default: two `formatDate()` calls joined with " - ") at that point.

## 38. Data Table With A Pinned, Resizable Name Column

```ts
const table = createArkDataTable(ui, {
  tableRef: 'R-TBL',
  theadRef: 'R-THEAD',
  itemRefs: rowRefs,
  headerRefs: ['R-HNAME', 'R-HEMAIL', 'R-HROLE'],
  columns: [
    { headerRef: 'R-HNAME', accessor: (rowRef) => nameOf(rowRef), cellRefs: nameCellRefs, width: 200, minWidth: 120 },
    { headerRef: 'R-HEMAIL', accessor: (rowRef) => emailOf(rowRef), cellRefs: emailCellRefs },
    { headerRef: 'R-HROLE', accessor: (rowRef) => roleOf(rowRef), cellRefs: roleCellRefs, width: 100 },
  ],
  pinnedColumnRefs: ['R-HNAME'], // stays visible while Email/Role scroll underneath it
  resizeHandleRefs: ['R-HNAMERESIZE'], // a thin grip element at R-HNAME's trailing edge
});

table.hideColumn('R-HROLE'); // e.g. a "columns" toggle menu
table.setColumnWidth('R-HEMAIL', 280); // e.g. restoring a saved layout
```

`resizeHandleRefs` lines up by index with `headerRefs` — only give a handle to the columns you want resizable. Pinned columns stack left-to-right in the order listed in `pinnedColumnRefs`; each one's sticky offset is measured off the columns pinned before it, so resizing `R-HNAME` automatically keeps anything pinned after it aligned. `columns[].cellRefs` is what makes hide/pin/resize reach each row's actual cell, not just the header — `createArkDataTable(...)`'s existing sort/pagination behavior only ever needed `accessor()`, never the cells themselves.

## 39. Grouped Combobox Options

```ts
createArkCombobox(ui, {
  inputRef: 'R-CB',
  contentRef: 'R-CBLIST',
  optionRefs: ['R-APPLE', 'R-APRICOT', 'R-BEET'],
  groups: [
    { groupRef: 'R-FRUITGROUP', labelRef: 'R-FRUITLABEL', optionRefs: ['R-APPLE', 'R-APRICOT'] },
    { groupRef: 'R-VEGGROUP', labelRef: 'R-VEGLABEL', optionRefs: ['R-BEET'] },
  ],
});
```

`optionRefs` stays the single flat list driving filtering, arrow-key highlight order, and roving focus — `groups` only adds the visual/semantic grouping on top of it, so every ref inside a group must also appear in `optionRefs`. Typing a query that matches nothing in a group hides that group's `groupRef` (heading included) the same way `emptyRef` hides when nothing matches at all.

## 40. Marketing Site Header With Mega Menu Panels

```ts
const nav = createArkMegaMenu(ui, {
  rootRef: 'R-NAV',
  items: [
    { triggerRef: 'R-PRODUCTS', contentRef: 'R-PRODUCTSPANEL' },
    { triggerRef: 'R-SOLUTIONS', contentRef: 'R-SOLUTIONSPANEL' },
    { triggerRef: 'R-PRICING', contentRef: 'R-PRICINGPANEL' },
  ],
  // openOnHover defaults to true — a real mouse move away from both the
  // trigger and the panel is what actually closes it (hoverCloseDelay),
  // so crossing the gap between them doesn't flicker the panel shut
  hoverOpenDelay: 100,
  hoverCloseDelay: 200,
});

nav.open('R-PRICING'); // e.g. deep-linking to a section with its menu pre-opened
```

Each `contentRef` panel holds whatever markup that section needs — link columns, a promo card, a featured-product image — unlike `createArkMenu(...)`'s flat `itemRefs` list. Only one panel is ever open at a time; opening a second trigger closes the first automatically. Keyboard users get the same experience without a mouse: Arrow Left/Right moves between top-level triggers, ArrowDown/Enter/Space opens the focused one's panel, and Escape closes it — all without hover ever entering the picture.

## 41. Native Chart With Live Data And Resize

```ts
ui.render('F-ROOT-D-COLUMN .R-REVCHART-F-CHART.', app);

const chart = createArkChart(ui, {
  containerRef: 'R-REVCHART',
  type: 'area',
  categories: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
  series: [
    { label: 'Revenue', values: [820, 932, 901, 934, 1290], color: '#22c55e' },
  ],
  valueFormat: (value) => `$${Math.round(value)}`,
  onHoverChange: (point) => {
    // point is undefined on hover-out
  },
});

// live update, e.g. from a polling/subscription callback
socket.on('revenue', (values) => chart.setSeries([{ label: 'Revenue', values, color: '#22c55e' }]));

// keep it responsive to layout changes you already observe elsewhere
const observer = new ResizeObserver(() => chart.resize());
observer.observe(ui.getElement('R-REVCHART'));
```

Give `containerRef` the `CHART` style part for the shipped look (border, padding, a `color` token the axis text/gridlines inherit via `currentColor`). Multiple `series` entries group as side-by-side bars (`type: 'bar'`) or overlapping lines/filled areas (`type: 'line'`/`'area'`) — each gets its own color from `series[].color` or the built-in palette cycled by index.

## Verification

These patterns are covered by:

- [tests/test-primitives.mjs](tests/test-primitives.mjs)
- [tests/test-accessibility.mjs](tests/test-accessibility.mjs)
- [tests/browser-primitives.mjs](tests/browser-primitives.mjs)
