# Migrating From shadcn/ui

ARK is not a code-copy generator. The migration path is to move repeated wrapper logic into ARK runtime patterns and native primitive helpers.

## Mapping

- `components.json` -> `ark-ui.components.json`
- `npx shadcn add ...` -> `npx ark-ui init` plus direct package imports
- app-local utility fragments -> `@deadark/ark-ui/utilities`
- form wrapper glue -> `@deadark/ark-ui/adapters`

## Migration Steps

1. Replace deep local component copies with imports from `@deadark/ark-ui/components`.
2. Move typography, surfaces, and tone back to Dead Ark theme tokens.
3. Replace local form-controller glue with ARK adapters.
4. Replace one-off `cn()` style affordances with runtime/styler rules or utility helpers.

## What Changes Architecturally

- shadcn optimizes for copied code ownership.
- ARK optimizes for package-native primitives, semantic runtime patterns, and shared Dead Ark theme behavior.

That means ARK should remove repeated glue code over time instead of multiplying it across apps.
