# ARK UI Getting Started

`ark-ui` now starts in the browser, not in a framework wrapper.

The fastest way to understand the system is:

1. Build the browser-native runtime.
2. Run the planner demo.
3. Walk the live workflow.
4. Package the app into `.flx`.
5. Verify the package.
6. Unpack the artifact and verify it still runs.

If you want the full step-by-step, start with [docs/GOLDEN_PATH.md](docs/GOLDEN_PATH.md).

## Fast Start

```bash
cd /path/to/ark-ui
npm install
npm run build
ark dev examples/todo --port 4173
ark build examples/todo --out-dir dist/todo
ark verify dist/todo/app.flx --pretty
```

Then open `http://127.0.0.1:4173/`.

In the demo:

1. Open `Compose task`.
2. Enter a title and note.
3. Pick a status with `flux-select`.
4. Pick an assignee with `flux-combobox`.
5. Pick a due date with `flux-datepicker`.
6. Save the task.
7. Open `Quick command`.
8. Navigate to `Settings`.

That flow proves:

- DOM-first rendering
- `data-flx` state binding
- native `flux-*` custom elements
- route swaps without a framework runtime
- buildless local development

## What You Use

- `ark dev`: serve HTML and ESM directly from a project root
- `ark build`: emit compacted browser assets plus an `app.flx` package
- `ark inspect`: summarize a package artifact
- `ark verify`: prove package and unpacked-file integrity from manifest checksums
- `ark serve`: run an `app.flx` package directly as a live app
- `ark unpack`: reconstruct runnable files from an `app.flx` package

## What Ships Today

- `flux-dom`: reactive DOM binding over `.flx` state
- `flux-router`: route swaps without React Router or Next.js
- `flux-button`, `flux-dialog`, `flux-menu`, `flux-tabs`
- `flux-select`, `flux-combobox`, `flux-calendar`, `flux-datepicker`
- `flux-popover`, `flux-command`, `flux-sheet`, `flux-drawer`

## Package Surface

If you are consuming `ark-ui` as a package rather than working from this repo, the main entry points are still:

- `@deadark/ark-ui/runtime`
- `@deadark/ark-ui/primitives`
- `@deadark/ark-ui/components`
- `@deadark/ark-ui/core`
- `@deadark/ark-ui/page-builders`
- `@deadark/ark-ui/flux-dom`
- `@deadark/ark-ui/flux-router`
- `@deadark/ark-ui/elements`
- `@deadark/ark-ui/config`
- `@deadark/ark-ui/adapters`
- `@deadark/ark-ui/utilities`

## Which Layer Do I Want

`primitives` -> `components` -> `core` -> `page-builders` is a strict
dependency chain (see
[docs/architecture/COMPONENT_LAYER_MODEL.md](docs/architecture/COMPONENT_LAYER_MODEL.md)) —
each layer only imports the one below it. Pick the highest layer that fits
the job, and drop down only when it doesn't:

1. **Reach for a Page Builder first** (`@deadark/ark-ui/page-builders`, see
   [docs/architecture/PAGE_BUILDER_SCHEMA.md](docs/architecture/PAGE_BUILDER_SCHEMA.md))
   — a schema-driven full page. `buildArkDashboardPage`/`buildArkSettingsPage`/
   `buildArkAdminTablePage` cover dashboard, settings, and admin-table
   shapes; see [examples/admin-console](examples/admin-console/) for a real
   one. If your page doesn't fit any of the three, assemble it by hand from
   Core Components instead.
2. **Drop to a Core Component** (`@deadark/ark-ui/core`, see
   [CORE_COMPONENTS.md](CORE_COMPONENTS.md)) when a builder's schema
   doesn't fit your case, or none exists yet — e.g. "I need a data table"
   is `createArkCoreDataTable()`, not a hand-assembled table + pagination +
   toolbar.
3. **Drop to a Layered Component** (`@deadark/ark-ui/components`, styled
   parts like `CARD`/`DIALOG` plus a primitive) when you're hand-building a
   page from themed pieces — e.g. "I need a themed button" is a styled
   `A-CLICK` node via `registerArkComponents()`, no Core composite needed.
4. **Drop to a Primitive** (`@deadark/ark-ui/primitives`, see
   [PRIMITIVES.md](PRIMITIVES.md)) only when you're building a new Layered
   Component yourself — unstyled behavior with no visual opinion.

## Recommended Reading Order

1. [docs/GOLDEN_PATH.md](docs/GOLDEN_PATH.md)
2. [README.md](README.md)
3. [docs/MIGRATING_FROM_REACT_NEXT.md](docs/MIGRATING_FROM_REACT_NEXT.md)
4. [examples/react-migration/index.html](examples/react-migration/index.html)
5. [PRIMITIVES.md](PRIMITIVES.md)

## The Honest Frame

This is not “React components with different branding.” It is a browser-native interface system:

- HTML is the app surface
- `data-flx` is the binding layer
- Web Components are the primitive model
- `.flx` packages are the delivery artifact
