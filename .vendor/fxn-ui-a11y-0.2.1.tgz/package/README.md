# @fxn/ui-a11y

Reusable, framework-neutral accessibility wiring shared across `@fxn/ui-primitives`
factories: ref normalization, ARIA/attribute sync helpers (`./dom`), and the
focus-scope/dismissable-layer/presence *composition* recipes overlay
primitives (dialog, popover, ...) build on (`./overlay`).

## Scope note

The low-level focus-trap, outside-click/escape dismissal, and mount/unmount
presence *mechanics* remain implemented once, in `@fxn/ui`'s runtime
(`createFocusScope`/`activateFocusScope`, `createDismissableLayer`/
`handleOutsidePointer`/`handleOutsideFocus`, `createPresence`) — that engine
is tightly coupled to the runtime's ref table, portal stack, and DOM writer,
and extracting it is a larger, separate piece of work than this package
takes on. What this package owns is the smaller, genuinely reusable layer
above that: normalizing ref names, syncing ARIA/data attributes onto a ref
consistently, and the *configuration recipe* (what a modal dialog's focus
scope should look like vs. a non-modal popover's) that primitive factories
were previously duplicating inline.

## Usage

```js
import { normalizeRef, setAttrs, syncModelRef } from "@fxn/ui-a11y/dom";
import { configureFocusScope, configureDismissableLayer, configurePresence } from "@fxn/ui-a11y/overlay";
```

Both modules are structurally typed against a minimal host interface
(`ArkA11yHost` / `ArkA11yOverlayHost`) rather than importing `@fxn/ui`
directly — any object exposing the small subset of methods used (as ARK UI's
`createArkUI()` instance already does) satisfies them.

## Generated ids: one reserved prefix (`./ids`, 0.2.0)

Every DOM id that Ark code generates starts with `ARK_GENERATED_ID_PREFIX`
(`"ark-r-"`). A CMS keys saved edits by element `id`; a counter id depends on
mount order, so a key built from it re-points (or names nothing) after any
restructuring. One prefix lets a key-deriver skip every generated id with one
test, and lets an authoring tool refuse a hand-written id that uses it.

```js
import { createArkGeneratedId, isArkGeneratedId, checkAuthoredId } from "@fxn/ui-a11y/ids";
createArkGeneratedId("flux-tabs");   // "ark-r-flux-tabs--1"
isArkGeneratedId("ark-r-title-3");   // true: never a stable key
checkAuthoredId("ark-r-hero");       // { ok: false, failure, needs, remedy }
```

- `ark-r-` is not new: the Ark UI runtime already emits `ark-<slug("R-...")>-N`,
  and defxn's `js/content/layout.js` already skips `/^ark-r-/`.
- Ids made here always contain `--` before the counter; the runtime's slug never
  does, so the two generators cannot collide.
- The counter lives on `globalThis` (registered symbol), so two bundles that
  each inline this module still hand out unique ids on one page.
- `@fxn/ui-elements` (tabs, combobox, command) and `@fxn/ui-primitives`
  (toast handles) generate through it. `@deadark/sdk/cms` refuses a block id with
  the prefix (`CMS_RESERVED_ID_PREFIX`, parity-tested against this constant).
