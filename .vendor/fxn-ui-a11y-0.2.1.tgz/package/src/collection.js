/**
 * Roving-tabindex / typeahead composition for the collection-shaped ARK
 * primitives — menu, menubar, mega menu, tabs, select, combobox, radio group,
 * toggle group, button group, breadcrumbs, pagination, calendar grid, and the
 * generic item collection.
 *
 * As with `overlay.js` and `live-region.js`, the *mechanism* — the single
 * `tabindex="0"` that travels with the active item, the arrow-key/Home/End
 * handling, the printable-character typeahead buffer — is implemented once in
 * `@fxn/ui`'s runtime (`createRovingFocusGroup()` in
 * ark-ui.runtime.ts), where it is entangled with the ref table and DOM writer.
 * What genuinely belongs here, and is what every one of those factories was
 * separately re-deriving in `ark-ui.components.ts`, is the *recipe*: the
 * orientation/loop/typeahead triple that makes a given widget's keyboard model
 * match its ARIA role, and the `${containerRef}-items` collection-id
 * convention that ties the group to the container that advertises it.
 */

/** The collection id a container ref's roving group is registered under. */
export function collectionIdFor(containerRef) {
  return `${containerRef}-items`;
}

/**
 * Registers a roving focus group. `orientation` decides which arrow keys move
 * focus, `loop` whether the ends wrap, and `typeahead` whether printable
 * characters jump to a matching item — the three knobs that separate, say, a
 * vertical looping menu with typeahead from a horizontal non-looping pagination
 * strip without it.
 */
export function configureRovingFocusGroup(ui, collectionId, config) {
  ui.createRovingFocusGroup(collectionId, config);
}

/**
 * The vertical/looping/typeahead recipe shared by menu-like popups: menus,
 * submenus, context menus, listboxes, and the combobox result list.
 */
export function configureMenuFocusGroup(ui, collectionId, refs, config = {}) {
  ui.createRovingFocusGroup(collectionId, {
    refs,
    orientation: "vertical",
    loop: config.loop ?? true,
    typeahead: config.typeahead ?? true,
  });
}

/**
 * The single-axis, no-typeahead recipe shared by tab lists, toggle/button
 * groups, and pagination — widgets whose items are labelled by position rather
 * than by a name a user would type toward.
 */
export function configureStripFocusGroup(ui, collectionId, refs, config = {}) {
  ui.createRovingFocusGroup(collectionId, {
    refs,
    orientation: config.orientation ?? "horizontal",
    loop: config.loop ?? true,
    typeahead: config.typeahead ?? false,
  });
}
