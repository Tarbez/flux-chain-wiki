/**
 * Focus-scope, dismissable-layer, and presence *composition* helpers.
 *
 * Important honesty note (see this package's README): the actual focus-trap,
 * outside-click/escape dismissal, and presence/unmount algorithms are
 * implemented once, in `@fxn/ui`'s runtime (`ark-ui.runtime.ts`,
 * functions `createFocusScope`/`activateFocusScope`, `createDismissableLayer`/
 * `activateDismissableLayer`/`handleOutsidePointer`/`handleOutsideFocus`, and
 * `createPresence`). That engine is deeply entangled with the runtime's ref
 * table, portal/overlay stack, and DOM writer — it is not something a
 * behavior-preserving "move" can lift out without rewriting it, and doing so
 * is explicitly out of scope for this batch (see ARK_UI_EVOLUTION_PLAN.md
 * Batch 3 vs. the runtime's actual structure).
 *
 * What *does* genuinely belong here, and is a real (not aspirational) shared
 * behavior layer: deciding *what a modal dialog's / non-modal popover's*
 * focus-scope, dismissable-layer, and presence configuration should look
 * like — the recipe, not the mechanism — so `createArkDialog` and
 * `createArkPopover` in `@fxn/ui-primitives` compose it identically
 * instead of each re-deriving it. These are the exact call sites moved,
 * unchanged, out of `ark-ui.components.ts`.
 */

export function configureFocusScope(ui, id, config) {
  ui.createFocusScope(id, config);
}

export function configureDismissableLayer(ui, id, config) {
  ui.createDismissableLayer(id, config);
}

export function configurePresence(ui, id, config) {
  ui.createPresence(id, config);
}

export function openOverlay(ui, ref) {
  ui.openOverlay(ref);
}

export function closeOverlay(ui, ref) {
  ui.closeOverlay(ref);
}

/**
 * Activates an already-configured focus scope without going through
 * `openOverlay()` — what a widget does when its popup is already mounted and
 * only focus needs to move into it (a menu re-opened by keyboard, a select
 * listbox whose content stays in the tree, a sheet whose panel animates).
 */
export function activateFocusScope(ui, scopeId) {
  ui.activateFocusScope(scopeId);
}

/**
 * The trigger/content open-state pairing shared by every disclosure-shaped
 * primitive that is *not* a full dialog: menus, submenus, sheets, sidebars,
 * navigation menus, and the alert/collapsible family.
 *
 * Both refs are updated together — the trigger so `aria-expanded` and the
 * runtime's state styling follow, the content so it hides and its presence is
 * tracked — and then the overlay stack is opened or closed. Splitting these,
 * as each factory used to do inline in `ark-ui.components.ts`, is how a
 * trigger's `aria-expanded` drifts out of sync with what is actually on
 * screen. Moved verbatim from that file's `setOpen()`.
 */
export function setOverlayOpen(ui, triggerRef, contentRef, open) {
  const triggerState = ui.get(triggerRef) || {};
  const contentState = ui.get(contentRef) || {};
  ui.update(triggerRef, { ...(typeof triggerState === "object" ? triggerState : {}), open });
  ui.update(contentRef, { ...(typeof contentState === "object" ? contentState : {}), open, hidden: !open });
  if (open) ui.openOverlay(contentRef);
  else ui.closeOverlay(contentRef);
}
