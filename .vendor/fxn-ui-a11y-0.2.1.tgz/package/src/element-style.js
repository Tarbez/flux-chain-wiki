/**
 * CSP-safe element style and visibility writing, moved verbatim (same logic,
 * same fallbacks, same single registry) out of `ark-ui.csp.ts` so primitive
 * factories extracted into `@fxn/ui-primitives` can reach it without
 * importing back into `@fxn/ui` — the dependency direction the
 * evolution plan requires (`ark-primitives -> ark-a11y`, never the reverse).
 * `createArkAccordion`'s panel-height measurement is the first such caller.
 *
 * It must live in exactly one module, not be copied per package: the
 * `data-ark-dynamic-style="dN"` ids are handed out from a single counter and
 * matched by a single `[data-ark-dynamic-style="dN"]` rule. Two independent
 * copies would both start at `d1` and cross-apply each other's rules to
 * unrelated elements. `ark-ui.csp.ts` therefore re-exports these rather than
 * keeping its own copy.
 *
 * Why a dynamic stylesheet rule at all rather than `el.style`: under a strict
 * Content-Security-Policy without `'unsafe-inline'`, writing the `style`
 * attribute is blocked. A nonce'd (or constructed) stylesheet is not, so every
 * imperative style write goes through a per-element rule and only falls back
 * to `el.style` when no stylesheet can be reached (SSR, a test harness, a
 * document that refuses `insertRule`).
 */

let dynamicStyleElement = null;
let constructedDynamicSheet = null;
let dynamicStyleCounter = 0;

const dynamicRules = new WeakMap();

function discoveredNonce() {
  const configured = globalThis.__ARK_UI_CSP_NONCE__;
  if (configured) return configured;
  const source = document.querySelector?.("script[nonce],style[nonce]");
  return source?.nonce || source?.getAttribute?.("nonce") || "";
}

function dynamicSheet() {
  const constructableDocument = document;
  if (typeof CSSStyleSheet === "function" && Array.isArray(constructableDocument.adoptedStyleSheets)) {
    if (!constructedDynamicSheet) {
      try {
        constructedDynamicSheet = new CSSStyleSheet();
        constructableDocument.adoptedStyleSheets = [...constructableDocument.adoptedStyleSheets, constructedDynamicSheet];
      } catch { constructedDynamicSheet = null; }
    }
    if (constructedDynamicSheet) return constructedDynamicSheet;
  }
  if (dynamicStyleElement?.isConnected && dynamicStyleElement.sheet) return dynamicStyleElement.sheet;
  dynamicStyleElement = document.querySelector?.("style[data-ark-ui-dynamic]") || null;
  if (!dynamicStyleElement) {
    dynamicStyleElement = document.createElement("style");
    dynamicStyleElement.setAttribute("data-ark-ui-dynamic", "");
    const nonce = discoveredNonce();
    if (nonce) dynamicStyleElement.setAttribute("nonce", nonce);
    document.head?.appendChild(dynamicStyleElement);
  }
  return dynamicStyleElement.sheet;
}

function ensureRule(el) {
  const existing = dynamicRules.get(el);
  if (existing) return existing;
  const sheet = dynamicSheet();
  if (!sheet?.insertRule) return null;
  const id = `d${++dynamicStyleCounter}`;
  el.setAttribute("data-ark-dynamic-style", id);
  try {
    const index = sheet.cssRules.length;
    sheet.insertRule(`[data-ark-dynamic-style="${id}"]{}`, index);
    const rule = sheet.cssRules[index];
    if (!rule?.style?.setProperty) {
      sheet.deleteRule?.(index);
      el.removeAttribute("data-ark-dynamic-style");
      return null;
    }
    const entry = { id, rule };
    dynamicRules.set(el, entry);
    return entry;
  } catch {
    el.removeAttribute("data-ark-dynamic-style");
    return null;
  }
}

/** Writes one CSP-safe property (custom properties included) onto an element. */
export function setArkElementStyle(el, property, value) {
  const normalizedProperty = property.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
  if (!/^(--[A-Za-z0-9_-]+|[A-Za-z][A-Za-z0-9-]*)$/.test(normalizedProperty)) return;
  const normalizedValue = value == null ? "" : String(value);
  const entry = ensureRule(el);
  if (!entry) {
    if (typeof el.style?.setProperty === "function") {
      if (normalizedValue) el.style.setProperty(normalizedProperty, normalizedValue);
      else el.style.removeProperty(normalizedProperty);
    } else if (el.style) {
      el.style[property] = normalizedValue;
    }
    return;
  }
  if (normalizedValue) entry.rule.style.setProperty(normalizedProperty, normalizedValue);
  else entry.rule.style.removeProperty(normalizedProperty);
}

/** Reads a property back, preferring this module's dynamic rule over `el.style`. */
export function getArkElementStyle(el, property) {
  const dynamic = dynamicRules.get(el)?.rule.style.getPropertyValue(property);
  if (dynamic) return dynamic;
  if (typeof el.style?.getPropertyValue === "function") return el.style.getPropertyValue(property);
  return el.style?.[property] || "";
}

/** `setArkElementStyle()` for a whole bag of properties. */
export function setArkElementStyles(el, styles) {
  for (const [property, value] of Object.entries(styles)) setArkElementStyle(el, property, value);
}

/**
 * Hides/shows an element through this module's CSP-safe dynamic-rule
 * mechanism instead of relying on the plain `hidden` attribute alone. The
 * `hidden` attribute's UA rule is easy to lose: any author class that also
 * sets an explicit `display` (e.g. a flex-layout step/panel class) has the
 * same specificity and, being later in the cascade, wins over `[hidden]` --
 * the element stays visible even though `hidden` is set. (See
 * ark-ui.runtime.ts's own presence rendering, which hit this exact trap and
 * works around it the same way.) This still sets/removes `hidden` and
 * `aria-hidden` for assistive tech and `:not([hidden])` selectors, but
 * drives the actual visibility through a rule this module guarantees wins.
 */
export function setArkElementHidden(el, hidden) {
  if (hidden) {
    el.setAttribute("hidden", "");
    el.setAttribute("aria-hidden", "true");
  } else {
    el.removeAttribute("hidden");
    el.removeAttribute("aria-hidden");
  }
  setArkElementStyle(el, "display", hidden ? "none" : "");
}
