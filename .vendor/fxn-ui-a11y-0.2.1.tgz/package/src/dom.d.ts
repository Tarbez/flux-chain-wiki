/**
 * Structural surface of the ARK UI runtime instance that the a11y/ARIA
 * wiring helpers in this package need. Deliberately NOT imported from
 * `@fxn/ui` — that would invert the dependency direction the
 * evolution plan requires (`ark-primitives -> ark-a11y`, never the other
 * way, and never a dependency back on `ark-ui` itself). The real object
 * returned by `ark-ui`'s `createArkUI()` already satisfies this shape
 * structurally, so no adapter code is needed at the call site.
 */
export interface ArkA11yRefConfig {
  attrs?: Record<string, string | number | boolean | null | undefined>;
  [key: string]: unknown;
}

export interface ArkA11yHost {
  getElement(ref: string): (HTMLElement & { attrs?: Record<string, string> }) | undefined;
  configureRef(ref: string, config: ArkA11yRefConfig): void;
  get(ref: string): unknown;
  update(ref: string, value: unknown): void;
}

/** Normalizes a ref name to the `R-` prefixed form the runtime expects. */
export declare function normalizeRef(value: string | undefined): string | undefined;

/** Normalizes an array of ref names. */
export declare function normalizeRefs(values: string[]): (string | undefined)[];

/**
 * Mutates a live DOM element's attribute directly, bypassing the
 * re-render that `configureRef()` would trigger. Use for attributes that
 * toggle on high-frequency pointer events, where a re-render would detach
 * the element mid-gesture.
 */
export declare function setLiveAttr(ui: ArkA11yHost, targetRef: string, name: string, value: string | undefined): void;

/** Merges (rather than replaces) an attrs bag onto a ref's configuration. */
export declare function setAttrs(ui: ArkA11yHost, targetRef: string, attrs: Record<string, string | undefined>): void;

/** Merges a state patch into whatever is currently stored at `targetRef`. */
export declare function syncModelRef(ui: ArkA11yHost, targetRef: string | undefined, patch: Record<string, unknown>): void;

/** Sets the `hidden` field on a ref's stored state, if the ref exists. */
export declare function setHidden(ui: ArkA11yHost, targetRef: string | undefined, hidden: boolean): void;

/** The rendered text content of a ref's element — `""` when it isn't mounted. */
export declare function textOf(ui: ArkA11yHost, targetRef: string): string;

/**
 * Reads the user-visible value of a control ref: the live element's
 * `.checked`/`.value` first, then the ref's stored `checked`/`selected`/`text`
 * state, then its rendered text. Checkbox/radio inputs and `role="switch"`
 * resolve to a boolean so validators see the checked state rather than the
 * `"on"` an unset native checkbox reports.
 */
export declare function getControlValue(ui: ArkA11yHost, controlRef: string): unknown;
