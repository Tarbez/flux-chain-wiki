export interface ArkLiveRegionConfig {
  politeness?: "polite" | "assertive";
  atomic?: boolean;
  relevant?: string;
  role?: "status" | "alert" | "log";
}

/**
 * Structural surface needed for live-region composition. As everywhere else
 * in this package this is declared, not imported from `@fxn/ui` —
 * the object `createArkUI()` returns already satisfies it.
 */
export interface ArkA11yLiveRegionHost {
  createLiveRegion(ref: string, config?: ArkLiveRegionConfig): void;
  announce(ref: string, text: string): void;
}

/** Declares `ref` as an ARIA live region with the given politeness/role. */
export declare function configureLiveRegion(ui: ArkA11yLiveRegionHost, targetRef: string, config?: ArkLiveRegionConfig): void;

/** Declares a polite `role="status"` region — the default for loading/progress copy. */
export declare function configureStatusRegion(ui: ArkA11yLiveRegionHost, targetRef: string): void;

/** Declares an assertive `role="alert"` region — for errors that interrupt. */
export declare function configureAlertRegion(ui: ArkA11yLiveRegionHost, targetRef: string): void;

/** Pushes `text` into an already-configured live region. */
export declare function announce(ui: ArkA11yLiveRegionHost, targetRef: string, text: string): void;
