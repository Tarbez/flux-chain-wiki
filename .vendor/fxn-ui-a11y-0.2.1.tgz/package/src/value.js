/**
 * Value/range normalization shared by ARK UI's range-shaped primitives —
 * progress, slider, pagination, carousel, and the calendar's day arithmetic.
 * Moved verbatim out of `ark-ui.components.ts`, where every one of those
 * factories reached for the same file-local helpers.
 *
 * These live in `@fxn/ui-a11y` rather than being duplicated per
 * primitive because the *accessible* value contract — `aria-valuenow` never
 * drifting outside the `aria-valuemin`/`aria-valuemax` a widget itself
 * advertises, and "is this the selected day" answering the same way for the
 * calendar grid's `aria-selected` as for its roving focus — depends on every
 * one of those widgets clamping and comparing identically.
 */

/** Clamps `value` into the inclusive `[min, max]` range. */
export function clampNumber(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

/** Stable `YYYY-M-D` identity for a date, ignoring the time component. */
export function dateKey(value) {
  return `${value.getFullYear()}-${value.getMonth()}-${value.getDate()}`;
}

/** True when both dates are present and fall on the same calendar day. */
export function sameDay(left, right) {
  return !!left && !!right && dateKey(left) === dateKey(right);
}

/** Midnight-normalized copy of a date, so day comparisons ignore the clock. */
export function dayOnly(value) {
  return new Date(value.getFullYear(), value.getMonth(), value.getDate());
}

/** Localized "March 2026"-style label for a calendar month header. */
export function formatCalendarLabel(month, year, locale) {
  return new Date(year, month, 1).toLocaleDateString(locale, { month: "long", year: "numeric" });
}
