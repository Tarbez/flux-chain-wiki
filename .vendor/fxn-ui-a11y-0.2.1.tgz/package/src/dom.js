/**
 * Reusable, framework-neutral DOM/ARIA wiring helpers shared by ARK UI's
 * primitive factories (dialog, popover, and — over future extraction
 * batches — the rest of the overlay/menu/select family).
 *
 * These functions are moved verbatim (byte-identical logic) out of
 * `ark-ui.components.ts`, where `createArkDialog` and `createArkPopover`
 * both carried their own copy. They operate against the small structural
 * "host" surface declared in `dom.d.ts` (`ArkA11yHost`) rather than the
 * concrete ARK UI runtime type, so this package has no build-time or
 * run-time dependency on `@fxn/ui` — the real `ArkUIInstance`
 * returned by `createArkUI()` already satisfies the structural shape.
 */

/** Normalizes a ref name to the `R-` prefixed form the runtime expects. */
export function normalizeRef(value) {
  if (!value) return undefined;
  return value.startsWith("R-") ? value : `R-${value}`;
}

/** Normalizes an array of ref names, dropping the `undefined` case. */
export function normalizeRefs(values) {
  return values.map((value) => normalizeRef(value));
}

/**
 * For attributes that toggle on high-frequency events (pointerdown/up/move).
 * `setAttrs()` goes through `configureRef()`, which unconditionally
 * re-renders and replaces the bound DOM element — firing that on every
 * pointerdown/up detaches the element mid-click, and Chromium (per spec)
 * then never fires the "click" event at all, since its mousedown target was
 * removed from the DOM before mouseup. That silently broke every
 * click-to-open trigger doing this. Mutate the live element's attribute
 * directly instead — no re-render.
 */
export function setLiveAttr(ui, targetRef, name, value) {
  const el = ui.getElement(targetRef);
  if (!el) return;
  if (value === undefined) el.removeAttribute(name);
  else el.setAttribute(name, value);
}

/**
 * `configureRef()`'s attrs merge is additive (old keys survive a call that
 * doesn't mention them, since repeated setup calls rely on that). Filtering
 * out `undefined` entries here used to mean an attribute that goes from
 * "true" back to unset (`data-open`, `data-dragging`, ...) would never
 * actually clear: the key was simply never mentioned again, so the stale
 * "true" from the last toggle stuck around forever. Passing the explicit
 * `undefined` through instead overrides the stored value; the renderer
 * already skips `undefined` attrs when writing the DOM, so this is what
 * makes a value -> unset transition actually take.
 */
export function setAttrs(ui, targetRef, attrs) {
  ui.configureRef(targetRef, { attrs });
}

/** Merges a state patch into whatever is currently stored at `targetRef`. */
export function syncModelRef(ui, targetRef, patch) {
  if (!targetRef) return;
  const current = ui.get(targetRef);
  ui.update(targetRef, {
    ...(current && typeof current === "object" ? current : {}),
    ...patch,
  });
}

/** Sets the `hidden` field on a ref's stored state, if the ref exists. */
export function setHidden(ui, targetRef, hidden) {
  if (!targetRef) return;
  const current = ui.get(targetRef) || {};
  ui.update(targetRef, { ...current, hidden });
}

/** The rendered text content of a ref's element — "" when it isn't mounted. */
export function textOf(ui, targetRef) {
  return ui.getElement(targetRef)?.textContent || "";
}

/**
 * Reads the *user-visible* value of an arbitrary control ref, resolving the
 * three places a value can actually live in this runtime, in the order the
 * assistive-technology-facing value follows:
 *
 *   1. the live element, for real form controls (`.checked` / `.value`);
 *   2. the ref's stored state, for controls the runtime models rather than
 *      renders as a native input (`checked` / `selected` / `text`);
 *   3. the rendered text, for everything else.
 *
 * Checkbox/radio inputs and `role="switch"` resolve to a boolean rather than
 * a string, so a field/form primitive validating them sees the checked state
 * and not the literal `"on"` that an unset `<input type=checkbox>.value`
 * reports. Moved verbatim out of `ark-ui.components.ts`.
 */
export function getControlValue(ui, controlRef) {
  const element = ui.getElement(controlRef);
  const state = ui.get(controlRef);
  const role = element?.attrs?.role;
  const type = element?.attrs?.type;
  if (type === "checkbox" || type === "radio" || role === "switch") {
    return !!(element?.checked ?? state?.checked ?? state?.selected);
  }
  if (element && "value" in element && typeof element.value !== "undefined" && element.value !== "") return element.value;
  if (state?.text !== undefined) return state.text;
  return textOf(ui, controlRef);
}
