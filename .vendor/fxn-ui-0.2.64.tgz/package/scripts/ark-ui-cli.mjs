#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import http from "node:http";
import crypto from "node:crypto";
import os from "node:os";
import { brotliCompressSync, brotliDecompressSync, gunzipSync, gzipSync, zstdCompressSync, zstdDecompressSync } from "node:zlib";
import { spawnSync } from "node:child_process";
import { fileURLToPath, pathToFileURL } from "node:url";
import { extractArkTemplateStudioBundle, parseArkTemplateStudioPayload } from "../dist/ark-ui.config.js";
import { looksLikeFlxArchiveBinary } from "../dist/ark-ui.flx-binary.js";
import {
  applyDelta,
  verifyRecoveryManifest,
  decodeArchive,
  diffArchives,
  encodeArchive,
  maxFlxDeltaChainLength,
  splitArchiveContinuations,
  verifyArchiveLineage,
  verifyArchiveStructure,
} from "../dist/ark-ui.flx-codec.js";
import {
  exportArkAccordionCode,
  exportArkAccordionCodeForAllTargets,
  exportArkTabsCode,
  exportArkTabsCodeForAllTargets,
} from "../dist/ark-ui.export.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const packageRoot = path.resolve(__dirname, "..");
const bundledRegistryPath = path.join(packageRoot, "ark-ui.components.json");
const bundledRegistry = JSON.parse(fs.readFileSync(bundledRegistryPath, "utf8"));

function printHelp() {
  process.stdout.write(
    [
      "ark-ui <command>",
      "",
      "Commands:",
      "  dev [dir]           Serve HTML and ESM directly from a project root",
      "  build [dir]         Copy/minify assets and prerender declared dynamic routes",
      "                      SEO options: --site-url <origin>",
      "  inspect [file]      Print package or archive metadata from an app.flx artifact",
      "  profile [file]      Print performance-oriented artifact and route stats",
      "  verify [file]       Validate an app.flx package, archive, or manifest",
      "  unpack [file] [dir] Reconstruct bundled assets from an app.flx artifact",
      "                      Options: --manifest-only | --route <path|routeId|blockId> | --asset <path>",
      "  reconstruct ...     Rebuild a full archive from a base archive and delta chain",
      "  serve [file]        Serve an app.flx package; use --ssr-module for dynamic routes",
      "                      Security: --csp-report-uri <url> --hsts [--hsts-preload]",
      "                      SSR limits: --request-timeout-ms --render-timeout-ms --max-ssr-concurrency",
      "                                  --max-request-bytes --max-stream-bytes --max-stream-chunks",
      "  init [dir]          Write ark-ui.components.json into a project",
      "  registry            Print the bundled ARK registry JSON",
      "  imports             Print recommended import entry points",
      "  code-export ...     Export component code for React, Next.js, Tailwind, shadcn, or Base UI",
      "  studio export ...   Build template/config/recipe-package artifacts from a config or bundle JSON",
      "  studio apply ...    Write a studio bundle into a consumer repo and optionally sync the SDK",
    ].join("\n") + "\n"
  );
}

function resolveTarget(dir = ".") {
  const targetDir = path.resolve(process.cwd(), dir);
  return path.join(targetDir, "ark-ui.components.json");
}

function writeRegistry(dir) {
  const target = resolveTarget(dir);
  fs.mkdirSync(path.dirname(target), { recursive: true });
  fs.writeFileSync(target, `${JSON.stringify(bundledRegistry, null, 2)}\n`, "utf8");
  process.stdout.write(`Wrote ${target}\n`);
}

function printImports() {
  process.stdout.write(
    [
      `runtime: ${bundledRegistry.runtimeImport}`,
      `components: ${bundledRegistry.componentsImport}`,
      `styler: ${bundledRegistry.stylerImport}`,
      `config: ${bundledRegistry.configImport}`,
      `adapters: ${bundledRegistry.adaptersImport}`,
      `utilities: ${bundledRegistry.utilitiesImport}`,
    ].join("\n") + "\n"
  );
}

function optionValue(args, name, fallback = null) {
  const index = args.indexOf(name);
  if (index === -1) return fallback;
  return args[index + 1] || fallback;
}

function hasOption(args, name) {
  return args.includes(name);
}

function parseNumericOption(args, name, fallback) {
  const raw = optionValue(args, name, String(fallback));
  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function parseBoundedNumericOption(args, name, fallback, minimum, maximum) {
  const value = Math.floor(parseNumericOption(args, name, fallback));
  return Math.min(maximum, Math.max(minimum, value));
}

function normalizeTransportCompression(value) {
  const normalized = String(value || "none").trim().toLowerCase();
  if (normalized === "none" || normalized === "identity") return "none";
  if (normalized === "gzip" || normalized === "gz") return "gzip";
  if (normalized === "brotli" || normalized === "br") return "brotli";
  if (normalized === "xz") return "xz";
  if (normalized === "zstd" || normalized === "zst") return "zstd";
  if (normalized === "7z" || normalized === "7zip") return "7z";
  throw new Error(`Unsupported transport compression: ${value}`);
}

function compressedArtifactPath(bundlePath, transportCompression) {
  if (transportCompression === "gzip") return `${bundlePath}.gz`;
  if (transportCompression === "brotli") return `${bundlePath}.br`;
  if (transportCompression === "xz") return `${bundlePath}.xz`;
  if (transportCompression === "zstd") return `${bundlePath}.zst`;
  if (transportCompression === "7z") return `${bundlePath}.7z`;
  return bundlePath;
}

function runWrapperCommand(command, args, input, action) {
  const result = spawnSync(command, args, { input, stdio: ["pipe", "pipe", "pipe"] });
  if (result.error) throw new Error(`${action} failed: ${result.error.message}`);
  if (result.status !== 0) {
    throw new Error(`${action} failed with exit code ${result.status}: ${String(result.stderr || "").trim() || "unknown error"}`);
  }
  return result.stdout;
}

function find7zBinary() {
  for (const candidate of ["7zz", "7z"]) {
    const result = spawnSync(candidate, ["--help"], { stdio: ["ignore", "ignore", "ignore"] });
    if (!result.error && result.status === 0) return candidate;
  }
  return null;
}

function run7zWrap(bytes) {
  const sevenZip = find7zBinary();
  if (!sevenZip) throw new Error("7z compression requires a local 7-Zip binary (`7zz` or `7z`) but none was found");
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "ark-ui-7z-"));
  try {
    const inputPath = path.join(tempDir, "app.flx");
    const archivePath = path.join(tempDir, "app.flx.7z");
    fs.writeFileSync(inputPath, Buffer.from(bytes));
    const result = spawnSync(sevenZip, ["a", "-t7z", "-mx=9", archivePath, inputPath], { stdio: ["ignore", "pipe", "pipe"] });
    if (result.error) throw new Error(`7z compression failed: ${result.error.message}`);
    if (result.status !== 0) throw new Error(`7z compression failed with exit code ${result.status}: ${String(result.stderr || "").trim() || "unknown error"}`);
    return fs.readFileSync(archivePath);
  } finally {
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

function run7zUnwrap(bytes) {
  const sevenZip = find7zBinary();
  if (!sevenZip) throw new Error("7z decompression requires a local 7-Zip binary (`7zz` or `7z`) but none was found");
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), "ark-ui-7z-"));
  try {
    const archivePath = path.join(tempDir, "app.flx.7z");
    fs.writeFileSync(archivePath, Buffer.from(bytes));
    const result = spawnSync(sevenZip, ["e", "-so", archivePath], { stdio: ["ignore", "pipe", "pipe"] });
    if (result.error) throw new Error(`7z decompression failed: ${result.error.message}`);
    if (result.status !== 0) throw new Error(`7z decompression failed with exit code ${result.status}: ${String(result.stderr || "").trim() || "unknown error"}`);
    return result.stdout;
  } finally {
    fs.rmSync(tempDir, { recursive: true, force: true });
  }
}

function encodeTransportLayer(bytes, transportCompression) {
  if (transportCompression === "gzip") return gzipSync(Buffer.from(bytes));
  if (transportCompression === "brotli") return brotliCompressSync(Buffer.from(bytes));
  if (transportCompression === "xz") return runWrapperCommand("xz", ["-z", "-c"], Buffer.from(bytes), "xz compression");
  if (transportCompression === "zstd") return zstdCompressSync(Buffer.from(bytes));
  if (transportCompression === "7z") return run7zWrap(bytes);
  return Buffer.from(bytes);
}

function detectTransportCompression(resolved, body) {
  if (resolved.endsWith(".gz")) return "gzip";
  if (resolved.endsWith(".br")) return "brotli";
  if (resolved.endsWith(".xz")) return "xz";
  if (resolved.endsWith(".zst") || resolved.endsWith(".zstd")) return "zstd";
  if (resolved.endsWith(".7z")) return "7z";
  if (body.byteLength >= 2 && body[0] === 0x1f && body[1] === 0x8b) return "gzip";
  if (body.byteLength >= 6 && body[0] === 0xfd && body[1] === 0x37 && body[2] === 0x7a && body[3] === 0x58 && body[4] === 0x5a && body[5] === 0x00) return "xz";
  if (body.byteLength >= 4 && body[0] === 0x28 && body[1] === 0xb5 && body[2] === 0x2f && body[3] === 0xfd) return "zstd";
  if (body.byteLength >= 6 && body[0] === 0x37 && body[1] === 0x7a && body[2] === 0xbc && body[3] === 0xaf && body[4] === 0x27 && body[5] === 0x1c) return "7z";
  return "none";
}

function decodeTransportLayer(body, transportCompression) {
  if (transportCompression === "gzip") return gunzipSync(body);
  if (transportCompression === "brotli") return brotliDecompressSync(body);
  if (transportCompression === "xz") return runWrapperCommand("xz", ["-d", "-c"], body, "xz decompression");
  if (transportCompression === "zstd") return zstdDecompressSync(body);
  if (transportCompression === "7z") return run7zUnwrap(body);
  return body;
}

function decodeRecoveryBytes(value) {
  if (value instanceof Uint8Array) return value;
  if (Array.isArray(value)) return Uint8Array.from(value);
  if (value && typeof value === "object" && Array.isArray(value.data)) return Uint8Array.from(value.data);
  if (typeof value === "string") return Uint8Array.from(Buffer.from(value, "base64"));
  return new Uint8Array();
}

function normalizeRecoveryPacket(packet) {
  return {
    ...packet,
    bytes: decodeRecoveryBytes(packet.bytes),
  };
}

function normalizeRecoveryShard(shard) {
  return {
    ...shard,
    bytes: decodeRecoveryBytes(shard.bytes),
  };
}

function looksLikeRecoveryManifest(parsed) {
  return parsed && typeof parsed === "object" && typeof parsed.parentArchiveId === "string" && typeof parsed.groupCount === "number"
    && Array.isArray(parsed.sources) && parsed.quorum && typeof parsed.quorum === "object";
}

function readRecoveryShardsFile(filePath) {
  const resolved = path.resolve(process.cwd(), filePath);
  const parsed = JSON.parse(fs.readFileSync(resolved, "utf8"));
  const shards = Array.isArray(parsed)
    ? parsed
    : Array.isArray(parsed?.shards)
      ? parsed.shards
      : [];
  return {
    resolved,
    shards: shards.map((shard) => normalizeRecoveryShard(shard)),
  };
}

function contentTypeFor(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".html") return "text/html; charset=utf-8";
  if (ext === ".js" || ext === ".mjs") return "text/javascript; charset=utf-8";
  if (ext === ".css") return "text/css; charset=utf-8";
  if (ext === ".json") return "application/json; charset=utf-8";
  if (ext === ".xml") return "application/xml; charset=utf-8";
  if (ext === ".svg") return "image/svg+xml";
  if (ext === ".png") return "image/png";
  if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
  if (ext === ".webp") return "image/webp";
  if (ext === ".avif") return "image/avif";
  if (ext === ".gif") return "image/gif";
  if (ext === ".woff") return "font/woff";
  if (ext === ".woff2") return "font/woff2";
  if (ext === ".ttf") return "font/ttf";
  if (ext === ".otf") return "font/otf";
  return "text/plain; charset=utf-8";
}

function cspHashSources(body, tagName) {
  if (!body) return [];
  const html = Buffer.isBuffer(body) || body instanceof Uint8Array ? Buffer.from(body).toString("utf8") : String(body);
  const pattern = tagName === "script"
    ? /<script\b(?![^>]*\bsrc\s*=)[^>]*>([\s\S]*?)<\/script\s*>/gi
    : /<style\b[^>]*>([\s\S]*?)<\/style\s*>/gi;
  const sources = new Set();
  for (const match of html.matchAll(pattern)) {
    const digest = crypto.createHash("sha256").update(match[1], "utf8").digest("base64");
    sources.add(`'sha256-${digest}'`);
  }
  return [...sources];
}

function cspReportTarget(extraArgs) {
  const target = optionValue(extraArgs, "--csp-report-uri", null);
  if (!target) return null;
  if (/[\s;"'\r\n]/.test(target)) throw new Error("--csp-report-uri must be a URL or absolute path without whitespace, quotes, or semicolons");
  if (!target.startsWith("/") && !/^https:\/\//i.test(target)) throw new Error("--csp-report-uri must use HTTPS or a same-origin absolute path");
  return target;
}

function hstsHeader(extraArgs) {
  if (!hasOption(extraArgs, "--hsts") && !extraArgs.includes("--hsts-max-age")) return null;
  const maxAge = parseBoundedNumericOption(extraArgs, "--hsts-max-age", 31_536_000, 0, 63_072_000);
  const preload = hasOption(extraArgs, "--hsts-preload");
  const includeSubDomains = preload || hasOption(extraArgs, "--hsts-include-subdomains");
  return `max-age=${maxAge}${includeSubDomains ? "; includeSubDomains" : ""}${preload ? "; preload" : ""}`;
}

function secureResponseHeaders(extraArgs, { development = false, nonce = null, body = null } = {}) {
  if (hasOption(extraArgs, "--no-security-headers")) return {};
  const nonceSource = nonce ? ` 'nonce-${nonce}'` : "";
  const scriptHashes = development ? [] : cspHashSources(body, "script");
  const styleHashes = development ? [] : cspHashSources(body, "style");
  const scriptSource = development ? "'self' 'unsafe-inline'" : ["'self'", ...scriptHashes].join(" ") + nonceSource;
  const styleSource = development ? "'self' 'unsafe-inline'" : ["'self'", ...styleHashes].join(" ") + nonceSource;
  const connectSource = development
    ? "'self' http://127.0.0.1:* http://localhost:* ws://127.0.0.1:* ws://localhost:*"
    : "'self'";
  const reportTarget = cspReportTarget(extraArgs);
  const reporting = reportTarget ? `; report-uri ${reportTarget}; report-to ark-csp` : "";
  const trustedTypes = development ? "" : "; require-trusted-types-for 'script'; trusted-types ark-ui";
  const headers = {
    "content-security-policy": `default-src 'self'; base-uri 'none'; object-src 'none'; frame-ancestors 'none'; form-action 'self'; script-src ${scriptSource}; script-src-attr 'none'; style-src ${styleSource}; style-src-attr 'none'; img-src 'self' data:; font-src 'self' data:; connect-src ${connectSource}; manifest-src 'self'${trustedTypes}${reporting}`,
    "cross-origin-opener-policy": "same-origin",
    "cross-origin-resource-policy": "same-origin",
    "permissions-policy": "camera=(), microphone=(), geolocation=(), payment=(), usb=()",
    "referrer-policy": "strict-origin-when-cross-origin",
    "x-content-type-options": "nosniff",
    "x-frame-options": "DENY",
  };
  if (reportTarget) headers["reporting-endpoints"] = `ark-csp=\"${reportTarget}\"`;
  const hsts = hstsHeader(extraArgs);
  if (hsts) headers["strict-transport-security"] = hsts;
  return headers;
}

function resolveDevRequest(rootDir, requestPath, entryFile) {
  const normalized = decodeURIComponent(String(requestPath || "/").split("?")[0]);
  if (normalized === "/dist" || normalized.startsWith("/dist/")) {
    const distRelative = normalized === "/dist" ? "" : normalized.slice("/dist/".length);
    const distCandidate = path.resolve(packageRoot, "dist", distRelative);
    const distRoot = path.resolve(packageRoot, "dist");
    if (!distCandidate.startsWith(distRoot)) return null;
    if (fs.existsSync(distCandidate) && fs.statSync(distCandidate).isFile()) return distCandidate;
    return null;
  }
  const requestedPath = normalized === "/" ? `/${entryFile}` : normalized;
  const candidate = path.resolve(rootDir, `.${requestedPath}`);
  if (!candidate.startsWith(rootDir)) return null;
  if (fs.existsSync(candidate) && fs.statSync(candidate).isFile()) return candidate;
  const nestedIndex = path.resolve(rootDir, `.${normalized}`, entryFile);
  if (nestedIndex.startsWith(rootDir) && fs.existsSync(nestedIndex) && fs.statSync(nestedIndex).isFile()) return nestedIndex;
  return null;
}

function proxyDevSidecar(request, response, extraArgs) {
  const securityHeaders = secureResponseHeaders(extraArgs, { development: true });
  const upstreamPath = String(request.url || "/").replace(/^\/__flxd/, "") || "/";
  const target = {
    hostname: optionValue(extraArgs, "--flxd-host", "127.0.0.1"),
    port: parseNumericOption(extraArgs, "--flxd-port", 8765),
    path: upstreamPath.startsWith("/") ? upstreamPath : `/${upstreamPath}`,
    method: request.method || "GET",
    headers: {
      ...(request.headers || {}),
      host: `${optionValue(extraArgs, "--flxd-host", "127.0.0.1")}:${parseNumericOption(extraArgs, "--flxd-port", 8765)}`,
    },
  };

  const upstream = http.request(target, (upstreamResponse) => {
    const headers = { ...securityHeaders, ...upstreamResponse.headers, "cache-control": "no-store" };
    delete headers["content-length"];
    headers["access-control-allow-origin"] = "*";
    headers["access-control-allow-methods"] = "GET,POST,OPTIONS";
    headers["access-control-allow-headers"] = "content-type";
    response.writeHead(upstreamResponse.statusCode || 502, headers);
    upstreamResponse.pipe(response);
  });

  upstream.on("error", (error) => {
    response.writeHead(502, { ...securityHeaders, "content-type": "application/json; charset=utf-8", "cache-control": "no-store" });
    response.end(JSON.stringify({
      ok: false,
      error: `flxd proxy failed: ${error.message}`,
      target: `http://${target.hostname}:${target.port}${target.path}`,
    }));
  });

  if ((request.method || "GET").toUpperCase() === "GET" || (request.method || "GET").toUpperCase() === "HEAD") {
    upstream.end();
    return;
  }
  request.pipe(upstream);
}

function runDevServer(dir, extraArgs) {
  const rootDir = path.resolve(process.cwd(), dir || ".");
  const host = optionValue(extraArgs, "--host", "127.0.0.1");
  const port = parseNumericOption(extraArgs, "--port", 4173);
  const entryFile = optionValue(extraArgs, "--entry", "index.html");

  const server = http.createServer((request, response) => {
    if (String(request.url || "/").startsWith("/__flxd")) {
      proxyDevSidecar(request, response, extraArgs);
      return;
    }
    const securityHeaders = secureResponseHeaders(extraArgs, { development: true });
    const filePath = resolveDevRequest(rootDir, request.url || "/", entryFile);
    if (!filePath) {
      response.writeHead(404, { ...securityHeaders, "content-type": "text/plain; charset=utf-8" });
      response.end("Not found");
      return;
    }
    const body = fs.readFileSync(filePath);
    response.writeHead(200, { ...securityHeaders, "content-type": contentTypeFor(filePath), "cache-control": "no-store" });
    response.end(body);
  });

  server.listen(port, host, () => {
    process.stdout.write(`ark-ui dev server running at http://${host}:${port}/\n`);
    process.stdout.write(`Serving ${rootDir}\n`);
  });
}

const BUILD_IGNORED_DIRS = new Set(["node_modules", ".git", "dist"]);
const BUILDABLE_EXTENSIONS = new Set([".html", ".js", ".mjs", ".css", ".json", ".svg", ".png", ".jpg", ".jpeg", ".webp", ".avif", ".gif", ".woff", ".woff2", ".ttf", ".otf"]);
const TEXT_BUILDABLE_EXTENSIONS = new Set([".html", ".js", ".mjs", ".css", ".json"]);
const MODULE_SPECIFIER_PATTERN = /\bimport\s+(?:[^"'`]+\s+from\s+)?["']([^"'`]+)["']|\bexport\s+[^"'`]*?\sfrom\s+["']([^"'`]+)["']|\bimport\(\s*["']([^"'`]+)["']\s*\)/g;
const HTML_MODULE_SRC_PATTERN = /(<script\b[^>]*\btype=["']module["'][^>]*\bsrc=["'])([^"']+)(["'][^>]*>)/gi;

function walkBuildFiles(rootDir, relativeDir = "") {
  const current = path.join(rootDir, relativeDir);
  const entries = fs.readdirSync(current, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    if (BUILD_IGNORED_DIRS.has(entry.name)) continue;
    const rel = path.join(relativeDir, entry.name);
    const full = path.join(rootDir, rel);
    if (entry.isDirectory()) files.push(...walkBuildFiles(rootDir, rel));
    else if (BUILDABLE_EXTENSIONS.has(path.extname(entry.name).toLowerCase())) files.push({ full, relative: rel.split(path.sep).join("/") });
  }
  return files;
}

function toPosixPath(value) {
  return value.split(path.sep).join("/");
}

function isRelativeSpecifier(specifier) {
  return specifier.startsWith("./") || specifier.startsWith("../");
}

function canBuildFile(filePath) {
  return BUILDABLE_EXTENSIONS.has(path.extname(filePath).toLowerCase());
}

function packageRelativePath(filePath) {
  const relative = path.relative(packageRoot, filePath);
  if (!relative || relative.startsWith("..") || path.isAbsolute(relative)) return null;
  return toPosixPath(relative);
}

function vendoredRelativePath(filePath) {
  const packaged = packageRelativePath(filePath);
  if (packaged) return `_vendor/${packaged}`;
  return `_vendor/external/${path.basename(filePath)}`;
}

function rewrittenSpecifier(fromRelativePath, targetRelativePath) {
  const fromDir = path.posix.dirname(fromRelativePath);
  const relative = path.posix.relative(fromDir, targetRelativePath);
  if (!relative || relative === "") return "./";
  return relative.startsWith(".") ? relative : `./${relative}`;
}

// Matches a bare `@deadark/<pkg>/<subpath>` specifier -- the sibling
// packages introduced by ARK_UI_EVOLUTION_PLAN.md 3.3 Batches 1-3
// (`@deadark/flux-state`, `@deadark/flux-dom`, `@fxn/ui-syntax`,
// `@fxn/ui-a11y`, `@fxn/ui-primitives`) and the earlier
// `@deadark/flx-codec` extraction. `@fxn/ui/*` itself is excluded --
// that's this package's own public surface, not an external dependency to
// vendor.
const BARE_SIBLING_SPECIFIER = /^@deadark\/([a-z0-9_-]+)\/(.+)$/;

function siblingPackageExportsMap(pkgName) {
  const pkgJsonPath = path.join(packageRoot, "node_modules", "@deadark", pkgName, "package.json");
  if (!fs.existsSync(pkgJsonPath)) return null;
  return JSON.parse(fs.readFileSync(pkgJsonPath, "utf8")).exports || {};
}

function resolveSiblingPackageSpecifier(specifier) {
  const match = specifier.match(BARE_SIBLING_SPECIFIER);
  if (!match) return null;
  const [, pkgName, subpath] = match;
  if (pkgName === "ark-ui") return null;
  const exportsMap = siblingPackageExportsMap(pkgName);
  const entry = exportsMap && exportsMap[`./${subpath}`];
  if (!entry) return null;
  const target = typeof entry === "string" ? entry : entry.import || entry.default;
  if (!target) return null;
  return path.join(packageRoot, "node_modules", "@deadark", pkgName, target.replace(/^\.\//, ""));
}

function resolveExternalDependency(ownerPath, specifier, rootDir) {
  const resolved = isRelativeSpecifier(specifier)
    ? path.resolve(path.dirname(ownerPath), specifier)
    : resolveSiblingPackageSpecifier(specifier);
  if (!resolved) return null;
  if (!fs.existsSync(resolved) || !fs.statSync(resolved).isFile()) return null;
  if (!canBuildFile(resolved)) return null;
  if (resolved.startsWith(rootDir) && isRelativeSpecifier(specifier)) return null;
  return {
    full: resolved,
    relative: vendoredRelativePath(resolved),
  };
}

function rewriteTextAssetReferences(file, source, rootDir, queueFile) {
  const ext = path.extname(file.full).toLowerCase();
  if (ext === ".js" || ext === ".mjs") {
    return source.replace(MODULE_SPECIFIER_PATTERN, (match, importSpecifier, exportSpecifier, dynamicSpecifier) => {
      const specifier = importSpecifier || exportSpecifier || dynamicSpecifier;
      const dependency = resolveExternalDependency(file.full, specifier, rootDir);
      if (!dependency) return match;
      queueFile(dependency);
      return match.replace(specifier, rewrittenSpecifier(file.relative, dependency.relative));
    });
  }
  if (ext === ".html") {
    return source.replace(HTML_MODULE_SRC_PATTERN, (match, prefix, specifier, suffix) => {
      const dependency = resolveExternalDependency(file.full, specifier, rootDir);
      if (!dependency) return match;
      queueFile(dependency);
      return `${prefix}${rewrittenSpecifier(file.relative, dependency.relative)}${suffix}`;
    });
  }
  return source;
}

function localAssetPath(htmlFile, sourceValue) {
  if (!sourceValue || /^(?:[a-z]+:|\/\/|data:|#)/i.test(sourceValue)) return null;
  const clean = sourceValue.split(/[?#]/)[0];
  return path.resolve(path.dirname(htmlFile), clean);
}

function imageDimensions(filePath) {
  if (!filePath || !fs.existsSync(filePath)) return null;
  const ext = path.extname(filePath).toLowerCase();
  const body = fs.readFileSync(filePath);
  if (ext === ".png" && body.length >= 24 && body.toString("ascii", 1, 4) === "PNG") {
    return { width: body.readUInt32BE(16), height: body.readUInt32BE(20) };
  }
  if (ext === ".gif" && body.length >= 10) return { width: body.readUInt16LE(6), height: body.readUInt16LE(8) };
  if (ext === ".svg") {
    const svg = body.toString("utf8", 0, Math.min(body.length, 4096));
    const width = /\bwidth=["']([\d.]+)/i.exec(svg)?.[1];
    const height = /\bheight=["']([\d.]+)/i.exec(svg)?.[1];
    const viewBox = /\bviewBox=["'][^"']*?([\d.]+)\s+([\d.]+)["']/i.exec(svg);
    if ((width && height) || viewBox) return { width: Math.round(Number(width ?? viewBox[1])), height: Math.round(Number(height ?? viewBox[2])) };
  }
  if ((ext === ".jpg" || ext === ".jpeg") && body[0] === 0xff && body[1] === 0xd8) {
    let offset = 2;
    while (offset + 9 < body.length) {
      if (body[offset] !== 0xff) { offset += 1; continue; }
      const marker = body[offset + 1];
      const length = body.readUInt16BE(offset + 2);
      if (marker >= 0xc0 && marker <= 0xc3) return { width: body.readUInt16BE(offset + 7), height: body.readUInt16BE(offset + 5) };
      if (length < 2) break;
      offset += 2 + length;
    }
  }
  return null;
}

function hasAttribute(tag, name) {
  return new RegExp(`\\s${name}(?:\\s*=|\\s|>)`, "i").test(tag);
}

function escapeRegExp(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function htmlPerformancePipeline(file, source) {
  const images = [];
  const scripts = [];
  let html = source.replace(/<img\b[^>]*>/gi, (tag) => {
    const src = /\bsrc=["']([^"']+)["']/i.exec(tag)?.[1];
    const asset = localAssetPath(file.full, src);
    const dimensions = imageDimensions(asset);
    const priority = /\b(?:fetchpriority=["']high["']|data-ark-priority=["']high["'])/i.test(tag);
    let optimized = tag;
    if (dimensions && !hasAttribute(optimized, "width")) optimized = optimized.replace(/\s*\/?>$/, ` width="${dimensions.width}"$&`);
    if (dimensions && !hasAttribute(optimized, "height")) optimized = optimized.replace(/\s*\/?>$/, ` height="${dimensions.height}"$&`);
    if (!hasAttribute(optimized, "decoding")) optimized = optimized.replace(/\s*\/?>$/, " decoding=\"async\"$&");
    if (!hasAttribute(optimized, "loading")) optimized = optimized.replace(/\s*\/?>$/, ` loading="${priority ? "eager" : "lazy"}"$&`);
    if (priority && !hasAttribute(optimized, "fetchpriority")) optimized = optimized.replace(/\s*\/?>$/, " fetchpriority=\"high\"$&");

    const responsive = [];
    if (asset) {
      const ext = path.extname(asset);
      const stem = path.basename(asset, ext);
      for (const name of fs.readdirSync(path.dirname(asset))) {
        const match = new RegExp(`^${escapeRegExp(stem)}-(\\d+)w${escapeRegExp(ext)}$`, "i").exec(name);
        if (match) responsive.push({ width: Number(match[1]), src: src.replace(new RegExp(`${ext.replace(".", "\\.")}(?=[?#]|$)`, "i"), `-${match[1]}w${ext}`) });
      }
      if (dimensions?.width) responsive.push({ width: dimensions.width, src });
      responsive.sort((left, right) => left.width - right.width);
      if (responsive.length > 1 && !hasAttribute(optimized, "srcset")) {
        optimized = optimized.replace(/\s*\/?>$/, ` srcset="${responsive.map((entry) => `${entry.src} ${entry.width}w`).join(", ")}" sizes="100vw"$&`);
      }
    }

    let modern = [];
    if (asset && /\.(?:png|jpe?g)$/i.test(asset)) {
      for (const ext of [".avif", ".webp"]) {
        const candidate = asset.replace(/\.[^.]+$/, ext);
        if (fs.existsSync(candidate)) modern.push({ type: contentTypeFor(candidate), src: src.replace(/\.[^./?#]+(?=[?#]|$)/, ext) });
      }
    }
    images.push({ src, width: dimensions?.width, height: dimensions?.height, priority, responsive: responsive.map((entry) => entry.src), modern: modern.map((entry) => entry.src) });
    if (modern.length && !/^\s*<picture/i.test(tag)) {
      return `<picture>${modern.map((entry) => `<source type="${entry.type}" srcset="${entry.src}">`).join("")}${optimized}</picture>`;
    }
    return optimized;
  });
  html = html.replace(/<script\b[^>]*\bsrc=["'](https?:\/\/[^"']+)["'][^>]*>/gi, (tag, src) => {
    const strategy = /\bdata-ark-strategy=["'](async|defer)["']/i.exec(tag)?.[1] || "defer";
    scripts.push({ src, strategy, integrity: /\bintegrity=["'][^"']+["']/i.test(tag) });
    if (!hasAttribute(tag, "async") && !hasAttribute(tag, "defer") && !/\btype=["']module["']/i.test(tag)) {
      return tag.replace(/>$/, ` ${strategy}>`);
    }
    return tag;
  });
  html = html.replace(/<link\b[^>]*\bdata-ark-font\b[^>]*>/gi, (tag) => {
    let next = tag;
    if (!hasAttribute(next, "rel")) next = next.replace(/>$/, " rel=\"preload\">");
    if (!hasAttribute(next, "as")) next = next.replace(/>$/, " as=\"font\">");
    if (!hasAttribute(next, "crossorigin")) next = next.replace(/>$/, " crossorigin=\"anonymous\">");
    return next;
  });
  const imagePreloads = images.filter((image) => image.priority).map((image) => `<link rel="preload" as="image" href="${image.src}" fetchpriority="high">`).join("");
  if (imagePreloads) html = /<\/head>/i.test(html) ? html.replace(/<\/head>/i, `${imagePreloads}</head>`) : `${imagePreloads}${html}`;
  return { html, metadata: { images, scripts } };
}

function minifyTextAsset(filePath, source) {
  const ext = path.extname(filePath).toLowerCase();
  if (ext === ".html") return source.replace(/>\s+</g, "><").replace(/\n\s*/g, "").trim();
  if (ext === ".css") return source.replace(/\/\*[\s\S]*?\*\//g, "").replace(/\s+/g, " ").replace(/\s*([{}:;,])\s*/g, "$1").trim();
  if (ext === ".js" || ext === ".mjs") return source.replace(/^\s*\/\/.*$/gm, "").replace(/\n{2,}/g, "\n").trim();
  if (ext === ".json") return JSON.stringify(JSON.parse(source));
  return source;
}

function sha256(buffer) {
  return crypto.createHash("sha256").update(buffer).digest("hex");
}

function metaContent(source, name) {
  const escaped = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const direct = new RegExp(`<meta\\b[^>]*name=["']${escaped}["'][^>]*content=(["'])([\\s\\S]*?)\\1[^>]*>`, "i").exec(source);
  if (direct) return direct[2].trim();
  const reverse = new RegExp(`<meta\\b[^>]*content=(["'])([\\s\\S]*?)\\1[^>]*name=["']${escaped}["'][^>]*>`, "i").exec(source);
  return reverse ? reverse[2].trim() : "";
}

function linkHref(source, rel) {
  const escaped = rel.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const direct = new RegExp(`<link\\b[^>]*rel=["']${escaped}["'][^>]*href=(["'])([\\s\\S]*?)\\1[^>]*>`, "i").exec(source);
  if (direct) return direct[2].trim();
  const reverse = new RegExp(`<link\\b[^>]*href=(["'])([\\s\\S]*?)\\1[^>]*rel=["']${escaped}["'][^>]*>`, "i").exec(source);
  return reverse ? reverse[2].trim() : "";
}

function openGraphMetadata(source) {
  const values = {};
  const tags = source.match(/<meta\b[^>]*>/gi) || [];
  for (const tag of tags) {
    const property = /\bproperty=["'](og:[^"']+)["']/i.exec(tag)?.[1];
    const content = /\bcontent=(["'])([\s\S]*?)\1/i.exec(tag)?.[2];
    if (property && content !== undefined) values[property] = content.trim();
  }
  return values;
}

function jsonLdMetadata(source) {
  const values = [];
  const pattern = /<script\b[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  for (const match of source.matchAll(pattern)) {
    try {
      values.push(JSON.parse(match[1]));
    } catch {
      // Invalid JSON-LD remains in the HTML, but is not promoted into the route contract.
    }
  }
  if (values.length === 0) return undefined;
  return values.length === 1 ? values[0] : values;
}

function parseStaticPaths(value) {
  if (!value) return [];
  const trimmed = value.trim();
  if (trimmed.startsWith("[")) {
    const parsed = JSON.parse(trimmed);
    return Array.isArray(parsed) ? parsed.filter((entry) => typeof entry === "string" && entry.startsWith("/")) : [];
  }
  return trimmed.split(",").map((entry) => entry.trim()).filter((entry) => entry.startsWith("/"));
}

function routePatternParams(pattern, concretePath) {
  const names = [];
  if (pattern === "/") return concretePath === "/" ? {} : null;
  const source = pattern.replace(/^\/+|\/+$/g, "").split("/").map((segment) => {
    if (segment.startsWith(":")) {
      names.push(segment.slice(1));
      return "([^/]+)";
    }
    if (segment.startsWith("*")) {
      names.push(segment.slice(1));
      return "(.*)";
    }
    return segment.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  }).join("/");
  const match = new RegExp(`^/${source}/?$`).exec(concretePath.split("?")[0]);
  if (!match) return null;
  return Object.fromEntries(names.map((name, index) => [name, decodeURIComponent(match[index + 1] || "")]));
}

function interpolateRouteValue(value, params, concretePath) {
  return String(value).replace(/\{\{\s*([^}]+)\s*\}\}/g, (_, key) => key.trim() === "path" ? concretePath : (params[key.trim()] ?? ""));
}

function interpolateRouteHtml(source, params, concretePath) {
  return source.replace(/\{\{\s*([^}]+)\s*\}\}/g, (_, key) => {
    const value = key.trim() === "path" ? concretePath : (params[key.trim()] ?? "");
    return String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  });
}

function staticAssetPath(routePath) {
  const pathname = routePath.split("?")[0].replace(/^\/+/, "");
  if (!pathname) return "index.html";
  const decodedSegments = pathname.split("/").map((segment) => decodeURIComponent(segment));
  if (decodedSegments.some((segment) => segment === "." || segment === "..")) {
    throw new Error(`Static route path cannot contain traversal segments: ${routePath}`);
  }
  if (path.posix.extname(pathname)) return pathname;
  return `${pathname.replace(/\/+$/, "")}/index.html`;
}

function rewriteGeneratedHtmlReferences(source, templateAsset, generatedAsset) {
  const templateDir = path.posix.dirname(templateAsset);
  const generatedDir = path.posix.dirname(generatedAsset);
  return source.replace(/(\b(?:src|href)=(["']))([^"']+)(\2)/gi, (match, prefix, _quote, specifier, suffix) => {
    if (!specifier.startsWith("./") && !specifier.startsWith("../")) return match;
    const target = path.posix.normalize(path.posix.join(templateDir, specifier));
    const relative = path.posix.relative(generatedDir, target) || path.posix.basename(target);
    return `${prefix}${relative.startsWith(".") ? relative : `./${relative}`}${suffix}`;
  });
}

function deriveRouteId(routePath) {
  if (routePath === "/") return "root";
  return routePath.replace(/^\/+|\/+$/g, "").replace(/[^\w/-]+/g, "-").replace(/\//g, "__") || "root";
}

function parseRouteGraphMeta(value) {
  if (!value) return [];
  const trimmed = value.trim();
  if (trimmed.startsWith("[") || trimmed.startsWith("{")) {
    const parsed = JSON.parse(trimmed);
    const entries = Array.isArray(parsed) ? parsed : Array.isArray(parsed?.edges) ? parsed.edges : [];
    return entries
      .filter((entry) => entry && typeof entry === "object" && typeof entry.route === "string" && entry.route)
      .map((entry) => ({
        route: entry.route,
        dependencyId: typeof entry.dependencyId === "string" ? entry.dependencyId : undefined,
        relation: typeof entry.relation === "string" ? entry.relation : undefined,
        phase: typeof entry.phase === "string" ? entry.phase : undefined,
        required: typeof entry.required === "boolean" ? entry.required : true,
        sourceRoute: typeof entry.sourceRoute === "string" ? entry.sourceRoute : undefined,
        stateScope: typeof entry.stateScope === "string" ? entry.stateScope : undefined,
        asset: typeof entry.asset === "string" ? entry.asset : undefined,
        barrier: typeof entry.barrier === "string" ? entry.barrier : undefined,
        continuationTag: typeof entry.continuationTag === "string" ? entry.continuationTag : undefined,
        tags: Array.isArray(entry.tags) ? entry.tags.filter((tag) => typeof tag === "string" && tag) : undefined,
      }));
  }
  return value
    .split(",")
    .map((entry) => entry.trim())
    .filter(Boolean)
    .map((entry) => {
      const [route, relation, phase, requiredToken, dependencyId, sourceRoute, stateScope, barrier, continuationTag, tagsToken] = entry.split("|").map((part) => part.trim());
      if (!route) return null;
      return {
        route,
        dependencyId: dependencyId || undefined,
        relation: relation || undefined,
        phase: phase || undefined,
        required: requiredToken ? requiredToken !== "optional" && requiredToken !== "false" : true,
        sourceRoute: sourceRoute || undefined,
        stateScope: stateScope || undefined,
        barrier: barrier || undefined,
        continuationTag: continuationTag || undefined,
        tags: tagsToken ? tagsToken.split("+").map((tag) => tag.trim()).filter(Boolean) : undefined,
      };
    })
    .filter(Boolean);
}

function extractRouteMetadata(source, routePath) {
  const titleMatch = /<title>([\s\S]*?)<\/title>/i.exec(source);
  const prefetch = metaContent(source, "ark-prefetch")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
  const dependencyGraph = parseRouteGraphMeta(metaContent(source, "ark-route-graph"));
  const dependsOn = metaContent(source, "ark-depends-on")
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
  for (const dependency of dependencyGraph) {
    if (dependency.route && !dependsOn.includes(dependency.route)) dependsOn.push(dependency.route);
  }
  const title = titleMatch ? titleMatch[1].replace(/\s+/g, " ").trim() : "";
  const description = metaContent(source, "description");
  const canonical = linkHref(source, "canonical");
  const robots = metaContent(source, "robots");
  const openGraph = openGraphMetadata(source);
  const jsonLd = jsonLdMetadata(source);
  const sitemap = {
    exclude: metaContent(source, "ark-sitemap-exclude") === "true",
    changefreq: metaContent(source, "ark-sitemap-changefreq") || undefined,
    priority: metaContent(source, "ark-sitemap-priority") ? Number(metaContent(source, "ark-sitemap-priority")) : undefined,
    lastmod: metaContent(source, "ark-sitemap-lastmod") || undefined,
  };
  const head = {
    title: title || undefined,
    description: description || undefined,
    canonical: canonical || undefined,
    robots: robots || undefined,
    openGraph: Object.keys(openGraph).length ? openGraph : undefined,
    jsonLd,
    sitemap: Object.values(sitemap).some((value) => value !== undefined && value !== false) ? sitemap : undefined,
  };
  return {
    pathPattern: metaContent(source, "ark-route-pattern") || undefined,
    staticPaths: parseStaticPaths(metaContent(source, "ark-static-paths")),
    title,
    description,
    head,
    routeId: metaContent(source, "ark-route-id") || deriveRouteId(routePath),
    prefetch,
    dependsOn,
    dependencyGraph,
  };
}

function routeEntriesFor(files, entryFile, htmlMetadataByAsset = new Map()) {
  const htmlFiles = files.filter((file) => file.relative.endsWith(".html") && !file.generated);
  const routes = htmlFiles.map((file) => {
    const metadata = htmlMetadataByAsset.get(file.relative) || {};
    const derivedPath = file.relative === entryFile ? "/" : `/${file.relative.replace(/\/index\.html$/, "/").replace(/\.html$/, "")}`;
    const { pathPattern, ...routeMetadata } = metadata;
    return {
      path: pathPattern || derivedPath,
      asset: file.relative,
      ...routeMetadata,
    };
  });
  return routes.length > 0 ? routes : [{ path: "/", asset: entryFile }];
}

function sitemapXml(routes, siteUrl) {
  const urls = [];
  for (const route of routes) {
    const concretePaths = route.staticPaths?.length ? route.staticPaths : route.path.includes(":") || route.path.includes("*") ? [] : [route.path];
    for (const concretePath of concretePaths) {
      if (route.head?.sitemap?.exclude) continue;
      const params = routePatternParams(route.path, concretePath) || {};
      const canonicalTemplate = route.head?.canonical;
      const location = canonicalTemplate
        ? interpolateRouteValue(canonicalTemplate, params, concretePath)
        : siteUrl
          ? new URL(concretePath, siteUrl.endsWith("/") ? siteUrl : `${siteUrl}/`).href
          : "";
      if (!/^https?:\/\//i.test(location)) continue;
      const sitemap = route.head?.sitemap || {};
      urls.push([
        "<url>",
        `<loc>${location.replace(/&/g, "&amp;").replace(/</g, "&lt;")}</loc>`,
        sitemap.lastmod ? `<lastmod>${sitemap.lastmod}</lastmod>` : "",
        sitemap.changefreq ? `<changefreq>${sitemap.changefreq}</changefreq>` : "",
        Number.isFinite(sitemap.priority) ? `<priority>${sitemap.priority}</priority>` : "",
        "</url>",
      ].join(""));
    }
  }
  if (urls.length === 0) return "";
  return `<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${urls.join("")}</urlset>`;
}

function toArchiveAssetPayload(filePath, buffer) {
  const ext = path.extname(filePath).toLowerCase();
  if (TEXT_BUILDABLE_EXTENSIONS.has(ext)) return { payload: buffer.toString("utf8"), encoding: "utf8" };
  return { payload: buffer.toString("base64"), encoding: "base64" };
}

function buildArchiveArtifact({ entryFile, manifest, manifestFiles, writtenAssets, rootDir, baseDictionary = null }) {
  const archiveInput = {
    entry: entryFile,
    baseDictionary,
    generatedBy: "ark-ui-cli",
    sourceFormat: "ark-flx-manifest",
    routes: (manifest.routes || []).map((route) => ({
      routeId: route.routeId || deriveRouteId(route.path),
      path: route.path || "/",
      title: route.title || undefined,
      description: route.description || undefined,
      head: route.head || undefined,
      staticPaths: route.staticPaths || [],
      dependsOn: route.dependsOn || [],
      dependencyGraph: route.dependencyGraph || [],
      payload: {
        asset: route.asset || null,
        prefetch: route.prefetch || [],
        dependsOn: route.dependsOn || [],
        dependencyGraph: route.dependencyGraph || [],
        description: route.description || "",
        title: route.title || "",
        head: route.head || null,
        staticPaths: route.staticPaths || [],
      },
    })),
    assets: writtenAssets.map((asset) => {
      const encoded = toArchiveAssetPayload(asset.path, asset.buffer);
      return {
        path: asset.path,
        contentType: asset.type,
        payload: encoded.payload,
        encoding: encoded.encoding,
        compression: "identity",
        hash: asset.sha256,
      };
    }),
  };
  const archiveBytes = encodeArchive(archiveInput);
  return {
    format: "flx-archive-v2",
    block: "13",
    version: 2,
    root: rootDir,
    manifest,
    fileCount: manifestFiles.length,
    bytes: archiveBytes.byteLength,
    archiveBytes,
  };
}

function writeManifestSidecar(outDir, manifestName, manifest) {
  fs.writeFileSync(path.join(outDir, manifestName), `${JSON.stringify(manifest, null, 2)}\n`, "utf8");
}

function runBuild(dir, extraArgs) {
  const rootDir = path.resolve(process.cwd(), dir || ".");
  const outDir = path.resolve(process.cwd(), optionValue(extraArgs, "--out-dir", "dist/app"));
  const entryFile = optionValue(extraArgs, "--entry", "index.html");
  const manifestName = optionValue(extraArgs, "--manifest", "app.flx.json");
  const bundleName = optionValue(extraArgs, "--bundle", "app.flx");
  const format = optionValue(extraArgs, "--format", "package");
  const transportCompression = normalizeTransportCompression(optionValue(extraArgs, "--transport-compression", "none"));
  const baseArchive = optionValue(extraArgs, "--base", null);
  const baseDictionaryPath = optionValue(extraArgs, "--base-dictionary", null);
  const continuationChunkSize = parseNumericOption(extraArgs, "--continuation-chunk-size", 0);
  const siteUrl = optionValue(extraArgs, "--site-url", "");
  const pending = walkBuildFiles(rootDir);
  const seenRelative = new Set();
  const files = [];
  const queueFile = (file) => {
    if (seenRelative.has(file.relative)) return;
    pending.push(file);
  };

  fs.rmSync(outDir, { recursive: true, force: true });
  fs.mkdirSync(outDir, { recursive: true });

  const manifestFiles = [];
  const bundledAssets = [];
  const writtenAssets = [];
  const htmlMetadataByAsset = new Map();
  const performanceByAsset = new Map();
  const recordGeneratedAsset = (relative, buffer, type) => {
    const target = path.resolve(outDir, relative);
    if (target !== outDir && !target.startsWith(`${outDir}${path.sep}`)) {
      throw new Error(`Generated asset escapes the build directory: ${relative}`);
    }
    fs.mkdirSync(path.dirname(target), { recursive: true });
    fs.writeFileSync(target, buffer);
    const written = fs.readFileSync(target);
    manifestFiles.push({ path: relative, type, bytes: written.byteLength, sha256: sha256(written) });
    bundledAssets.push({ path: relative, encoding: "base64", data: written.toString("base64") });
    writtenAssets.push({ path: relative, type, sha256: sha256(written), buffer: written });
    files.push({ full: target, relative, generated: true });
  };
  while (pending.length > 0) {
    const file = pending.shift();
    if (!file || seenRelative.has(file.relative)) continue;
    seenRelative.add(file.relative);
    const target = path.join(outDir, file.relative);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const ext = path.extname(file.full).toLowerCase();
    if (TEXT_BUILDABLE_EXTENSIONS.has(ext)) {
      const source = fs.readFileSync(file.full, "utf8");
      const rewritten = rewriteTextAssetReferences(file, source, rootDir, queueFile);
      const pipelined = ext === ".html" ? htmlPerformancePipeline(file, rewritten) : { html: rewritten, metadata: null };
      const output = minifyTextAsset(file.full, pipelined.html);
      fs.writeFileSync(target, `${output}${output.endsWith("\n") ? "" : "\n"}`, "utf8");
      if (ext === ".html") {
        const routePath = file.relative === entryFile ? "/" : `/${file.relative.replace(/\/index\.html$/, "/").replace(/\.html$/, "")}`;
        htmlMetadataByAsset.set(file.relative, extractRouteMetadata(output, routePath));
        performanceByAsset.set(file.relative, pipelined.metadata);
      }
    } else {
      fs.copyFileSync(file.full, target);
    }
    const written = fs.readFileSync(target);
    manifestFiles.push({
      path: file.relative,
      type: contentTypeFor(target),
      bytes: written.byteLength,
      sha256: sha256(written),
    });
    bundledAssets.push({
      path: file.relative,
      encoding: "base64",
      data: written.toString("base64"),
    });
    writtenAssets.push({
      path: file.relative,
      type: contentTypeFor(target),
      sha256: sha256(written),
      buffer: written,
    });
    files.push(file);
  }

  const routes = routeEntriesFor(files, entryFile, htmlMetadataByAsset);
  for (const route of routes) {
    if (!route.staticPaths?.length) continue;
    const template = fs.readFileSync(path.join(outDir, route.asset), "utf8");
    for (const concretePath of route.staticPaths) {
      const params = routePatternParams(route.path, concretePath);
      if (!params) throw new Error(`Static path ${concretePath} does not match route pattern ${route.path}`);
      const generatedAsset = staticAssetPath(concretePath);
      if (generatedAsset === route.asset || manifestFiles.some((file) => file.path === generatedAsset)) continue;
      const interpolated = interpolateRouteHtml(template, params, concretePath);
      const output = rewriteGeneratedHtmlReferences(interpolated, route.asset, generatedAsset);
      recordGeneratedAsset(generatedAsset, Buffer.from(`${output}${output.endsWith("\n") ? "" : "\n"}`, "utf8"), "text/html; charset=utf-8");
    }
  }
  const sitemap = sitemapXml(routes, siteUrl);
  if (sitemap && !manifestFiles.some((file) => file.path === "sitemap.xml")) {
    recordGeneratedAsset("sitemap.xml", Buffer.from(`${sitemap}\n`, "utf8"), "application/xml; charset=utf-8");
  }

  const manifest = {
    format: "ark-flx-manifest",
    block: "13",
    version: 1,
    generatedAt: new Date().toISOString(),
    root: rootDir,
    entry: entryFile,
    routes,
    files: manifestFiles,
    performance: Object.fromEntries(performanceByAsset),
  };
  const baseDictionary = baseDictionaryPath
    ? (() => {
        const artifact = readFlxArtifact(baseDictionaryPath);
        if (artifact.kind !== "archive") throw new Error(`Base dictionary source must be an archive artifact: ${artifact.resolved}`);
        return artifact.archive.dictionary;
      })()
    : null;

  writeManifestSidecar(outDir, manifestName, manifest);
  if (format === "manifest") {
    process.stdout.write(
      [
        `Built browser-native app from ${rootDir}`,
        `Output: ${outDir}`,
        `Manifest: ${path.join(outDir, manifestName)}`,
        `Format: manifest`,
        `Files: ${manifestFiles.length}`,
        `Next: ark inspect ${path.join(outDir, manifestName)}`,
        `Next: ark verify ${path.join(outDir, manifestName)}`,
      ].join("\n") + "\n"
    );
    return;
  }
  if (format === "archive") {
    const archiveArtifact = buildArchiveArtifact({ entryFile, manifest, manifestFiles, writtenAssets, rootDir, baseDictionary });
    const bundlePath = path.join(outDir, bundleName);
    fs.writeFileSync(bundlePath, Buffer.from(archiveArtifact.archiveBytes));
    if (transportCompression !== "none") {
      const compressedBytes = encodeTransportLayer(archiveArtifact.archiveBytes, transportCompression);
      fs.writeFileSync(compressedArtifactPath(bundlePath, transportCompression), compressedBytes);
    }
    if (continuationChunkSize > 0) {
      const continuations = splitArchiveContinuations(archiveArtifact.archiveBytes, continuationChunkSize).map((chunk) => ({
        parentArchiveId: chunk.parentArchiveId,
        chunkIndex: chunk.chunkIndex,
        chunkCount: chunk.chunkCount,
        byteOffset: chunk.byteOffset,
        totalBytes: chunk.totalBytes,
        resumeToken: chunk.resumeToken,
        chunkChecksum: chunk.chunkChecksum,
        bytes: chunk.bytes.byteLength,
        receivedBlocks: chunk.receivedBlocks || [],
        receiptGraph: chunk.receiptGraph || [],
        receiptSummary: chunk.receiptSummary || null,
      }));
      fs.writeFileSync(path.join(outDir, "app.flx.continuations.json"), `${JSON.stringify(continuations, null, 2)}\n`, "utf8");
    }
    process.stdout.write(
      [
        `Built browser-native app from ${rootDir}`,
        `Output: ${outDir}`,
        `Manifest: ${path.join(outDir, manifestName)}`,
        `Archive: ${path.join(outDir, bundleName)}`,
        transportCompression !== "none" ? `Transport: ${compressedArtifactPath(path.join(outDir, bundleName), transportCompression)} (${transportCompression})` : null,
        `Format: archive`,
        `Files: ${manifestFiles.length}`,
        `Bytes: ${archiveArtifact.bytes}`,
        `Next: ark inspect ${path.join(outDir, bundleName)}`,
        `Next: ark verify ${path.join(outDir, bundleName)}`,
      ].join("\n") + "\n"
    );
    return;
  }
  if (format === "delta") {
    if (!baseArchive) throw new Error("Delta builds require --base <archive.flx>");
    const archiveArtifact = buildArchiveArtifact({ entryFile, manifest, manifestFiles, writtenAssets, rootDir, baseDictionary });
    const base = readFlxArtifact(baseArchive);
    if (base.kind !== "archive") throw new Error(`Delta base must be an archive artifact: ${base.resolved}`);
    const deltaInput = diffArchives(base.parsed, archiveArtifact.archiveBytes);
    const deltaBytes = encodeArchive(deltaInput);
    const bundlePath = path.join(outDir, bundleName);
    fs.writeFileSync(bundlePath, Buffer.from(deltaBytes));
    if (transportCompression !== "none") {
      const compressedBytes = encodeTransportLayer(deltaBytes, transportCompression);
      fs.writeFileSync(compressedArtifactPath(bundlePath, transportCompression), compressedBytes);
    }
    if (continuationChunkSize > 0) {
      const continuations = splitArchiveContinuations(deltaBytes, continuationChunkSize).map((chunk) => ({
        parentArchiveId: chunk.parentArchiveId,
        chunkIndex: chunk.chunkIndex,
        chunkCount: chunk.chunkCount,
        byteOffset: chunk.byteOffset,
        totalBytes: chunk.totalBytes,
        resumeToken: chunk.resumeToken,
        chunkChecksum: chunk.chunkChecksum,
        bytes: chunk.bytes.byteLength,
        receivedBlocks: chunk.receivedBlocks || [],
        receiptGraph: chunk.receiptGraph || [],
        receiptSummary: chunk.receiptSummary || null,
      }));
      fs.writeFileSync(path.join(outDir, "app.flx.continuations.json"), `${JSON.stringify(continuations, null, 2)}\n`, "utf8");
    }
    process.stdout.write(
      [
        `Built browser-native app from ${rootDir}`,
        `Output: ${outDir}`,
        `Manifest: ${path.join(outDir, manifestName)}`,
        `Delta: ${path.join(outDir, bundleName)}`,
        transportCompression !== "none" ? `Transport: ${compressedArtifactPath(path.join(outDir, bundleName), transportCompression)} (${transportCompression})` : null,
        `Base: ${base.resolved}`,
        `Format: delta`,
        `Files: ${manifestFiles.length}`,
        `Next: ark inspect ${path.join(outDir, bundleName)}`,
        `Next: ark verify ${path.join(outDir, bundleName)} --base ${base.resolved}`,
      ].join("\n") + "\n"
    );
    return;
  }
  fs.writeFileSync(path.join(outDir, bundleName), `${JSON.stringify({
    format: "ark-flx-package",
    block: "13",
    version: 1,
    manifest,
    assets: bundledAssets,
  }, null, 2)}\n`, "utf8");
  process.stdout.write(
    [
      `Built browser-native app from ${rootDir}`,
      `Output: ${outDir}`,
      `Manifest: ${path.join(outDir, manifestName)}`,
      `Bundle: ${path.join(outDir, bundleName)}`,
      `Files: ${manifestFiles.length}`,
      `Next: ark inspect ${path.join(outDir, bundleName)}`,
      `Next: ark verify ${path.join(outDir, bundleName)}`,
    ].join("\n") + "\n"
  );
}

function readFlxArtifact(filePath) {
  const resolved = path.resolve(process.cwd(), filePath || "app.flx");
  const sourceBody = fs.readFileSync(resolved);
  const transportCompression = detectTransportCompression(resolved, sourceBody);
  const body = decodeTransportLayer(sourceBody, transportCompression);
  if (looksLikeFlxArchiveBinary(body)) {
    const decoded = decodeArchive(body);
    const archiveAssets = decoded.assets.map((asset) => ({
      blockId: asset.blockId,
      path: asset.path,
      encoding: asset.encoding || "utf8",
      data: asset.payload,
      contentType: asset.contentType,
      rawByteLength: asset.rawByteLength,
      compressedByteLength: asset.compressedByteLength,
      sha256: asset.hash || null,
    }));
    const assetByPath = new Map(archiveAssets.map((asset) => [asset.path, asset]));
    const manifestFiles = decoded.manifest.files.map((file) => {
      const asset = assetByPath.get(file.path);
      return {
        blockId: asset?.blockId || null,
        path: file.path,
        type: file.contentType,
        bytes: typeof file.size === "number"
          ? file.size
          : asset
            ? (asset.encoding === "base64"
              ? Buffer.from(asset.data, "base64").byteLength
              : Buffer.from(String(asset.data || ""), "utf8").byteLength)
            : 0,
        sha256: file.hash || asset?.sha256 || null,
      };
    });
    const routeDetails = new Map(decoded.routes.map((route) => {
      const payload = route.payload && typeof route.payload === "object" ? route.payload : {};
      return [route.routeId, {
        blockId: route.blockId,
        asset: typeof payload.asset === "string" ? payload.asset : null,
        prefetch: Array.isArray(payload.prefetch) ? payload.prefetch : [],
        dependsOn: Array.isArray(route.dependsOn) ? route.dependsOn : (Array.isArray(payload.dependsOn) ? payload.dependsOn : []),
        dependencyGraph: Array.isArray(route.dependencyGraph) ? route.dependencyGraph : (Array.isArray(payload.dependencyGraph) ? payload.dependencyGraph : []),
      }];
    }));
    const manifestRoutes = decoded.manifest.routes.map((route) => ({
      ...route,
      blockId: routeDetails.get(route.routeId)?.blockId || null,
      asset: routeDetails.get(route.routeId)?.asset || null,
      prefetch: routeDetails.get(route.routeId)?.prefetch || [],
      dependsOn: route.dependsOn || routeDetails.get(route.routeId)?.dependsOn || [],
      dependencyGraph: route.dependencyGraph || routeDetails.get(route.routeId)?.dependencyGraph || [],
    }));
    const states = decoded.states.map((state) => ({
      blockId: state.blockId,
      stateId: state.stateId,
      scope: state.scope,
      schema: state.schema || null,
      rootPath: state.rootPath || null,
      snapshotVersion: state.snapshotVersion ?? null,
    }));
    return {
      resolved,
      kind: "archive",
      transport: {
        compression: transportCompression,
        wrapped: transportCompression !== "none",
        inputBytes: sourceBody.byteLength,
        archiveBytes: body.byteLength,
      },
      parsed: { header: decoded.header, blocks: decoded.blocks },
      manifest: {
        format: "ark-flx-manifest",
        block: "13",
        version: 1,
      generatedAt: decoded.header.createdAt,
      entry: decoded.manifest.entry,
      syncSources: decoded.manifest.syncSources || [],
      routes: manifestRoutes,
      files: manifestFiles,
    },
      assets: archiveAssets,
      states,
      archive: decoded,
    };
  }
  const source = body.toString("utf8");
  const parsed = JSON.parse(source);
  if (parsed?.format === "ark-flx-package" && Array.isArray(parsed.assets) && parsed.manifest) {
    return {
      resolved,
      kind: "package",
      transport: {
        compression: transportCompression,
        wrapped: transportCompression !== "none",
        inputBytes: sourceBody.byteLength,
        archiveBytes: body.byteLength,
      },
      parsed,
      manifest: parsed.manifest,
      assets: parsed.assets,
    };
  }
  if (parsed?.format === "ark-flx-manifest" && Array.isArray(parsed.files)) {
    return {
      resolved,
      kind: "manifest",
      transport: {
        compression: transportCompression,
        wrapped: transportCompression !== "none",
        inputBytes: sourceBody.byteLength,
        archiveBytes: body.byteLength,
      },
      parsed,
      manifest: parsed,
      assets: null,
    };
  }
  if (parsed?.format === "ark-flx-recovery-manifest" || looksLikeRecoveryManifest(parsed)) {
    const manifest = {
      ...parsed,
      repairPackets: Array.isArray(parsed.repairPackets) ? parsed.repairPackets.map((packet) => normalizeRecoveryPacket(packet)) : [],
    };
    return {
      resolved,
      kind: "recovery-manifest",
      transport: {
        compression: transportCompression,
        wrapped: transportCompression !== "none",
        inputBytes: sourceBody.byteLength,
        archiveBytes: body.byteLength,
      },
      parsed: manifest,
      manifest,
      assets: null,
    };
  }
  throw new Error(`Invalid ark flx artifact: ${resolved}`);
}

function summarizeFlxArtifact(filePath) {
  const artifact = readFlxArtifact(filePath);
  const routes = artifact.manifest.routes || [];
  const files = artifact.manifest.files || [];
  const totalBytes = files.reduce((sum, file) => sum + Number(file.bytes || file.rawByteLength || 0), 0);
  const summary = {
    file: artifact.resolved,
    kind: artifact.kind,
    format: artifact.kind === "archive" ? "flx-archive" : artifact.parsed.format,
    block: artifact.kind === "archive" ? "archive" : artifact.parsed.block,
    version: artifact.kind === "archive" ? artifact.parsed.header?.major : artifact.parsed.version,
    entry: artifact.manifest.entry || null,
    routeCount: routes.length,
    fileCount: files.length,
    totalBytes,
    primaryRoute: routes[0] || null,
    routes,
    files,
    assets: artifact.assets?.length || 0,
    generatedAt: artifact.manifest.generatedAt,
    syncSources: artifact.manifest.syncSources || [],
    transport: artifact.transport || {
      compression: "none",
      wrapped: false,
      inputBytes: null,
      archiveBytes: null,
    },
    blockCount: artifact.kind === "archive" ? artifact.parsed.blocks.length : null,
    stateCount: artifact.states?.length || 0,
    states: artifact.states || [],
  };
  if (artifact.kind === "recovery-manifest") {
    summary.groupCount = artifact.manifest.groupCount;
    summary.sourceCount = Array.isArray(artifact.manifest.sources) ? artifact.manifest.sources.length : 0;
    summary.quorum = artifact.manifest.quorum || null;
    summary.recovery = {
      parentArchiveId: artifact.manifest.parentArchiveId,
      archiveHash: artifact.manifest.archiveHash,
      shardSize: artifact.manifest.shardSize,
      repairKind: artifact.manifest.repair?.kind || null,
      repairLayout: artifact.manifest.repair?.layout || null,
      packetCount: artifact.manifest.repairInventory?.packetCount || 0,
      groupsPerPacket: artifact.manifest.repairInventory?.groupsPerPacket || 0,
      reconstructionLimit: artifact.manifest.repairInventory?.reconstructionLimit || 0,
      readiness: artifact.manifest.repairInventory?.readiness || { grade: "production-grade", notes: [] },
      guarantees: artifact.manifest.repairInventory?.guarantees || { guaranteedPatterns: [], bestEffortPatterns: [], matrix: [] },
      packetClassCounts: artifact.manifest.repairInventory?.packetClassCounts || {},
      coverageByGroup: artifact.manifest.repairInventory?.coverageByGroup || [],
    };
    return summary;
  }
  if (artifact.kind === "archive") {
    const archiveAssets = artifact.archive.assets || [];
    const compressedBytes = artifact.archive.blocks.reduce((sum, block) => sum + Number(block.length || 0), 0);
    const rawBytes = archiveAssets.reduce((sum, asset) => sum + Number(asset.rawByteLength || 0), 0);
    const dictionary = artifact.archive.dictionary || {
      strings: [],
      paths: [],
      contentTypes: [],
      routeIds: [],
      stateScopes: [],
      routeTokens: [],
      keys: [],
    };
    const dictionaryEntries = [
      ...(dictionary.strings || []),
      ...(dictionary.paths || []),
      ...(dictionary.contentTypes || []),
      ...(dictionary.routeIds || []),
      ...(dictionary.stateScopes || []),
      ...(dictionary.routeTokens || []),
      ...(dictionary.keys || []),
    ].length;
    summary.archiveMetrics = {
      compressedBytes,
      rawBytes,
      compressionRatio: rawBytes > 0 ? Number((compressedBytes / rawBytes).toFixed(3)) : 1,
      blockCount: artifact.archive.blocks.length,
      dictionaryEntries,
      dictionaryHitRate: dictionaryEntries > 0 ? Number((((files.length + routes.length) / dictionaryEntries)).toFixed(3)) : 0,
      blockTypes: artifact.archive.blocks.map((block) => block.type),
      blockIds: artifact.archive.blocks.map((block) => ({ id: block.id, type: block.type })),
    };
    if (summary.transport?.wrapped) {
      summary.archiveMetrics.transportBytes = summary.transport.inputBytes;
      summary.archiveMetrics.transportCompression = summary.transport.compression;
      summary.archiveMetrics.transportRatio = compressedBytes > 0
        ? Number((summary.transport.inputBytes / compressedBytes).toFixed(3))
        : 1;
    }
    summary.delta = artifact.archive.delta
      ? {
          parentArchiveId: artifact.archive.delta.parentArchiveId,
          operationCount: artifact.archive.delta.operations.length,
          deltaKind: artifact.archive.delta.deltaKind || "delta",
          nextArchiveId: artifact.archive.delta.nextArchiveId || null,
          touchedBlockIds: artifact.archive.delta.operations
            .filter((operation) => operation.op !== "replace-entry")
            .map((operation) => operation.blockId)
            .slice(0, 5),
        }
      : null;
    summary.continuation = artifact.archive.continuation
      ? {
          parentArchiveId: artifact.archive.continuation.parentArchiveId,
          chunkIndex: artifact.archive.continuation.chunkIndex,
          chunkCount: artifact.archive.continuation.chunkCount,
          byteOffset: artifact.archive.continuation.byteOffset,
          totalBytes: artifact.archive.continuation.totalBytes,
          receivedBlocks: artifact.archive.continuation.receivedBlocks || [],
          receiptState: artifact.archive.continuation.receiptState || null,
          receiptGraph: artifact.archive.continuation.receiptGraph || [],
          receiptSummary: artifact.archive.continuation.receiptSummary || null,
        }
      : null;
  }
  return summary;
}

function runInspect(packagePath) {
  const summary = summarizeFlxArtifact(packagePath);
  if (hasOption(process.argv.slice(2), "--pretty")) {
    if (summary.kind === "recovery-manifest") {
      const matrixLines = (summary.recovery?.guarantees?.matrix || []).map((row) => {
        const proof = row.proofMode ? ` proof=${row.proofMode}` : "";
        const analyzed = row.analyzedCombinations ? ` combos=${row.analyzedCombinations}` : "";
        const sets = Array.isArray(row.sets) ? ` sets=${row.sets.length}` : "";
        return `- loss=${row.lossCount} coverage=${row.coverage}${proof}${analyzed}${sets}`;
      });
      process.stdout.write(
        [
          `FLX Recovery Manifest: ${summary.file}`,
          `Parent archive: ${summary.recovery.parentArchiveId}`,
          `Group count: ${summary.groupCount}`,
          `Sources: ${summary.sourceCount}`,
          `Quorum: ${summary.quorum?.minSources}/${summary.quorum?.minMatchingSources}`,
          `Repair: ${summary.recovery.repairKind || "none"} / ${summary.recovery.repairLayout || "none"}`,
          `Packets: ${summary.recovery.packetCount}`,
          `Groups per packet: ${summary.recovery.groupsPerPacket}`,
          `Reconstruction limit: ${summary.recovery.reconstructionLimit}`,
          `Readiness: ${summary.recovery.readiness.grade}`,
          ...(summary.recovery.readiness.notes || []).map((note) => `- ${note}`),
          "Recoverability matrix:",
          ...(matrixLines.length ? matrixLines : ["- none"]),
        ].join("\n") + "\n"
      );
      return;
    }
    const typeCounts = summary.files.reduce((acc, file) => {
      const key = String(file.type || "unknown");
      acc[key] = (acc[key] || 0) + 1;
      return acc;
    }, {});
    const primary = summary.primaryRoute;
    const routeLines = summary.routes.map((route) => {
      const prefetch = Array.isArray(route.prefetch) && route.prefetch.length > 0 ? ` prefetch=${route.prefetch.join(",")}` : "";
      const dependsOn = Array.isArray(route.dependsOn) && route.dependsOn.length > 0 ? ` dependsOn=${route.dependsOn.join(",")}` : "";
      const dependencyGraph = Array.isArray(route.dependencyGraph) && route.dependencyGraph.length > 0 ? ` graph=${route.dependencyGraph.length}` : "";
      const routeId = route.routeId ? ` id=${route.routeId}` : "";
      const title = route.title ? ` title="${route.title}"` : "";
      const blockId = route.blockId ? ` block=${route.blockId}` : "";
      return `- ${route.path}${routeId}${title}${prefetch}${dependsOn}${dependencyGraph}${blockId}`;
    });
    const stateLines = (summary.states || []).map((state) => `- ${state.stateId} scope=${state.scope} block=${state.blockId}`);
    const assetLines = Object.entries(typeCounts)
      .sort((left, right) => String(left[0]).localeCompare(String(right[0])))
      .map(([type, count]) => `- ${type}: ${count}`);
    const fileLines = summary.files
      .slice()
      .sort((left, right) => Number(right.bytes || 0) - Number(left.bytes || 0))
      .map((file) => `- ${file.path} (${file.bytes} bytes)`);
    process.stdout.write(
      [
        `FLX Artifact: ${summary.file}`,
        `Kind: ${summary.kind}`,
        `Entry: ${summary.entry}`,
        `Routes: ${summary.routeCount}`,
        `Files: ${summary.fileCount}`,
        `Assets: ${summary.assets}`,
        `States: ${summary.stateCount}`,
        `Bytes: ${summary.totalBytes}`,
        summary.syncSources?.length ? `Sync sources: ${summary.syncSources.length}` : null,
        summary.archiveMetrics ? `Compressed bytes: ${summary.archiveMetrics.compressedBytes}` : null,
        summary.archiveMetrics ? `Compression ratio: ${summary.archiveMetrics.compressionRatio}` : null,
        summary.transport?.wrapped ? `Transport wrapper: ${summary.transport.compression} (${summary.transport.inputBytes} bytes)` : null,
        summary.archiveMetrics?.transportRatio ? `Transport ratio: ${summary.archiveMetrics.transportRatio}` : null,
        summary.archiveMetrics ? `Blocks: ${summary.archiveMetrics.blockCount}` : null,
        summary.delta ? `Delta parent: ${summary.delta.parentArchiveId}` : null,
        summary.delta ? `Delta operations: ${summary.delta.operationCount}` : null,
        summary.delta && summary.delta.touchedBlockIds.length > 0 ? `Touched blocks: ${summary.delta.touchedBlockIds.join(", ")}` : null,
        summary.continuation ? `Continuation chunk: ${summary.continuation.chunkIndex + 1}/${summary.continuation.chunkCount}` : null,
        summary.continuation?.receivedBlocks?.length ? `Received blocks: ${summary.continuation.receivedBlocks.join(", ")}` : null,
        summary.continuation?.receiptGraph?.length ? `Receipt graph: ${summary.continuation.receiptGraph.length} entries` : null,
        summary.continuation?.receiptSummary ? `Receipt summary: received=${summary.continuation.receiptSummary.receivedBlockCount || 0} pending=${summary.continuation.receiptSummary.pendingBlockCount || 0}` : null,
        primary ? `Primary route: ${primary.path} (${primary.routeId || "no-id"})` : "Primary route: none",
        primary?.description ? `Primary description: ${primary.description}` : null,
        summary.archiveMetrics ? `Dictionary entries: ${summary.archiveMetrics.dictionaryEntries}` : null,
        "Route map:",
        ...(routeLines.length > 0 ? routeLines : ["- none"]),
        ...(summary.stateCount > 0 ? ["State map:", ...stateLines] : []),
        ...(summary.archiveMetrics ? ["Block map:", ...summary.archiveMetrics.blockIds.map((block) => `- ${block.id} (${block.type})`)] : []),
        "File inventory:",
        ...(fileLines.length > 0 ? fileLines : ["- none"]),
        "Asset types:",
        ...(assetLines.length > 0 ? assetLines : ["- none"]),
      ].filter(Boolean).join("\n") + "\n"
    );
    return;
  }
  process.stdout.write(`${JSON.stringify(summary, null, 2)}\n`);
}

function resolveProfileTarget(targetPath) {
  const resolved = path.resolve(process.cwd(), targetPath || "app.flx");
  if (fs.existsSync(resolved) && fs.statSync(resolved).isDirectory()) {
    const packageCandidate = path.join(resolved, "app.flx");
    if (fs.existsSync(packageCandidate)) return packageCandidate;
    const manifestCandidate = path.join(resolved, "app.flx.json");
    if (fs.existsSync(manifestCandidate)) return manifestCandidate;
  }
  return resolved;
}

function runProfile(targetPath) {
  const summary = summarizeFlxArtifact(resolveProfileTarget(targetPath));
  if (summary.kind === "recovery-manifest") {
    const profile = {
      file: summary.file,
      kind: summary.kind,
      groupCount: summary.groupCount,
      sourceCount: summary.sourceCount,
      quorum: summary.quorum,
      recovery: {
        repairKind: summary.recovery.repairKind,
        repairLayout: summary.recovery.repairLayout,
        packetCount: summary.recovery.packetCount,
        groupsPerPacket: summary.recovery.groupsPerPacket,
        reconstructionLimit: summary.recovery.reconstructionLimit,
        readiness: summary.recovery.readiness,
        guaranteedPatterns: summary.recovery.guarantees?.guaranteedPatterns || [],
        bestEffortPatterns: summary.recovery.guarantees?.bestEffortPatterns || [],
        matrix: summary.recovery.guarantees?.matrix || [],
        coverageByGroup: summary.recovery.coverageByGroup || [],
        packetClassCounts: summary.recovery.packetClassCounts || {},
      },
    };
    if (hasOption(process.argv.slice(2), "--pretty")) {
      process.stdout.write(
        [
          `FLX Profile: ${profile.file}`,
          `Kind: ${profile.kind}`,
          `Groups: ${profile.groupCount}`,
          `Sources: ${profile.sourceCount}`,
          `Quorum: ${profile.quorum?.minSources}/${profile.quorum?.minMatchingSources}`,
          `Repair: ${profile.recovery.repairKind || "none"} / ${profile.recovery.repairLayout || "none"}`,
          `Packets: ${profile.recovery.packetCount}`,
          `Reconstruction limit: ${profile.recovery.reconstructionLimit}`,
          `Readiness: ${profile.recovery.readiness.grade}`,
        ].join("\n") + "\n"
      );
      return;
    }
    process.stdout.write(`${JSON.stringify(profile, null, 2)}\n`);
    return;
  }
  const files = summary.files || [];
  const routes = summary.routes || [];
  const largestAsset = files.slice().sort((left, right) => Number(right.bytes || 0) - Number(left.bytes || 0))[0] || null;
  const averageFileBytes = files.length > 0 ? Math.round(files.reduce((sum, file) => sum + Number(file.bytes || 0), 0) / files.length) : 0;
  const bytesPerRoute = routes.length > 0 ? Math.round(summary.totalBytes / routes.length) : summary.totalBytes;
  const routePrefetchCount = routes.reduce((sum, route) => sum + ((route.prefetch || []).length), 0);
  const typeCounts = files.reduce((acc, file) => {
    const key = String(file.type || "unknown");
    acc[key] = (acc[key] || 0) + 1;
    return acc;
  }, {});
  const profile = {
    file: summary.file,
    kind: summary.kind,
    entry: summary.entry,
    routeCount: summary.routeCount,
    fileCount: summary.fileCount,
    totalBytes: summary.totalBytes,
    bytesPerRoute,
    prefetchEdges: routePrefetchCount,
    largestAsset: largestAsset ? {
      path: largestAsset.path,
      type: largestAsset.type,
      bytes: largestAsset.bytes,
    } : null,
    assetTypes: typeCounts,
    routeTargets: routes.map((route) => ({
      path: route.path,
      routeId: route.routeId || null,
      prefetch: route.prefetch || [],
      target: route.target || null,
      dependsOn: route.dependsOn || [],
      dependencyGraph: route.dependencyGraph || [],
      requiresAuth: !!route.requiresAuth,
    })),
    syncSources: summary.syncSources || [],
  };
  if (summary.archiveMetrics) {
    profile.archive = {
      compressedBytes: summary.archiveMetrics.compressedBytes,
      rawBytes: summary.archiveMetrics.rawBytes,
      compressionRatio: summary.archiveMetrics.compressionRatio,
      blockCount: summary.archiveMetrics.blockCount,
      dictionaryEntries: summary.archiveMetrics.dictionaryEntries,
      dictionaryHitRate: summary.archiveMetrics.dictionaryHitRate,
      transportBytes: summary.archiveMetrics.transportBytes || null,
      transportCompression: summary.archiveMetrics.transportCompression || null,
      transportRatio: summary.archiveMetrics.transportRatio || null,
    };
  }
  if (summary.delta) profile.delta = summary.delta;
  if (hasOption(process.argv.slice(2), "--pretty")) {
    process.stdout.write(
      [
        `FLX Profile: ${profile.file}`,
        `Kind: ${profile.kind}`,
        `Entry: ${profile.entry}`,
        `Routes: ${profile.routeCount}`,
        `Files: ${profile.fileCount}`,
        `Bytes: ${profile.totalBytes}`,
        `Bytes per route: ${profile.bytesPerRoute}`,
        `Average file size: ${averageFileBytes}`,
        `Prefetch edges: ${profile.prefetchEdges}`,
        profile.syncSources?.length ? `Sync sources: ${profile.syncSources.length}` : null,
        profile.archive ? `Compressed bytes: ${profile.archive.compressedBytes}` : null,
        profile.archive ? `Compression ratio: ${profile.archive.compressionRatio}` : null,
        profile.archive?.transportCompression ? `Transport wrapper: ${profile.archive.transportCompression} (${profile.archive.transportBytes} bytes)` : null,
        profile.archive?.transportRatio ? `Transport ratio: ${profile.archive.transportRatio}` : null,
        profile.archive ? `Dictionary hit rate: ${profile.archive.dictionaryHitRate}` : null,
        profile.delta ? `Delta operations: ${profile.delta.operationCount}` : null,
        profile.largestAsset ? `Largest asset: ${profile.largestAsset.path} (${profile.largestAsset.bytes} bytes)` : "Largest asset: none",
      ].join("\n") + "\n"
    );
    return;
  }
  process.stdout.write(`${JSON.stringify(profile, null, 2)}\n`);
}

function resolvePackageRequest(parsed, requestPath) {
  const normalized = decodeURIComponent(String(requestPath || "/").split("?")[0]);
  const manifestEntry = parsed.manifest?.entry || "index.html";
  const requested = normalized === "/" ? manifestEntry : normalized.replace(/^\/+/, "");
  const direct = parsed.assets.find((asset) => asset.path === requested);
  if (direct) return direct;
  const nestedIndex = parsed.assets.find((asset) => asset.path === `${requested.replace(/\/+$/, "")}/index.html`);
  if (nestedIndex) return nestedIndex;
  return null;
}

function resolveArchiveRequest(artifact, requestPath) {
  const normalized = decodeURIComponent(String(requestPath || "/").split("?")[0]);
  const manifestEntry = artifact.manifest?.entry || "index.html";
  const requested = normalized === "/" ? manifestEntry : normalized.replace(/^\/+/, "");
  const direct = (artifact.assets || []).find((asset) => asset.path === requested);
  if (direct) return direct;
  const nestedIndex = (artifact.assets || []).find((asset) => asset.path === `${requested.replace(/\/+$/, "")}/index.html`);
  if (nestedIndex) return nestedIndex;
  return null;
}

function routeAssetPath(route) {
  if (typeof route?.asset === "string" && route.asset) return route.asset;
  const payload = route?.payload;
  if (payload && typeof payload === "object" && typeof payload.asset === "string" && payload.asset) return payload.asset;
  return null;
}

function filterManifestForAssets(manifest, assetPaths, routeSelector = null) {
  const wanted = new Set(assetPaths);
  const routes = Array.isArray(manifest.routes)
    ? manifest.routes.filter((route) => {
        if (routeSelector && routeSelector(route)) return true;
        const assetPath = routeAssetPath(route);
        return assetPath ? wanted.has(assetPath) : false;
      })
    : [];
  const files = Array.isArray(manifest.files)
    ? manifest.files.filter((file) => wanted.has(file.path))
    : [];
  return {
    ...manifest,
    routes,
    files,
  };
}

function resolveRouteSelection(artifact, selector) {
  const routes = Array.isArray(artifact.manifest?.routes) ? artifact.manifest.routes : [];
  return routes.find((route) => route.path === selector || route.routeId === selector || route.blockId === selector) || null;
}

function collectUnpackSelection(artifact, extraArgs) {
  const manifestOnly = hasOption(extraArgs, "--manifest-only");
  const routeSelector = optionValue(extraArgs, "--route", null);
  const assetSelector = optionValue(extraArgs, "--asset", null);
  const activeModes = [manifestOnly ? "manifest-only" : null, routeSelector ? "route" : null, assetSelector ? "asset" : null].filter(Boolean);
  if (activeModes.length > 1) {
    throw new Error(`Choose only one unpack filter: ${activeModes.join(", ")}`);
  }
  if (manifestOnly) {
    return {
      manifest: artifact.manifest,
      assets: [],
      mode: "manifest-only",
    };
  }
  if (routeSelector) {
    const route = resolveRouteSelection(artifact, routeSelector);
    if (!route) throw new Error(`Could not find route for unpack selection: ${routeSelector}`);
    const assetPath = routeAssetPath(route);
    if (!assetPath) throw new Error(`Selected route does not expose an asset path: ${routeSelector}`);
    const asset = (artifact.assets || []).find((entry) => entry.path === assetPath);
    if (!asset) throw new Error(`Could not find asset for selected route: ${assetPath}`);
    return {
      manifest: filterManifestForAssets(artifact.manifest, [assetPath], (candidate) => candidate === route),
      assets: [asset],
      mode: `route:${routeSelector}`,
    };
  }
  if (assetSelector) {
    const asset = (artifact.assets || []).find((entry) => entry.path === assetSelector);
    if (!asset) throw new Error(`Could not find asset for unpack selection: ${assetSelector}`);
    return {
      manifest: filterManifestForAssets(artifact.manifest, [assetSelector]),
      assets: [asset],
      mode: `asset:${assetSelector}`,
    };
  }
  return {
    manifest: artifact.manifest,
    assets: artifact.assets || [],
    mode: "full",
  };
}

function runUnpack(packagePath, outDirArg, extraArgs) {
  const artifact = readFlxArtifact(packagePath);
  const { resolved } = artifact;
  const outDir = path.resolve(process.cwd(), outDirArg || path.basename(resolved, path.extname(resolved)));
  const selection = collectUnpackSelection(artifact, extraArgs);
  fs.rmSync(outDir, { recursive: true, force: true });
  fs.mkdirSync(outDir, { recursive: true });

  for (const asset of selection.assets) {
    const target = path.join(outDir, asset.path);
    fs.mkdirSync(path.dirname(target), { recursive: true });
    const buffer = asset.encoding === "base64"
      ? Buffer.from(asset.data, "base64")
      : Buffer.from(String(asset.data || ""), "utf8");
    fs.writeFileSync(target, buffer);
  }

  fs.writeFileSync(path.join(outDir, "app.flx.json"), `${JSON.stringify(selection.manifest, null, 2)}\n`, "utf8");
  process.stdout.write(
    [
      `Unpacked ${resolved}`,
      `Output: ${outDir}`,
      `Kind: ${artifact.kind}`,
      `Mode: ${selection.mode}`,
      `Assets: ${selection.assets.length}`,
      `Manifest: ${path.join(outDir, "app.flx.json")}`,
    ].join("\n") + "\n"
  );
}

class SsrBoundaryError extends Error {
  constructor(status, code, message) {
    super(message);
    this.name = "SsrBoundaryError";
    this.status = status;
    this.code = code;
  }
}

function safeSsrResponseHeaders(headers) {
  const blocked = new Set(["connection", "content-length", "keep-alive", "proxy-authenticate", "proxy-authorization", "te", "trailer", "transfer-encoding", "upgrade"]);
  const safe = {};
  for (const [rawName, rawValue] of Object.entries(headers || {})) {
    const name = String(rawName).trim().toLowerCase();
    const value = String(rawValue);
    if (!/^[!#$%&'*+.^_`|~0-9a-z-]+$/.test(name) || blocked.has(name) || /[\r\n]/.test(value) || value.length > 8_192) continue;
    safe[name] = value;
  }
  return safe;
}

function readSsrRequestBody(request, maxBytes, signal) {
  const declared = Number(request.headers["content-length"] || 0);
  if (Number.isFinite(declared) && declared > maxBytes) return Promise.reject(new SsrBoundaryError(413, "REQUEST_TOO_LARGE", "Request body exceeds the configured limit"));
  return new Promise((resolve, reject) => {
    const chunks = [];
    let bytes = 0;
    const cleanup = () => {
      request.off("data", onData);
      request.off("end", onEnd);
      request.off("error", onError);
      request.off("aborted", onAborted);
      signal.removeEventListener("abort", onSignalAbort);
    };
    const fail = (error) => { cleanup(); reject(error); };
    const onData = (chunk) => {
      if (signal.aborted) return onSignalAbort();
      const buffer = Buffer.from(chunk);
      bytes += buffer.byteLength;
      if (bytes > maxBytes) {
        request.pause();
        fail(new SsrBoundaryError(413, "REQUEST_TOO_LARGE", "Request body exceeds the configured limit"));
        return;
      }
      chunks.push(buffer);
    };
    const onEnd = () => {
      cleanup();
      if (bytes === 0) return resolve(undefined);
      const body = Buffer.concat(chunks);
      const contentType = String(request.headers["content-type"] || "").split(";", 1)[0].trim().toLowerCase();
      if (contentType === "application/json") {
        try { resolve(JSON.parse(body.toString("utf8"))); }
        catch { reject(new SsrBoundaryError(400, "INVALID_JSON", "Request body is not valid JSON")); }
        return;
      }
      if (contentType === "application/x-www-form-urlencoded") return resolve(new URLSearchParams(body.toString("utf8")));
      if (contentType === "text/plain") return resolve(body.toString("utf8"));
      resolve(new Uint8Array(body));
    };
    const onError = (error) => fail(error);
    const onAborted = () => fail(new SsrBoundaryError(499, "REQUEST_ABORTED", "Request aborted"));
    const onSignalAbort = () => {
      const reason = signal.reason || new SsrBoundaryError(408, "REQUEST_TIMEOUT", "Request deadline exceeded");
      fail(reason);
      request.destroy(reason);
    };
    request.on("data", onData);
    request.once("end", onEnd);
    request.once("error", onError);
    request.once("aborted", onAborted);
    signal.addEventListener("abort", onSignalAbort, { once: true });
  });
}

function waitForDrain(response, signal) {
  if (signal.aborted) return Promise.reject(signal.reason || new Error("Request aborted"));
  return new Promise((resolve, reject) => {
    const cleanup = () => {
      response.off("drain", onDrain);
      response.off("error", onError);
      response.off("close", onClose);
      signal.removeEventListener("abort", onAbort);
    };
    const onDrain = () => { cleanup(); resolve(); };
    const onError = (error) => { cleanup(); reject(error); };
    const onClose = () => { cleanup(); reject(new Error("Response closed")); };
    const onAbort = () => { cleanup(); reject(signal.reason || new Error("Request aborted")); };
    response.once("drain", onDrain);
    response.once("error", onError);
    response.once("close", onClose);
    signal.addEventListener("abort", onAbort, { once: true });
  });
}

function awaitWithAbort(promise, signal) {
  if (signal.aborted) return Promise.reject(signal.reason || new Error("Request aborted"));
  return new Promise((resolve, reject) => {
    const onAbort = () => {
      cleanup();
      reject(signal.reason || new Error("Request aborted"));
    };
    const cleanup = () => signal.removeEventListener("abort", onAbort);
    signal.addEventListener("abort", onAbort, { once: true });
    Promise.resolve(promise).then(
      (value) => { cleanup(); resolve(value); },
      (error) => { cleanup(); reject(error); },
    );
  });
}

async function writeSsrBody(response, body, signal, limits) {
  let bytes = 0;
  let chunks = 0;
  const write = async (value) => {
    if (signal.aborted) throw signal.reason || new Error("Request aborted");
    if (typeof value !== "string" && !(value instanceof Uint8Array)) throw new SsrBoundaryError(500, "INVALID_STREAM_CHUNK", "SSR streams may emit only strings or Uint8Array chunks");
    const chunk = typeof value === "string" ? Buffer.from(value, "utf8") : Buffer.from(value);
    bytes += chunk.byteLength;
    chunks += 1;
    if (bytes > limits.maxBytes || chunks > limits.maxChunks) throw new SsrBoundaryError(503, "SSR_RESPONSE_LIMIT", "SSR response exceeded its configured stream limit");
    if (!response.write(chunk)) await waitForDrain(response, signal);
  };

  if (typeof body === "string" || body instanceof Uint8Array) {
    await write(body);
    return;
  }
  if (typeof body?.getReader === "function") {
    const reader = body.getReader();
    try {
      while (!signal.aborted) {
        const result = await awaitWithAbort(reader.read(), signal);
        if (result.done) break;
        await write(result.value);
      }
    } finally {
      if (signal.aborted) void reader.cancel(signal.reason).catch(() => undefined);
      try { reader.releaseLock(); } catch { /* A pending read releases after cancellation settles. */ }
    }
    return;
  }
  const iterator = body[Symbol.asyncIterator]();
  try {
    while (!signal.aborted) {
      const result = await awaitWithAbort(iterator.next(), signal);
      if (result.done) break;
      await write(result.value);
    }
  } finally {
    if (signal.aborted && iterator.return) void Promise.resolve(iterator.return()).catch(() => undefined);
  }
}

function sendSsrError(response, securityHeaders, error) {
  if (response.headersSent) {
    response.destroy(error instanceof Error ? error : undefined);
    return;
  }
  const status = error instanceof SsrBoundaryError ? error.status : 500;
  const code = error instanceof SsrBoundaryError ? error.code : "INTERNAL_SERVER_ERROR";
  const body = JSON.stringify({ error: { code, message: status === 500 ? "Internal server error" : error.message } });
  response.writeHead(status, { ...securityHeaders, "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "connection": "close" });
  response.end(body);
}

function directSsrBodyBytes(body) {
  if (typeof body === "string") return Buffer.byteLength(body, "utf8");
  if (body instanceof Uint8Array) return body.byteLength;
  return null;
}

function assetEtag(body, hash = null) {
  return `"sha256-${hash || sha256(body)}"`;
}

function isContentAddressedPath(assetPath) {
  return /(?:^|[._-])[a-f0-9]{8,}(?=\.|$)/i.test(path.basename(assetPath));
}

function staticCacheControl(assetPath, contentType) {
  if (isContentAddressedPath(assetPath)) return "public, max-age=31536000, immutable";
  if (/^(?:text\/html|application\/(?:json|xml))\b/i.test(contentType)) return "no-cache";
  return "public, max-age=0, must-revalidate";
}

function requestEtagMatches(request, etag) {
  const candidates = String(request.headers["if-none-match"] || "").split(",").map((value) => value.trim());
  return candidates.includes("*") || candidates.includes(etag) || candidates.includes(`W/${etag}`);
}

function runServe(packagePath, extraArgs) {
  if (hasOption(extraArgs, "--no-security-headers")) throw new Error("Production security headers are mandatory; configure an equal or stricter policy at the upstream host without disabling Ark UI's policy");
  const artifact = readFlxArtifact(packagePath);
  const { resolved, parsed } = artifact;
  const host = optionValue(extraArgs, "--host", "127.0.0.1");
  const port = parseNumericOption(extraArgs, "--port", 4174);
  const ssrModulePath = optionValue(extraArgs, "--ssr-module", null);
  const ssrModule = ssrModulePath
    ? import(pathToFileURL(path.resolve(process.cwd(), ssrModulePath)).href).then((module) => {
        const handler = module.handleFluxRequest || module.default;
        if (typeof handler !== "function") throw new Error("SSR module must export handleFluxRequest or a default handler function");
        return handler;
      })
    : null;

  const limits = {
    requestTimeoutMs: parseBoundedNumericOption(extraArgs, "--request-timeout-ms", 10_000, 100, 120_000),
    renderTimeoutMs: parseBoundedNumericOption(extraArgs, "--render-timeout-ms", 15_000, 100, 300_000),
    maxRequestBytes: parseBoundedNumericOption(extraArgs, "--max-request-bytes", 1_048_576, 0, 16_777_216),
    maxBytes: parseBoundedNumericOption(extraArgs, "--max-stream-bytes", 8_388_608, 1_024, 67_108_864),
    maxChunks: parseBoundedNumericOption(extraArgs, "--max-stream-chunks", 2_048, 1, 100_000),
    maxConcurrency: parseBoundedNumericOption(extraArgs, "--max-ssr-concurrency", 64, 1, 1_024),
    shutdownTimeoutMs: parseBoundedNumericOption(extraArgs, "--shutdown-timeout-ms", 10_000, 100, 60_000),
  };
  let activeSsr = 0;
  let shuttingDown = false;
  const activeControllers = new Set();
  const sockets = new Set();

  const server = http.createServer(async (request, response) => {
    const asset = artifact.kind === "archive"
      ? resolveArchiveRequest(artifact, request.url || "/")
      : resolvePackageRequest(parsed, request.url || "/");
    if (!asset) {
      if (ssrModule) {
        if (shuttingDown || activeSsr >= limits.maxConcurrency) {
          const securityHeaders = secureResponseHeaders(extraArgs);
          response.writeHead(503, { ...securityHeaders, "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "retry-after": "1" });
          response.end(JSON.stringify({ error: { code: "SSR_BUSY", message: "SSR capacity is currently unavailable" } }));
          return;
        }
        activeSsr += 1;
        const controller = new AbortController();
        activeControllers.add(controller);
        const nonce = crypto.randomBytes(18).toString("base64url");
        const securityHeaders = secureResponseHeaders(extraArgs, { nonce });
        const requestTimer = setTimeout(() => controller.abort(new SsrBoundaryError(408, "REQUEST_TIMEOUT", "Request deadline exceeded")), limits.requestTimeoutMs);
        request.on("aborted", () => controller.abort());
        response.on("close", () => { if (!response.writableEnded) controller.abort(); });
        try {
          const body = await readSsrRequestBody(request, limits.maxRequestBytes, controller.signal);
          clearTimeout(requestTimer);
          const renderTimer = setTimeout(() => controller.abort(new SsrBoundaryError(504, "RENDER_TIMEOUT", "SSR render deadline exceeded")), limits.renderTimeoutMs);
          const handler = await ssrModule;
          const headers = Object.fromEntries(Object.entries(request.headers).map(([key, value]) => [key, Array.isArray(value) ? value.join(", ") : String(value || "")]));
          try {
            const result = await awaitWithAbort(handler({
              url: new URL(request.url || "/", `http://${request.headers.host || `${host}:${port}`}`),
              method: request.method || "GET",
              headers,
              signal: controller.signal,
              cspNonce: nonce,
              body,
            }), controller.signal);
            if (controller.signal.aborted) throw controller.signal.reason || new SsrBoundaryError(504, "RENDER_TIMEOUT", "SSR render deadline exceeded");
            if (!result || typeof result !== "object") throw new SsrBoundaryError(500, "INVALID_SSR_RESPONSE", "SSR handlers must return a response object");
            const status = Math.floor(Number(result?.status || 200));
            if (status < 100 || status > 599) throw new SsrBoundaryError(500, "INVALID_SSR_STATUS", "SSR returned an invalid status code");
            const directBytes = directSsrBodyBytes(result?.body);
            if (directBytes !== null && directBytes > limits.maxBytes) throw new SsrBoundaryError(503, "SSR_RESPONSE_LIMIT", "SSR response exceeded its configured stream limit");
            response.writeHead(status, { "content-type": "text/html; charset=utf-8", ...safeSsrResponseHeaders(result?.headers), ...securityHeaders });
            if ((request.method || "GET").toUpperCase() !== "HEAD" && result?.body != null) {
              await writeSsrBody(response, result.body, controller.signal, limits);
            }
            if (!response.writableEnded) response.end();
          } finally {
            clearTimeout(renderTimer);
          }
        } catch (error) {
          clearTimeout(requestTimer);
          sendSsrError(response, securityHeaders, controller.signal.aborted && controller.signal.reason ? controller.signal.reason : error);
          process.stderr.write(`SSR request failed: ${error instanceof Error ? error.message : String(error)}\n`);
        } finally {
          activeSsr -= 1;
          activeControllers.delete(controller);
        }
        return;
      }
      const securityHeaders = secureResponseHeaders(extraArgs);
      response.writeHead(404, { ...securityHeaders, "content-type": "text/plain; charset=utf-8" });
      response.end("Not found");
      return;
    }
    const body = asset.encoding === "base64"
      ? Buffer.from(asset.data, "base64")
      : Buffer.from(String(asset.data || ""), "utf8");
    const html = contentTypeFor(asset.path).startsWith("text/html");
    const contentType = contentTypeFor(asset.path);
    const securityHeaders = secureResponseHeaders(extraArgs, { body: html ? body : null });
    const etag = assetEtag(body, asset.sha256 || asset.hash || null);
    const responseHeaders = {
      ...securityHeaders,
      "content-type": contentType,
      "cache-control": staticCacheControl(asset.path, contentType),
      "etag": etag,
      "cache-status": "ArkUI; hit",
    };
    if (requestEtagMatches(request, etag)) {
      response.writeHead(304, responseHeaders);
      response.end();
      return;
    }
    response.writeHead(200, {
      ...responseHeaders,
    });
    if ((request.method || "GET").toUpperCase() === "HEAD") response.end();
    else response.end(body);
  });

  server.maxHeadersCount = 100;
  server.headersTimeout = limits.requestTimeoutMs;
  server.requestTimeout = limits.requestTimeoutMs;
  server.keepAliveTimeout = Math.min(5_000, limits.requestTimeoutMs);
  server.on("connection", (socket) => {
    sockets.add(socket);
    socket.once("close", () => sockets.delete(socket));
  });

  const shutdown = () => {
    if (shuttingDown) return;
    shuttingDown = true;
    for (const controller of activeControllers) controller.abort(new SsrBoundaryError(503, "SERVER_SHUTDOWN", "Server is shutting down"));
    server.close(() => process.exit(0));
    server.closeIdleConnections?.();
    const timer = setTimeout(() => {
      for (const socket of sockets) socket.destroy();
      process.exit(0);
    }, limits.shutdownTimeoutMs);
    timer.unref();
  };
  process.once("SIGINT", shutdown);
  process.once("SIGTERM", shutdown);

  server.listen(port, host, () => {
    process.stdout.write(`ark-ui flx server running at http://${host}:${port}/\n`);
    process.stdout.write(`Serving package ${resolved}\n`);
  });
}

function verifyManifestFiles(manifest, rootDir) {
  const failures = [];
  for (const file of manifest.files || []) {
    const target = path.join(rootDir, file.path);
    if (!fs.existsSync(target) || !fs.statSync(target).isFile()) {
      failures.push(`missing file: ${file.path}`);
      continue;
    }
    const body = fs.readFileSync(target);
    if (Number(file.bytes || 0) !== body.byteLength) failures.push(`byte mismatch: ${file.path}`);
    if (String(file.sha256 || "") !== sha256(body)) failures.push(`sha mismatch: ${file.path}`);
  }
  return failures;
}

function verifyPackageAssets(artifact) {
  const failures = [];
  const manifestFiles = new Map((artifact.manifest.files || []).map((file) => [file.path, file]));
  for (const asset of artifact.assets || []) {
    const file = manifestFiles.get(asset.path);
    if (!file) {
      failures.push(`asset missing from manifest: ${asset.path}`);
      continue;
    }
    const body = asset.encoding === "base64"
      ? Buffer.from(asset.data, "base64")
      : Buffer.from(String(asset.data || ""), "utf8");
    if (Number(file.bytes || 0) !== body.byteLength) failures.push(`asset byte mismatch: ${asset.path}`);
    if (String(file.sha256 || "") !== sha256(body)) failures.push(`asset sha mismatch: ${asset.path}`);
  }
  if ((artifact.assets || []).length !== (artifact.manifest.files || []).length) {
    failures.push("asset count does not match manifest file count");
  }
  return failures;
}

function verifyArchiveAssets(artifact) {
  const failures = [];
  const manifestFiles = new Map((artifact.manifest.files || []).map((file) => [file.path, file]));
  for (const asset of artifact.assets || []) {
    const file = manifestFiles.get(asset.path);
    if (!file) {
      failures.push(`archive asset missing from manifest: ${asset.path}`);
      continue;
    }
    const body = asset.encoding === "base64"
      ? Buffer.from(asset.data, "base64")
      : Buffer.from(String(asset.data || ""), "utf8");
    if (Number(file.bytes || 0) !== body.byteLength) failures.push(`archive asset byte mismatch: ${asset.path}`);
    if (String(file.sha256 || "") !== String(asset.sha256 || "")) failures.push(`archive asset sha mismatch: ${asset.path}`);
  }
  if ((artifact.assets || []).length !== (artifact.manifest.files || []).length) {
    failures.push("archive asset count does not match manifest file count");
  }
  return failures;
}

function runVerify(filePath, extraArgs) {
  const artifact = readFlxArtifact(filePath);
  const verifyDir = optionValue(extraArgs, "--dir", null);
  const basePath = optionValue(extraArgs, "--base", null);
  const shardsPath = optionValue(extraArgs, "--shards", null);
  const failures = [];
  let archiveVerification = null;
  let lineageVerification = null;
  let recoveryVerification = null;
  if (artifact.kind === "package") failures.push(...verifyPackageAssets(artifact));
  if (artifact.kind === "archive") {
    archiveVerification = verifyArchiveStructure(artifact.parsed);
    if (!archiveVerification.valid) failures.push(...archiveVerification.errors);
    failures.push(...verifyArchiveAssets(artifact));
    if (basePath) {
      const baseArtifact = readFlxArtifact(basePath);
      if (baseArtifact.kind !== "archive") failures.push(`base artifact must be archive: ${baseArtifact.resolved}`);
      else {
        lineageVerification = verifyArchiveLineage(baseArtifact.parsed, artifact.parsed);
        if (!lineageVerification.valid) failures.push(...lineageVerification.errors);
      }
    }
  }
  if (artifact.kind === "recovery-manifest") {
    if (!shardsPath) failures.push("recovery manifest verification requires --shards <file>");
    else {
      const shardInput = readRecoveryShardsFile(shardsPath);
      recoveryVerification = verifyRecoveryManifest(artifact.manifest, shardInput.shards);
      if (!recoveryVerification.valid) failures.push(...recoveryVerification.errors);
    }
  }
  if (verifyDir) {
    const rootDir = path.resolve(process.cwd(), verifyDir);
    failures.push(...verifyManifestFiles(artifact.manifest, rootDir));
  }
  const summary = {
    file: artifact.resolved,
    kind: artifact.kind,
    verified: failures.length === 0,
    fileCount: (artifact.manifest.files || []).length,
    routeCount: (artifact.manifest.routes || []).length,
    checkedDirectory: verifyDir ? path.resolve(process.cwd(), verifyDir) : null,
    transportCompression: artifact.transport?.compression || "none",
    archiveStatus: archiveVerification?.status || null,
    lineageStatus: lineageVerification ? (lineageVerification.valid ? "valid" : "invalid") : null,
    recoveryStatus: recoveryVerification?.summary?.recoverability || null,
    recoveryPolicy: recoveryVerification ? {
      satisfied: recoveryVerification.summary.policySatisfied,
      basis: recoveryVerification.summary.policyBasis,
      confidence: recoveryVerification.summary.repairConfidence,
      readiness: recoveryVerification.summary.recoveryReadiness,
      repairedGroups: recoveryVerification.summary.repairedGroups,
      missingGroups: recoveryVerification.summary.missingGroups,
      degradedGroups: recoveryVerification.summary.degradedGroups,
    } : null,
    failures,
  };
  if (hasOption(extraArgs, "--pretty")) {
    process.stdout.write(
      [
        `FLX Verify: ${summary.file}`,
        `Kind: ${summary.kind}`,
        `Verified: ${summary.verified ? "yes" : "no"}`,
        `Files: ${summary.fileCount}`,
        `Routes: ${summary.routeCount}`,
        summary.transportCompression !== "none" ? `Transport: ${summary.transportCompression}` : null,
        summary.lineageStatus ? `Lineage: ${summary.lineageStatus}` : null,
        summary.recoveryStatus ? `Recovery: ${summary.recoveryStatus}` : null,
        summary.recoveryPolicy ? `Recovery policy: ${summary.recoveryPolicy.satisfied ? "satisfied" : "not satisfied"} (${summary.recoveryPolicy.basis}, ${summary.recoveryPolicy.confidence}, ${summary.recoveryPolicy.readiness})` : null,
        summary.checkedDirectory ? `Directory: ${summary.checkedDirectory}` : null,
        failures.length > 0 ? "Failures:" : "Failures: none",
        ...(failures.length > 0 ? failures.map((failure) => `- ${failure}`) : []),
      ].filter(Boolean).join("\n") + "\n"
    );
    if (failures.length > 0) process.exitCode = 1;
    return;
  }
  process.stdout.write(`${JSON.stringify(summary, null, 2)}\n`);
  if (failures.length > 0) process.exitCode = 1;
}

function runReconstruct(argv) {
  if (argv.length < 2) throw new Error("Reconstruct requires <base.flx> <delta.flx...>");
  const optionStart = argv.findIndex((value) => value.startsWith("--"));
  const positional = optionStart === -1 ? argv : argv.slice(0, optionStart);
  const extraArgs = optionStart === -1 ? [] : argv.slice(optionStart);
  const [basePath, ...deltaPaths] = positional;
  if (!basePath || deltaPaths.length === 0) throw new Error("Reconstruct requires at least one delta archive");
  if (deltaPaths.length > maxFlxDeltaChainLength()) {
    throw new Error(`Delta chain length exceeds limit: ${deltaPaths.length} > ${maxFlxDeltaChainLength()}`);
  }
  const outFile = path.resolve(process.cwd(), optionValue(extraArgs, "--out", "reconstructed.flx"));
  const baseArtifact = readFlxArtifact(basePath);
  if (baseArtifact.kind !== "archive") throw new Error(`Reconstruct base must be archive: ${baseArtifact.resolved}`);
  let current = baseArtifact.archive;
  for (const deltaPath of deltaPaths) {
    const deltaArtifact = readFlxArtifact(deltaPath);
    if (deltaArtifact.kind !== "archive") throw new Error(`Reconstruct delta must be archive: ${deltaArtifact.resolved}`);
    current = decodeArchive(encodeArchive(applyDelta(current, deltaArtifact.archive)));
  }
  const syncSources = [
    {
      kind: "reconstruct-base",
      archiveId: baseArtifact.archive.header.archiveId,
      archiveHash: baseArtifact.archive.integrity.archiveHash,
      uri: baseArtifact.resolved,
      appliedAt: current.header.createdAt,
    },
    ...deltaPaths.map((deltaPath) => {
      const deltaArtifact = readFlxArtifact(deltaPath);
      if (deltaArtifact.kind !== "archive") throw new Error(`Reconstruct delta must be archive: ${deltaArtifact.resolved}`);
      return {
        kind: "reconstruct-delta",
        archiveId: deltaArtifact.archive.header.archiveId,
        archiveHash: deltaArtifact.archive.integrity.archiveHash,
        uri: deltaArtifact.resolved,
        appliedAt: deltaArtifact.archive.header.createdAt,
      };
    }),
  ];
  const reconstructed = encodeArchive({
    archiveId: current.header.archiveId,
    createdAt: current.header.createdAt,
    entry: current.manifest.entry,
    generatedBy: current.manifest.generatedBy,
    sourceFormat: current.manifest.sourceFormat,
    syncSources,
    routes: current.routes,
    assets: current.assets,
    states: current.states,
  });
  fs.mkdirSync(path.dirname(outFile), { recursive: true });
  fs.writeFileSync(outFile, Buffer.from(reconstructed));
  process.stdout.write(
    [
      "Reconstructed archive chain",
      `Base: ${path.resolve(process.cwd(), basePath)}`,
      ...deltaPaths.map((deltaPath) => `Delta: ${path.resolve(process.cwd(), deltaPath)}`),
      `Output: ${outFile}`,
      `Next: ark verify ${outFile}`,
    ].join("\n") + "\n"
  );
}

function studioUsage() {
  process.stdout.write(
    [
      "ark-ui studio export <input-json> [out-dir]",
      "ark-ui studio apply <bundle-json> [consumer-dir]",
      "",
      "Options:",
      "  --consumer-path <path>   Consumer path embedded into generated commands.",
      "  --manifest <url|path>    Manifest passed to SDK sync when --sync is used.",
      "  --sync                   Run deadark-theme sync-consumer after apply.",
      "  --sync-bin <command>     Override sync command. Default: deadark-theme",
    ].join("\n") + "\n"
  );
}

function ensureDir(dirPath) {
  fs.mkdirSync(dirPath, { recursive: true });
}

function readJsonFile(filePath) {
  return fs.readFileSync(path.resolve(process.cwd(), filePath), "utf8");
}

function writeStudioFiles(outDir, files) {
  ensureDir(outDir);
  for (const file of files) {
    const target = path.join(outDir, file.path);
    ensureDir(path.dirname(target));
    fs.writeFileSync(target, file.contents, "utf8");
  }
}

function codeExportUsage() {
  process.stdout.write(
    [
      "ark-ui code-export <accordion|tabs> <input-json> [out-dir]",
      "",
      "Options:",
      "  --target <name>   react | nextjs | tailwind | shadcn | base-ui | all",
    ].join("\n") + "\n"
  );
}

function codeExport(component, inputPath, outDir, extraArgs) {
  if ((component !== "accordion" && component !== "tabs") || !inputPath) {
    codeExportUsage();
    process.exit(1);
  }
  const payload = JSON.parse(readJsonFile(inputPath));
  const target = optionValue(extraArgs, "--target", "react");
  const targetDir = path.resolve(process.cwd(), outDir || ".");
  const exportOne = component === "tabs" ? exportArkTabsCode : exportArkAccordionCode;
  const exportAll = component === "tabs" ? exportArkTabsCodeForAllTargets : exportArkAccordionCodeForAllTargets;
  if (target === "all") {
    const bundles = exportAll(payload);
    bundles.forEach((bundle) => writeStudioFiles(path.join(targetDir, bundle.target), bundle.files));
    process.stdout.write(
      [
        `Exported ${component} code bundles to ${targetDir}`,
        ...bundles.map((bundle) => `- ${bundle.target}: ${path.join(targetDir, bundle.target)}`),
      ].join("\n") + "\n"
    );
    return;
  }
  const bundle = exportOne(payload, target);
  writeStudioFiles(targetDir, bundle.files);
  process.stdout.write(
    [
      `Exported ${component} ${bundle.target} bundle to ${targetDir}`,
      ...bundle.files.map((file) => `- ${path.join(targetDir, file.path)}`),
      `Dependencies: ${bundle.dependencies.join(", ")}`,
    ].join("\n") + "\n"
  );
}

function runSyncCommand(command, args, cwd) {
  const result = spawnSync(command, args, { cwd, stdio: "inherit", shell: false });
  if (result.error) throw result.error;
  if (result.status !== 0) throw new Error(`Sync command failed with exit code ${result.status}`);
}

function studioExport(inputPath, outDir, extraArgs) {
  if (!inputPath) {
    studioUsage();
    process.exit(1);
  }
  const consumerPath = optionValue(extraArgs, "--consumer-path", ".");
  const payload = readJsonFile(inputPath);
  const bundle = parseArkTemplateStudioPayload(payload);
  const exported = extractArkTemplateStudioBundle(bundle.config, { consumerPath });
  const targetDir = path.resolve(process.cwd(), outDir || ".");
  writeStudioFiles(targetDir, exported.files);
  process.stdout.write(
    [
      `Exported studio bundle to ${targetDir}`,
      ...exported.files.map((file) => `- ${path.join(targetDir, file.path)}`),
      `Apply: ${exported.applyPlan.studioApplyCommand}`,
    ].join("\n") + "\n"
  );
}

function studioApply(bundlePath, consumerDir, extraArgs) {
  if (!bundlePath) {
    studioUsage();
    process.exit(1);
  }
  const consumerPath = path.resolve(process.cwd(), consumerDir || ".");
  const payload = readJsonFile(bundlePath);
  const bundle = parseArkTemplateStudioPayload(payload);
  const applied = extractArkTemplateStudioBundle(bundle.config, { consumerPath });
  writeStudioFiles(consumerPath, applied.files.filter((file) => file.kind !== "studio-bundle"));
  process.stdout.write(
    [
      `Applied studio artifacts to ${consumerPath}`,
      ...applied.files.filter((file) => file.kind !== "studio-bundle").map((file) => `- ${path.join(consumerPath, file.path)}`),
    ].join("\n") + "\n"
  );
  if (!hasOption(extraArgs, "--sync")) {
    process.stdout.write(`Next: ${applied.syncPlan.localCommand}\n`);
    return;
  }
  const syncBin = optionValue(extraArgs, "--sync-bin", "deadark-theme");
  const manifest = optionValue(extraArgs, "--manifest", null);
  const syncArgs = ["sync-consumer", consumerPath];
  if (manifest) syncArgs.push("--manifest", manifest);
  runSyncCommand(syncBin, syncArgs, consumerPath);
}

const [command, arg] = process.argv.slice(2);
let handled = false;

if (!command || command === "--help" || command === "-h") {
  printHelp();
  process.exit(0);
}

if (command === "init") {
  handled = true;
  writeRegistry(arg);
  process.exit(0);
}

if (command === "dev") {
  handled = true;
  runDevServer(arg, process.argv.slice(3));
  process.on("SIGINT", () => process.exit(0));
  process.on("SIGTERM", () => process.exit(0));
  process.exitCode = 0;
}

if (command === "build") {
  handled = true;
  runBuild(arg, process.argv.slice(3));
  process.exit(0);
}

if (command === "inspect") {
  handled = true;
  runInspect(arg);
  process.exit(0);
}

if (command === "profile") {
  handled = true;
  runProfile(arg);
  process.exit(0);
}

if (command === "verify") {
  handled = true;
  runVerify(arg, process.argv.slice(3));
  process.exit(process.exitCode || 0);
}

if (command === "unpack") {
  handled = true;
  runUnpack(arg, process.argv.slice(4)[0], process.argv.slice(3));
  process.exit(0);
}

if (command === "serve") {
  handled = true;
  runServe(arg, process.argv.slice(4));
  process.exitCode = 0;
}

if (command === "reconstruct") {
  handled = true;
  runReconstruct(process.argv.slice(3));
  process.exit(0);
}

if (command === "registry") {
  handled = true;
  process.stdout.write(`${JSON.stringify(bundledRegistry, null, 2)}\n`);
  process.exit(0);
}

if (command === "imports") {
  handled = true;
  printImports();
  process.exit(0);
}

if (command === "studio") {
  handled = true;
  const [subcommand, inputPath, targetDir, ...extraArgs] = process.argv.slice(3);
  if (subcommand === "export") {
    studioExport(inputPath, targetDir, extraArgs);
    process.exit(0);
  }
  if (subcommand === "apply") {
    studioApply(inputPath, targetDir, extraArgs);
    process.exit(0);
  }
  studioUsage();
  process.exit(1);
}

if (command === "code-export") {
  handled = true;
  const [component, inputPath, targetDir, ...extraArgs] = process.argv.slice(3);
  codeExport(component, inputPath, targetDir, extraArgs);
  process.exit(0);
}

if (handled) {
  process.exitCode = process.exitCode ?? 0;
} else {
process.stderr.write(`Unknown command: ${command}\n`);
printHelp();
process.exit(1);
}
