# Performance

Ark UI builds for fast navigation without requiring a permanent application server.

## HTTP caching

`ark serve` assigns content-addressed assets (`app.a1b2c3d4.js`) `public, max-age=31536000, immutable`. HTML, manifests, and other stable URLs receive strong SHA-256 ETags and revalidate with `If-None-Match`; `HEAD` returns the same metadata without a body. Production responses include `Cache-Status` for instrumentation.

## Route rendering

Routes sharing a manifest `layout` preserve the layout element and update only `target` or `[data-flux-route-outlet]`. Stream chunks can provide a stable `key` and a `priority` of `visible`, `normal`, or `background`. The first chunk mounts immediately; later chunks are frame-batched, bounded by `maxBufferedChunks`, and yield after `streamFrameBudgetMs`. Flux binds only inserted or replaced section roots.

Use `decodeFluxArchive` from `@fxn/ui/flx-worker` for package decoding. Inputs above 256 KiB move to a module worker by default; bytes are transferred and work terminates on abort.

## Shared route cache

`FluxRouteCacheAdapter` is the shared storage contract. Keys are `${namespace}:${version}:${routeKey}`, tag invalidation is distributed by the adapter, failures fall back to the resolver, and only serializable string or HTML route results enter shared storage. Use `onStatus` with `fluxCacheStatusHeader` to expose hit, miss, stale, deduplicated, and revalidated states.

Authenticated data remains uncached unless the route explicitly selects `scope: "private"` and the router supplies `cachePartition`. That partition must be an opaque tenant/user/session cache identity, never an authorization credential. `dispose()` detaches a cache instance from distributed invalidation when its process or request scope ends.

### Flux mesh adapter

`@fxn/ui/flux-cache-gun` turns an injected Gun-compatible mesh into the shared route cache, so application code does not need Redis, KV, or provider-specific adapters:

```ts
import Gun from "gun";
import { createFluxGunCacheAdapter } from "@fxn/ui/flux-cache-gun";
import { FluxRouteCache } from "@fxn/ui/flux-router";

const gun = Gun(["https://miner.example/gun"]);
const adapter = createFluxGunCacheAdapter(gun, {
  // Back these with the deployment's Ed25519 identity. Browser peers receive
  // only the public verification key; never ship a server signing key.
  sign: (canonical) => minerIdentity.sign(canonical),
  verify: (canonical, signature) => minerIdentity.verify(canonical, signature),
});
const cache = new FluxRouteCache({ adapter, namespace: "site", version: "2026-08" });
```

Signed mode is mandatory by default. Cache records are bound to their route key, size/TTL/tag bounded, integrity checked, and authenticated. Tag memberships use independent CRDT child nodes rather than race-prone arrays; memberships and short-lived invalidation events are signed too. Reads time out and safely fall through to the route resolver. Use `invalidatePathAsync` / `invalidateTagsAsync` (or the router's `invalidateCacheAsync`) when a mutation must await mesh invalidation before returning.

Private route payloads are denied by default because signatures provide authenticity, not confidentiality. `allowPrivate: true` is accepted only with `trust: "trusted-peers"` and must be restricted to a server-only, access-controlled mesh. Browser-participating meshes should replicate only signed public cache entries. Large `.flx` artifacts should remain content-addressed in the Archivist layer and place only their verified CID in public route HTML or metadata; route cache records intentionally remain bounded.

### Janitor

Every Gun cache write creates a signed expiry-bucket membership. This avoids an unbounded scan of the entries graph. A daemon can run one bounded pass or start the overlap-safe scheduler:

```ts
import { startFluxGunCacheJanitor } from "@fxn/ui/flux-cache-gun";

const stopJanitor = startFluxGunCacheJanitor(gun, {
  sign: minerIdentity.sign,
  verify: minerIdentity.verify,
  intervalMs: 300_000,
  maxBucketsPerRun: 8,
  maxEntriesPerBucket: 500,
  maxInvalidationEvents: 1_000,
});
```

The janitor verifies memberships before deleting, removes corresponding tag edges, prunes expired entries, and bounds signed invalidation history by age and count. `AbortSignal` or the returned function stops it cleanly. This scheduler belongs in the Gun-owning miner/daemon process. `flxd` independently collects expired artifact files, but it still does not own Gun graph cleanup because it has no Gun write transport.

### Archivist artifacts

Compose `createFluxArchivistCacheAdapter` around the Gun adapter. Values above 64 KiB become valid FLX archives and Gun stores only a signed `flx:` CID pointer. Every read checks byte length, recomputes the CID, runs full FLX structural/integrity decoding, and verifies the embedded cache key before returning data. `createFluxDaemonArchivistStore` is the production `flxd` transport: it requires authenticated pin/fetch/delete calls, verifies returned CIDs, skips corrupt replicas, and enforces a minimum successful replica count.

```ts
const archivistStore = createFluxDaemonArchivistStore({
  daemonUrls: ["https://miner-a.internal", "https://miner-b.internal"],
  bearerToken: process.env.FLXD_CACHE_API_TOKEN,
  minReplicas: 2,
});
const shared = createFluxArchivistCacheAdapter(gunAdapter, archivistStore, {
  thresholdBytes: 64 * 1024,
  maxArtifactBytes: 16 * 1024 * 1024,
});
```

### Quorum publication

Wrap the shared adapter with `createFluxQuorumCacheAdapter` and mark selected route policies `consistency: "quorum"`. `createFluxDaemonQuorumCoordinator` sends one canonical proof to independent `flxd` daemons and accepts only provisioned signer identities with valid Ed25519 signatures. Ark binds proofs to the exact key/digest/expiry, persists the proof, and re-verifies it on every shared read. Data is published only after quorum; failed commits leave no optimistic value to roll back.

```ts
const minerCoordinator = createFluxDaemonQuorumCoordinator({
  daemonUrls: ["https://miner-a.internal", "https://miner-b.internal"],
  bearerToken: process.env.FLXD_CACHE_API_TOKEN,
  trustedSignerIds: process.env.FLXD_TRUSTED_SIGNERS.split(","),
  threshold: 2,
});
const committed = createFluxQuorumCacheAdapter(shared, minerCoordinator, {
  minThreshold: 2,
  maxAttestations: 3,
});

const cache = new FluxRouteCache({ adapter: committed });
// Route manifest: cache: { scope: "public", consistency: "quorum" }
```

Quorum caching is a publication-integrity feature, not a financial ledger. Treasury balances and authorization decisions must remain authoritative server/domain mutations with their own consensus and replay protection.

Each daemon requires `FLXD_CACHE_API_TOKEN` (at least 32 characters) and `FLXD_CACHE_SIGNING_SEED_B64` (an independent 32-byte Ed25519 seed). Obtain `/api/cache/identity` during trusted provisioning and pin those signer IDs in application configuration; never trust identities discovered during a cache write. Keep tokens and coordinators server-side, use a private network or TLS reverse proxy, rotate credentials deliberately, and never embed the bearer token in browser JavaScript.

### Chaos verification

`tests/test-mesh-chaos.mjs` runs three isolated virtual Gun peers through a 1,000-key concurrent burst, a partition, full reconnection convergence, bounded graph checks, and replicated janitor deletion. Focused suites prove CID poisoning rejection, corrupt-replica failover, signed record rejection, trusted Ed25519 quorum enforcement, and subscription cleanup. The Rust `flxd` process test exercises the real authenticated HTTP pin/fetch and attestation APIs on a loopback port.

## Entry points

Build generates `@fxn/ui/components/<component>` and `@fxn/ui/icons/solyrunners/<icon>` modules plus `dist/ark-ui.import-map.json`. These are dependency-closed modules, not re-export facades. `dist/ark-ui.performance.json` enforces per-entry minified, gzip, and Brotli limits during every build.

## Assets

The CLI reserves intrinsic image dimensions, emits responsive `srcset` from `name-<width>w.ext` siblings, wraps PNG/JPEG sources with available AVIF/WebP alternatives, and preloads only images marked `data-ark-priority="high"`. Other images default to lazy loading and async decoding. Mark font preload links with `data-ark-font`; Ark adds `as="font"` and anonymous CORS. Ship subsetted WOFF2 files per language range rather than a single full font. External classic scripts default to `defer`; use `data-ark-strategy="async"` only for independent scripts.
