# Flux Animate

`FluxAnimate` is the native animation engine for `ark-ui` and `flux-dom`.

It keeps the same zero-build, DOM-first model as the rest of the stack:

- declare animation intent in HTML with `data-flx-animate*`
- let the Web Animations API handle motion on the element
- let Flux state changes decide *when* a preset runs
- keep layout/presence/ARIA behavior in the primitive helpers

## Import

```ts
import { FluxAnimate, startFluxAnimate } from "@fxn/ui/animate";
```

## Core Pattern

```html
<div data-flx-animate="fadeIn">Hello</div>

<aside
  data-flx-animate="$UI.sidebar.open ? slideIn : slideOut"
  data-flx-animate-duration="320ms"
  data-flx-animate-easing="cubic-bezier(0.2, 0, 0, 1)"
>
  Sidebar
</aside>
```

```ts
const animator = new FluxAnimate({
  root: app,
  store: flux.store,
});
```

If you want console control immediately, use the bootstrap helper instead:

```ts
const animator = startFluxAnimate({
  root: app,
  store: flux.store,
  ui,
  globalName: "fluxAnimate",
});
```

That exposes `window.fluxAnimate` with direct debug controls.

If you are already using `createArkUI()`, there is now a native path too:

```ts
const ui = createArkUI({
  animations: {
    globalName: "fluxAnimate",
  },
});
```

Or after creation:

```ts
ui.enableAnimations({ globalName: "fluxAnimate" });
```

## Attributes

- `data-flx-animate`: preset name or Flux conditional expression
- `data-flx-animate-delay`: start delay like `120ms` or `0.2s`
- `data-flx-animate-duration`: duration override
- `data-flx-animate-easing`: easing override
- `data-flx-animate-config`: JSON config for spring/gesture behavior
- `data-flx-animate-exit`: explicit exit preset when a primitive wants one
- `data-flx-animate-stagger`: stagger spacing for child sequencing
- `data-flx-animate-once="true"`: play the named preset only once per node
- `data-flx-animate-id`: stable FLIP/layout identity

## Built-In Presets

- `fadeIn`
- `fadeOut`
- `slideIn`
- `slideOut`
- `fadeUp`
- `scaleIn`
- `scaleOut`
- `spring`
- `layout`
- `stagger`
- `route:enter`
- `route:exit`
- `accordion:enter`
- `accordion:exit`

## Flux State Expressions

The engine accepts the same path style teams already use in Flux-facing markup:

```html
<div data-flx-animate="$UI.dialog.open ? scaleIn : fadeOut"></div>
<div data-flx-animate="$R-PANEL.open ? accordion:enter : accordion:exit"></div>
```

Both `$UI.path` and `$R-REF.path` forms are normalized onto the underlying store path before subscription.

## Router Integration

`FluxRouter` can orchestrate route transitions directly:

```ts
const animator = new FluxAnimate({ root: app, store: flux.store });

const router = new FluxRouter({
  root: app,
  flux,
  animate: animator,
});
```

Then mark route roots in the rendered HTML:

```html
<section data-flx-animate="route:enter" data-flx-animate-exit="route:exit">
  ...
</section>
```

## Primitive Pattern

Primitives should keep ownership of structure, presence, ARIA, and state.
`FluxAnimate` should layer on top of that by stamping `data-flx-animate*` attrs onto the already-managed refs.

Accordion is the reference pattern:

- `createPresence()` still owns mounted/hidden state
- `createArkAccordion()` stamps panel refs with Flux animation attrs
- `FluxAnimate` reads those attrs and animates opacity/transform on open/close

That means the primitive stays usable without the animator, but upgrades automatically when an app binds `FluxAnimate`.

## Accordion Example

```ts
createArkAccordion(ui, {
  rootRef: "R-FAQ",
  values: ["shipping", "billing"],
  animation: {
    enterPreset: "accordion:enter",
    exitPreset: "accordion:exit",
    duration: "220ms",
    stagger: "40ms",
  },
});
```

This writes a conditional expression onto each panel in the form:

```txt
$R-PANEL.open ? accordion:enter : accordion:exit
```

## Console Control

When bootstrapped with `startFluxAnimate({ ui, globalName: "fluxAnimate" })`, the browser console gets:

- `fluxAnimate.list()`
- `fluxAnimate.play("#my-id", "fadeIn")`
- `fluxAnimate.playRef("R-PN1", "accordion:enter")`
- `fluxAnimate.get("R-PN1")`
- `fluxAnimate.routeEnter()`
- `fluxAnimate.routeExit()`
- `fluxAnimate.captureLayout()`
- `fluxAnimate.animateLayout()`

Example:

```js
fluxAnimate.playRef("R-PN1", "accordion:enter")
fluxAnimate.play("#sidebar", "slideIn")
fluxAnimate.list()
```

If you only construct `new FluxAnimate(...)`, nothing is exposed globally by default. The engine will run, but the console bridge will not be installed until you call `attachFluxAnimateConsole(...)` or `startFluxAnimate(...)`.

## Reduced Motion

`FluxAnimate` respects `prefers-reduced-motion`. When reduced motion is active, animations resolve immediately instead of running full motion timing.
