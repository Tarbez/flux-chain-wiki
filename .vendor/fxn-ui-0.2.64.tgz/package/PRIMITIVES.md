# ARK UI Primitives

This file documents the first-class primitive helpers that sit on top of the ARK UI runtime.

For a slot-first composition model on top of these imperative behavior primitives, use `@fxn/ui/headless` and see `HEADLESS.md`.

## Included Helpers

- `createArkDialog(...)`
- `createArkAlert(...)`
- `createArkAlertDialog(...)`
- `createArkPopover(...)`
- `createArkTooltip(...)`
- `createArkMenu(...)`
- `createArkMegaMenu(...)`
- `createArkChart(...)`
- `createArkMenuGroup(...)`
- `createArkMenuLabel(...)`
- `createArkMenuSeparator(...)`
- `createArkMenuItem(...)`
- `createArkSubmenu(...)`
- `createArkMenuCheckboxItem(...)`
- `createArkMenuRadioGroup(...)`
- `createArkTabs(...)`
- `createArkSelect(...)`
- `createArkCombobox(...)`
- `createArkCollapsible(...)`
- `createArkCodeBlock(...)`
- `createArkSheet(...)`
- `createArkDrawer(...)`
- `createArkProgress(...)`
- `createArkCheckbox(...)`
- `createArkCheckboxGroup(...)`
- `createArkContextMenu(...)`
- `createArkInputGroup(...)`
- `createArkOtpField(...)` (`createArkInputOtp(...)` compatibility alias)
- `createArkDirection(...)`
- `createArkItem(...)`
- `createArkMarker(...)`
- `createArkMessageScroller(...)`
- `createArkNativeSelect(...)`
- `createArkResizablePanels(...)`
- `createArkRadioGroup(...)`
- `createArkSeparator(...)`
- `createArkSpinner(...)`
- `createArkToggle(...)`
- `createArkToggleGroup(...)`
- `createArkDisclosure(...)`
- `createArkAccordion(...)`
- `createArkBreadcrumbs(...)`
- `createArkPagination(...)`
- `createArkCommandSurface(...)`
- `createArkForm(...)`
- `createArkCollection(...)`
- `createArkTable(...)`
- `createArkDataTable(...)`
- `createArkAspectRatio(...)`
- `createArkAttachment(...)`
- `createArkAvatar(...)`
- `createArkButtonGroup(...)`
- `createArkMessageBubble(...)`
- `createArkOverlayIndicator(...)`
- `createArkDirection(...)`
- `createArkScrollArea(...)`
- `createArkSidebar(...)`
- `createArkAppShell(...)`
- `createArkNavigationMenu(...)`
- `createArkMenubar(...)`
- `createArkSlider(...)`
- `createArkCalendar(...)`
- `createArkDatePicker(...)`
- `createArkCarousel(...)`
- `createArkToastRegion(...)`
- `createArkTheme(...)`
- `createArkStyleRecipe(...)`
- `createArkStyleLibraryPack(...)`
- `createArkBrandTemplate(...)`

Alongside these, some **style-schema primitives** — Badge, Kbd, Switch, and Skeleton — ship as pattern-grammar roles with no imperative `createArkX(...)` helper: they're wired entirely through the `F`/`M` pattern string and theme tokens, so there's nothing to configure at runtime. See their docs pages in the ArkUI docs site for the exact role tokens. Badge is a legitimate example of this shape done right: `M-BADGE` for the default look plus `X-SECONDARY`/`X-OUTLINE`/`X-DANGER`/`X-SUCCESS`/`X-WARNING` tone modifiers (e.g. `X-DANGER-M-BADGE`) — matches shadcn's variant prop with zero runtime behavior needed. Avatar and Checkbox used to be on this list too (a static circle with a text fallback and no image handling; a bare `<input type=checkbox>` with no indeterminate support) — as of 2026-08-23/24 they're `createArkAvatar(...)`/`createArkCheckbox(...)`, real primitives, because "style-only" can't express image load/error state, a fallback-after-delay, or the `.indeterminate` DOM property (which has no HTML attribute form at all).

## Dialog

Use `createArkDialog(...)` when a surface is modal.

What it wires:

- trigger to content relationship
- `role="dialog"` and `aria-modal`
- focus trap and focus restore
- dismissable layer
- portal mounting
- backdrop creation
- body scroll lock

## Alert

Use `createArkAlert(...)` for inline product messaging and `createArkAlertDialog(...)` for confirmation-heavy modal interruption.

What they wire:

- alert title/body/icon/action parts
- dismissible alert state with optional live-region behavior
- `role="alertdialog"` for destructive or high-priority modal confirmation, with outside/overlay clicks disabled by default — only `Action`, `Cancel`, or Escape can close it, unlike a plain `createArkDialog()`
- dedicated tone/state metadata for app-level orchestration
- controlled and uncontrolled open state, lifecycle reasons, completion hooks, and cancellable action/cancel/Escape hooks
- multiple or detached-style triggers with active-trigger payloads
- persistent mounting for exit animation plus imperative `open`, `close`, `toggle`, `setOpen`, and `syncControlled` actions

See [PRIMITIVE_COOKBOOK.md](PRIMITIVE_COOKBOOK.md#12-dismissible-alert-and-a-destructive-alert-dialog) for a full example of both.

## Popover

Use `createArkPopover(...)` for anchored non-modal surfaces.

What it wires:

- trigger to content relationship
- dialog-style popup semantics
- non-modal focus scope
- portal positioning

## Tooltip

Use `createArkTooltip(...)` for hover/focus-triggered hint text on a trigger element.

What it wires:

- `role="tooltip"` and `aria-describedby` on the trigger
- anchored overlay positioning, defaulting to `top`/`center`
- show on hover or focus, hide on mouseleave or blur
- presence-driven mount/unmount with `aria-hidden`

## Menu

Use `createArkMenu(...)` for action menus and `createArkSubmenu(...)` for nested branches.

Use `createArkMenuGroup(...)`, `createArkMenuLabel(...)`, and `createArkMenuSeparator(...)` to build richer menu surfaces.

Use `createArkMenuItem(...)` for leaf items, `createArkMenuCheckboxItem(...)` for toggleable menu items, and `createArkMenuRadioGroup(...)` for single-selection groups.

What it wires:

- `role="menu"` / `role="menuitem"`
- roving tabindex
- typeahead
- nested dismiss boundaries
- disabled item support
- leaf-item close behavior
- checkbox and radio item semantics
- group, label, and separator composition helpers
- optional app-scale state model via `stateRef`

Use `createArkContextMenu(...)` for a right-click menu — pass a `targetRef` (the real element whose `contextmenu` event should open it) and an `anchorRef` (a small `position:fixed` element the overlay anchors to). It reuses `createArkMenu(...)` entirely; the only new behavior is repositioning `anchorRef` to the pointer's `clientX`/`clientY` on every right-click before opening, since the overlay positioner needs a real element's `getBoundingClientRect()` — there's no "virtual anchor" concept in this runtime.

## Checkbox

Use `createArkCheckbox(...)` for a single checkbox with real tri-state support, and `createArkCheckboxGroup(...)` for a set of independently-checkable items.

What they wire:

- `createArkCheckbox(...)`: the `.indeterminate` DOM property (which has no HTML attribute form — JS-property-only per spec) plus `aria-checked="mixed"`, both written directly to the live element since neither can go through the generic attrs pipeline; `check()`/`uncheck()`/`toggle()`, `stateRef`, and `onCheckedChange`
- `createArkCheckboxGroup(...)`: a `role="group"` root and independent `checked` state per item, tracked in one `stateRef` — deliberately does **not** wire roving focus, since unlike a radio group each checkbox stays its own Tab stop (arrow keys don't move between them)

## Tabs

Use `createArkTabs(...)` to connect a tablist, tabs, and panels.

What it wires:

- `tablist`, `tab`, and `tabpanel` semantics
- roving focus across tabs
- helper-level selected state
- disabled-tab handling
- optional automatic activation
- helper-level panel visibility
- optional app-scale state model via `stateRef`

## Select

Use `createArkSelect(...)` for button-triggered listbox selection.

What it wires:

- trigger popup semantics
- listbox and option roles
- open and close behavior
- committed selection state
- highlighted option state
- disabled option handling
- Escape-to-cancel behavior
- optional value text syncing
- optional app-scale state model via `stateRef`

Use `createArkNativeSelect(...)` instead when you want a real `<select>`/`<option>` — the platform's own mobile picker, SSR/no-JS resilience, and no custom listbox JS at all. Options are populated onto the live element imperatively at setup (this runtime's `F`/`M` pattern grammar can't spread a JS array into markup), and value changes after that write `.value` directly rather than through `ui.update()`, which would replace the element and wipe the `<option>`s.

## Input Group

Use `createArkInputGroup(...)` around an `<input>` plus prefix/suffix addons — an icon button, a "$"/".com" affix. Thin by design, like `createArkAspectRatio(...)`: the real value is the `INPUTGROUP` style part, which merges the input's border with its addons into one shared border and focus ring instead of each rendering its own.

## Input OTP

Use `createArkOtpField(...)` for a production segmented verification-code field. It keeps one real `<input maxlength=1>` per character slot, joins the value through an optional hidden form input, and supports controlled/uncontrolled state, numeric/alpha/alphanumeric validation, custom normalization, masking, autofill, auto-submit, paste, focus navigation, invalid/complete hooks, and bidirectional Flux store binding. `createArkInputOtp(...)` remains as a compatibility alias.

What it wires:

- auto-advance to the next slot after typing a character
- backspace on an already-empty slot clears and refocuses the previous slot (matches every production OTP input, rather than just stopping at the boundary)
- Arrow-key navigation between slots
- paste fan-out: a full code pasted into any slot fills the remaining slots from that point, not just the one slot the paste landed in
- `stateRef`, `onValueChange`, and `onComplete` (fires once every slot has a character)
- `setValue(...)` / `clear()` handle methods

Pair it with the `OTP` / `OTPSLOT` style parts.

The browser-native `<flux-otp-field>` masks its input slots by default; add `reveal` only for non-secret verification codes that should remain visible. Fixed codes may use `length`. Variable-length PINs should provide `min-length` and `max-length`: only the minimum slots are initially visible, then the primitive reveals one continuation slot at a time as the user types. It exposes `data-min-complete` when the minimum is satisfied and `data-visible-length` for styling and diagnostics.

### Scoped authorization dialog

`<flux-authorization-dialog>` is the shared modal shell for inspectable signing
requests. It inherits the focus trap, Escape dismissal, focus restoration and ARIA
semantics of `<flux-dialog>`, and adds `state`, `action`, and `capability` attributes.
`ScopedAuthorizationDialog` from `@fxn/ui/flux-authorization-react`
renders a shared consent view inside this shell. Non-React products can use
`scopedAuthorizationView` from `@fxn/ui/flux-authorization-view`.
Both require the broker to provide the digest and the **exact bytes** it will
sign; the readable manifest is a separate disclosure. The view never signs or
derives keys. The product's authorization broker may sign only after explicit
approval, and must invalidate a pending request when the identity changes.

## Direction

Use `createArkDirection(...)` as the app-wide `dir` provider. Setting `dir` on `rootRef` is what `isRtlContext()` (ark-ui.runtime.ts) walks up to via `closest('[dir]')` when it flips Arrow-key direction for every horizontal collection nested underneath — accordion, tabs, menubar, carousel, and anything else built on `createRovingFocusGroup(...)` inherits RTL support for free from this one attribute; there's no separate per-component RTL wiring to do. The returned handle's `setDirection(...)`/`getState()` make it live state instead of a fire-once attribute write, e.g. for a user-facing language switcher that flips direction without a full remount.

## Item

Use `createArkItem(...)` for a plain clickable list row — a file browser entry, a search result, a settings row — using the same icon/leading + label/content + trailing-action shape Menu/Select/Combobox items already informally have. Pass a shared `collection` id (a roving-focus-group id you create) when several `createArkItem(...)` rows sit in one plain list; leave it off for a single standalone item.

What it wires:

- `role="button"` and click-to-select
- `selected`/`disabled` state, `stateRef`, and `onSelect`

Pair it with the `ITEM` / `ITEMLEADING` / `ITEMCONTENT` / `ITEMTRAILING` style parts.

## Marker

Use `createArkMarker(...)` to place a pin/annotation at an x/y coordinate on a map, canvas, or image surface — `unit: "percent"` (default) tracks correctly if the surface resizes or zooms; `unit: "pixel"` for a fixed-size surface. The container gets `position: relative` automatically; the marker is positioned via `left`/`top`/`transform`, tip-anchored to the coordinate (not its bounding-box corner, the usual expectation for a pin glyph). Pair it with the `MARKER` style part for the shipped pin look, and pass `onSelect` for a clickable marker.

## Combobox

Use `createArkCombobox(...)` for text entry with filtered options.

What it wires:

- `role="combobox"` and `aria-activedescendant`
- popup listbox semantics
- input-driven filtering
- arrow-key highlight updates
- disabled option handling
- Enter-to-commit behavior
- Escape restores the committed value
- popup open and close coordination
- optional empty-state surface and app-scale state model via `stateRef`
- optional `groups` — labelled subsets of `optionRefs`, each wired with `role="group"`/`aria-labelledby` like a native `<optgroup>`; a group's heading auto-hides once filtering leaves none of its options visible

## Disclosure

Use `createArkDisclosure(...)` for inline collapsible content and `createArkCollapsible(...)` when you want the same behavior under a dedicated collapsible surface contract.

What it wires:

- trigger-to-panel relationship
- `aria-expanded` and `aria-controls`
- region labelling for the revealed content
- button keyboard toggling

## Code Block

Use `createArkCodeBlock(...)` when a docs page, playground, or settings surface needs collapsible code that should inherit the active Ark theme instead of depending on page-local wrappers.

What it wires:

- the same disclosure semantics as `createArkDisclosure(...)`
- a shipped `CODEBLOCK` / `CODEBLOCKTRIGGER` / `CODEBLOCKCONTENT` / `CODEBLOCKCODE` part set
- open and closed trigger labels, defaulting to `View code` and `Hide code`
- direct code text syncing through `codeRef`

## Accordion

Use `createArkAccordion(...)` for grouped, keyboard-navigable reveal sections — FAQ lists, settings groups, filter panels.

What it wires:

- `type: "single" | "multiple"` open modes, with `collapsible` controlling whether a single open item can close back to none
- value-based items via `values`, `defaultValue`, and the returned handle's `setValue()` / `open()` / `close()` / `toggle()` methods
- root-level `disabled`, plus per-item `disabledRefs` / `disabledItemRefs`, reflected as `aria-disabled` and `data-disabled`
- `itemRefs` / `triggerRefs` / `panelRefs` state attributes like `data-state`, `data-open`, `data-value`, `data-index`, and `data-orientation`
- `aria-expanded`/`aria-controls`/region labelling between each trigger and panel
- optional `keepMounted: false` unmounting, or `hiddenUntilFound` for searchable closed panels
- roving-tabindex keyboard nav across triggers (Up/Down/Home/End) via `createRovingFocusGroup()`, with `loopFocus` control
- `stateRef` and `onValueChange` for reading or reacting to the open value set plus index/ref details
- optional `animation` stamping of `data-flx-animate*` attrs onto panel refs so `FluxAnimate` can layer native enter/exit motion on top of presence and a11y behavior

Pair it with the `ACCORDION` / `ACCORDIONITEM` / `ACCORDIONHEADER` / `ACCORDIONTRIGGER` / `ACCORDIONCONTENT` / `ACCORDIONCONTENTBODY` style parts for the shipped look — a chevron that rotates off `aria-expanded`, and a grid-row open/close animation driven by `createPresence()`'s `data-presence` attribute. If you also bind [FLUX_ANIMATE.md](FLUX_ANIMATE.md), `createArkAccordion()` can stamp each panel with a conditional expression like `$R-PANEL.open ? accordion:enter : accordion:exit`, so presence still owns height/layout while the animator adds opacity/transform motion. **Leave `M` off the trigger and body refs** when using those parts: giving a ref both an `F` shape and an `M` meaning makes schema resolution use the `M` value and silently drop the `F`-specific style (see `resolveSchema()` in `ark-ui.runtime.ts`). Set label/body text with `ui.update(ref, { text })` instead. See [PRIMITIVE_COOKBOOK.md](PRIMITIVE_COOKBOOK.md#9-faq-accordion-with-disabled-items) for a full example.

## Breadcrumbs And Pagination

Use `createArkBreadcrumbs(...)` for wayfinding trails and `createArkPagination(...)` for page progression controls.

What they wire:

- roving focus across trail or page items
- `aria-current="page"` for the active location
- hidden separators for breadcrumb punctuation
- previous and next boundary disabling in pagination
- optional `maxVisible`/`ellipsisRef` overflow collapsing on breadcrumbs — hides the middle items behind a `BREADCRUMBELLIPSIS` button (shadcn's `BreadcrumbEllipsis`) that expands the full trail on click
- optional `siblingCount`/`leadingEllipsisRef`/`trailingEllipsisRef` truncation on pagination — keeps the first page, the last page, and a window around the current page visible, collapsing the rest behind up to two ellipses

## Button Group

Use `createArkButtonGroup(...)` when independent buttons should render visually joined — a filter bar, a segmented set of view switches that aren't a single selection value. This is a different thing from `createArkToggleGroup(...)`: a Button Group has no shared pressed/selection state at all, each member is just a plain button that happens to sit flush against its neighbors (exactly what shadcn's own Button Group is).

What it wires:

- `role="group"` and `data-orientation` on the root
- joined-border, corner-rounding-only-at-the-ends styling via the `BUTTONGROUP` part
- arrow-key roving focus across the members (Base UI Toolbar's contribution to the pattern)

## Sheets, Progress, And Toggles

Use `createArkSheet(...)` and `createArkDrawer(...)` for directional modal surfaces, `createArkProgress(...)` for loading and completion feedback, `createArkRadioGroup(...)` for grouped single selection, `createArkSeparator(...)` for semantic dividers, `createArkSpinner(...)` for loading indicators, and `createArkToggle(...)` plus `createArkToggleGroup(...)` for pressed-state actions.

What they wire:

- directional sheet and drawer helpers with backdrop/focus handling
- progressbar semantics with indicator/value coordination
- grouped radio selection with roving focus
- semantic separators and spinner status parts
- single and grouped pressed-state controls with app-scale state models

## Message Bubble And Overlay Indicator

Use `createArkMessageBubble(...)` for chat/speech-bubble surfaces and `createArkOverlayIndicator(...)` for a corner-anchored presence dot or count badge (an unread count on a bell icon, an activity dot on a nav item). These are deliberately separate, distinctly-named primitives rather than one ambiguous "Bubble" — a chat bubble and a notification dot don't share any behavior.

What they wire:

- `data-align` (`own`/`other`) and `data-grouped` on the message bubble root, for the tail-side styling and consecutive-message collapsing
- `data-corner` placement, a `max`-capped count (renders "9+" past the cap), and `dot`-only mode with no count on the overlay indicator
- `setCount(...)` to update an overlay indicator's badge value later

Both `indicatorRef` (on `createArkOverlayIndicator`) and the timestamp/status refs on `createArkMessageBubble` need a real `M-` meaning in your own markup, not a bare `F-` shape — see the note on the `MESSAGEBUBBLE` schema entry in `ark-ui.components.ts` for why (a CONTAINER-role leaf never gets its `text` written).

Use `createArkMessageScroller(...)` to wrap the scrolling container a thread of `createArkMessageBubble(...)` rows lives in.

What it wires:

- at-bottom tracking off the viewport's own `scroll` event
- `notifyNewContent()`: call it right after appending a new message — it auto-scrolls if the viewport was already at the bottom, or bumps an unread count and shows `unreadRef` if the user had scrolled up to read history (clicking `unreadRef` scrolls to bottom and clears the count)
- `scrollToBottom(...)` for an explicit "jump to latest" control

## Command Surface

Use `createArkCommandSurface(...)` for searchable command palettes and launcher surfaces.

What it wires:

- combobox-style filtering and selection
- empty and loading state coordination
- committed command callbacks
- consistent command-surface parts for theming

## Form System

Use `createArkForm(...)` on top of `createArkField(...)` when a screen needs labels, validation, messaging, and submission flow as one system.

What it wires:

- field-level error state and `aria-invalid`
- assertive error summaries plus polite submit status messaging
- required-field enforcement and custom validation hooks
- submit-button loading and disabled state coordination
- success surface toggling after valid submission

## Collections And Tables

Use `createArkCollection(...)` for list-like selection, `createArkTable(...)` when the selectable surface is tabular, and `createArkDataTable(...)` when the table also needs client-side sorting and simple page-level navigation.

What they wire:

- roving focus through items or rows
- single or multiple selection state
- empty and loading display coordination
- optional detail-panel visibility based on selection
- header-driven client-side sort hooks and simple page slicing in `createArkDataTable(...)`
- `createArkDataTable(...)` also wires column show/hide (`hiddenColumnRefs`, `showColumn()`/`hideColumn()`), column pinning (`pinnedColumnRefs` — each pinned column's sticky `left` offset is measured off the rendered width of the pinned columns before it, so resizing an earlier one keeps later ones aligned instead of drifting), and column resizing (`resizeHandleRefs`, one grip ref per resizable column — dragging it adjusts that column's width, clamped to `minWidth`, plus an imperative `setColumnWidth()`). Each `columns[]` entry needs a `cellRefs` array (one ref per row) for any of these three to reach that column's cells, not just its header
- `createArkTable(...)` also wires optional `captionRef`/`theadRef`/`footerRef` parts, a lighter single-column `sortableHeaderRefs` sort (none → asc → desc → none, driven off `aria-sort` — for data-aware column sorting over row values, use `createArkDataTable(...)` instead), and `stickyHeader`/`stickyFirstColumnRefs` pinning

Pair `createArkTable(...)` with the `TABLE` / `TABLECAPTION` / `THEAD` / `TABLEFOOTER` / `TBODY` / `ROW` / `CELL` / `HEADERCELL` style parts.

## App Shell

Use `createArkAppShell(...)` when a product needs a persistent icon rail plus an independently expandable labeled nav strip, with a main content region that always fills the rest of the width. Unlike `createArkSidebar(...)` — whose rail and panel are mutually exclusive (one replaces the other) — the App Shell keeps the rail mounted at all times and only toggles the nav strip beside it.

What it wires:

- a CSS grid on `shellRef` (`rail | nav | main`, or `rail | main` when no `navRef` is given) that animates column widths on toggle
- `hidden` state on `navRef` when collapsed, kept in sync with the grid
- an optional `triggerRef` that toggles the nav strip
- `stateRef`/`onExpandedChange` for reading or reacting to the expanded flag

## Navigation Menu, Mega Menu, And Menubar

Use `createArkNavigationMenu(...)` for tab-like section switching where triggers swap inline panels. Use `createArkMegaMenu(...)` when each top-level trigger instead needs its own floating panel of arbitrary content (link columns, a promo card) — a marketing/e-commerce site header, not a settings-page tab strip. Use `createArkMenubar(...)` for desktop-style top-level action chrome where each trigger owns an overlay-backed menu.

What they wire:

- navigation-menu panel switching on top of the tab substrate
- mega-menu per-trigger floating panels (`items[].contentRef` holds arbitrary markup, unlike Menu/Menubar's flat `itemRefs`), one open at a time, with `aria-expanded` kept in sync however a panel closes (click, keyboard, Escape, or an outside click/focus via the dismissable layer)
- mega-menu hover-intent open/close (`openOnHover`, default true, with separate `hoverOpenDelay`/`hoverCloseDelay`) hardened against a real bug class: `configureRef()`/`update()` replace the trigger element on every re-render, and a stationary cursor now sitting over the freshly-swapped-in element fires a fresh `pointerenter` with no actual mouse movement — left unguarded, that reopens a panel the user just dismissed, seconds later, for no visible reason. The fix tracks real hover presence separately from a "this trigger closed while genuinely hovered" suppression set that only clears on an actual `pointerleave`
- mega-menu roving focus across top-level triggers (Arrow Left/Right) and keyboard open (ArrowDown/Enter/Space) — focus deliberately stays on the trigger rather than auto-jumping into panel content, since that content is consumer-authored and not guaranteed to have `onAction` handlers wired up
- menubar-level roving focus across top-level triggers
- persistent `role="menubar"` / `role="menuitem"` semantics for the top rail
- one-open-branch coordination across the top rail
- shared menu behavior for each branch via the existing menu helper

Pair `createArkMegaMenu(...)` with the `MEGAMENU` style part.

## Layout, Media, And Motion

Use `createArkAspectRatio(...)` to lock a media shell to a predictable ratio, `createArkScrollArea(...)` for overflow surfaces with optional custom thumbs, `createArkSidebar(...)` for collapsible side panels — pass `closedWidth` for a condensed-but-still-mounted closed state (e.g. an icon-width strip with the same nav buttons, just narrower) instead of the default fully-hidden `0px` — `createArkNavigationMenu(...)` for nav-panel coordination, `createArkSlider(...)` for range-like value picking, and `createArkCarousel(...)` for track/slide progression.

What they wire:

- ratio-locked media shells with child fill behavior
- overflow viewport styling plus optional thumb syncing, pointer-draggable thumbs (tracks the pointer's delta from drag-start, not its live position, so a fast flick past the track edge doesn't overshoot or snap), and an optional `cornerRef` shown only when both `scrollbarXRef` and `scrollbarYRef` are wired
- collapsible sidebar open-state coordination
- navigation-menu panel switching on top of the tab substrate
- keyboard and pointer value control for sliders
- slide index, dot, and previous/next coordination for carousels, plus `role="region"`/`aria-roledescription` landmark semantics, Arrow-key navigation (bubbles from any focused descendant), and an `autoplay` interval that pauses on pointer hover or keyboard focus and resumes on leave/blur

Use `createArkResizablePanels(...)` for a split-pane layout — a file browser's sidebar + content, a code editor's panes.

What it wires:

- flex-basis-driven panel sizing from a `sizes` fraction array (defaults to an equal split)
- pointer-drag on each handle, with per-panel `minSizes` clamping that borrows the shortfall back from the handle's other side rather than just stopping dead
- Arrow-key nudging on a focused handle, and `role="separator"` (the WAI-ARIA window-splitter pattern)

## Calendar, Date, Attachment, And Toast

Use `createArkCalendar(...)` for month-grid date picking, `createArkDatePicker(...)` when that calendar lives in a popover, `createArkAttachment(...)` for file-input orchestration, and `createArkToastRegion(...)` for live-region notification stacks.

What they wire:

- month labels, prev/next controls, and selectable day grids
- `minDate`/`maxDate` bounds (disabled the same as an explicit `disabledDates` entry) and an optional `locale` for the month/year label
- WAI-ARIA PageUp/PageDown (±1 month) and Shift+PageUp/PageDown (±1 year) keyboard stepping, clamped to the target month's real length and refocusing the landed day
- `mode: "range"`: a `{ start, end }` pair instead of one `selectedDate`, with the standard click sequence (first pick starts a fresh range; second pick ends it, or swaps into `start` if it lands earlier than the current start — never an inverted range) and `data-range-start`/`data-range-end`/`data-range-middle` markers on each day cell for styling the highlighted band. `createArkDatePicker(...)` inherits this and only closes its popover once the range is complete
- popover-backed date selection with value-text syncing (`formatDate` for a single date, `formatRange` for a `{ start, end }` pair)
- file-input state extraction and selected-file summaries, plus an optional `dropzoneRef` for drag-and-drop and a `removeFile(index)` handle method
- timed toast show/dismiss behavior with live-region announcements

## Chart

Use `createArkChart(...)` for native line/bar/area rendering — no charting-library dependency, matching the rest of ark-ui's dependency-free posture. It's structurally different from every other primitive in this file: the runtime has no SVG-tag support (adding it would be a core-rendering-pipeline change out of proportion to one primitive), so `createArkChart(...)` mounts a real `<svg>` subtree it builds and redraws with raw DOM calls (`document.createElementNS`) directly into `containerRef`, entirely outside `ui.render()`'s pattern-grammar tree — the same "own a subtree imperatively" approach `createArkNativeSelect(...)` already uses for `<option>`s. `containerRef` just needs to exist as a plain element; requires a real browser DOM (or an SVG-capable DOM shim), unlike markup-driven primitives.

What it wires:

- a value axis that auto-scales to the data (always including zero, so bars/areas never render past the baseline) or a fixed `min`/`max`, with gridlines and formatted tick labels (`valueFormat`)
- category axis labels from `categories`
- per-data-point hover: a floating tooltip (`[data-ark-part="chart-tooltip"]`, styled inline since no F-shape schema routes to it) showing the series label and formatted value, plus `onHoverChange({ seriesIndex, categoryIndex, value })` / `onHoverChange(undefined)` on enter/leave
- `setSeries(...)` to redraw with new data (e.g. live polling) without rebuilding the chart
- `resize()` to re-measure the container and redraw — call it from your own `ResizeObserver`; the chart doesn't set one up itself
- a default categorical color palette, cycled by series index, overridable per-series via `color`

Pair it with the `CHART` style part — its `color` token is what the chart's axis text and gridlines inherit (they draw with `stroke="currentColor"`/`fill="currentColor"`, the same trick native SVG icons use). Line and bar/area variants only for now — no stacking, multiple value axes, or donut/pie shapes yet.

## Avatar

Use `createArkAvatar(...)` for a user/entity image with a text fallback — initials, an icon, whatever renders while there's no image or it fails to load.

What it wires:

- `<img>` `load`/`error` listening, swapping to the fallback automatically on either a missing `src` or a failed load
- optional `fallbackDelay`: holds the fallback back for that many ms instead of showing it the instant loading starts, so a normal-speed image never flashes the fallback right before replacing it (matches Radix/Base UI Avatar's `delayMs`)
- an optional `statusRef` corner dot (`online`/`away`/`busy`/`offline`) via `data-status`
- `setSrc(...)` to swap images (e.g. after the user picks a new photo) and `getState()` for the current `idle`/`loading`/`loaded`/`error` status

Pair it with the `AVATAR` / `AVATARIMAGE` / `AVATARFALLBACK` / `AVATARSTATUS` style parts for the shipped circular-crop look. See [PRIMITIVE_COOKBOOK.md](PRIMITIVE_COOKBOOK.md#20-avatar-with-image-fallback-and-status-dot) for a full example.

## Theming Primitives

Use `createArkTheme(...)` to resolve token/semantic/preset overrides into the complete `ArkTheme` object every `createArkX(...)` call reads from (and `extendArkTheme(...)` to layer a second theme on top of a resolved one). Use `createArkStyleRecipe(...)` for a named, composable override bundle a theme or another recipe can extend, `createArkStyleLibraryPack(...)` for the versioned, exportable container of saved recipes, and `createArkBrandTemplate(...)` for a normalized brand definition resolvable by name from the built-in brand template registry via `resolveArkBrandTemplate(...)`.

Unlike the rest of this file, these four are pure data factories — they take no `ui` instance and touch no DOM; they only produce the objects the rest of the runtime consumes.

What they wire:

- token/semantic/preset/slot merging with `mergePresets(...)` / `mergeSlots(...)`
- recipe composition and validation (`validateArkStyleRecipe(...)`)
- named lookup of built-in recipes and brand templates from a registry
- the on-disk/export shape (`version`, `schemaVersion`, `recipes`) used by the Design tab's brand-theme picker

## Notes

- Overlays now support fallback placements, same-width popups for field-like controls, sticky repositioning on viewport changes, and stacked backdrop z-index management.
- Modal overlays apply scroll lock plus application-root inert/`aria-hidden` shielding while active, and stacked modals now mark covered layers as background-only so only the top modal stays interactive.

## Cookbook

For guided, copy-pasteable examples, see [PRIMITIVE_COOKBOOK.md](PRIMITIVE_COOKBOOK.md).

## Testing

See:

- [tests/test-primitives.mjs](tests/test-primitives.mjs)
- [tests/test-accessibility.mjs](tests/test-accessibility.mjs)
- [tests/browser-primitives.mjs](tests/browser-primitives.mjs)

## Native HTML adoption: compact source workspace

The DPN workspace in `ark-tlm-desktop` consumes ARK's native `flux-button`,
`flux-tabs`, and `flux-popover` components from `@fxn/ui-elements` (the
implementation re-exported by `@fxn/ui/elements`). It uses the ARK icon
pack and semantic theme tokens, with product-specific layout composed around
these shared interactions.

This adoption fixed panel-input/nested-tab scoping, unique tab/panel ARIA links,
and button tab-stop restoration in the shared elements implementation. See
[the element package notes](../ark-elements/README.md) and its `npm test` suite.
