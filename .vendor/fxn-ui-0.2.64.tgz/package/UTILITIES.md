# ARK Utilities

ARK utility helpers are for repeated affordance logic that should stay package-owned instead of being reimplemented per app.

## Current Utilities

- `createArkScrollFadeStyles()`
- `createArkShimmerStyles()`
- `getArkUtilityKeyframes()`
- `getArkFieldInputStyles()`
- `getArkFieldMessageStyles()`

## Intent

This is the ARK equivalent of the helper layer that libraries such as shadcn often leave to app code. The strategy here is:

1. keep the runtime zero-dependency
2. ship reusable affordance/style helpers from explicit package entry points
3. let apps opt into them without copying utility files around

## Example

```ts
import { createArkScrollFadeStyles, createArkShimmerStyles } from "@fxn/ui/utilities";
```
