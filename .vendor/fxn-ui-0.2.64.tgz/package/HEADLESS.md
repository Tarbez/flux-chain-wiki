# ARK Headless Components

ARK now ships a slot-first headless composition layer in `@fxn/ui/headless`.

## What It Solves

The older primitive surface exposed behavior mostly as `createArkDialog(...)`, `createArkPopover(...)`, `createArkSelect(...)`, and direct ref wiring. The headless layer keeps those behavior primitives, but moves authoring and customization to named slots and declarative trees.

## Core API

```ts
import {
  createArkHeadlessComponent,
  createArkHeadlessDialog,
  defineArkHeadlessComponent,
} from "@fxn/ui/headless";
```

- `defineArkHeadlessComponent(...)`: declare a slot tree and slot registry
- `createArkHeadlessComponent(...)`: render, mount, and style a custom headless component
- `createArkHeadlessDialog(...)`, `createArkHeadlessPopover(...)`, `createArkHeadlessSelect(...)`: built-in slot-first factories on top of ARK behavior primitives

## Slot Model

Each component is described by:

1. a `tree` that defines composition
2. `slots` keyed by names such as `trigger`, `content`, `title`, `option:alpha`
3. an optional `mount()` hook that attaches behavior

Consumers customize by slot name instead of reaching for raw refs:

```ts
dialog.configureSlot("content", { className: "danger-sheet" });
dialog.styleSlot("trigger", { width: "100%" });
dialog.setSlotState("content", { open: true, hidden: false });
```

## Intent

This is the ARK answer to Base UI style headless composition: slots are first-class, behavior wiring is still reusable, and teams can extend or replace structure without dropping back to ad hoc ref soup.
