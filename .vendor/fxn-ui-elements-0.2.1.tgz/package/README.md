# ARK UI native elements

The browser-native, hand-authored HTML surface of ARK UI. The public
`@fxn/ui/elements` entry point re-exports this package. Import just the
`defineFlux*` functions you use; registration is opt-in and idempotent.

```js
import { defineFluxButton, defineFluxTabs, defineFluxPopover } from '@fxn/ui-elements/elements';
defineFluxButton();
defineFluxTabs();
defineFluxPopover();
```

Use semantic theme tokens in consumer styles. Elements own accessibility and
interaction behavior; applications own document state and product workflows.
See [ARK UI](../ark-ui/README.md) for the full primitive/component system.

## Compact workspace adoption — 2026-09-07

The DPN workspace in `ark-tlm-desktop` exercises buttons, tabs and popovers in a
compact file list and source preview. Its adoption exposed and fixed shared bugs:

- Tab discovery skips panel contents and nested tab sets. A panel's search input
  or button must never be promoted to a tab trigger.
- Tab navigation handles keys only on the current set's triggers. Home, End and
  arrows retain their normal editing behavior inside panel inputs.
- Generated tab and panel IDs are unique per instance and linked with
  `aria-controls` / `aria-labelledby`. Explicit IDs are retained.

## Generated ids — 2026-10-19 (0.2.0)

Every id an element generates (tab/panel ids, combobox and command option ids)
comes from `@fxn/ui-a11y/ids` and starts with the reserved prefix `ark-r-`
(`ark-r-flux-tabs--3-tab-1`), so a CMS never keys saved edits by a mount-order
counter. Option ids used to be `flux-combobox-option-<activeIndex+1>`: two
comboboxes on one page shared them, and filtering gave two options of one
combobox the same id. Each option now gets one fresh id; regression cases are
in `test/elements.test.mjs`.
- Disabling and re-enabling a button restores its previous tab stop, including
  an explicitly excluded `tabindex="-1"`.

`npm test` runs the shared element behavior suite. The desktop's
`npm run test:dpn-page-dom` additionally proves these interactions in Electron.
