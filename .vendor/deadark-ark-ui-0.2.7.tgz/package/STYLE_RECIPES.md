# ArkUI Style Recipes

This document is the operational contract for ArkUI style recipes and saved starter packs.

## Card Radius Law

Cards use `radiusSm`, never `radius`/`radiusLg` — those stay reserved for pills, modals, sheets, and circular controls. A card is a quiet step in the layout, not a new shape to notice. `CARD`, `DARK|CARD|CONTAINER`, and `STAT` in `ark-ui.components.ts` follow this; any new card-family part should too.

## Background Subtlety

A raised/nested/overlay surface should read as a quiet step away from `canvas`, not a new color field. Use `auditArkBackgroundSubtlety(tokens)` from `@deadark/ark-ui/styler` to check a token set's HSL-lightness drift before shipping a theme — it flags `surface`/`overlay` drift over 8 points, `raised` over 13, and `nested`/`surfaceMuted` over 20. Only hex tokens are measurable; anything else (`rgba()`, `hsl()`, CSS vars) is reported as skipped rather than guessed.

## Precedence

Style resolution is deterministic and always flows in this order:

1. Provider theme
2. Starter recipe
3. Overlay recipes, in array order
4. Local recipe or local theme overrides
5. Runtime escape hatches inside the styler

Within a single layer, later writes to the same property win. Across layers, a later layer only overrides the properties it touches.

## Composition

`composeArkStyleRecipes()` resolves recipe inheritance first, then folds the flattened list from left to right.

- `tokens`, `semantic`: shallow merge, later keys win
- `presets`, `slots`: deep merge, later keys win only on touched properties
- `recipeTokens`: shallow merge with normalized defaults
- `extends`: can be a string or an ordered string array

`resolveArkThemeLayers()` applies the composed recipe output on top of the provider, derives the recipe-token layer, then applies local overrides.

## Locking

Provider-owned covenant chrome is registered as `locked`. A consumer theme, direct recipe, or runtime `register()` call cannot replace those locked schema keys.

This is currently how the `ARKMARK|TEXT` covenant remains provider-controlled even when everything else is re-themed by the consumer.

## Escape Hatches

ArkUI supports two escape-hatch classes:

- Recipe/theme local overrides: explicit token, slot, semantic, or preset writes inside the resolved layer plan
- Styler arbitrary values/selectors: validated by the styler and only emitted when they pass the safety rules

Escape hatches do not bypass layer precedence. They still resolve through the same merge rules, and unsafe arbitrary CSS is rejected.

## Saved Pack Schema

Saved starter packs use `version: 2` and `schemaVersion: "ark-style-library/v2"`.

Top-level shape:

```json
{
  "version": 2,
  "schemaVersion": "ark-style-library/v2",
  "defaults": {
    "starter": "editorial",
    "density": "airy",
    "accentStrategy": "subtle"
  },
  "recipes": {
    "recipe-name": {
      "name": "recipe-name",
      "recipe": { "name": "recipe-name" },
      "tags": ["marketing"],
      "version": 1,
      "retired": false,
      "favorite": true,
      "createdAt": "2026-07-31T00:00:00.000Z",
      "updatedAt": "2026-07-31T00:00:00.000Z"
    }
  }
}
```

Use `validateArkStyleRecipe()` for individual recipes and `validateArkStyleLibraryPack()` for full saved packs before writing them to disk or accepting imported JSON.

## Migration

`importArkStyleLibraryPack()` now accepts:

- current `v2` packs
- older `v1` packs
- legacy plain recipe maps keyed by recipe name

`migrateArkStyleLibraryPack()` returns the migrated pack plus metadata about which migration steps were applied.

## Caching

ArkUI caches:

- composed recipe outputs from `composeArkStyleRecipes()`
- fully resolved layered themes from `resolveArkThemeLayers()`

Use `getArkRecipeCacheStats()` to inspect cache hit/miss counts and `resetArkRecipeCaches()` in tests or benchmarks.

## Regression Coverage

Production hardening coverage now includes:

- schema validation and migration tests for saved packs
- snapshot tests for composed recipe and layered theme output
- performance tests for many layered recipe resolutions with cache reuse

## Bundled Starter Packs

Bundled example packs ship in `starter-packs/`:

- [marketing-starters.json](starter-packs/marketing-starters.json)
- [product-starters.json](starter-packs/product-starters.json)

The same examples are exported in code through `EXAMPLE_STYLE_LIBRARY_PACKS`.
