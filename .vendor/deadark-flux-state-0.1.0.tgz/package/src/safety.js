// Attribute/property allowlisting and Trusted-Types policy acquisition for
// Flux-bound DOM writes. Framework-neutral: everything here operates on
// strings and `globalThis.trustedTypes` only -- no `document`, `HTMLElement`,
// or `Element` reference. `@deadark/flux-dom` calls into this module to
// decide whether a given attribute/property write is safe to apply; it does
// not duplicate this policy.
const FLUX_URL_ATTRIBUTES = new Set(["href", "src", "action", "formaction", "poster", "xlink:href"]);
const FLUX_BLOCKED_PROPERTIES = new Set(["innerhtml", "outerhtml", "srcdoc", "style", "constructor", "prototype", "__proto__"]);
const FLUX_TRUSTED_TYPES_POLICY = "ark-ui";

let fluxTrustedTypesPolicy;

export function getFluxTrustedTypesPolicy() {
  if (fluxTrustedTypesPolicy !== undefined) return fluxTrustedTypesPolicy;
  const trustedTypes = globalThis.trustedTypes;
  if (!trustedTypes) return (fluxTrustedTypesPolicy = null);
  try {
    fluxTrustedTypesPolicy = trustedTypes.createPolicy(FLUX_TRUSTED_TYPES_POLICY, { createHTML: (value) => value });
  } catch {
    fluxTrustedTypesPolicy = null;
  }
  return fluxTrustedTypesPolicy;
}

function isSafeFluxUrl(value) {
  const compact = value.trim().replace(/[\x00-\x20]+/g, "");
  if (!compact || compact.startsWith("#") || compact.startsWith("/") || compact.startsWith("./") || compact.startsWith("../")) return true;
  const scheme = /^([a-z][a-z0-9+.-]*):/i.exec(compact)?.[1]?.toLowerCase();
  return !scheme || scheme === "http" || scheme === "https" || scheme === "mailto" || scheme === "tel";
}

export function isSafeFluxAttribute(name, value) {
  const normalized = name.trim().toLowerCase();
  if (!normalized || normalized.startsWith("on") || normalized === "srcdoc" || normalized === "srcset" || normalized === "style") return false;
  return !FLUX_URL_ATTRIBUTES.has(normalized) || isSafeFluxUrl(value);
}

export function isSafeFluxProperty(name, value) {
  const normalized = name.trim().toLowerCase();
  if (!normalized || normalized.startsWith("on") || FLUX_BLOCKED_PROPERTIES.has(normalized)) return false;
  return !FLUX_URL_ATTRIBUTES.has(normalized) || isSafeFluxUrl(String(value ?? ""));
}
