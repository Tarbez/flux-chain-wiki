// Framework-neutral browser state engine: a keyed store with fine-grained
// path subscriptions, computed values, optimistic writes, an offline queue,
// conflict records, undo/redo history, and a replay timeline. No DOM,
// theme, router, or provider code -- see docs/architecture/
// ARK_UI_EVOLUTION_PLAN.md section 3.2 for the ownership boundary this
// module exists to enforce. `@deadark/flux-dom` binds this engine to the
// DOM; it does not own any of this behavior itself.
//
// State transitions vs. side effects (ARK_UI_EVOLUTION_PLAN.md 3.3 Batch 1
// deliverable -- "explicit distinction between state transitions and side
// effects"):
//
// - Transitions are pure data changes recorded on the store itself:
//   `set`, `optimisticSet`, `commitOptimistic`, `rollbackOptimistic`,
//   `applyRemote`, `resolveConflict`, `undo`/`redo`, `restoreSnapshot`.
//   Every transition is deterministic given the store's current values and
//   is what `getTimeline()` replays. A `defineComputed(path, deps, compute)`
//   callback must itself be a pure function of the store's current values
//   -- it re-runs on every dependency change, so it must not perform I/O,
//   mutate anything outside its own return value, or depend on anything but
//   `store.get(...)` for its declared `deps`.
// - Side effects are everything this module does *in reaction to* a
//   transition, off to the side of the store's own data: persisting a
//   snapshot to `storage` (see `#persist`, gated by `persistenceKey`), and
//   notifying registered `FluxSyncTarget`s so a host can push a queued
//   write to a peer/relay/gateway. Side effects never feed back into what
//   `get()` returns for the same path -- if a side effect needs to change
//   store data (e.g. a remote ack), it must do so through a transition
//   (`applyRemote`), not by touching internal state directly.
//
// This split is why `FluxStoreAdapter` (the interface `flux-dom` and any
// other consumer programs against) only exposes `get`/`set`/`subscribe` --
// the transition surface -- and never the persistence/sync machinery.

function splitPath(path) {
  return path.split(".").map((part) => part.trim()).filter(Boolean);
}

function getNestedValue(value, segments) {
  let current = value;
  for (const segment of segments) {
    if (!current || typeof current !== "object") return undefined;
    current = current[segment];
  }
  return current;
}

function cloneContainer(value) {
  if (Array.isArray(value)) return [...value];
  if (value && typeof value === "object") return { ...value };
  return {};
}

function cloneValue(value) {
  if (value == null || typeof value !== "object") return value;
  if (typeof structuredClone === "function") return structuredClone(value);
  return JSON.parse(JSON.stringify(value));
}

function valuesEqual(left, right) {
  if (Object.is(left, right)) return true;
  if (left && right && typeof left === "object" && typeof right === "object") {
    try {
      return JSON.stringify(left) === JSON.stringify(right);
    } catch {
      return false;
    }
  }
  return false;
}

function setNestedValue(value, segments, nextValue) {
  if (segments.length === 0) return nextValue;
  const root = cloneContainer(value);
  let current = root;
  for (let index = 0; index < segments.length; index += 1) {
    const segment = segments[index];
    if (index === segments.length - 1) {
      current[segment] = nextValue;
      break;
    }
    const existing = current[segment];
    const cloned = cloneContainer(existing);
    current[segment] = cloned;
    current = cloned;
  }
  return root;
}

function defaultStorage() {
  return globalThis.localStorage;
}

function mergeObjectsDeep(left, right) {
  if (Array.isArray(left) && Array.isArray(right)) return [...left, ...right];
  if (!left || typeof left !== "object") return cloneValue(right);
  if (!right || typeof right !== "object") return cloneValue(right);
  const merged = { ...left };
  for (const [key, value] of Object.entries(right)) {
    const current = merged[key];
    if (current && value && typeof current === "object" && typeof value === "object" && !Array.isArray(current) && !Array.isArray(value)) {
      merged[key] = mergeObjectsDeep(current, value);
    } else if (Array.isArray(current) && Array.isArray(value)) {
      merged[key] = [...current, ...value];
    } else {
      merged[key] = cloneValue(value);
    }
  }
  return merged;
}

export class FluxMemoryStore {
  #values = new Map();
  #listeners = new Map();
  #computed = new Map();
  #dependencyMap = new Map();
  #optimistic = new Map();
  #history = [];
  #redoStack = [];
  #offlineQueue = [];
  #conflicts = [];
  #metrics = {
    gets: 0,
    sets: 0,
    notifications: 0,
    subscriptions: 0,
    computedRecomputes: 0,
    optimisticWrites: 0,
    optimisticCommits: 0,
    optimisticRollbacks: 0,
    offlineQueued: 0,
    conflictCount: 0,
  };
  #online = true;
  #writeCounter = 0;
  #historyLimit = 200;
  #timelineLimit;
  #timeline = [];
  #timelineCounter = 0;
  #persistenceKey;
  #storage;
  #syncTargets = new Map();

  constructor(options = {}) {
    this.#historyLimit = options.historyLimit ?? 200;
    this.#timelineLimit = options.timelineLimit ?? 250;
    this.#persistenceKey = options.persistenceKey ?? null;
    this.#storage = options.storage ?? defaultStorage();
    this.#loadPersistedState();
  }

  get(path) {
    this.#metrics.gets += 1;
    if (this.#values.has(path)) return this.#values.get(path);
    const segments = splitPath(path);
    for (let index = segments.length - 1; index > 0; index -= 1) {
      const parentPath = segments.slice(0, index).join(".");
      if (!this.#values.has(parentPath)) continue;
      return getNestedValue(this.#values.get(parentPath), segments.slice(index));
    }
    return undefined;
  }

  set(path, value) {
    this.#write(path, value, { recordHistory: true, source: "local" });
  }

  subscribe(path, listener) {
    this.#metrics.subscriptions += 1;
    const listeners = this.#listeners.get(path) ?? new Set();
    listeners.add(listener);
    this.#listeners.set(path, listeners);
    return () => {
      const current = this.#listeners.get(path);
      if (!current) return;
      current.delete(listener);
      if (current.size === 0) this.#listeners.delete(path);
    };
  }

  defineComputed(path, deps, compute) {
    const definition = {
      path,
      deps: deps.map((dep) => dep.trim()).filter(Boolean),
      compute,
    };
    this.#computed.set(path, definition);
    for (const dep of definition.deps) {
      const dependents = this.#dependencyMap.get(dep) ?? new Set();
      dependents.add(path);
      this.#dependencyMap.set(dep, dependents);
    }
    this.#recomputeComputed(path);
    return () => {
      this.#computed.delete(path);
      for (const dep of definition.deps) {
        const dependents = this.#dependencyMap.get(dep);
        if (!dependents) continue;
        dependents.delete(path);
        if (dependents.size === 0) this.#dependencyMap.delete(dep);
      }
    };
  }

  optimisticSet(path, value) {
    const id = `optimistic-${++this.#writeCounter}`;
    this.#optimistic.set(id, {
      id,
      path,
      previous: cloneValue(this.get(path)),
      next: cloneValue(value),
      timestamp: Date.now(),
    });
    this.#metrics.optimisticWrites += 1;
    this.#write(path, value, { recordHistory: true, source: "optimistic" });
    return id;
  }

  commitOptimistic(id) {
    if (!this.#optimistic.has(id)) return false;
    this.#optimistic.delete(id);
    this.#metrics.optimisticCommits += 1;
    this.#offlineQueue = this.#offlineQueue.map((entry) => entry.id === id ? { ...entry, status: "replayed" } : entry);
    this.#pushTimeline({ type: "commit", detail: id });
    this.#persistState();
    return true;
  }

  rollbackOptimistic(id) {
    const entry = this.#optimistic.get(id);
    if (!entry) return false;
    this.#optimistic.delete(id);
    this.#offlineQueue = this.#offlineQueue.filter((queued) => queued.id !== id);
    this.#metrics.optimisticRollbacks += 1;
    this.#write(entry.path, cloneValue(entry.previous), { recordHistory: false, source: "rollback" });
    return true;
  }

  undo() {
    const entry = this.#history.pop();
    if (!entry) return false;
    this.#redoStack.push(entry);
    this.#write(entry.path, cloneValue(entry.previous), { recordHistory: false, source: "undo" });
    return true;
  }

  redo() {
    const entry = this.#redoStack.pop();
    if (!entry) return false;
    this.#history.push(entry);
    this.#write(entry.path, cloneValue(entry.next), { recordHistory: false, source: "redo" });
    return true;
  }

  setOnline(online) {
    this.#online = online;
    this.#pushTimeline({ type: "online", detail: online ? "online" : "offline" });
    this.#persistState();
  }

  isOnline() {
    return this.#online;
  }

  flushOfflineQueue() {
    this.#offlineQueue = this.#offlineQueue.map((entry) => ({ ...entry, status: "replayed" }));
    this.#pushTimeline({ type: "replay", detail: `${this.#offlineQueue.length} writes replayed` });
    this.#persistState();
    return this.getOfflineQueue();
  }

  getOfflineQueue() {
    return this.#offlineQueue.map((entry) => ({ ...entry, value: cloneValue(entry.value) }));
  }

  applyRemote(path, value, options = {}) {
    const queued = this.#offlineQueue.find((entry) => entry.path === path && entry.status === "queued");
    if (queued && !valuesEqual(queued.value, value)) {
      this.#conflicts.push({
        path,
        base: cloneValue(this.get(path)),
        local: cloneValue(queued.value),
        remote: cloneValue(value),
        timestamp: Date.now(),
      });
      this.#metrics.conflictCount += 1;
      this.#pushTimeline({ type: "conflict", path, detail: options.prefer === "local" ? "kept-local" : "needs-resolution" });
      this.#persistState();
      if (options.prefer === "local") return;
    }
    this.#write(path, value, { recordHistory: true, source: "remote" });
  }

  getConflicts() {
    return this.#conflicts.map((entry) => ({
      ...entry,
      local: cloneValue(entry.local),
      remote: cloneValue(entry.remote),
    }));
  }

  resolveConflict(path, choice) {
    const index = this.#conflicts.findIndex((entry) => entry.path === path);
    if (index === -1) return false;
    const conflict = this.#conflicts[index];
    this.#conflicts.splice(index, 1);
    this.#pushTimeline({ type: "resolve", path, detail: choice });
    if (choice === "remote") {
      this.#write(path, cloneValue(conflict.remote), { recordHistory: true, source: "remote" });
    } else if (choice === "merge-shallow") {
      this.#write(path, { ...(conflict.local && typeof conflict.local === "object" ? conflict.local : {}), ...(conflict.remote && typeof conflict.remote === "object" ? conflict.remote : {}) }, { recordHistory: true, source: "remote" });
    } else if (choice === "merge-deep") {
      this.#write(path, mergeObjectsDeep(conflict.local, conflict.remote), { recordHistory: true, source: "remote" });
    } else if (choice === "merge-append") {
      const merged = Array.isArray(conflict.local) && Array.isArray(conflict.remote)
        ? [...conflict.local, ...conflict.remote]
        : mergeObjectsDeep(conflict.local, conflict.remote);
      this.#write(path, merged, { recordHistory: true, source: "remote" });
    }
    this.#persistState();
    return true;
  }

  clearConflicts() {
    this.#conflicts = [];
    this.#persistState();
  }

  snapshotPaths(paths) {
    const snapshot = {};
    for (const path of paths) snapshot[path] = cloneValue(this.get(path));
    return snapshot;
  }

  restoreSnapshot(snapshot) {
    for (const [path, value] of Object.entries(snapshot)) {
      this.#write(path, cloneValue(value), { recordHistory: false, source: "snapshot" });
    }
  }

  getMetrics() {
    return { ...this.#metrics };
  }

  getTimeline() {
    return this.#timeline.map((entry) => ({ ...entry }));
  }

  registerSyncTarget(target) {
    this.#syncTargets.set(target.id, { ...target, lastSeenAt: target.lastSeenAt ?? Date.now() });
    this.#pushTimeline({ type: "set", detail: `sync-target:${target.id}` });
    this.#persistState();
  }

  updateSyncTarget(id, patch) {
    const current = this.#syncTargets.get(id);
    if (!current) return false;
    this.#syncTargets.set(id, {
      ...current,
      ...patch,
      lastSeenAt: patch.lastSeenAt ?? Date.now(),
    });
    this.#pushTimeline({ type: "set", detail: `sync-target-update:${id}` });
    this.#persistState();
    return true;
  }

  getSyncTargets() {
    return Array.from(this.#syncTargets.values()).map((target) => ({ ...target }));
  }

  resetMetrics() {
    this.#metrics = {
      gets: 0,
      sets: 0,
      notifications: 0,
      subscriptions: 0,
      computedRecomputes: 0,
      optimisticWrites: 0,
      optimisticCommits: 0,
      optimisticRollbacks: 0,
      offlineQueued: 0,
      conflictCount: 0,
    };
  }

  #write(path, value, options) {
    const previous = cloneValue(this.get(path));
    if (options.recordHistory && !valuesEqual(previous, value)) {
      this.#history.push({
        path,
        previous,
        next: cloneValue(value),
        timestamp: Date.now(),
      });
      if (this.#history.length > this.#historyLimit) this.#history.shift();
      if (options.source !== "redo") this.#redoStack = [];
    }
    this.#metrics.sets += 1;
    this.#values.set(path, cloneValue(value));
    this.#patchAncestors(path, value);
    if (options.source === "optimistic") this.#pushTimeline({ type: "optimistic", path });
    else if (options.source === "rollback") this.#pushTimeline({ type: "rollback", path });
    else this.#pushTimeline({ type: "set", path, detail: options.source });
    if (!this.#online && (options.source === "local" || options.source === "optimistic")) {
      this.#offlineQueue.push({
        id: options.source === "optimistic"
          ? `optimistic-${this.#writeCounter}`
          : `queued-${++this.#writeCounter}`,
        path,
        value: cloneValue(value),
        timestamp: Date.now(),
        status: "queued",
      });
      this.#metrics.offlineQueued += 1;
      this.#pushTimeline({ type: "queue", path });
    }
    const affectedPaths = this.#affectedPaths(path);
    this.#notifyPaths(affectedPaths);
    this.#recomputeDependencies(path, new Set(affectedPaths));
    this.#persistState();
  }

  #patchAncestors(path, value) {
    const segments = splitPath(path);
    for (let index = segments.length - 1; index > 0; index -= 1) {
      const parentPath = segments.slice(0, index).join(".");
      if (!this.#values.has(parentPath)) continue;
      const parentValue = this.#values.get(parentPath);
      this.#values.set(parentPath, setNestedValue(parentValue, segments.slice(index), cloneValue(value)));
    }
  }

  #affectedPaths(path) {
    const affected = new Set([path]);
    for (const listenerPath of this.#listeners.keys()) {
      if (listenerPath === path || listenerPath.startsWith(`${path}.`) || path.startsWith(`${listenerPath}.`)) {
        affected.add(listenerPath);
      }
    }
    for (const computedPath of this.#computed.keys()) {
      if (computedPath === path || computedPath.startsWith(`${path}.`) || path.startsWith(`${computedPath}.`)) {
        affected.add(computedPath);
      }
    }
    return Array.from(affected);
  }

  #notifyPaths(paths) {
    for (const affectedPath of paths) {
      const listeners = this.#listeners.get(affectedPath);
      if (!listeners) continue;
      const nextValue = this.get(affectedPath);
      for (const listener of listeners) {
        this.#metrics.notifications += 1;
        listener(nextValue);
      }
    }
  }

  #recomputeDependencies(path, seen) {
    for (const [dep, computedPaths] of this.#dependencyMap.entries()) {
      if (!(dep === path || dep.startsWith(`${path}.`) || path.startsWith(`${dep}.`))) continue;
      for (const computedPath of computedPaths) {
        if (seen.has(computedPath)) continue;
        seen.add(computedPath);
        this.#recomputeComputed(computedPath, seen);
      }
    }
  }

  #recomputeComputed(path, seen = new Set()) {
    const definition = this.#computed.get(path);
    if (!definition) return;
    const nextValue = definition.compute(this);
    if (valuesEqual(this.#values.get(path), nextValue)) return;
    this.#metrics.computedRecomputes += 1;
    this.#values.set(path, cloneValue(nextValue));
    this.#pushTimeline({ type: "computed", path });
    this.#notifyPaths(this.#affectedPaths(path));
    this.#recomputeDependencies(path, seen);
    this.#persistState();
  }

  #loadPersistedState() {
    if (!this.#persistenceKey || !this.#storage) return;
    try {
      const raw = this.#storage.getItem(this.#persistenceKey);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      this.#values = new Map(Array.isArray(parsed.values) ? parsed.values : []);
      this.#offlineQueue = Array.isArray(parsed.offlineQueue) ? parsed.offlineQueue : [];
      this.#conflicts = Array.isArray(parsed.conflicts) ? parsed.conflicts : [];
      this.#online = parsed.online !== false;
      this.#timeline = Array.isArray(parsed.timeline) ? parsed.timeline : [];
      this.#syncTargets = new Map(Array.isArray(parsed.syncTargets) ? parsed.syncTargets.map((target) => [target.id, target]) : []);
      this.#timelineCounter = this.#timeline.reduce((max, entry) => Math.max(max, Number(entry.id || 0)), 0);
    } catch {
      // ignore malformed persisted state and start fresh
    }
  }

  #persistState() {
    if (!this.#persistenceKey || !this.#storage) return;
    const snapshot = {
      version: 1,
      values: Array.from(this.#values.entries()),
      offlineQueue: this.getOfflineQueue(),
      conflicts: this.getConflicts(),
      online: this.#online,
      timeline: this.getTimeline(),
      syncTargets: this.getSyncTargets(),
    };
    try {
      this.#storage.setItem(this.#persistenceKey, JSON.stringify(snapshot));
    } catch {
      // best-effort persistence only
    }
  }

  #pushTimeline(entry) {
    this.#timeline.push({
      id: ++this.#timelineCounter,
      timestamp: Date.now(),
      ...entry,
    });
    if (this.#timeline.length > this.#timelineLimit) this.#timeline.splice(0, this.#timeline.length - this.#timelineLimit);
  }
}
