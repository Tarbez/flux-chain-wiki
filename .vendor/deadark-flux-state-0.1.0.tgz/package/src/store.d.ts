export type FluxValue = unknown;

export interface FluxStoreAdapter {
  get(path: string): FluxValue;
  set(path: string, value: FluxValue): void;
  subscribe(path: string, listener: (value: FluxValue) => void): () => void;
}

export interface FluxComputedDefinition {
  path: string;
  deps: string[];
  compute: (store: FluxStoreAdapter) => FluxValue;
}

export interface FluxOptimisticEntry {
  id: string;
  path: string;
  previous: FluxValue;
  next: FluxValue;
  timestamp: number;
}

export interface FluxHistoryEntry {
  path: string;
  previous: FluxValue;
  next: FluxValue;
  timestamp: number;
}

export interface FluxQueuedWrite {
  id: string;
  path: string;
  value: FluxValue;
  timestamp: number;
  status: "queued" | "replayed";
}

export interface FluxConflictRecord {
  path: string;
  local: FluxValue;
  remote: FluxValue;
  base?: FluxValue;
  timestamp: number;
}

export interface FluxStoreMetrics {
  gets: number;
  sets: number;
  notifications: number;
  subscriptions: number;
  computedRecomputes: number;
  optimisticWrites: number;
  optimisticCommits: number;
  optimisticRollbacks: number;
  offlineQueued: number;
  conflictCount: number;
}

export interface FluxTimelineEntry {
  id: number;
  type: "set" | "computed" | "optimistic" | "rollback" | "commit" | "queue" | "replay" | "conflict" | "resolve" | "online";
  path?: string;
  detail?: string;
  timestamp: number;
}

export interface FluxMemoryStoreOptions {
  persistenceKey?: string;
  storage?: Storage;
  historyLimit?: number;
  timelineLimit?: number;
}

export interface FluxSyncTarget {
  id: string;
  kind: "peer" | "relay" | "gateway" | "local";
  status: "online" | "offline" | "degraded";
  latencyMs?: number;
  trust?: number;
  queuedWrites?: number;
  description?: string;
  lastSeenAt?: number;
}

export declare class FluxMemoryStore implements FluxStoreAdapter {
  constructor(options?: FluxMemoryStoreOptions);
  get(path: string): FluxValue;
  set(path: string, value: FluxValue): void;
  subscribe(path: string, listener: (value: FluxValue) => void): () => void;
  defineComputed(path: string, deps: string[], compute: (store: FluxStoreAdapter) => FluxValue): () => void;
  optimisticSet(path: string, value: FluxValue): string;
  commitOptimistic(id: string): boolean;
  rollbackOptimistic(id: string): boolean;
  undo(): boolean;
  redo(): boolean;
  setOnline(online: boolean): void;
  isOnline(): boolean;
  flushOfflineQueue(): FluxQueuedWrite[];
  getOfflineQueue(): FluxQueuedWrite[];
  applyRemote(path: string, value: FluxValue, options?: { prefer?: "remote" | "local" }): void;
  getConflicts(): FluxConflictRecord[];
  resolveConflict(path: string, choice: "local" | "remote" | "merge-shallow" | "merge-deep" | "merge-append"): boolean;
  clearConflicts(): void;
  snapshotPaths(paths: string[]): Record<string, FluxValue>;
  restoreSnapshot(snapshot: Record<string, FluxValue>): void;
  getMetrics(): FluxStoreMetrics;
  getTimeline(): FluxTimelineEntry[];
  registerSyncTarget(target: FluxSyncTarget): void;
  updateSyncTarget(id: string, patch: Partial<FluxSyncTarget>): boolean;
  getSyncTargets(): FluxSyncTarget[];
  resetMetrics(): void;
}
