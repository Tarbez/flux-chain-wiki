interface FluxTrustedTypesPolicy {
  createHTML(value: string): unknown;
}

export declare function getFluxTrustedTypesPolicy(): FluxTrustedTypesPolicy | null;
export declare function isSafeFluxAttribute(name: string, value: string): boolean;
export declare function isSafeFluxProperty(name: string, value?: unknown): boolean;
