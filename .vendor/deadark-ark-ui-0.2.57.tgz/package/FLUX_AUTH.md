# Flux Auth Kit — `@deadark/ark-ui/flux-auth`

The portable identity envelope, as a skeleton every Flux app can share.

```ts
import { createAuthKitSession, AUTH_KIT_FILE_ACCEPT } from '@deadark/ark-ui/flux-auth';
```

## Why this exists

`ark-dao` and `flux-dao-app` each carried a private, byte-identical copy of the
same four hundred lines: strip a BOM, try gzip, try three text encodings, peel
the `FLX-AUTH-KIT/<n>` envelope, validate a vault shape that differs at v3, v4,
v5, v6, v7 and v8, derive PBKDF2, open AES-GCM. `flux-code-app` had no copy at
all, so it could only accept a raw recovery phrase — which almost nobody still
holds, because the thing people actually keep is the `.auth.flx` file.

Two copies of a security-critical parser is one copy too many, and zero copies
is a feature that cannot ship. This module is the one copy.

## The boundary

ark-ui owns the **envelope**. Your app owns the **identity**.

| ark-ui does | your app does |
| --- | --- |
| Decode a file: BOM, NUL, gzip, UTF-16, `data:`, code fences | — |
| Validate the v1 vault shape | — |
| Open PBKDF2-SHA256 → AES-256-GCM, return the secret | — |
| Summarise a kit without opening it | Render it, in your own design |
| Re-seal under a new PIN | — |
| — | Derive Ed25519 from the recovery phrase |
| — | Verify identity cores, wallet links, ML-DSA-87 keys |
| — | Decide where a kit lives between sessions |

That line is why the module has no dependencies. bip39 and Ed25519 are not
ark-ui's to carry, and pulling them in would put a signing library into every
page that renders a button.

## Opening a kit

```ts
import { readAuthKitFile, openAuthKit, describeAuthKit } from '@deadark/ark-ui/flux-auth';

const vault = await readAuthKitFile(file);        // throws AuthKitError with a code
const summary = describeAuthKit(vault);           // safe to render before unlocking
const opened = await openAuthKit(vault, { pin, password }, verifyRoot);
```

### `verifyRoot` is not optional in practice

Opening the envelope proves someone knew the PIN. It does **not** prove the
phrase inside derives `rootPublicKey`. Without a verifier, `openAuthKit`
returns `rootVerified: false` and nothing else has been established — an
attacker can seal any phrase they like under a PIN they chose into a vault that
names your identity.

If your app goes on to *sign* with the result, supply the verifier:

```ts
const verifyRoot: AuthKitRootVerifier = async ({ mnemonic, derivation, callsign }) => {
  // derivation is 'flux-bip39-v1' or 'deadark-profile-v1' — they are not the
  // same computation and the same phrase produces different keys under each.
  return { rootPublicKey: await deriveRoot(mnemonic, derivation, callsign) };
};
```

`flux-code-app/src/lib/auth-kit.ts` is a complete worked example of both
derivations, and arranges things so the signer and the verifier are the same
computation — which makes verification impossible to skip.

## The UI

Three renderers, one view model. `authKitView` (in `@deadark/ark-ui/flux-auth-view`)
turns a session state into plain data — heading, rows, fields, buttons, one
notice — and each renderer only draws it. They cannot disagree about copy, about
which action is destructive, or about whether an unverified kit deserves a
warning, because none of them decides any of that.

| Target | Import | Entry |
| --- | --- | --- |
| React web — `ark-dao`, `flux-dao-app`, `flux-code-app`, `chat.deadark.com` | `@deadark/ark-ui/flux-auth-react` | `AuthKitPanel`, `useAuthKitSession` |
| DOM — `ark-browser`'s Electron renderer, anything without React | `@deadark/ark-ui/flux-auth-ui` | `createArkAuthKitPanel`, `ARK_AUTH_KIT_STYLES` |
| React Native — the Expo chat app | `@deadark/ark-ui/flux-auth-native` | `ArkAuthKitScreen` |
| Your own markup | `@deadark/ark-ui/flux-auth-view` | `authKitView` |

```tsx
// React
<AuthKitPanel
  session={session}
  product="Flux Code"
  readyHint="Opening your workspace."
  onUnlock={async (opened) => onSignedIn(await identityFrom(opened))}
/>
```

```js
// DOM
const panel = createArkAuthKitPanel({ container, session, product: 'Ark Browser', onUnlock });
// panel.destroy() unsubscribes and empties the container.
```

```ts
// React Native — there is no <input type="file">, so the picker is injected.
h(ArkAuthKitScreen, { session, pickAuthKit, onUnlock });
```

**Throwing inside `onUnlock` is the supported way to refuse an identity.** The
message lands in the panel's own notice, and the session stays open — so an app
can reject someone it recognises but will not admit, without the panel having to
pretend the unlock itself failed.

### Keep me signed in

Every panel offers the windows the owner set, 1, 3, 7 and 14 days, plus "Only
this tab", once a kit is open. The app writes no code for this. The session owns
it (`keepFor`, `forgetKept`, `restoreKept`, `updateOpened` on `AuthKitSession`),
the view model draws it (`view.keep`), and the three renderers paint it.

- The kept record holds the file, the phrase and the wallet keys, in the
  persisted-secret vault (`@deadark/ark-ui/flux-auth-persisted-secret`): a key
  that cannot be copied out of the browser, with a hard expiry. Its grammar is
  in `ark-ui.flux-auth-keep.ts`, never JSON.
- On mount, each renderer calls `restoreKept()` and then your `onUnlock` with the
  reopened kit, exactly as after a typed unlock. `verifyRoot` runs again, so the
  phrase is proven against the file every time. If your `onUnlock` throws, the
  kept copy is deleted, so a refusal cannot repeat on every load.
- Sign out (the panel's own button) deletes the kept copy. `session.clear()` on
  unmount does not: a page that goes away has not signed out.
- When the app changes the open file (adds a wallet or a public id), it calls
  `session.updateOpened({ vault, secret })` so the kept copy holds the new file.
- `createAuthKitSession({ keep: { scope } })` namespaces the store (default
  `fxn-id-sign-in`). `keep: false` removes the block. React Native has no
  IndexedDB: pass `keep: { store }` with a vault of your own, or the screen offers
  no windows there. Absent is absent, never "none chosen".
- Hooks for styling: `data-ark-auth="keep"`, `keep-options` (buttons carry
  `data-value` and `data-active`), `keep-note`, `keep-status`, `keep-actions`
  (`data-action="forget"`). Classes: `.ark-auth-keep*`, in `ARK_AUTH_KIT_STYLES`.

Before 2026-10-29 this block lived in one app's entry file, so only the sites
built from `flux/defxn/scripts/auth-entry.js` had the windows. See the
`ark-ui.flux-auth-keep.ts` header.

### Styling

Everything reads ark-ui semantic tokens (`--surface`, `--border`, `--accent`,
`--text-muted`, `--drift`) and nothing is `!important`. Three ways to design,
in increasing order of divergence:

1. Remap the tokens on `.ark-auth-panel`. This is what `flux-code-app` does, and
   it is a dozen lines of CSS.
2. Override the `.ark-auth-*` classes, or pass `classPrefix` for your own.
   Every element also carries a `data-ark-auth` hook — `panel`, `heading`,
   `hint`, `rows`, `form`, `field-pin`, `field-password`, `actions`, `notice` —
   and the panel root carries `data-stage` and `data-busy`.
3. Render `authKitView` yourself. You keep the copy and the state machine and
   give up nothing in layout.

The DOM stylesheet ships as a string (`ARK_AUTH_KIT_STYLES`) rather than a
`.css` file, so an app with no CSS pipeline — an Electron renderer, say — can
inject it directly.

## The headless session

`createAuthKitSession` is a store, not a component. React binds it with
`useSyncExternalStore`; ark-ui patterns bind it by subscribing; a CLI drives it
directly. Your markup stays yours.

```tsx
const session = useMemo(() => createAuthKitSession({ verifyRoot }), []);
const state = useSyncExternalStore(session.subscribe, session.getState, session.getState);

// state.status: 'empty' | 'loaded' | 'busy' | 'open' | 'error'
// state.summary: non-secret facts, from 'loaded' onward
// state.error:   { code, message }
// state.unverified: true when a kit is open but its root was never proven
```

A failed unlock returns to `loaded` with the kit intact, so the person retypes
the PIN rather than re-choosing the file. `clear()` drops the kit and the
secret; call it on sign-out and on unmount.

## Errors

Switch on `AuthKitError.code`, never on message text:

| code | means |
| --- | --- |
| `auth-kit.not-json` | Not an Auth Kit envelope or JSON document |
| `auth-kit.incomplete` | Shape does not match the v1 Auth Kit shape |
| `auth-kit.malformed-material` | Key or encryption material is the wrong size |
| `auth-kit.html-page` | A saved HTML page, not an export |
| `auth-kit.undecodable` | No text encoding produced a kit |
| `auth-kit.pin-policy` | PIN is not 6–12 digits, or under 8 with no password |
| `auth-kit.decrypt-failed` | Wrong PIN or password — the file is fine |
| `auth-kit.secret-malformed` | Decrypted, but carries no usable phrase |
| `auth-kit.root-mismatch` | The phrase does not produce the identity named |
| `auth-kit.identity-mismatch` | Sealed identity differs from the envelope's |

The last two are worth separating in your UI from the first: a wrong PIN is the
user's to fix, whereas a root mismatch means the file is not what it claims and
no amount of retyping will help.

## The frozen envelope

Do not change any of this. Every kit already in a user's downloads folder was
written to it, and two implementations — `flux-auth/auth-kit-migration` for
v3–v5 and `ark-dao`'s vault for v6–v8 — were written independently and agree
exactly.

- KDF: PBKDF2-SHA256, **at least 600,000** iterations, salt ≥ 16 bytes
- Unlock secret: `` `${pin}\0${password}` `` — a NUL, not a colon
- Cipher: AES-256-GCM, 12-byte IV
- Plaintext: UTF-8 JSON carrying `mnemonic`
- Envelope: `FLX-AUTH-KIT/<version>\n` + url-safe base64, unpadded

## Adopting it in an existing repo

1. Replace your file-reading and `parseVault` with `readAuthKitFile` /
   `parseAuthKit`. Behaviour is identical — the validation clauses were
   transcribed from `ark-dao`, not reinterpreted.
2. Replace your PBKDF2/AES-GCM block with `openAuthKitEnvelope`.
3. Keep your derivation, core verification and migration code. Pass the
   derivation in as `verifyRoot`.
4. Keep your components. Point them at `createAuthKitSession` instead of local
   state.

What ark-ui does **not** replace is the V3→V8 migration chain. That is real
identity surgery — it mints wallets and ML-DSA-87 keys and re-signs cores — and
it belongs where the crypto lives.

Tests: `tests/test-flux-auth.mjs` (envelope), `tests/test-flux-auth-ui.mjs` (view model and DOM panel).

## Secret Key kits, and a harder reader (2026-10-21)

- **v10 opens with a Secret Key.** It needs the PIN, the password, an optional key word, and a 128-bit Secret Key that the file never holds. The identity fields are bound as AES-GCM associated data. `LATEST_AUTH_KIT_VERSION` stays 9, because a v9 kit cannot move to v10 without a new key shown to its owner. Design: `docs/FXN_ID_SECRET_KEY_v0.md` at the workspace root.
- **New credentials.** `AuthKitCredentials` adds `secretKey` and `word`. New error codes: `auth-kit.secret-key-required`, `auth-kit.secret-key-invalid` and `auth-kit.secret-key-mismatch`. `describeAuthKit` adds `needsSecretKey`. No panel asks for these fields yet.
- **Hardening for every version.** The reader caps KDF rounds at `MAX_KDF_ITERATIONS`. It refuses a header that disagrees with the body, and a gzip body over `MAX_AUTH_KIT_BYTES`. `openAuthKit` refuses an identity ID that is not the anchor digest of the kit's own root key.
