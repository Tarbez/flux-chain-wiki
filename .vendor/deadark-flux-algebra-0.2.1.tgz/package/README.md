# @deadark/flux-algebra

Canonical JavaScript FLX algebra implementation: the dumb block-splitting
parser, dense block decoders, polarity, semantics, and pattern analysis.

The grammar authority is [`@deadark/flux-spec`](../flux-spec), specifically
`spec/dense-encoding-v4.md` and its registries. This package implements that
contract; it does not define or supersede it. When code and flux-spec disagree,
flux-spec wins.

Pure JS. No I/O, no native dependency, no network. Everything here is a
function over strings and plain objects.

## Why this package exists

This engine was vendored by copy-paste into three places, and all three
drifted apart:

| Copy | State when extracted (2026-08-14) |
| :--- | :--- |
| `trust-language-models/scripts/flux-algebra` | source used for the corrected 2026-08-05 implementation |
| `ark-miner-cli/src/flux` | code-identical to that source except a native fast path in `tokenizer.mjs` |
| `flux-claims/src/flux` | **deliberately frozen** on the older Pratt/operator-table design |

`flux-claims` is intentionally **not** a consumer of this package. Its copy
predates the 2026-08-05 correction (Directive 1), and Batch 3 of that
correction — re-syncing flux-claims — was explicitly skipped. Migrating it is a
behavioral change to claim verification, not a refactor. Leave it frozen until
someone decides to make that change on purpose.

## Parser contract

The parser knows exactly two characters:

- `-` — top-level block separator
- `.` — isolation fence, matched against the next `.` in the same scope and
  parsed recursively

Every other character is kept verbatim inside whichever raw block it appears
in. The parser never inspects a block's own text; deciding what a block *means*
is a resolver's job. Whitespace runs are insignificant block boundaries, so a
fence can be written with a readable leading space (`"XSEC .GROUP."`) without
that space joining the preceding atom.

`position` on `AtomNode` / `GroupNode` is a 0-based sibling index within the
current nesting scope, not a character offset. A fence's contents renumber from
0 — its own local reality.

## Usage

```js
import { parseText, flattenAtoms, tokenize, annotatePolarity } from "@deadark/flux-algebra";

tokenize("I302G-AS3TGBLRPG-JKDNRLNW");
// -> ["I302G", "AS3TGBLRPG", "JKDNRLNW"]
```

Subpath exports are available for `./parser`, `./tokenizer`, `./resolvers`,
`./semantics`, and `./analysis`.

## Native acceleration

This package stays pure JS on purpose. A consumer with a native addon (as
ark-miner-cli has) should wrap it — try the native path, fall back to these
functions — rather than forking the engine. Forking is how the three copies
above drifted in the first place.

## Tests

```bash
npm test
```

36 tests, carried over unchanged from the canonical copy.
