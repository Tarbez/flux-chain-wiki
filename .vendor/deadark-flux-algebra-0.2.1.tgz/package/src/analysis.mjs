import { environmentLineage, escapedKeyPrefixesFor, escapeKeyField } from "./semantics.mjs";

/**
 * Dead Ark integration hooks named directly in the spec this module was
 * built against:
 *
 *  - classifyPattern: a polarity-annotated atom list is a "State" unless it
 *    contains a polarity gradient (a transition between positive/negative/
 *    null across positions), in which case it's an "Action".
 *  - seamFlag: a pattern with no seam at all - no negative/null polarity and
 *    no isolation fence - is flagged 451 ("boundary pressure"): nothing in
 *    it gives the engine a place to isolate or negate, so it can't be
 *    decomposed further.
 *  - routeForReview: patterns whose observer-relative meaning is already
 *    mostly resolved (high "coherence") are routed to an adversarial
 *    reviewer. defaultDevilsAdvocate is a real, deterministic reviewer (an
 *    adversarial checklist, same output for the same input - not an
 *    adversarial intelligence); pass your own `devilsAdvocate` callback to
 *    substitute a live peer (e.g. a TLM Five Peers adversarial peer).
 *    createDevilsAdvocate() returns a stateful variant: share one instance
 *    across calls (pass a `patternKey` in options so it can recognize a
 *    repeat) and it names how many times the same pattern has already
 *    passed review instead of treating every call as new. There is no bus
 *    in this standalone engine (unlike the Python side's flux_engine +
 *    five_peer.py), so "live" here means "has memory across calls", not
 *    "wired into a message bus".
 *
 * Corrected 2026-08-05 (Directive 1/3): every function here now takes a
 * flat, polarity-annotated AtomNode array (see parser.mjs's flattenAtoms +
 * polarity.mjs's annotatePolarity) instead of a tokenizer "stream" of mixed
 * operator/token entries -- there is no more "operator" entry kind to
 * filter out, since "-"/"." never appear in the atom list at all (they're
 * structural, consumed entirely by the parser). `entry.value`/`entry.index`
 * are now `atom.text`/`atom.position`.
 */

const DEFAULT_COHERENCE_THRESHOLD = 0.75;

/**
 * @param {object[]} atoms - polarity-annotated AtomNode[]
 * @returns {{ kind: "state" | "action", transitions: number, sawPositive: boolean, sawNegative: boolean, sawNull: boolean }}
 */
export function classifyPattern(atoms) {
  let sawPositive = false;
  let sawNegative = false;
  let sawNull = false;
  let transitions = 0;
  let previous = null;

  for (const atom of atoms) {
    if (atom.polarity === "positive") sawPositive = true;
    if (atom.polarity === "negative") sawNegative = true;
    if (atom.polarity === "null") sawNull = true;
    if (previous !== null && previous !== atom.polarity) transitions += 1;
    previous = atom.polarity;
  }

  return {
    kind: transitions > 0 ? "action" : "state",
    transitions,
    sawPositive,
    sawNegative,
    sawNull,
  };
}

/**
 * @param {object[]} atoms - polarity-annotated AtomNode[]
 * @param {{ hasIsolationFence?: boolean }} [options]
 * @returns {{ code: 451, reason: string } | null}
 */
export function seamFlag(atoms, { hasIsolationFence = false } = {}) {
  const hasNegativeSeam = atoms.some((atom) => atom.polarity === "negative");
  const hasNullSeam = atoms.some((atom) => atom.polarity === "null");
  const seamless = !hasNegativeSeam && !hasNullSeam && !hasIsolationFence;
  return seamless ? { code: 451, reason: "boundary pressure: no polarity or isolation seam found" } : null;
}

/**
 * Fraction of atom positions that already have a resolved (non-imagined)
 * meaning for `observer` in `semanticMap`.
 *
 * @param {object[]} atoms - AtomNode[]
 * @param {Map<string, any>} semanticMap
 * @param {string} observer
 * @param {string} environment
 */
export function coherenceScore(atoms, semanticMap, observer, environment = "DEFAULT") {
  if (atoms.length === 0) return 0;
  // Computed once per call, not once per atom: environmentLineage's cost
  // grows with the number of `|`-separated segments in `environment`, and
  // re-deriving it per atom multiplied that cost by the pattern's atom
  // count for no reason -- the lineage doesn't change across atoms. Same
  // reasoning for escapedKeyPrefixesFor: `environment`/`observer` are also
  // constant across every atom, so escaping them (which dominates cost for
  // a long environment lineage) happens once here rather than once per atom.
  const lineage = semanticMap ? environmentLineage(environment) : [];
  const prefixes = semanticMap ? escapedKeyPrefixesFor(lineage, observer) : [];
  let resolved = 0;
  for (const atom of atoms) {
    const suffix = `${escapeKeyField(atom.text)}|${escapeKeyField(atom.position)}`;
    if (prefixes.some((prefix) => semanticMap.has(prefix + suffix))) {
      resolved += 1;
    }
  }
  return resolved / atoms.length;
}

/**
 * @param {object[]} atoms - AtomNode[]
 * @param {Map<string, any>} semanticMap
 * @param {string} observer
 * @param {{ devilsAdvocate?: (input: { atoms: object[], score: number, observer: string, environment: string, patternKey?: string }) => any, threshold?: number, patternKey?: string }} [options]
 */
export function routeForReview(atoms, semanticMap, observer, environment = "DEFAULT", options = {}) {
  const { devilsAdvocate = defaultDevilsAdvocate, threshold = DEFAULT_COHERENCE_THRESHOLD, patternKey } = options;
  const score = coherenceScore(atoms, semanticMap, observer, environment);
  if (score >= threshold && typeof devilsAdvocate === "function") {
    return { routed: true, score, review: devilsAdvocate({ atoms, score, observer, environment, patternKey }) };
  }
  return { routed: false, score };
}

/**
 * The default adversarial reviewer: a deterministic checklist, not an
 * adversarial intelligence. Challenges a too-coherent pattern with concrete
 * questions - who defined each resolved meaning, and where are the seams?
 *
 * @param {{ atoms: object[], score: number, observer: string, environment: string }} input
 */
export function defaultDevilsAdvocate({ atoms, score, observer, environment = "DEFAULT" }) {
  const classification = classifyPattern(atoms);
  const seam = seamFlag(atoms, { hasIsolationFence: false });
  const adversarialNotes = [
    `coherence ${score} for observer '${observer}' in environment '${environment}' - were these definitions independently confirmed, or self-declared?`,
  ];
  if (seam) {
    adversarialNotes.push(`451: no polarity or isolation seam - who benefits from this pattern reading as settled?`);
  }
  if (classification.kind === "state" && !classification.sawNegative && !classification.sawNull) {
    adversarialNotes.push("all-positive state: nothing here is suppressed or deleted - is that plausible?");
  }
  for (const atom of atoms.slice(0, 5)) {
    adversarialNotes.push(`challenge '${atom.text}'@${atom.position}: who defined this, and what breaks if it's wrong?`);
  }
  return { adversarialNotes, classification, seam };
}

/**
 * Stateful Devil's Advocate factory. A fresh call to defaultDevilsAdvocate
 * has no memory, so it treats a pattern that keeps passing review as new
 * every time. Share the function this returns across calls (with a stable
 * `patternKey` per pattern in routeForReview's options) and it will name
 * the repeat instead: "this exact pattern has now been marked coherent N
 * times ... why does it keep coming back for review?". Still deterministic
 * given its own history - it does not synthesize a novel objection.
 *
 * @returns {(input: { atoms: object[], score: number, observer: string, environment: string, patternKey?: string }) => any}
 */
export function createDevilsAdvocate() {
  const reviewCounts = new Map();

  return function liveDevilsAdvocate({ atoms, score, observer, environment = "DEFAULT", patternKey }) {
    const review = defaultDevilsAdvocate({ atoms, score, observer, environment });
    if (!patternKey) return review;

    const key = `${environment}|${observer}|${patternKey}`;
    const timesReviewed = (reviewCounts.get(key) ?? 0) + 1;
    reviewCounts.set(key, timesReviewed);
    if (timesReviewed > 1) {
      review.adversarialNotes.push(
        `this exact pattern has now been marked coherent ${timesReviewed} times for observer ` +
          `'${observer}' in environment '${environment}' - if it were truly settled, why does it keep coming back for review?`,
      );
    }
    return review;
  };
}

export function collapseEnvironmentAction(atoms, semanticMap, observer, environment = "DEFAULT") {
  const classification = classifyPattern(atoms);
  // See coherenceScore's comment: computed once per call, not once per atom.
  const lineage = environmentLineage(environment);
  const prefixes = escapedKeyPrefixesFor(lineage, observer);
  const resolved = atoms.map((atom) => {
    const suffix = `${escapeKeyField(atom.text)}|${escapeKeyField(atom.position)}`;
    for (let i = 0; i < lineage.length; i += 1) {
      const key = prefixes[i] + suffix;
      if (semanticMap.has(key)) {
        return { token: atom.text, index: atom.position, sourceEnvironment: lineage[i], meaning: semanticMap.get(key) };
      }
    }
    return { token: atom.text, index: atom.position, sourceEnvironment: environment, meaning: { gap: true } };
  });
  return {
    environment,
    observer,
    classification: classification.kind,
    transitions: classification.transitions,
    action:
      classification.kind === "action"
        ? {
            type: "environment-collapse",
            intent: resolved[1]?.meaning?.intent || resolved[0]?.meaning?.intent || "act",
            target: resolved[3]?.meaning || resolved[2]?.meaning || null,
            operation: resolved[0]?.meaning || null,
          }
        : null,
    resolved,
  };
}
