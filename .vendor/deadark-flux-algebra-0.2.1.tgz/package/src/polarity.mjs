/**
 * Attaches a resolver-computed polarity to each AtomNode in a flattened
 * block list. Corrected 2026-08-05 (Directive 1): the stream-of-entries
 * concept ("operator" vs "token" typed entries) is gone along with the
 * Pratt parser -- flattenAtoms (parser.mjs) now hands this an array of
 * plain AtomNode leaves, and polarity is read from each atom's own raw
 * text via resolvers.mjs's `resolvePolarity`, exactly mirroring the Python
 * engine's evaluator.py.
 */

import { resolvePolarity } from "./resolvers.mjs";

/**
 * @param {{ text: string }} atom
 * @returns {import("./types.mjs").Polarity}
 */
export function detectPolarity(atom) {
  return resolvePolarity(atom.text).polarity;
}

/**
 * @param {object[]} atoms - AtomNode[]
 * @returns {object[]} atoms with `.polarity` and `.stripped` attached
 */
export function annotatePolarity(atoms) {
  return atoms.map((atom) => {
    const { polarity, stripped } = resolvePolarity(atom.text);
    return { ...atom, polarity, stripped };
  });
}
