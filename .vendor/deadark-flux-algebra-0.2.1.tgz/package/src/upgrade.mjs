/**
 * resolveUpgrade: pick the version of a type-scoped letter extension (e.g.
 * `J`, per dense-encoding-v4.md's "Settled: `J`'s shape is scoped by
 * manifest type") that was actually in force at a given spec version --
 * so a resolver reading an *old* manifest gets the contract that governed
 * it, not whatever `manifest-types.json` says today.
 *
 * This module never reads the registry itself and never hardcodes real
 * types' history. The caller supplies a `history` table, keyed the same way
 * the registry already nests things (`manifestType -> letter -> [...]`),
 * where each entry is the registry's own `letterExtensions` entry shape
 * (`shape`/`definedIn`/`note`) plus one more field this module requires:
 * `since`, the spec version the entry became effective at.
 *
 * `buildUpgradeHistory` (below, added 2026-09-08) is how a caller turns a
 * parsed `manifest-types.json` into that table, so real registry data can
 * drive this instead of only the hand-built fixtures in upgrade.test.mjs.
 * It stays pure -- it takes the already-parsed object, it does no I/O --
 * which is what keeps this package dependency-free.
 *
 * Same discipline as every resolver in resolvers.mjs: no history for the
 * requested (type, letter) pair, or no entry old enough to cover the target
 * version, throws `DenseEncodingError` rather than falling back to
 * whatever's newest -- a silently-wrong shape choice is exactly the failure
 * mode this module exists to prevent.
 */

import { DenseEncodingError } from "./resolvers.mjs";

const SEMVER_PATTERN = /^(\d+)\.(\d+)\.(\d+)$/;

/**
 * @param {string} version
 * @param {string} label - for error messages only
 * @returns {[number, number, number]}
 */
function parseVersion(version, label) {
  const match = typeof version === "string" ? SEMVER_PATTERN.exec(version) : null;
  if (!match) {
    throw new DenseEncodingError(`${label}: expected a semver "major.minor.patch" string, got ${JSON.stringify(version)}`);
  }
  return [Number(match[1]), Number(match[2]), Number(match[3])];
}

/** @returns {number} negative if a<b, 0 if equal, positive if a>b */
function compareVersions(a, b) {
  for (let index = 0; index < 3; index += 1) {
    if (a[index] !== b[index]) return a[index] - b[index];
  }
  return 0;
}

/**
 * Resolves the extension entry for `letter` on `manifestType` that was in
 * force at `targetVersion` -- the latest entry whose `since` is `<=
 * targetVersion`. Later entries (a `since` after `targetVersion`) are
 * exactly the upgrades that had not happened yet, so they're ignored, not
 * preferred.
 *
 * @param {Record<string, Record<string, Array<{since: string, [key: string]: any}>>>} history
 *        manifestType -> letter -> version-ordered-or-not list of entries,
 *        each an entryShape object (`shape`/`definedIn`/`note`, matching
 *        manifest-types.json's `letterExtensions.entryShape`) plus `since`.
 * @param {string} manifestType - a `Y` value, e.g. "BLOCK"
 * @param {string} letter - the type-scoped letter, e.g. "J"
 * @param {string} targetVersion - the spec version the manifest targets/was
 *        written against, e.g. "3.6.0"
 * @returns {{since: string, [key: string]: any}} the winning history entry
 * @example
 * resolveUpgrade(
 *   { X: { J: [
 *     { since: "3.5.0", shape: "opaque-alphanumeric", definedIn: "spec-a.md" },
 *     { since: "4.0.0", shape: "coded-fields", definedIn: "spec-b.md" },
 *   ] } },
 *   "X", "J", "3.6.0",
 * ) // -> { since: "3.5.0", shape: "opaque-alphanumeric", definedIn: "spec-a.md" }
 */
export function resolveUpgrade(history, manifestType, letter, targetVersion) {
  const target = parseVersion(targetVersion, "resolveUpgrade: targetVersion");
  const entries = history?.[manifestType]?.[letter];
  if (!Array.isArray(entries) || entries.length === 0) {
    throw new DenseEncodingError(
      `resolveUpgrade: no version history registered for letter '${letter}' on type "${manifestType}" -- cannot resolve without it`,
    );
  }

  let winner = null;
  let winnerVersion = null;
  for (const entry of entries) {
    const since = parseVersion(entry?.since, `resolveUpgrade: "since" for ${manifestType}.${letter} entry`);
    const isEligible = compareVersions(since, target) <= 0;
    const isNewerThanCurrentWinner = !winnerVersion || compareVersions(since, winnerVersion) > 0;
    if (isEligible && isNewerThanCurrentWinner) {
      winner = entry;
      winnerVersion = since;
    }
  }

  if (!winner) {
    throw new DenseEncodingError(
      `resolveUpgrade: no ${manifestType}.${letter} extension was in force at version ${targetVersion} -- ` +
        `earliest registered "since" is later than the target`,
    );
  }
  return winner;
}

/**
 * Normalizes one registry `letterExtensions[letter]` value into a list.
 *
 * The registry records a letter's extension as a single object today
 * (`{J: {shape, definedIn, note}}`). A letter whose shape genuinely changes
 * later becomes an array of versioned objects. Accepting both is what makes
 * the registry able to grow history without a migration.
 */
function extensionEntries(value) {
  if (Array.isArray(value)) return value;
  if (value && typeof value === "object") return [value];
  return [];
}

/**
 * Builds `resolveUpgrade`'s `history` table from a parsed
 * `manifest-types.json`.
 *
 * **Entries with no `since` are skipped, never guessed.** That is deliberate
 * and matches `sinceTracking`'s own rule -- "Applied going forward only --
 * existing entries predating this convention are left unannotated rather
 * than backfilled with a guessed version number". The consequence is that
 * `resolveUpgrade` throws its "no version history registered" error for an
 * un-annotated letter rather than silently returning today's shape, which is
 * exactly the failure mode this module exists to produce. A skipped entry is
 * a visible gap, not a fallback.
 *
 * Use `listUnversionedExtensions` to see what was skipped and why.
 *
 * @param {{types?: Array<{type?: string, letterExtensions?: Record<string, any>}>}} manifestTypes
 *        the parsed registry object. Not a path -- this module does no I/O.
 * @returns {Record<string, Record<string, Array<{since: string}>>>}
 *          `manifestType -> letter -> versioned entries`, ready for resolveUpgrade.
 * @example
 * const history = buildUpgradeHistory(JSON.parse(await readFile(registryPath)));
 * resolveUpgrade(history, "LEXEME", "J", "0.4.2");
 */
export function buildUpgradeHistory(manifestTypes) {
  const history = {};
  for (const entry of manifestTypes?.types ?? []) {
    const type = entry?.type;
    if (typeof type !== "string" || !entry?.letterExtensions) continue;
    for (const [letter, value] of Object.entries(entry.letterExtensions)) {
      const versioned = extensionEntries(value).filter(
        (candidate) => typeof candidate?.since === "string",
      );
      if (versioned.length === 0) continue;
      history[type] ??= {};
      history[type][letter] = versioned;
    }
  }
  return history;
}

/**
 * Lists every type-scoped letter extension the registry declares that
 * carries no `since`, and is therefore invisible to `resolveUpgrade`.
 *
 * This is the honest-gap report. It is not a TODO list to be closed by
 * backfilling versions: for most of these the true addition version is not
 * knowable from what the registry recorded at the time, and
 * `sinceTracking`'s note is explicit that guessing "would let a consumer
 * believe a `since` comparison it cannot actually rely on". The report
 * exists so a caller can tell "no history recorded" apart from "no such
 * extension", which are different facts.
 *
 * @param {{types?: Array<{type?: string, letterExtensions?: Record<string, any>}>}} manifestTypes
 * @returns {Array<{type: string, letter: string}>} sorted by type, then letter
 */
export function listUnversionedExtensions(manifestTypes) {
  const gaps = [];
  for (const entry of manifestTypes?.types ?? []) {
    const type = entry?.type;
    if (typeof type !== "string" || !entry?.letterExtensions) continue;
    for (const [letter, value] of Object.entries(entry.letterExtensions)) {
      const declared = extensionEntries(value);
      if (declared.length === 0) continue;
      if (declared.every((candidate) => typeof candidate?.since !== "string")) {
        gaps.push({ type, letter });
      }
    }
  }
  return gaps.sort((a, b) => a.type.localeCompare(b.type) || a.letter.localeCompare(b.letter));
}
