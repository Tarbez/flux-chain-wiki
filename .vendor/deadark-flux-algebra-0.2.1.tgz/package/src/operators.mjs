/**
 * Corrected design, 2026-08-05 (Directive 1): there is no more mutable
 * operator table -- "-"/"." are structurally fixed, not runtime-registered
 * data (see parser.mjs). This file survives only as the named constants
 * that document that fact for callers that used to introspect the old
 * table (`defineOperator`/`undefineOperator`/`createOperatorTable` are
 * gone; DEFINE ... AS ... is gone from bootstrap.mjs along with them).
 */

export const SEPARATORS = Object.freeze(["-", "."]);

export const FIXITY = Object.freeze({
  "-": "separator",
  ".": "fence",
});
