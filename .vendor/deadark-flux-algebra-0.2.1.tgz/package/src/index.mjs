export { parseText, flattenAtoms, ParseError } from "./parser.mjs";
export { tokenize } from "./tokenizer.mjs";
export { SEPARATORS, FIXITY } from "./operators.mjs";
export {
  resolvePolarity,
  DenseEncodingError,
  PrimaryResolver,
  ComplementaryResolver,
  ActionResolver,
  TargetResolver,
  ReferentialResolver,
  ROLE_RESOLVERS,
  resolveDenseBlock,
  encodeManifestType,
} from "./resolvers.mjs";
export { resolveUpgrade, buildUpgradeHistory, listUnversionedExtensions } from "./upgrade.mjs";
export { detectPolarity, annotatePolarity } from "./polarity.mjs";
export { createSemanticMap, defineMeaning, resolveMeaning, hasMeaning, imaginePlaceholder, environmentLineage } from "./semantics.mjs";
export { applyDefinitions, isStatement, DefineStatementError } from "./bootstrap.mjs";
export {
  classifyPattern,
  seamFlag,
  coherenceScore,
  routeForReview,
  defaultDevilsAdvocate,
  createDevilsAdvocate,
  collapseEnvironmentAction,
} from "./analysis.mjs";

import { parseText, flattenAtoms } from "./parser.mjs";
import { annotatePolarity } from "./polarity.mjs";

/**
 * Convenience pipeline: parse -> flatten -> annotate polarity. Returns the
 * parsed AST alongside the polarity-annotated top-level atom list so
 * callers can run analysis.mjs against the same atoms without re-parsing.
 * `hasFence` is a plain substring check (not a tree walk) -- by the time a
 * pattern has parsed successfully, a "." in its text can only mean a
 * (closed) isolation fence, since an unclosed one would already have
 * thrown in parseText.
 *
 * @param {string} text
 */
export function run(text) {
  const node = parseText(text);
  const atoms = annotatePolarity(flattenAtoms(node));
  const hasFence = text.includes(".");
  return { node, atoms, hasFence };
}
