/**
 * @typedef {"positive" | "negative" | "null"} Polarity
 *
 * @typedef {Object} StreamEntry
 * @property {"token" | "operator"} type
 * @property {string} value
 * @property {string} raw
 * @property {number} index - position of this entry in the Psi tuple, used as
 *   the observer-relative semantic map's position key
 * @property {Polarity} [polarity]
 *
 * @typedef {"left" | "right"} Associativity
 * @typedef {"infix" | "prefix" | "fence" | "fence-open" | "fence-close"} Fixity
 *
 * @typedef {Object} OperatorSpec
 * @property {string} symbol
 * @property {number} precedence
 * @property {Associativity} [associativity]
 * @property {number} arity
 * @property {Fixity} fixity
 * @property {string} [pairsWith] - closing symbol, for fence-open operators
 * @property {(...args: any[]) => any} fn
 *
 * @typedef {Map<string, OperatorSpec>} OperatorTable
 *
 * @typedef {{ type: "Atom", value: string, polarity: Polarity, position: number }} AtomNode
 * @typedef {{ type: "Unary", op: string, arg: AstNode, position: number }} UnaryNode
 * @typedef {{ type: "Binary", op: string, left: AstNode, right: AstNode, position: number }} BinaryNode
 * @typedef {{ type: "Isolated", inner: AstNode, position: number }} IsolatedNode
 * @typedef {{ type: "Sequence", items: AstNode[] }} SequenceNode
 * @typedef {AtomNode | UnaryNode | BinaryNode | IsolatedNode | SequenceNode} AstNode
 */

export {};
