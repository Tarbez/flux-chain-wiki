import test from "node:test";
import assert from "node:assert/strict";

import { applyDefinitions, isStatement, DefineStatementError } from "./bootstrap.mjs";
import { createSemanticMap, resolveMeaning } from "./semantics.mjs";

test("isStatement recognizes a DEFINE line case-insensitively", () => {
  assert.equal(isStatement("DEFINE FIX MEANS 1 AT POSITION 0"), true);
  assert.equal(isStatement("define fix means 1 at position 0"), true);
  assert.equal(isStatement("FIX"), false);
});

test("applyDefinitions writes a JSON-literal meaning into the semantic map", () => {
  const map = createSemanticMap();
  const applied = applyDefinitions('DEFINE FIX MEANS "display:flex" AT POSITION 1 FOR app-a IN FILE-css', map);
  assert.equal(applied.length, 1);
  const result = resolveMeaning(map, "FILE-css", "app-a", "FIX", 1);
  assert.equal(result.value, "display:flex");
});

test("applyDefinitions rejects a non-JSON meaning", () => {
  const map = createSemanticMap();
  assert.throws(() => applyDefinitions("DEFINE FIX MEANS not-json AT POSITION 1", map), DefineStatementError);
});

test("applyDefinitions handles several DEFINE statements in one text block", () => {
  const map = createSemanticMap();
  const text = [
    'DEFINE FIX MEANS "a" AT POSITION 0',
    'DEFINE GO MEANS "b" AT POSITION 1',
  ].join("\n");
  const applied = applyDefinitions(text, map);
  assert.equal(applied.length, 2);
});

test("applyDefinitions on a DEFINE with no AT POSITION anywhere after it does not hang or scan unboundedly (G3)", () => {
  // No "AT POSITION" ever appears, so the lazy JSON-literal capture group
  // must fail to match within a bounded amount of work rather than trying
  // progressively longer expansions across the whole remaining input.
  const text = `DEFINE FIX MEANS ${"x".repeat(500_000)}`;
  const start = Date.now();
  const applied = applyDefinitions(text, createSemanticMap());
  const elapsedMs = Date.now() - start;
  assert.deepEqual(applied, []);
  assert.ok(elapsedMs < 1000, `expected the failed-match scan to stay well under 1s, took ${elapsedMs}ms`);
});

test("applyDefinitions still matches a JSON literal right at the bound (regression guard for the cap itself)", () => {
  const map = createSemanticMap();
  const longString = "x".repeat(2000); // under the 4096-char cap once JSON-quoted
  const text = `DEFINE FIX MEANS "${longString}" AT POSITION 0`;
  const applied = applyDefinitions(text, map);
  assert.equal(applied.length, 1);
  assert.equal(applied[0].meaning, longString);
});
