import test from "node:test";
import assert from "node:assert/strict";

import { coherenceScore, collapseEnvironmentAction, classifyPattern, seamFlag } from "./analysis.mjs";
import { createSemanticMap, defineMeaning } from "./semantics.mjs";

function atom(text, position, polarity = "positive") {
  return { text, position, polarity };
}

test("coherenceScore is 1 when every atom has a resolved meaning", () => {
  const map = createSemanticMap();
  defineMeaning(map, "DEFAULT", "alice", "FIX", 1, { intent: "x" });
  defineMeaning(map, "DEFAULT", "alice", "GO", 2, { intent: "y" });
  const score = coherenceScore([atom("FIX", 1), atom("GO", 2)], map, "alice");
  assert.equal(score, 1);
});

test("coherenceScore is 0 for a pattern with no semantic map", () => {
  const score = coherenceScore([atom("FIX", 1)], null, "alice");
  assert.equal(score, 0);
});

test("coherenceScore counts a token containing '|' correctly (G2 regression via analysis.mjs's real call path)", () => {
  const map = createSemanticMap();
  defineMeaning(map, "DEFAULT", "alice", "x|5", 7, { intent: "real" });
  const score = coherenceScore([atom("x|5", 7)], map, "alice");
  assert.equal(score, 1);
});

test("coherenceScore falls back through environment lineage the same way for every atom", () => {
  const map = createSemanticMap();
  defineMeaning(map, "DEFAULT", "alice", "FIX", 1, { intent: "default" });
  const score = coherenceScore([atom("FIX", 1), atom("FIX", 1)], map, "alice", "app-a|file-css");
  assert.equal(score, 1);
});

test("collapseEnvironmentAction resolves a token containing '|' correctly (G2 regression via analysis.mjs's real call path)", () => {
  const map = createSemanticMap();
  defineMeaning(map, "DEFAULT", "alice", "x|5", 3, { intent: "real" });
  const result = collapseEnvironmentAction([atom("x|5", 3, "positive"), atom("GO", 4, "negative")], map, "alice");
  assert.equal(result.resolved[0].meaning.intent, "real");
  assert.equal(result.resolved[0].sourceEnvironment, "DEFAULT");
});

test("collapseEnvironmentAction marks an unresolved atom as a gap rather than throwing", () => {
  const map = createSemanticMap();
  const result = collapseEnvironmentAction([atom("UNKNOWN", 1)], map, "alice");
  assert.equal(result.resolved[0].meaning.gap, true);
});

test("classifyPattern flags a polarity transition as an action", () => {
  const result = classifyPattern([atom("A", 0, "positive"), atom("B", 1, "negative")]);
  assert.equal(result.kind, "action");
  assert.equal(result.transitions, 1);
});

test("seamFlag flags a pattern with no negative/null polarity and no isolation fence", () => {
  const result = seamFlag([atom("A", 0, "positive")]);
  assert.equal(result.code, 451);
});

test("coherenceScore stays fast across many atoms for a realistic (sub-cap) environment lineage (G1 perf regression guard)", () => {
  const map = createSemanticMap();
  const segments = Array.from({ length: 200 }, (_, index) => `s${index}`);
  const environment = segments.join("|");
  defineMeaning(map, "DEFAULT", "alice", "FIX", 1, { intent: "default" });
  const atoms = Array.from({ length: 200 }, (_, index) => atom(`TOKEN${index}`, index));

  const start = Date.now();
  coherenceScore(atoms, map, "alice", environment);
  const elapsedMs = Date.now() - start;
  assert.ok(elapsedMs < 1000, `expected one coherenceScore call over 200 atoms x 200 segments to stay well under 1s, took ${elapsedMs}ms`);
});

test("coherenceScore stays fast across many atoms even for a pathologically long, attacker-influenced environment string (G1 + MAX_ENVIRONMENT_LENGTH combined)", () => {
  const map = createSemanticMap();
  const environment = Array.from({ length: 200_000 }, (_, index) => `seg${index}`).join("|");
  defineMeaning(map, "DEFAULT", "alice", "FIX", 1, { intent: "default" });
  const atoms = Array.from({ length: 200 }, (_, index) => atom(`TOKEN${index}`, index));

  const start = Date.now();
  coherenceScore(atoms, map, "alice", environment);
  const elapsedMs = Date.now() - start;
  assert.ok(elapsedMs < 1000, `expected one coherenceScore call over 200 atoms x a ~1.6MB environment to stay well under 1s, took ${elapsedMs}ms`);
});
