import test from "node:test";
import assert from "node:assert/strict";

import { parseText, flattenAtoms, ParseError } from "./parser.mjs";
import { tokenize } from "./tokenizer.mjs";
import { annotatePolarity } from "./polarity.mjs";
import { applyDefinitions, isStatement, DefineStatementError } from "./bootstrap.mjs";
import { classifyPattern, seamFlag, coherenceScore, routeForReview, createDevilsAdvocate, collapseEnvironmentAction } from "./analysis.mjs";
import { createSemanticMap, resolveMeaning, defineMeaning, hasMeaning, imaginePlaceholder } from "./semantics.mjs";

// Corrected 2026-08-05 (Directive 1): this engine's parser now knows about
// exactly two characters -- "-" (top-level separator) and "." (isolation
// fence) -- mirroring src/deadark_micro_ai/flux_engine/parser.py block for
// block. There is no more mutable operator table, no more arithmetic/
// composite-operator demos (+ - * / ! ~ ( ) => :- |> ++ :|:), and DEFINE
// only ever writes a MEANS meaning into the semantic map now. Tests below
// use dense patterns (e.g. I302G-AS3TGBLRPG-JKDNRLNW) exclusively -- see
// docs/architecture/flux-symbolic-engine.md's addendum for the full
// rationale and shared/flux-claims/CLAUDE.md for why that package's own
// vendored copy of the pre-correction grammar is untouched by this file.

function runAtoms(text) {
  return annotatePolarity(flattenAtoms(parseText(text)));
}

test("tokenize splits a dense pattern into its raw top-level blocks", () => {
  assert.deepEqual(tokenize("I302G-AS3TGBLRPG-JKDNRLNW"), ["I302G", "AS3TGBLRPG", "JKDNRLNW"]);
});

test("parseText produces AtomNode/GroupNode/SequenceNode with an untouched raw block per dimension", () => {
  const node = parseText("IADMIN-CREG-XSEC .AMERGE-MSECURITY.");
  assert.equal(node.type, "SequenceNode");
  assert.equal(node.nodes.length, 4);

  const [iadmin, creg, xsec, group] = node.nodes;
  assert.deepEqual(iadmin, { type: "AtomNode", text: "IADMIN", position: 0 });
  assert.deepEqual(creg, { type: "AtomNode", text: "CREG", position: 1 });
  assert.deepEqual(xsec, { type: "AtomNode", text: "XSEC", position: 2 });
  assert.equal(group.type, "GroupNode");
  assert.equal(group.content, "AMERGE-MSECURITY");
  assert.equal(group.position, 3);

  // A fence's contents are recursively parsed and locally renumbered from 0.
  assert.equal(group.inner.type, "SequenceNode");
  assert.deepEqual(group.inner.nodes[0], { type: "AtomNode", text: "AMERGE", position: 0 });
  assert.deepEqual(group.inner.nodes[1], { type: "AtomNode", text: "MSECURITY", position: 1 });
});

test("a single top-level block collapses to a bare AtomNode, not a one-item SequenceNode", () => {
  const node = parseText("ABC");
  assert.equal(node.type, "AtomNode");
  assert.equal(node.text, "ABC");
});

test("flattenAtoms excludes a GroupNode's contents -- callers must walk node.inner explicitly", () => {
  const node = parseText("A-B.C.D");
  const atoms = flattenAtoms(node);
  assert.deepEqual(atoms.map((a) => a.text), ["A", "B", "D"]);
});

test("every other character -- numbers, !, ~, 0, ? -- stays verbatim inside its raw block", () => {
  assert.doesNotThrow(() => parseText("F-IDBU-1347!L360-0-?"));
  const atoms = runAtoms("F-IDBU-1347!L360-0-?");
  // "1347!L360" is one opaque block: "!" is not a structurally significant
  // character post-correction, so it never splits a run. 5 top-level blocks.
  assert.deepEqual(atoms.map((a) => a.text), ["F", "IDBU", "1347!L360", "0", "?"]);

  const seam = seamFlag(atoms, { hasIsolationFence: false });
  assert.equal(seam, null, "the lone '0' block resolves null, which is still a seam");
});

test("a pattern with no polarity seam and no isolation fence is flagged 451", () => {
  const atoms = runAtoms("ABC");
  const seam = seamFlag(atoms, { hasIsolationFence: false });
  assert.deepEqual(seam, { code: 451, reason: "boundary pressure: no polarity or isolation seam found" });
});

test("classifyPattern detects a polarity gradient as an Action, uniform polarity as a State", () => {
  const action = classifyPattern(runAtoms("A-!B"));
  assert.equal(action.kind, "action");
  assert.ok(action.transitions > 0);

  const state = classifyPattern(runAtoms("A-B-C"));
  assert.equal(state.kind, "state");
  assert.equal(state.transitions, 0);
});

test("blocks are split unicode-safely on the default separator", () => {
  assert.deepEqual(tokenize("\u{1F525}-\u{1F680}"), ["\u{1F525}", "\u{1F680}"]);
});

test("unclosed isolation fence throws ParseError instead of silently truncating", () => {
  assert.throws(() => parseText(".UNCLOSED"), ParseError);
  assert.throws(() => parseText(".UNCLOSED"), /unclosed isolation fence/);
});

test("a completely empty pattern throws ParseError", () => {
  assert.throws(() => parseText(""), ParseError);
  assert.throws(() => parseText("---"), ParseError, "pure separators with no content between them still yield zero atoms");
});

test("observer-relative semantic map gaps by default and imagines only when opted in", () => {
  const map = createSemanticMap();
  assert.equal(hasMeaning(map, "DEFAULT", "alice", "USER", 0), false);

  // Default: a miss is a visible gap, and nothing is stored.
  const gap = resolveMeaning(map, "DEFAULT", "alice", "USER", 0);
  assert.equal(gap.defined, false);
  assert.equal(gap.gap, true);
  assert.equal(hasMeaning(map, "DEFAULT", "alice", "USER", 0), false);

  // Opt-in: imaginePlaceholder restores the old self-populating behavior.
  const imagined = resolveMeaning(map, "DEFAULT", "alice", "USER", 0, imaginePlaceholder);
  assert.equal(imagined.value.imagined, true);
  assert.equal(hasMeaning(map, "DEFAULT", "alice", "USER", 0), true);

  defineMeaning(map, "DEFAULT", "bob", "USER", 0, { role: "admin" });
  assert.deepEqual(resolveMeaning(map, "DEFAULT", "bob", "USER", 0).value, { role: "admin" });

  // Same token/position, different observer -> different meaning.
  assert.notDeepEqual(resolveMeaning(map, "DEFAULT", "alice", "USER", 0), resolveMeaning(map, "DEFAULT", "bob", "USER", 0));
});

test("isStatement recognizes a DEFINE line and rejects an ordinary pattern", () => {
  assert.equal(isStatement('DEFINE FIX MEANS "repair" AT POSITION 1'), true);
  assert.equal(isStatement("F-IDBU-1347"), false);
});

test("DEFINE ... MEANS ... AT POSITION ... writes an observer/environment-relative meaning", () => {
  const map = createSemanticMap();
  const applied = applyDefinitions('DEFINE FIX MEANS "display:flex" AT POSITION 1 FOR app-a IN FILE-css', map);
  assert.equal(applied.length, 1);
  assert.deepEqual(resolveMeaning(map, "FILE-css", "app-a", "FIX", 1).value, "display:flex");
});

test("DEFINE ... MEANS falls back to default observer/environment when FOR/IN are omitted", () => {
  const map = createSemanticMap();
  applyDefinitions('DEFINE ROOT MEANS {"kind":"origin"} AT POSITION 0', map, { observer: "default", environment: "DEFAULT" });
  assert.deepEqual(resolveMeaning(map, "DEFAULT", "default", "ROOT", 0).value, { kind: "origin" });
});

test("DEFINE ... MEANS rejects a non-JSON body instead of evaluating arbitrary code", () => {
  const map = createSemanticMap();
  assert.throws(() => applyDefinitions("DEFINE X MEANS not_json AT POSITION 0", map), DefineStatementError);
});

test("multiple DEFINE ... MEANS statements in one program are all applied in order", () => {
  const map = createSemanticMap();
  const applied = applyDefinitions(
    'DEFINE A MEANS "first" AT POSITION 0 DEFINE B MEANS "second" AT POSITION 1',
    map,
  );
  assert.equal(applied.length, 2);
  assert.deepEqual(resolveMeaning(map, "DEFAULT", "default", "A", 0).value, "first");
  assert.deepEqual(resolveMeaning(map, "DEFAULT", "default", "B", 1).value, "second");
});

test("defaultDevilsAdvocate produces real adversarial challenges for coherent patterns", () => {
  const map = createSemanticMap();
  const atoms = runAtoms("USER-CREATE");
  atoms.forEach((atom) => defineMeaning(map, "DEFAULT", "alice", atom.text, atom.position, "resolved"));

  // No custom hook passed: the default reviewer runs once coherence clears.
  const routed = routeForReview(atoms, map, "alice", "DEFAULT", {});
  assert.equal(routed.routed, true);
  assert.ok(Array.isArray(routed.review.adversarialNotes));
  assert.ok(routed.review.adversarialNotes.length >= 2);
  assert.ok(routed.review.adversarialNotes.some((note) => note.includes("who defined")));
});

test("routeForReview only calls the Devil's Advocate hook once coherence clears the threshold", () => {
  const map = createSemanticMap();
  const atoms = runAtoms("USER-CREATE");

  let calls = 0;
  const devilsAdvocate = () => {
    calls += 1;
    return { adversarialNotes: "checked" };
  };

  const belowThreshold = routeForReview(atoms, map, "alice", "DEFAULT", { devilsAdvocate });
  assert.equal(belowThreshold.routed, false);
  assert.equal(calls, 0);

  atoms.forEach((atom) => defineMeaning(map, "DEFAULT", "alice", atom.text, atom.position, "resolved"));
  const aboveThreshold = routeForReview(atoms, map, "alice", "DEFAULT", { devilsAdvocate });
  assert.equal(aboveThreshold.routed, true);
  assert.equal(calls, 1);
  assert.equal(coherenceScore(atoms, map, "alice", "DEFAULT"), 1);
});

test("createDevilsAdvocate shares memory across calls and names a repeat review", () => {
  const map = createSemanticMap();
  const atoms = runAtoms("USER-CREATE");
  atoms.forEach((atom) => defineMeaning(map, "DEFAULT", "alice", atom.text, atom.position, "resolved"));

  const devilsAdvocate = createDevilsAdvocate();
  const first = routeForReview(atoms, map, "alice", "DEFAULT", { devilsAdvocate, patternKey: "USER-CREATE" });
  assert.ok(!first.review.adversarialNotes.some((note) => note.includes("keep coming back")));

  const second = routeForReview(atoms, map, "alice", "DEFAULT", { devilsAdvocate, patternKey: "USER-CREATE" });
  assert.ok(second.review.adversarialNotes.some((note) => note.includes("keep coming back")));
  assert.ok(second.review.adversarialNotes.some((note) => note.includes("2 times")));

  // A fresh reviewer instance has no memory -- same pattern, no escalation.
  const freshDevilsAdvocate = createDevilsAdvocate();
  const third = routeForReview(atoms, map, "alice", "DEFAULT", { devilsAdvocate: freshDevilsAdvocate, patternKey: "USER-CREATE" });
  assert.ok(!third.review.adversarialNotes.some((note) => note.includes("keep coming back")));
});

test("environment inheritance resolves through FILE-ts before DEFAULT", () => {
  const map = createSemanticMap();
  defineMeaning(map, "FILE-ts", "alice", "FIX", 0, { action: "memoize component" });

  const resolved = resolveMeaning(map, "RUNTIME-NODE|FILE-ts", "alice", "FIX", 0);
  assert.equal(resolved.defined, true);
  assert.equal(resolved.sourceEnvironment, "FILE-ts");
  assert.deepEqual(resolved.value, { action: "memoize component" });
});

test("collapseEnvironmentAction returns a first-class action object", () => {
  const map = createSemanticMap();
  // A trailing "!URGENT" block gives this pattern an actual polarity
  // transition -- "-" alone carries no polarity signal by itself (see the
  // classifyPattern test above). Dense-block positions are now a 0-based
  // sibling index (0,1,2,3,4), not a stream-index with gaps for "-".
  const atoms = runAtoms("A-FIX-R-LAYOUT-!URGENT");
  defineMeaning(map, "FILE-css", "demo", "A", 0, { action: "display:flex" });
  defineMeaning(map, "FILE-css", "demo", "FIX", 1, { intent: "repair" });
  defineMeaning(map, "FILE-css", "demo", "R", 2, { role: "layout" });
  defineMeaning(map, "FILE-css", "demo", "LAYOUT", 3, { scope: "css" });

  const collapsed = collapseEnvironmentAction(atoms, map, "demo", "FILE-css");
  assert.equal(collapsed.environment, "FILE-css");
  assert.equal(collapsed.classification, "action");
  assert.equal(collapsed.action.operation.action, "display:flex");
});
