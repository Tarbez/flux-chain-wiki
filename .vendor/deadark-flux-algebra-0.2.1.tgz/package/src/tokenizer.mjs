/**
 * Convenience wrapper: the flat, left-to-right list of top-level raw block
 * strings in a pattern (isolation-fenced groups excluded, same as
 * flattenAtoms) -- e.g. tokenize("I302G-AS3TGBLRPG-JKDNRLNW") returns
 * ["I302G", "AS3TGBLRPG", "JKDNRLNW"]. Callers that need the full tree
 * (fences included) should call parseText directly.
 */

import { parseText, flattenAtoms } from "./parser.mjs";

/**
 * @param {string} text
 * @returns {string[]}
 */
export function tokenize(text) {
  return flattenAtoms(parseText(text)).map((atom) => atom.text);
}
