/**
 * Specialist resolvers: the parser is dumb, resolvers decide what a raw
 * block means. Mirrors flux_engine/resolvers.py on the Python side exactly
 * -- same rule, same rationale, applied to this engine's Atom nodes instead
 * of Python's AtomNode.
 *
 * A block's text can never itself start with (or contain) "-": the parser
 * always consumes it as a separator (or, inside a claim-style table, "-"
 * isn't a registered operator at all and stays part of the surrounding
 * text). So the negative-prefix check below only needs "!"/"~".
 */

const NEGATIVE_PREFIXES = ["!", "~"];
const NULL_TOKENS = new Set(["0", "\\0", "\0", "∅"]);

/**
 * @param {string} raw
 * @returns {{ polarity: "positive" | "negative" | "null", stripped: string }}
 */
export function resolvePolarity(raw) {
  if (NULL_TOKENS.has(raw)) {
    return { polarity: "null", stripped: raw };
  }
  for (const prefix of NEGATIVE_PREFIXES) {
    if (raw.startsWith(prefix) && raw.length > prefix.length) {
      return { polarity: "negative", stripped: raw.slice(prefix.length) };
    }
  }
  return { polarity: "positive", stripped: raw };
}

/**
 * Dense block-encoding resolvers (spec added 2026-08-05, after the Directive
 * 1 parser correction above). The parser is still dumb -- it only knows "-"
 * and "."; everything below decides what a raw block's *text* means once
 * the parser has already handed it over untouched.
 *
 * A dense block is `<ROLE_LETTER><PACKED>` with no dashes inside PACKED
 * (dashes always belong to the parser, never to a resolver's input) --
 * e.g. "I302E2A1" is role `I` with packed text "302E2A1". The wordy style
 * from before this spec (`IALICE-KBOB-ASEND-MHELLO-XENCRYPTED`) is REJECTED
 * here, not silently accepted: a role's packed text has to lead with the
 * digits/verb that role expects, and a role letter with no dedicated
 * resolver throws instead of being ignored.
 *
 * Only the sub-parameter codes actually evidenced in the spec are known:
 *   I (Primary):        leading digits -> Identity; E -> Environment; A -> Agency
 *   B (Complementary):  leading digits -> Budget;   P -> Priority;    S -> Consistency
 *   A (Action):         a known verb (SEND, NOTIFY, ...) then optional flag
 *                        letters (X -> Encrypted)
 *   T (Target):         "<number><unit letters>" -> { Value, Unit }, else the
 *                        whole packed text is an opaque Target string
 *   R (Referential):    the whole packed text is an opaque Ref string
 * Everything else (extra sub-field letters beyond E/A/P/S, extra action
 * verbs/flags, extra roles beyond I/B/A/T/R) is intentionally unhandled --
 * adding codes nobody asked for would be inventing a DSL the spec never
 * described. `DenseEncodingError` is thrown instead of guessing.
 */
export class DenseEncodingError extends Error {}

/**
 * Shared "<digits><LETTER><digits><LETTER><digits>..." unpacker used by both
 * PrimaryResolver and ComplementaryResolver: a leading run of digits is the
 * role's implicit first field (Identity / Budget), and every subsequent
 * `<LETTER><digits>` pair is looked up in `codeMap`. A letter with no known
 * mapping is kept verbatim as its own field (so real data is never silently
 * dropped) and a letter with no digits following it (e.g. a trailing flag
 * like the "G" in "I302G") is recorded as `true`, mirroring how ActionResolver
 * treats trailing flag letters -- this is an inference beyond the spec's
 * given examples (which never leave a bare trailing letter), documented here
 * rather than guessed silently elsewhere.
 *
 * @param {string} packed - block text with the role letter already stripped
 * @param {string} leadingField - field name for the leading digit run
 * @param {Record<string,string>} codeMap - sub-field letter -> field name
 * @param {string} roleLabel - for error messages only
 */
function unpackCodedFields(packed, leadingField, codeMap, roleLabel) {
  const leadingMatch = /^(\d+)/.exec(packed);
  if (!leadingMatch) {
    throw new DenseEncodingError(
      `${roleLabel}: expected a leading number for ${leadingField} in "${packed}" -- looks like wordy/non-dense text, not a packed block`,
    );
  }
  const result = { [leadingField]: Number(leadingMatch[1]) };
  let rest = packed.slice(leadingMatch[0].length);

  while (rest.length) {
    const pairMatch = /^([A-Z])(\d+)/.exec(rest);
    if (pairMatch) {
      const [, letter, digits] = pairMatch;
      result[codeMap[letter] || letter] = Number(digits);
      rest = rest.slice(pairMatch[0].length);
      continue;
    }
    const flagMatch = /^([A-Z])/.exec(rest);
    if (flagMatch) {
      const [, letter] = flagMatch;
      result[codeMap[letter] || letter] = true;
      rest = rest.slice(flagMatch[0].length);
      continue;
    }
    throw new DenseEncodingError(`${roleLabel}: unparseable remainder "${rest}" in "${packed}"`);
  }
  return result;
}

const PRIMARY_CODES = { E: "Environment", A: "Agency" };
const COMPLEMENTARY_CODES = { P: "Priority", S: "Consistency" };

/**
 * Role letter `I`. Input is the full block including the leading "I".
 * @example PrimaryResolver("I302E2A1") -> { Identity: 302, Environment: 2, Agency: 1 }
 */
export function PrimaryResolver(block) {
  return unpackCodedFields(stripRole(block, "I"), "Identity", PRIMARY_CODES, "PrimaryResolver");
}

/**
 * Role letter `B`. Input is the full block including the leading "B".
 * @example ComplementaryResolver("B10P5S1") -> { Budget: 10, Priority: 5, Consistency: 1 }
 */
export function ComplementaryResolver(block) {
  return unpackCodedFields(stripRole(block, "B"), "Budget", COMPLEMENTARY_CODES, "ComplementaryResolver");
}

// Registered action verbs, sorted longest-first so a longer verb is never
// shadowed by a shorter one that happens to be a prefix of it.
//
// The first two are the spec's own examples. The social and registry verbs
// were added 2026-08-14: `A` is the only role that can say *what is being
// done*, and it knew two verbs, so every social interaction and every registry
// operation in the taxonomy was inexpressible.
//
// No verb below is a prefix of another (checked when adding), so the
// longest-first ordering is belt-and-braces rather than load-bearing today.
// If a future verb ever is a prefix of an existing one (SEND / SENDER), this
// ordering plus ActionResolver's all-trailing-letters-must-be-known-flags rule
// is what keeps the misparse from happening.
const KNOWN_ACTION_VERBS = [
  // Messaging -- from the original spec.
  "SEND", "NOTIFY",
  // Social graph.
  "FOLLOW", "ENDORSE", "SUPPORT", "CITE", "COLLABORATE", "DELEGATE",
  // Registry operations.
  "REGISTER", "UPDATE", "QUERY", "DELETE",
  // Chain -- chain-manifest-v1.md §3.1/§5, added 2026-08-19: A=MINT marks a
  // storage-contribution reward TRANSACTION, self-authorizing by reference
  // to a finalized PROOF manifest rather than by sender balance.
  "MINT",
  // AMM compatibility profile. Registered in flux-spec alongside the AMM
  // manifest types; kept here so the registry remains the checked interface.
  "BUY", "SELL", "LIQUIDITYADD", "LIQUIDITYREMOVE", "SETTLE",
].sort((a, b) => b.length - a.length);
const ACTION_FLAG_CODES = { X: "Encrypted" };

/**
 * Role letter `A`. Input is the full block including the leading "A".
 * Matches a known verb, then decodes any trailing letters as flags -- but
 * only if *every* trailing letter is a known flag code, so an unrecognized
 * verb that merely happens to start with a known one (e.g. some future
 * "SENDER") doesn't get misread as SEND + garbage flags.
 * @example ActionResolver("ASENDX") -> { Action: 'SEND', Encrypted: true }
 * @example ActionResolver("ANOTIFY") -> { Action: 'NOTIFY' }
 */
export function ActionResolver(block) {
  const packed = stripRole(block, "A");
  const verb = KNOWN_ACTION_VERBS.find((candidate) => {
    if (!packed.startsWith(candidate)) return false;
    const remainder = packed.slice(candidate.length);
    return [...remainder].every((letter) => letter in ACTION_FLAG_CODES);
  });
  if (!verb) {
    throw new DenseEncodingError(`ActionResolver: no known action verb matches "${packed}"`);
  }
  const result = { Action: verb };
  for (const letter of packed.slice(verb.length)) {
    result[ACTION_FLAG_CODES[letter]] = true;
  }
  return result;
}

const NUMERIC_UNIT_PATTERN = /^(\d+)([A-Z]+)$/;
const OPAQUE_TARGET_PATTERN = /^[A-Za-z0-9]+$/;

/**
 * Role letter `T`. Input is the full block including the leading "T". A
 * "<number><unit letters>" packed text is a measurement; anything else,
 * provided it's dash-free alphanumeric, is an opaque target string.
 *
 * Closed 2026-08-19 (chain-manifest-v1.md §3.1 / dense-encoding-v3.md's
 * "Not yet defined"): `T` amounts are whole numbers only, permanently -- a
 * literal `.` conflicts with Rule 1 ("`-` is the only punctuation a
 * manifest may contain"). This mirrors flux-core::roles::target's own
 * 2026-08-19 tightening, which rejects `.` in both the numeric-unit branch
 * and the opaque fallback (the fallback previously accepted *any*
 * dash-free text, which is how `.` was silently swallowed even outside the
 * numeric branch).
 * @example TargetResolver("TMSGHELLO") -> { Target: 'MSGHELLO' }
 * @example TargetResolver("T75C") -> { Value: 75, Unit: 'C' }
 */
export function TargetResolver(block) {
  const packed = stripRole(block, "T");
  const numeric = NUMERIC_UNIT_PATTERN.exec(packed);
  if (numeric) {
    return { Value: Number(numeric[1]), Unit: numeric[2] };
  }
  if (!OPAQUE_TARGET_PATTERN.test(packed)) {
    throw new DenseEncodingError(`Target: "${packed}" is not a whole-number measurement or a dash-free alphanumeric opaque string`);
  }
  return { Target: packed };
}

/**
 * Role letter `R`. Input is the full block including the leading "R". The
 * spec gives no internal structure for referential blocks -- the packed
 * text is an opaque reference id.
 * @example ReferentialResolver("RABC123") -> { Ref: 'ABC123' }
 */
export function ReferentialResolver(block) {
  return { Ref: stripRole(block, "R") };
}

function stripRole(block, letter) {
  // `letter` is a registered token, any length >= 1 since dense-encoding-v4.md
  // 0.4.3 (role recognition is registry lookup, not a single-character
  // assumption) -- `startsWith`/`slice(letter.length)` generalize the old
  // `block[0] !== letter`/`slice(1)` single-char check with identical
  // behavior for every pre-0.4.3 single-letter role.
  if (typeof block !== "string" || !block.startsWith(letter)) {
    throw new DenseEncodingError(`expected block starting with role token '${letter}', got "${block}"`);
  }
  return block.slice(letter.length);
}

// ---------------------------------------------------------------------------
// Manifest core roles (added 2026-08-14)
//
// The five roles above (I/B/A/T/R) describe a *pattern*. These six describe a
// *manifest*: who signed it, what it is, where its content lives, and when.
// They exist because dense encoding could not previously express any of that --
// an Ed25519 key fails `I` (which requires leading decimal digits), and
// SIG/CID/TYPE had no role letter at all and threw.
//
// Letters were chosen to avoid the existing five. That matters more than
// mnemonics: a role letter is a single character, so an unregistered letter
// that happens to start with I/B/A/T/R is silently swallowed rather than
// rejected -- "TYPEGHOST" resolves as Target "YPEGHOST", a wrong-but-successful
// parse. `Y` carries type precisely so nobody writes "TYPE..." and hits that.
//
// Opaque roles (G/S/C) do not decode their payload. Whether key material is hex
// or base58 is the caller's business; both are dash-free, which is the only
// property this layer needs. Base64 is unusable in either -- its "+/=" and
// base64url's "-" both collide with the grammar.
// ---------------------------------------------------------------------------

const ALPHANUMERIC = /^[A-Za-z0-9]+$/;
const UPPERCASE_ALPHA = /^[A-Z][A-Z0-9]*$/;
const DIGITS = /^\d+$/;

// Minimum payload lengths, in characters. These are not cosmetic: without a
// floor, ANY English word starting with G/S/C parses as valid key material --
// "SECURITY" would resolve to { Signature: "ECURITY" } instead of being
// rejected. The floors sit well below the shortest real encoding of each value
// (an Ed25519 public key is 32 bytes: 64 hex or ~44 base58; a signature is 64
// bytes: 128 hex or ~88 base58; a CIDv0 is 46 characters), so they reject
// prose without constraining any legitimate encoding.
const MIN_PAYLOAD = Object.freeze({ Ghost: 32, Signature: 64, Cid: 16 });

function opaqueRole(block, letter, field, label) {
  const packed = stripRole(block, letter);
  if (!ALPHANUMERIC.test(packed)) {
    throw new DenseEncodingError(`${label}: expected dash-free alphanumeric payload in "${block}"`);
  }
  const minimum = MIN_PAYLOAD[field];
  if (packed.length < minimum) {
    throw new DenseEncodingError(`${label}: payload "${packed}" is ${packed.length} chars, below the ${minimum}-char minimum for ${field}`);
  }
  return { [field]: packed };
}

function numericRole(block, letter, field, label) {
  const packed = stripRole(block, letter);
  if (!DIGITS.test(packed)) {
    throw new DenseEncodingError(`${label}: expected digits in "${block}"`);
  }
  return { [field]: Number(packed) };
}

/**
 * Role letter `G`. Ghost identity key -- hex or base58 Ed25519 key material.
 * Exists because `I` requires leading decimal digits and so cannot carry a real
 * key; `I` keeps its numeric Identity/Environment/Agency meaning unchanged.
 * @example GhostResolver("Gab12cd34") -> { Ghost: 'ab12cd34' }
 */
export function GhostResolver(block) {
  return opaqueRole(block, "G", "Ghost", "GhostResolver");
}

// ---------------------------------------------------------------------------
// Manifest type codes (dense-encoding-v4.md's "v4.1", specVersion 0.4.1,
// 2026-08-19). `Y` loses its permanent word exemption: every type registered
// in flux-spec/registry/manifest-types.json now also carries a resolver-
// assigned `code` (base-36, 0-9A-Z, starting at 1 character), and the code is
// what gets signed on the wire going forward. A resolver expands the code
// back to the plain word only for the storage form -- never on the wire.
//
// Hand-copied from the registry rather than read at runtime, same convention
// KNOWN_ACTION_VERBS above already follows: this package is pure JS with no
// I/O (see package.json's own description), so the registry's `type`/`code`
// pairs are mirrored here as a literal table instead of loaded from disk.
// Keep in sync with manifest-types.json's `types` array by hand when either
// changes.
//
// This mirrors flux-core's Rust implementation (commit 3aa4005) exactly:
// decode accepts either the legacy word or the new code and normalizes to
// the canonical word; encode translates word -> code for callers that still
// pass the readable word to a builder API. `openSet: true` means the table
// is deliberately incomplete forever -- a self-registered type with no code
// yet is not an error, it is the intended fallback.
const MANIFEST_TYPE_CODES = Object.freeze({
  GHOST: "0",
  SOCIAL: "1",
  VAULT: "2",
  TRANSACTION: "3",
  SEARCH: "4",
  RESOLVER: "5",
  GRANT: "6",
  ACL: "7",
  CLAIM: "8",
  DEVICE: "9",
  WALLET: "A",
  SESSION: "B",
  REVOKE: "C",
  SETTINGS: "D",
  COMMUNITY: "E",
  RESOLUTION: "F",
  PROFILE: "G",
  POST: "H",
  THREAD: "I",
  COMMENT: "J",
  MESSAGE: "K",
  NOTIFICATION: "L",
  WEBHOOK: "M",
  ASSET: "N",
  PIN: "O",
  RELEASE: "P",
  PEER: "Q",
  BLOCK: "R",
  VOTE: "S",
  PROOF: "T",
  LIQUIDITYLOCK: "U",
  LAUNCHBOND: "V",
  POOL: "W",
  POSITION: "X",
  SWAP: "Y",
  CLEARING: "Z",
  CLEARINGVOTE: "00",
  PERCEPTION: "01",
  PATTERN: "02",
  REPRESENTATION: "03",
  SPATIAL: "04",
  TOPOLOGICAL: "05",
  RELATIONAL: "06",
  SHARD: "07",
  REBALANCE: "08",
  PROPOSAL: "09",
  GOVVOTE: "0A",
  GOVVETO: "0B",
  AIO: "0C",
  AIP: "0D",
  AIPCLAIM: "0E",
  AIOCLAIM: "0F",
  INTENT: "0G",
  OFFER: "0H",
  AGREEMENT: "0I",
  FULFILLMENT: "0J",
  RECEIPT: "0K",
  VALUEOBJECT: "0L",
  CELLREQUEST: "0M",
  CELLCERT: "0N",
  CONSUMEDMARKER: "0O",
  CELLEQUIVOCATION: "0P",
  TRADEINTENT: "0Q",
  LIQUIDITYOFFER: "0R",
  SETTLEMENTPROPOSAL: "0S",
  ACCEPTANCE: "0T",
  SETTLEMENTRECEIPT: "0U",
  RESOLVERPACKAGE: "0V",
  RESOLUTIONCLAIM: "0W",
  CHECKERCLAIM: "0X",
  RESOLVERCONFLICT: "0Y",
  CONFLICT: "0Z",
  CONFLICTRESOLUTION: "10",
  REPLICATIONRECEIPT: "11",
});

const MANIFEST_CODE_TYPES = Object.freeze(
  Object.fromEntries(Object.entries(MANIFEST_TYPE_CODES).map(([word, code]) => [code, word])),
);

/**
 * Encodes a canonical manifest type word into its wire-form `Y` payload.
 * Registered types translate to their resolver-assigned code (`GHOST` ->
 * `"0"`); anything not in the table -- an open-set/self-registered type with
 * no code assigned yet, or a value that is already a code -- passes through
 * unchanged, which is the intended fallback for `manifest-types.json`'s
 * `openSet: true` catalog, not an error.
 * @param {string} word
 * @returns {string}
 * @example encodeManifestType("GHOST") -> "0"
 * @example encodeManifestType("NEWCOMER") -> "NEWCOMER" (unregistered, passes through)
 */
export function encodeManifestType(word) {
  return Object.prototype.hasOwnProperty.call(MANIFEST_TYPE_CODES, word) ? MANIFEST_TYPE_CODES[word] : word;
}

/**
 * Role letter `Y`. Manifest type (GHOST, SOCIAL, VAULT, ...). Accepts both
 * the legacy plain-uppercase word and, as of v4.1, the resolver-assigned
 * code -- decode always normalizes to the canonical word before any
 * downstream matching sees it, exactly like flux-core's Rust decoder
 * (commit 3aa4005). A recognized code expands to its word; an
 * already-canonical word (legacy wire form, or an unregistered/open-set
 * type migrate-on-touch hasn't reached yet) passes through unchanged.
 * @example TypeResolver("YGHOST") -> { Type: 'GHOST' }
 * @example TypeResolver("Y0") -> { Type: 'GHOST' }
 */
export function TypeResolver(block) {
  const packed = stripRole(block, "Y");
  if (Object.prototype.hasOwnProperty.call(MANIFEST_CODE_TYPES, packed)) {
    return { Type: MANIFEST_CODE_TYPES[packed] };
  }
  if (!UPPERCASE_ALPHA.test(packed)) {
    throw new DenseEncodingError(`TypeResolver: manifest type must be uppercase, got "${packed}"`);
  }
  return { Type: packed };
}

/**
 * Role letter `S`. Signature over the manifest's preceding blocks.
 * @example SignatureResolver("Sfe90ab") -> { Signature: 'fe90ab' }
 */
export function SignatureResolver(block) {
  return opaqueRole(block, "S", "Signature", "SignatureResolver");
}

/**
 * Role letter `C`. Content address (CID) of the manifest's payload.
 * @example ContentResolver("Cbafy123") -> { Cid: 'bafy123' }
 */
export function ContentResolver(block) {
  return opaqueRole(block, "C", "Cid", "ContentResolver");
}

/**
 * Role letter `M`. Moment -- a Unix timestamp in seconds.
 * @example MomentResolver("M1760000000") -> { Moment: 1760000000 }
 */
export function MomentResolver(block) {
  return numericRole(block, "M", "Moment", "MomentResolver");
}

/**
 * Role letter `V`. Manifest version, a monotonically increasing integer.
 * @example VersionResolver("V3") -> { Version: 3 }
 */
export function VersionResolver(block) {
  return numericRole(block, "V", "Version", "VersionResolver");
}

// ---------------------------------------------------------------------------
// Authorization roles (added 2026-08-14)
//
// `G` says who signed a manifest. These three say who it is *for*, what they
// may do, and until when -- the fields flux-auth had to drop from its dense
// rendering because there was no way to express them.
//
// The obvious letters are unavailable: `K` (from the old `KCLIENT`) and `X`
// (from the old `XREAD`) are reserved-as-invalid, because the spec tests
// assert `KBOB` and `XENCRYPTED` must throw. Registering either would make the
// superseded wordy grammar parse again. `H`, `P`, and `D` are drawn from the
// free list instead.
//
// Every one of them rejects prose *structurally* rather than by length floor:
//
//   H requires lowercase hex  -> "HOLDER" fails ("OLDER" is not hex)
//   P requires a leading 0/1  -> "PRIMARY" fails (no effect digit)
//   D requires digits         -> "DELETE" fails
//
// That matters more here than it did for G/S/C. Those carry key material,
// where a length floor is enough. These carry short human-authored names, so a
// floor would not have saved them -- `P` in particular would have swallowed
// any capitalized word beginning with P and resolved it *successfully*, which
// the grammar doc calls out as strictly worse than an error.
// ---------------------------------------------------------------------------

const LOWERCASE_HEX = /^[0-9a-f]+$/;

/**
 * Role letter `H`. Holder -- the party a manifest is issued *to*, as opposed
 * to `G`, the ghost identity that signed it. In an auth grant this is the
 * client id; in an ACL manifest it is the subject the permissions apply to.
 *
 * The payload is lowercase hex of the holder's UTF-8 identifier (flux-auth's
 * `hexOfUtf8`), not the identifier itself. Re-encoding, not escaping: a client
 * id like `my-app.example` contains characters that are either structural
 * (`-`) or outright illegal (`.`) in a dense pattern, and there is no escape
 * character to fall back on.
 *
 * Requiring hex rather than any alphanumeric is what makes prose fail loudly:
 * an alphanumeric rule would have resolved `HELLOWORLD` to a holder of
 * `ELLOWORLD` instead of throwing.
 *
 * @example HolderResolver("H6d792d617070") -> { Holder: '6d792d617070' }
 */
export function HolderResolver(block) {
  const packed = stripRole(block, "H");
  if (!LOWERCASE_HEX.test(packed)) {
    throw new DenseEncodingError(`HolderResolver: expected lowercase hex in "${block}" -- holder ids are hex of their UTF-8 bytes, not raw text`);
  }
  if (packed.length % 2 !== 0) {
    throw new DenseEncodingError(`HolderResolver: hex payload "${packed}" has odd length, so it does not decode to whole bytes`);
  }
  if (packed.length < 2) {
    throw new DenseEncodingError(`HolderResolver: empty holder id in "${block}"`);
  }
  return { Holder: packed };
}

const PERMISSION_PATTERN = /^([01])((?:[0-9a-f]{2})+)$/;

/**
 * Role letter `P`. A single permission and whether it is granted or denied:
 * `1` grants, `0` denies. Repeatable -- a manifest carries one `P` block per
 * permission, and dense encoding has no nesting to express a list any other
 * way.
 *
 * The name is lowercase hex of its UTF-8 bytes, exactly like `H`. An earlier
 * draft of this role took an uppercase name directly (`P1READ`), which read
 * better but could not carry the permission vocabulary that actually exists:
 * ark-api's scopes are `workspace:read` and `assets:encrypted:read`, and `:`
 * is not a legal dense character. Re-encode, never escape -- the same rule the
 * rest of this grammar follows.
 *
 * The effect digit is not decoration. It is the same guard `I` and `B` use: a
 * mandatory leading digit is what stops an ordinary capitalized word from
 * parsing. Without it, `PRIMARY` would resolve to `{ Permission: 'RIMARY' }`
 * -- a wrong-but-successful parse, the exact failure mode this grammar's
 * collision-hazard section exists to prevent. Folding deny into `P` this way
 * also avoids spending a second role letter on `N`, which would have had that
 * same prose problem in a worse form (`NOTIFY` is a real token elsewhere in
 * this table).
 *
 * Unlike `H`, the payload is decoded rather than passed through: a holder id
 * is matched, but a permission name is *read*, and every consumer would
 * otherwise repeat the same decode. The round-trip check rejects hex that is
 * not valid UTF-8, which would otherwise surface as replacement characters
 * inside an authorization decision.
 *
 * The value is an object rather than two flat fields, so a consumer collecting
 * repeated blocks gets `[{name, granted}, ...]` instead of two parallel arrays
 * it has to trust are positionally aligned.
 *
 * @example PermissionResolver("P1776f726b73706163653a72656164")
 *          -> { Permission: { name: 'workspace:read', granted: true } }
 */
export function PermissionResolver(block) {
  const packed = stripRole(block, "P");
  const match = PERMISSION_PATTERN.exec(packed);
  if (!match) {
    throw new DenseEncodingError(`PermissionResolver: expected an effect digit (1 grant / 0 deny) followed by lowercase hex of the permission name, got "${packed}"`);
  }
  // TextDecoder rather than Buffer: this package is a portable engine and must
  // keep running outside Node. `fatal` is what rejects hex that is not valid
  // UTF-8, which would otherwise reach an authorization decision as
  // replacement characters.
  const hex = match[2];
  const bytes = new Uint8Array(hex.length / 2);
  for (let index = 0; index < bytes.length; index += 1) {
    bytes[index] = Number.parseInt(hex.slice(index * 2, index * 2 + 2), 16);
  }
  let name;
  try {
    name = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
  } catch {
    throw new DenseEncodingError(`PermissionResolver: payload "${hex}" is not valid UTF-8`);
  }
  return { Permission: Object.freeze({ name, granted: match[1] === "1" }) };
}

/**
 * Role letter `D`. Deadline -- the Unix timestamp in seconds after which a
 * manifest is no longer valid. Deliberately the same shape as `M` (Moment):
 * `M` is when a manifest was made, `D` is when it stops counting.
 *
 * This role only carries the claim. Comparing it to a clock is the consumer's
 * job -- flux-algebra has no notion of "now" and should not acquire one.
 *
 * @example DeadlineResolver("D1760003600") -> { Deadline: 1760003600 }
 */
export function DeadlineResolver(block) {
  return numericRole(block, "D", "Deadline", "DeadlineResolver");
}

/** Role letter -> resolver, for dispatching a block by its first character. */
export const ROLE_RESOLVERS = Object.freeze({
  I: PrimaryResolver,
  B: ComplementaryResolver,
  A: ActionResolver,
  T: TargetResolver,
  R: ReferentialResolver,
  G: GhostResolver,
  Y: TypeResolver,
  S: SignatureResolver,
  C: ContentResolver,
  M: MomentResolver,
  V: VersionResolver,
  H: HolderResolver,
  P: PermissionResolver,
  D: DeadlineResolver,
});

/**
 * Dispatches a single dense block (role letter + packed text) to its
 * resolver by first character. A role letter with no registered resolver
 * (anything outside the pattern roles I/B/A/T/R, the manifest core
 * G/Y/S/C/M/V, and the authorization roles H/P/D) throws
 * rather than being ignored -- per the spec, an unhandled role is unsupported
 * dense encoding, not a silent no-op.
 *
 * @param {string} block - e.g. "I302E2A1"
 */
// Registry-generated token list, longest first -- dense-encoding-v4.md 0.4.3:
// a block's role is whichever registered token is the LONGEST match at its
// start, found by registry lookup, never by character-class/position rules.
// `ROLE_RESOLVERS` here only ever holds single-character core-profile keys
// (flux-algebra implements exactly the `core` profile, by its own declared
// scope -- `dense-wire`/`claim` profile tokens like NAME/TITLE live in their
// own implementations), so this degenerates to the pre-0.4.3 single-letter
// lookup with IDENTICAL behavior for every existing role; it is written
// generically so it is correct if this set ever gains a longer token too.
const ROLE_TOKENS_LONGEST_FIRST = Object.keys(ROLE_RESOLVERS).sort((a, b) => b.length - a.length);

export function resolveDenseBlock(block) {
  if (typeof block !== "string" || !block.length) {
    throw new DenseEncodingError(`resolveDenseBlock: empty block`);
  }
  const token = ROLE_TOKENS_LONGEST_FIRST.find((candidate) => block.startsWith(candidate));
  const resolver = token !== undefined ? ROLE_RESOLVERS[token] : undefined;
  if (!resolver) {
    throw new DenseEncodingError(`resolveDenseBlock: no resolver registered for role token starting "${block}"`);
  }
  return resolver(block);
}
