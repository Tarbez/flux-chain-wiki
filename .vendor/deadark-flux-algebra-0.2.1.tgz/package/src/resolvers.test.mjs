import test from "node:test";
import assert from "node:assert/strict";

import { tokenize } from "./tokenizer.mjs";
import {
  resolvePolarity,
  DenseEncodingError,
  PrimaryResolver,
  ComplementaryResolver,
  ActionResolver,
  TargetResolver,
  ReferentialResolver,
  resolveDenseBlock,
  encodeManifestType,
} from "./resolvers.mjs";

// Dense block-encoding spec (added 2026-08-05). Covers each of the five
// per-role resolver examples verbatim, then the "valid" and "invalid" full
// pattern examples from the spec.

test("resolvePolarity keeps working unchanged (existing callers depend on it)", () => {
  assert.deepEqual(resolvePolarity("FOO"), { polarity: "positive", stripped: "FOO" });
  assert.deepEqual(resolvePolarity("!FOO"), { polarity: "negative", stripped: "FOO" });
  assert.deepEqual(resolvePolarity("0"), { polarity: "null", stripped: "0" });
});

test("PrimaryResolver decodes I302E2A1", () => {
  assert.deepEqual(PrimaryResolver("I302E2A1"), { Identity: 302, Environment: 2, Agency: 1 });
});

test("ComplementaryResolver decodes B10P5S1", () => {
  assert.deepEqual(ComplementaryResolver("B10P5S1"), { Budget: 10, Priority: 5, Consistency: 1 });
});

test("ActionResolver decodes ASENDX (verb + Encrypted flag)", () => {
  assert.deepEqual(ActionResolver("ASENDX"), { Action: "SEND", Encrypted: true });
});

test("ActionResolver decodes ANOTIFY (verb, no flags)", () => {
  assert.deepEqual(ActionResolver("ANOTIFY"), { Action: "NOTIFY" });
});

test("TargetResolver decodes TMSGHELLO as an opaque target string", () => {
  assert.deepEqual(TargetResolver("TMSGHELLO"), { Target: "MSGHELLO" });
});

test("TargetResolver decodes T75C as a numeric value + unit", () => {
  assert.deepEqual(TargetResolver("T75C"), { Value: 75, Unit: "C" });
});

test("TargetResolver rejects T75.5C -- decimals conflict with Rule 1, closed 2026-08-19", () => {
  assert.throws(() => TargetResolver("T75.5C"), DenseEncodingError);
});

test("TargetResolver rejects T0.5KG for the same reason", () => {
  assert.throws(() => TargetResolver("T0.5KG"), DenseEncodingError);
});

test("ReferentialResolver decodes RABC123 as an opaque ref", () => {
  assert.deepEqual(ReferentialResolver("RABC123"), { Ref: "ABC123" });
});

test("valid dense pattern: I302E2A1-B10P5S1-ASENDX-TMSGHELLO resolves block by block", () => {
  const blocks = tokenize("I302E2A1-B10P5S1-ASENDX-TMSGHELLO");
  assert.deepEqual(blocks, ["I302E2A1", "B10P5S1", "ASENDX", "TMSGHELLO"]);
  assert.deepEqual(blocks.map(resolveDenseBlock), [
    { Identity: 302, Environment: 2, Agency: 1 },
    { Budget: 10, Priority: 5, Consistency: 1 },
    { Action: "SEND", Encrypted: true },
    { Target: "MSGHELLO" },
  ]);
});

test("valid dense pattern: B10P5S1-I302E2A1-ANOTIFY-TALERT-RREF001 resolves block by block, order-free", () => {
  const blocks = tokenize("B10P5S1-I302E2A1-ANOTIFY-TALERT-RREF001");
  assert.deepEqual(blocks.map(resolveDenseBlock), [
    { Budget: 10, Priority: 5, Consistency: 1 },
    { Identity: 302, Environment: 2, Agency: 1 },
    { Action: "NOTIFY" },
    { Target: "ALERT" },
    { Ref: "REF001" },
  ]);
});

test("dense pattern I302G-AS3TGBLRPG-JKDNRLNW still tokenizes into raw blocks (parser stays dumb)", () => {
  // From the spec's "valid" list. No resolved output is given in the spec
  // for this one (its second/third blocks use role letters -- S, J -- with
  // no dedicated resolver), so this only asserts what's actually specified:
  // the dumb parser still splits it into dense (non-wordy) top-level blocks.
  assert.deepEqual(tokenize("I302G-AS3TGBLRPG-JKDNRLNW"), ["I302G", "AS3TGBLRPG", "JKDNRLNW"]);
});

test("PrimaryResolver tolerates a bare trailing flag letter (I302G) without a spec-given output", () => {
  // Not given an expected shape by the spec; documented inference (see
  // unpackCodedFields's comment in resolvers.mjs): a bare trailing letter
  // with no digits is recorded as a boolean flag under its own letter.
  assert.deepEqual(PrimaryResolver("I302G"), { Identity: 302, G: true });
});

// A full pattern only counts as valid dense encoding if every one of its
// top-level blocks resolves; one bad block flags the whole pattern, same as
// the spec's "must NOT parse as valid anymore" framing.
function isValidDensePattern(text) {
  try {
    tokenize(text).forEach(resolveDenseBlock);
    return true;
  } catch (err) {
    if (err instanceof DenseEncodingError) return false;
    throw err;
  }
}

test("invalid/wordy patterns from the spec are rejected as a whole, not silently accepted", () => {
  assert.equal(isValidDensePattern("IALICE-KBOB-ASEND-MHELLO-XENCRYPTED"), false);
  assert.equal(isValidDensePattern("F-REGISTRY-R-SECURITY"), false);
  assert.equal(isValidDensePattern("ISYSTEM-ANOTIFY-MUSER-XALERT"), false);

  // Confirming *why*: at least one block in each pattern has no registered
  // resolver, or fails its own role's dense-format check.
  assert.throws(() => resolveDenseBlock("IALICE"), DenseEncodingError); // no leading digits for Identity
  assert.throws(() => resolveDenseBlock("KBOB"), DenseEncodingError); // K has no registered resolver
  assert.throws(() => resolveDenseBlock("MHELLO"), DenseEncodingError); // M is Moment; "HELLO" is not digits
  assert.throws(() => resolveDenseBlock("XENCRYPTED"), DenseEncodingError); // X has no registered resolver
  assert.throws(() => resolveDenseBlock("F"), DenseEncodingError); // F has no registered resolver
  assert.throws(() => resolveDenseBlock("SECURITY"), DenseEncodingError); // S is Signature; "ECURITY" is under the 64-char floor
  assert.throws(() => resolveDenseBlock("ISYSTEM"), DenseEncodingError); // no leading digits for Identity
  assert.throws(() => resolveDenseBlock("MUSER"), DenseEncodingError); // M is Moment; "USER" is not digits
  assert.throws(() => resolveDenseBlock("XALERT"), DenseEncodingError); // X has no registered resolver

  // Not every block in a bad pattern is itself invalid in isolation -- e.g.
  // "REGISTRY"/"R" both happen to start with the registered R role letter
  // and so resolve as (nonsensical) opaque Refs, and "ASEND"/"ANOTIFY" are
  // valid Action blocks on their own. What makes each full pattern invalid
  // is that at least one *other* block in it has no dense-format resolver.
  assert.doesNotThrow(() => resolveDenseBlock("ANOTIFY"));
});

test("resolveDenseBlock rejects an unregistered role letter and an empty block", () => {
  assert.throws(() => resolveDenseBlock("ZFOO"), DenseEncodingError);
  assert.throws(() => resolveDenseBlock(""), DenseEncodingError);
});

test("ActionResolver rejects an unknown verb instead of guessing", () => {
  assert.throws(() => ActionResolver("AFOOBAR"), DenseEncodingError);
});

// --- Manifest core roles (G/Y/S/C/M/V, added 2026-08-14) -------------------

test("manifest core roles decode a signed, typed, addressable manifest", () => {
  const ghost = "a".repeat(64);       // 32-byte key as hex
  const signature = "b".repeat(128);  // 64-byte signature as hex
  const cid = "bafybeigdyrzt5sfp7udm7hu76uh7y26nf3efuylqabf3oclgtqy55fbzdi";
  const pattern = `G${ghost}-YGHOST-V3-M1760000000-C${cid}-S${signature}`;

  const decoded = tokenize(pattern).map((block) => resolveDenseBlock(block));

  assert.deepEqual(decoded, [
    { Ghost: ghost },
    { Type: "GHOST" },
    { Version: 3 },
    { Moment: 1760000000 },
    { Cid: cid },
    { Signature: signature },
  ]);
});

test("G carries key material that I cannot, and leaves I's numeric meaning intact", () => {
  // The gap that motivated these roles: an Ed25519 key fails PrimaryResolver,
  // which requires a leading decimal run for Identity.
  assert.throws(() => resolveDenseBlock(`I${"ab12cd34".repeat(8)}`), DenseEncodingError);
  assert.deepEqual(resolveDenseBlock(`G${"ab12cd34".repeat(8)}`), { Ghost: "ab12cd34".repeat(8) });
  assert.deepEqual(resolveDenseBlock("I302E2A1"), { Identity: 302, Environment: 2, Agency: 1 });
});

test("opaque roles reject prose instead of accepting it as key material", () => {
  // Without a length floor every word starting with S/G/C silently becomes a
  // valid field -- "SECURITY" would resolve to { Signature: "ECURITY" }.
  assert.throws(() => resolveDenseBlock("SECURITY"), DenseEncodingError);
  assert.throws(() => resolveDenseBlock("GHOSTLY"), DenseEncodingError);
  assert.throws(() => resolveDenseBlock("CONTENT"), DenseEncodingError);
});

test("Y requires uppercase so a type is never confused with key material", () => {
  assert.deepEqual(resolveDenseBlock("YSOCIAL"), { Type: "SOCIAL" });
  assert.throws(() => resolveDenseBlock("Yghost"), DenseEncodingError);
  // The misparse this role exists to prevent: "TYPEGHOST" is swallowed by the
  // Target role and resolves successfully to the wrong thing.
  assert.deepEqual(resolveDenseBlock("TYPEGHOST"), { Target: "YPEGHOST" });
});

// --- v4.1 manifest type codes (dense-encoding-v4.md, specVersion 0.4.1,
// added 2026-08-19) ----------------------------------------------------

test("encodeManifestType translates a registered word to its wire code", () => {
  assert.equal(encodeManifestType("GHOST"), "0");
  assert.equal(encodeManifestType("TRANSACTION"), "3");
  assert.equal(encodeManifestType("ACL"), "7");
});

test("encodeManifestType passes an unregistered/open-set word through unchanged", () => {
  assert.equal(encodeManifestType("NEWCOMER"), "NEWCOMER");
});

test("TypeResolver decodes a coded Y payload to the canonical word", () => {
  assert.deepEqual(resolveDenseBlock("Y0"), { Type: "GHOST" });
  assert.deepEqual(resolveDenseBlock("Y3"), { Type: "TRANSACTION" });
  assert.deepEqual(resolveDenseBlock("Y7"), { Type: "ACL" });
  // Multi-character codes (base-36 tier 2, e.g. CLEARINGVOTE's "00").
  assert.deepEqual(resolveDenseBlock("Y00"), { Type: "CLEARINGVOTE" });
  assert.deepEqual(resolveDenseBlock("Y0G"), { Type: "INTENT" });
  assert.deepEqual(resolveDenseBlock("Y0K"), { Type: "RECEIPT" });
  assert.deepEqual(resolveDenseBlock("Y0L"), { Type: "VALUEOBJECT" });
  assert.deepEqual(resolveDenseBlock("Y0M"), { Type: "CELLREQUEST" });
  assert.deepEqual(resolveDenseBlock("Y0P"), { Type: "CELLEQUIVOCATION" });
  assert.deepEqual(resolveDenseBlock("Y0Q"), { Type: "TRADEINTENT" });
  assert.deepEqual(resolveDenseBlock("Y0U"), { Type: "SETTLEMENTRECEIPT" });
  assert.deepEqual(resolveDenseBlock("Y0V"), { Type: "RESOLVERPACKAGE" });
  assert.deepEqual(resolveDenseBlock("Y0Y"), { Type: "RESOLVERCONFLICT" });
  assert.deepEqual(resolveDenseBlock("Y0Z"), { Type: "CONFLICT" });
  assert.deepEqual(resolveDenseBlock("Y10"), { Type: "CONFLICTRESOLUTION" });
});

test("TypeResolver still decodes the legacy plain-word wire form to the same canonical word", () => {
  assert.deepEqual(resolveDenseBlock("YGHOST"), { Type: "GHOST" });
  assert.deepEqual(resolveDenseBlock("YTRANSACTION"), { Type: "TRANSACTION" });
  assert.deepEqual(resolveDenseBlock("YACL"), { Type: "ACL" });
});

test("a legacy word and its coded equivalent decode to the identical Type value (GHOST/TRANSACTION/ACL)", () => {
  for (const [word, code] of [["GHOST", "0"], ["TRANSACTION", "3"], ["ACL", "7"]]) {
    assert.deepEqual(resolveDenseBlock(`Y${word}`), resolveDenseBlock(`Y${code}`));
  }
});

test("building with the word API (encodeManifestType) then decoding the wire block round-trips to the same word", () => {
  for (const word of ["GHOST", "TRANSACTION", "ACL"]) {
    const wireCode = encodeManifestType(word);
    const decoded = resolveDenseBlock(`Y${wireCode}`);
    assert.deepEqual(decoded, { Type: word });
  }
});

test("an unregistered/open-set type round-trips unchanged through encode and decode", () => {
  const openSetType = "NEWCOMER";
  const wirePayload = encodeManifestType(openSetType);
  assert.equal(wirePayload, openSetType);
  assert.deepEqual(resolveDenseBlock(`Y${wirePayload}`), { Type: openSetType });
});

test("numeric roles reject non-digit payloads", () => {
  assert.deepEqual(resolveDenseBlock("V12"), { Version: 12 });
  assert.deepEqual(resolveDenseBlock("M1760000000"), { Moment: 1760000000 });
  assert.throws(() => resolveDenseBlock("VNEXT"), DenseEncodingError);
  assert.throws(() => resolveDenseBlock("MUSER"), DenseEncodingError);
});

// --- Authorization roles (H/P/D, added 2026-08-14) -------------------------

const hex = (text) => Buffer.from(text, "utf8").toString("hex");

test("H/P/D express the grant fields dense encoding previously had to drop", () => {
  const holder = hex("my-app.example");
  const perms = [["1", "workspace:read"], ["1", "assets:encrypted:write"], ["0", "vault:write"]];
  const blocks = tokenize([`H${holder}`, ...perms.map(([e, n]) => `P${e}${hex(n)}`), "D1760003600"].join("-"));
  const decoded = blocks.map(resolveDenseBlock);

  assert.deepEqual(decoded[0], { Holder: holder });
  assert.deepEqual(decoded.slice(1, 4).map((block) => block.Permission), [
    { name: "workspace:read", granted: true },
    { name: "assets:encrypted:write", granted: true },
    { name: "vault:write", granted: false },
  ]);
  assert.deepEqual(decoded[4], { Deadline: 1760003600 });

  // The point of hex, for both roles: these real values carry "-", ".", and
  // ":" verbatim. The first is structural, the other two are illegal outright,
  // and there is no escape character to fall back on.
  assert.equal(Buffer.from(holder, "hex").toString("utf8"), "my-app.example");
});

test("P carries ark-api's actual scope vocabulary, colons and all", () => {
  // The reason P does not take an uppercase name directly: every scope this
  // grammar has to express contains a character a dense pattern cannot hold.
  for (const scope of ["workspace:read", "assets:encrypted:read", "analytics:write"]) {
    assert.deepEqual(resolveDenseBlock(`P1${hex(scope)}`), {
      Permission: { name: scope, granted: true },
    });
  }
});

test("P rejects hex that is not valid UTF-8 rather than emitting replacement chars", () => {
  assert.throws(() => resolveDenseBlock("P1ff"), DenseEncodingError);
  assert.throws(() => resolveDenseBlock("P1abc"), DenseEncodingError); // odd length
});

test("the new roles reject prose structurally, not by length floor", () => {
  // Each of these would have been a wrong-but-successful parse under a
  // permissive rule, which the grammar treats as worse than an error.
  assert.throws(() => resolveDenseBlock("HOLDER"), DenseEncodingError);      // not hex
  assert.throws(() => resolveDenseBlock("HELLOWORLD"), DenseEncodingError);  // not hex
  assert.throws(() => resolveDenseBlock("PRIMARY"), DenseEncodingError);     // no effect digit
  assert.throws(() => resolveDenseBlock("PERMISSION"), DenseEncodingError);  // no effect digit
  assert.throws(() => resolveDenseBlock("DELETE"), DenseEncodingError);      // not digits

  // A length floor alone would not have saved P: "PRIMARY" is longer than any
  // real permission name, so only the mandatory leading 0/1 rejects it.
  assert.throws(() => resolveDenseBlock("P2726561"), DenseEncodingError);    // effect must be 0 or 1
  assert.throws(() => resolveDenseBlock("P1READ"), DenseEncodingError);      // name must be hex
});

test("H rejects a hex payload that does not decode to whole bytes", () => {
  assert.throws(() => resolveDenseBlock("Habc"), DenseEncodingError);
  assert.deepEqual(resolveDenseBlock("Habcd"), { Holder: "abcd" });
});

test("K and X stay unregistered now that H/P/D cover client and scope", () => {
  // The whole reason these letters were passed over. Registering them would
  // make the superseded wordy grammar parse again.
  assert.throws(() => resolveDenseBlock("KBOB"), DenseEncodingError);
  assert.throws(() => resolveDenseBlock("XREAD"), DenseEncodingError);
  assert.throws(() => resolveDenseBlock("XENCRYPTED"), DenseEncodingError);
});

// --- Action verbs: social graph and registry operations --------------------

test("A decodes the social verbs the taxonomy needs", () => {
  for (const verb of ["FOLLOW", "ENDORSE", "SUPPORT", "CITE", "COLLABORATE", "DELEGATE"]) {
    assert.deepEqual(ActionResolver(`A${verb}`), { Action: verb }, `A${verb} should decode`);
  }
  // Flags still compose with the new verbs.
  assert.deepEqual(ActionResolver("AENDORSEX"), { Action: "ENDORSE", Encrypted: true });
});

test("A decodes the four registry operations", () => {
  for (const verb of ["REGISTER", "UPDATE", "QUERY", "DELETE"]) {
    assert.deepEqual(ActionResolver(`A${verb}`), { Action: verb }, `A${verb} should decode`);
  }
});

test("no registered action verb is a prefix of another", () => {
  // Guards the invariant the longest-first sort exists to protect. A new verb
  // that violates it (SEND / SENDER) should fail here, loudly, at the moment
  // it is added rather than at the first ambiguous decode.
  const verbs = ["SEND", "NOTIFY", "FOLLOW", "ENDORSE", "SUPPORT", "CITE",
    "COLLABORATE", "DELEGATE", "REGISTER", "UPDATE", "QUERY", "DELETE"];
  for (const outer of verbs) {
    for (const inner of verbs) {
      if (outer !== inner) assert.ok(!outer.startsWith(inner), `${outer} starts with ${inner}`);
    }
  }
  // And every one of them still round-trips, which is what proves the list
  // above is the list the resolver actually holds.
  for (const verb of verbs) assert.equal(ActionResolver(`A${verb}`).Action, verb);
});

test("A still rejects an unknown verb rather than guessing", () => {
  assert.throws(() => ActionResolver("AFOOBAR"), DenseEncodingError);
  assert.throws(() => ActionResolver("AUNFOLLOW"), DenseEncodingError);
});
