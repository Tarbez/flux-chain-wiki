/**
 * Observer- and environment-relative semantic map. Meaning is keyed on
 * (environment, observer, token, position) - the same token can mean
 * something different to a different observer, or to the same observer in a
 * different environment.
 *
 * A lookup that misses returns a visible GAP by default - it does not
 * fabricate a placeholder, and it does not store anything. This matches the
 * Python engine (flux_engine/semantics.py) and the wider design rule that
 * failures stay visible: a typo must surface as "undefined", not silently
 * acquire a made-up meaning. Passing an imagineMeaning callback opts in to
 * the self-populating behavior (imagine + store + return).
 */

/**
 * A real-world environment lineage ("app-a|file-css") is a handful of
 * characters. Producing K suffix strings from a `|`-separated chain of that
 * length is inherently O(K^2) total characters -- unavoidable given the
 * return contract of "every suffix, as a string" -- and a caller resolving
 * many tokens against the same lineage (coherenceScore/
 * collapseEnvironmentAction, once per atom) pays close to that O(K^2) again
 * per atom, since even the single longest (most-specific) candidate has
 * length O(K) and looking it up costs O(candidate length). Hoisting the
 * lineage computation out of the per-atom loop (see analysis.mjs) removes
 * the redundant *second* O(K^2) recomputation, but an attacker who can make
 * `environment` itself arbitrarily long still forces an O(K) (or, summed
 * across many atoms, O(atoms*K)) cost on every call no matter how the
 * candidates are built or cached.
 *
 * Capping the INPUT length directly bounds all of that to a small constant
 * regardless of what an attacker supplies, which is what actually closes
 * the DoS this module was audited for -- capping candidate *count* instead
 * (dropping some middle segments) would still leave the longest candidate
 * as long as the attacker's whole input. An `environment` past the cap
 * degrades to `["DEFAULT"]` -- the same "gap by default" fallback this
 * module already uses for a token with no defined meaning at all, not a
 * thrown error, since bootstrap-only trusted callers (bootstrap.mjs) never
 * approach this length and a request-path caller should fail toward "no
 * fine-grained context" rather than fail loudly.
 */
export const MAX_ENVIRONMENT_LENGTH = 2048;

/**
 * Builds candidates from the right (shortest first) and reverses once at the
 * end, instead of the previous `parts.slice(index).join("|")` +
 * `lineage.includes(candidate)` per iteration -- that combination was
 * quadratic in the number of `|`-separated segments even before accounting
 * for a caller invoking this per-atom (see analysis.mjs's coherenceScore/
 * collapseEnvironmentAction, which now call this once per pattern instead
 * of once per atom -- that per-atom re-invocation, not this function alone,
 * was the dominant cost for a large `environment` string). See
 * MAX_ENVIRONMENT_LENGTH's doc comment for the separate input-length cap
 * that bounds the remaining, still-real cost for a large `environment`.
 */
export function environmentLineage(environment = "DEFAULT") {
  const normalized = String(environment || "DEFAULT").trim() || "DEFAULT";
  if (normalized === "DEFAULT") return ["DEFAULT"];
  if (normalized.length > MAX_ENVIRONMENT_LENGTH) return ["DEFAULT"];
  const parts = normalized.split("|").filter(Boolean);
  const lineage = [];
  const seen = new Set();
  let candidate = "";
  for (let index = parts.length - 1; index >= 0; index -= 1) {
    candidate = candidate ? `${parts[index]}|${candidate}` : parts[index];
    if (!seen.has(candidate)) {
      seen.add(candidate);
      lineage.push(candidate);
    }
  }
  lineage.reverse();
  if (!seen.has("DEFAULT")) lineage.push("DEFAULT");
  return lineage;
}

// Fast path: most fields never contain the delimiter, so skip the two
// regex replace() calls entirely when there's nothing to escape. keyFor is
// on the hot path of coherenceScore/collapseEnvironmentAction's per-atom
// lookup loop, so this isn't just a micro-optimization -- an escape() that
// always paid two regex passes measurably regressed those callers' runtime
// even after G1's per-atom environmentLineage() re-invocation was fixed.
// Exported so a caller that reuses the same environment/observer across
// many lookups (coherenceScore/collapseEnvironmentAction, across every atom
// in a pattern) can escape those two fields ONCE instead of once per atom --
// see escapedKeyPrefixesFor below, which is what those two callers use.
export function escapeKeyField(value) {
  const text = String(value);
  return text.indexOf("|") === -1 && text.indexOf("\\") === -1 ? text : text.replace(/\\/g, "\\\\").replace(/\|/g, "\\|");
}

export function keyFor(environment, observer, token, position) {
  // `|` is a legal character inside `token`/`observer` (the parser treats it
  // as ordinary text, only `-`/`.` are structural) but was previously used
  // unescaped as this key's own field delimiter -- keyFor("DEFAULT","alice",
  // "x|5",7) and keyFor("DEFAULT","alice|x","5",7) collided on the identical
  // string. Encoding each field's own `|`/`\` first (so a real delimiter can
  // never appear inside a field) closes that cross-field collision.
  return `${escapeKeyField(environment)}|${escapeKeyField(observer)}|${escapeKeyField(token)}|${escapeKeyField(position)}`;
}

/**
 * Precomputes `${escaped candidate}|${escaped observer}|` for every entry in
 * `lineage`, once. A caller resolving many (token, position) pairs against
 * the same (lineage, observer) -- coherenceScore/collapseEnvironmentAction,
 * once per atom in a pattern -- builds each atom's actual lookup key by
 * appending just `${escapeKeyField(token)}|${escapeKeyField(position)}` to
 * one of these prefixes, instead of re-escaping the same (potentially long,
 * for a deep environment lineage) candidate and observer strings on every
 * single atom.
 *
 * @param {string[]} lineage
 * @param {string} observer
 * @returns {string[]} one prefix per lineage entry, same order
 */
export function escapedKeyPrefixesFor(lineage, observer) {
  const escapedObserver = escapeKeyField(observer);
  return lineage.map((candidate) => `${escapeKeyField(candidate)}|${escapedObserver}|`);
}

export function createSemanticMap() {
  return new Map();
}

/**
 * The old default, now opt-in: pass this (or your own callback) as
 * imagineMeaning to get placeholder-on-miss behavior.
 */
export function imaginePlaceholder(observer, token, position, environment = "DEFAULT") {
  return { imagined: true, observer, environment, token, position, placeholder: `${token}@${position}` };
}

/**
 * @param {Map<string, any>} map
 * @param {string} environment
 * @param {string} observer
 * @param {string} token
 * @param {number} position
 * @param {any} meaning
 */
export function defineMeaning(map, environment, observer, token, position, meaning) {
  map.set(keyFor(environment, observer, token, position), meaning);
}

/**
 * @param {Map<string, any>} map
 * @param {string} environment
 * @param {string} observer
 * @param {string} token
 * @param {number} position
 * @param {(observer: string, token: string, position: number, environment?: string) => any} [imagineMeaning]
 *   Opt-in: when provided, a miss imagines a meaning, stores it, and returns
 *   it. When omitted, a miss returns { defined: false, gap: true, ... } and
 *   stores nothing.
 */
export function resolveMeaning(map, environment, observer, token, position, imagineMeaning) {
  for (const candidate of environmentLineage(environment)) {
    const key = keyFor(candidate, observer, token, position);
    if (map.has(key)) {
      return { defined: true, environment, sourceEnvironment: candidate, value: map.get(key) };
    }
  }
  if (typeof imagineMeaning === "function") {
    const meaning = imagineMeaning(observer, token, position, environment);
    map.set(keyFor(environment, observer, token, position), meaning);
    return { defined: true, environment, sourceEnvironment: environment, value: meaning };
  }
  return { defined: false, gap: true, environment, sourceEnvironment: environment, observer, token, position };
}

export function hasMeaning(map, environment, observer, token, position) {
  return environmentLineage(environment).some((candidate) => map.has(keyFor(candidate, observer, token, position)));
}
