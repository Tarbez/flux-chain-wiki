/**
 * Safe surface syntax for trusted runtime bootstrapping. Mirrors
 * ../../src/deadark_micro_ai/flux_engine/define_statement.py exactly (same
 * grammar, same JSON-literal-only restriction).
 *
 * Corrected design, 2026-08-05 (Directive 1): DEFINE can no longer touch
 * the parser's grammar -- there is no more operator table to mutate ("-"/
 * "." are the only structurally significant characters, and that's fixed,
 * not data). `DEFINE ... AS ...` / `UNDEFINE ...` are gone. The only
 * surviving DEFINE form writes an observer-relative *meaning* into the
 * semantic map:
 *
 *   DEFINE FIX MEANS "display:flex" AT POSITION 1 FOR app-a IN FILE-css
 *
 * This is the only way a meaning gets set from user-facing text -- there is
 * no eval() of arbitrary code anywhere in this engine. A DEFINE statement
 * can only assign a JSON-literal meaning to one observer-relative semantic
 * map slot; it can never register new evaluation semantics, read/write
 * files, or execute anything.
 */

import { defineMeaning } from "./semantics.mjs";

// The JSON-literal capture is bounded (`.{1,4096}?`, not the previous
// unbounded `.+?`) so a DEFINE statement with no "AT POSITION" anywhere
// after it -- or one embedded in a large blob of otherwise-unrelated text --
// can't force the lazy quantifier through progressively longer expansions
// that scale with the whole remaining input length before failing. 4096
// chars is generous for any realistic JSON meaning literal.
const DEFINE_MEANING_PATTERN =
  /DEFINE\s+(\S+)\s+MEANS\s+(.{1,4096}?)\s+AT\s+POSITION\s+(-?\d+)(?:\s+FOR\s+(\S+))?(?:\s+IN\s+(\S+))?(?=\s+DEFINE\b|$)/gis;

export class DefineStatementError extends Error {}

/**
 * True if `line` is a DEFINE statement (used to separate bootstrap lines
 * from patterns in a multi-line program, the same role
 * define_statement.py's `is_statement` plays for FluxEngine.run_program).
 *
 * @param {string} line
 */
export function isStatement(line) {
  return line.trim().toUpperCase().startsWith("DEFINE ");
}

/**
 * Scans `text` for `DEFINE <token> MEANS <json> AT POSITION <n> [FOR
 * <observer>] [IN <environment>]` statements and writes each into
 * `semanticMap`. Returns the list of meanings applied.
 *
 * @param {string} text
 * @param {Map<string, any>} semanticMap
 * @param {{ observer?: string, environment?: string }} [defaults]
 */
export function applyDefinitions(text, semanticMap, { observer: defaultObserver = "default", environment: defaultEnvironment = "DEFAULT" } = {}) {
  const applied = [];
  DEFINE_MEANING_PATTERN.lastIndex = 0;
  let match;
  while ((match = DEFINE_MEANING_PATTERN.exec(text))) {
    const [, token, meaningRaw, positionRaw, observer, environment] = match;
    let meaning;
    try {
      meaning = JSON.parse(meaningRaw.trim());
    } catch {
      throw new DefineStatementError(
        `DEFINE ... MEANS requires a valid JSON literal value (for example "text", 1, true, null, {"key":"value"}): got ${JSON.stringify(meaningRaw.trim())}`,
      );
    }
    const position = Number(positionRaw);
    const resolvedObserver = observer || defaultObserver;
    const resolvedEnvironment = environment || defaultEnvironment;
    defineMeaning(semanticMap, resolvedEnvironment, resolvedObserver, token, position, meaning);
    applied.push({ token, position, observer: resolvedObserver, environment: resolvedEnvironment, meaning });
  }
  return applied;
}
