import test from "node:test";
import assert from "node:assert/strict";

import {
  createSemanticMap,
  defineMeaning,
  resolveMeaning,
  hasMeaning,
  environmentLineage,
  keyFor,
  MAX_ENVIRONMENT_LENGTH,
} from "./semantics.mjs";

test("environmentLineage walks from most-specific to DEFAULT, most-specific first", () => {
  assert.deepEqual(environmentLineage("app-a|file-css|DEFAULT"), ["app-a|file-css|DEFAULT", "file-css|DEFAULT", "DEFAULT"]);
});

test("environmentLineage of DEFAULT is just DEFAULT", () => {
  assert.deepEqual(environmentLineage("DEFAULT"), ["DEFAULT"]);
  assert.deepEqual(environmentLineage(), ["DEFAULT"]);
});

test("environmentLineage never duplicates DEFAULT when the input already ends in it", () => {
  const lineage = environmentLineage("a|b|DEFAULT");
  assert.equal(lineage.filter((entry) => entry === "DEFAULT").length, 1);
});

test("environmentLineage produces every suffix exactly once, longest first, for a large segment count (G1 correctness under the fixed implementation)", () => {
  const segments = Array.from({ length: 200 }, (_, index) => `seg${index}`);
  const lineage = environmentLineage(segments.join("|"));
  assert.equal(lineage.length, segments.length + 1); // +1 for the appended DEFAULT
  assert.equal(lineage[0], segments.join("|"));
  assert.equal(lineage[lineage.length - 2], segments[segments.length - 1]);
  assert.equal(lineage[lineage.length - 1], "DEFAULT");
});

test("environmentLineage degrades to DEFAULT for an environment past MAX_ENVIRONMENT_LENGTH, instead of building an unbounded lineage (G1)", () => {
  const oversized = "a".repeat(MAX_ENVIRONMENT_LENGTH + 1);
  assert.deepEqual(environmentLineage(oversized), ["DEFAULT"]);
});

test("environmentLineage still builds the full lineage right at the boundary (regression guard for the cap itself)", () => {
  // segments chosen so the joined string sits just under the cap.
  const segments = Array.from({ length: 200 }, (_, index) => `s${index}`);
  const environment = segments.join("|");
  assert.ok(environment.length < MAX_ENVIRONMENT_LENGTH, "test setup: environment must be under the cap");
  const lineage = environmentLineage(environment);
  assert.equal(lineage.length, segments.length + 1);
  assert.equal(lineage[0], environment);
});

test("environmentLineage stays fast even for a pathologically long, attacker-influenced environment string (G1 perf regression guard)", () => {
  // Far larger than anything the pre-cap implementation was benchmarked
  // against -- this is only tractable at all because it degrades to
  // ["DEFAULT"] rather than building a lineage proportional to its size.
  const environment = Array.from({ length: 200_000 }, (_, index) => `seg${index}`).join("|");
  const start = Date.now();
  for (let i = 0; i < 1000; i += 1) environmentLineage(environment);
  const elapsedMs = Date.now() - start;
  assert.ok(elapsedMs < 1000, `expected 1000 calls over a ~1.6MB environment string to stay well under 1s, took ${elapsedMs}ms`);
});

test("environmentLineage stays reasonably fast for a segment count right at the cap boundary (realistic worst case)", () => {
  const segments = Array.from({ length: 200 }, (_, index) => `s${index}`);
  const environment = segments.join("|");
  const start = Date.now();
  for (let i = 0; i < 200; i += 1) environmentLineage(environment);
  const elapsedMs = Date.now() - start;
  assert.ok(elapsedMs < 1000, `expected 200 calls at the cap boundary to stay well under 1s, took ${elapsedMs}ms`);
});

test("keyFor escapes a literal '|' inside a field so distinct (environment, observer, token, position) tuples never collide (G2)", () => {
  const keyA = keyFor("DEFAULT", "alice", "x|5", 7);
  const keyB = keyFor("DEFAULT", "alice|x", "5", 7);
  assert.notEqual(keyA, keyB);
});

test("keyFor escapes a literal backslash too, so the escape scheme itself doesn't introduce a new collision", () => {
  const keyA = keyFor("DEFAULT", "alice", "x\\|5", 7);
  const keyB = keyFor("DEFAULT", "alice", "x\\\\", 7); // would collide with the above if \\ | were built naively
  assert.notEqual(keyA, keyB);
});

test("resolveMeaning/defineMeaning round-trip correctly for tokens containing '|' (G2 end-to-end)", () => {
  const map = createSemanticMap();
  defineMeaning(map, "DEFAULT", "alice", "x|5", 7, { intent: "the real one" });
  defineMeaning(map, "DEFAULT", "alice|x", "5", 7, { intent: "should be independent" });

  const first = resolveMeaning(map, "DEFAULT", "alice", "x|5", 7);
  const second = resolveMeaning(map, "DEFAULT", "alice|x", "5", 7);
  assert.equal(first.value.intent, "the real one");
  assert.equal(second.value.intent, "should be independent");
});

test("hasMeaning agrees with resolveMeaning for a token containing '|'", () => {
  const map = createSemanticMap();
  defineMeaning(map, "DEFAULT", "alice", "x|5", 7, { intent: "defined" });
  assert.equal(hasMeaning(map, "DEFAULT", "alice", "x|5", 7), true);
  assert.equal(hasMeaning(map, "DEFAULT", "alice|x", "5", 7), false);
});

test("resolveMeaning returns a gap for an unregistered token, not a fabricated meaning", () => {
  const map = createSemanticMap();
  const result = resolveMeaning(map, "DEFAULT", "alice", "unknown", 1);
  assert.equal(result.defined, false);
  assert.equal(result.gap, true);
});

test("resolveMeaning falls back through the environment lineage to a broader definition", () => {
  const map = createSemanticMap();
  defineMeaning(map, "DEFAULT", "alice", "FIX", 1, { intent: "default meaning" });
  const result = resolveMeaning(map, "app-a|file-css", "alice", "FIX", 1);
  assert.equal(result.defined, true);
  assert.equal(result.sourceEnvironment, "DEFAULT");
  assert.equal(result.value.intent, "default meaning");
});
