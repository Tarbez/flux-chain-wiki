/**
 * Dumb block-splitting parser for Flux patterns -- the JS mirror of
 * ../../src/deadark_micro_ai/flux_engine/parser.py, same algorithm, same
 * node shapes (just object literals instead of dataclasses since this
 * engine has no Python-style frozen-dataclass convention).
 *
 * Corrected design, 2026-08-05 (Directive 1): this file used to be a
 * Pratt/operator-table parser reading precedence out of a mutable table
 * (see git history / shared/flux-claims's still-frozen vendored copy for that
 * design). Since shared/flux-claims keeps its own independently-vendored
 * copy and is not re-synced from this file (see docs/architecture -- Batch
 * 3 of the correction was explicitly skipped), this engine is now free to
 * go all the way to the corrected spec: the parser knows about exactly two
 * characters, "-" (top-level separator) and "." (isolation fence, matched
 * against the *next* "." in the same scope, recursively parsed). Every
 * other character is kept verbatim inside whichever raw block it appears
 * in. Meaning is a Resolver's job (resolvers.mjs), applied per raw block
 * after parsing -- this file never inspects a block's own text. Whitespace
 * is the one exception: runs of it are insignificant block boundaries (like
 * "-" without emitting a block of its own), purely so a fence can be
 * written with a readable space before it (`"XSEC .GROUP."`) without that
 * space becoming part of the preceding atom's text.
 *
 * `position` on AtomNode/GroupNode is a 0-based sibling index within the
 * current nesting scope (not a character offset) -- a fence's contents are
 * their own local reality, renumbered from 0, exactly like the Python
 * engine.
 */

export class ParseError extends Error {}

function collapse(items) {
  return items.length === 1 ? items[0] : { type: "SequenceNode", nodes: items };
}

/**
 * @param {string[]} chars - code points (Array.from'd string), so multi-unit
 *   characters (emoji, combining marks) never split across a block boundary
 * @param {number} start
 * @param {number} limit
 * @returns {{ items: object[], end: number }}
 */
function parseBlocks(chars, start, limit) {
  const items = [];
  let current = [];
  let position = 0;
  let i = start;

  const flush = () => {
    if (current.length) {
      items.push({ type: "AtomNode", text: current.join(""), position });
      position += 1;
      current = [];
    }
  };

  while (i < limit) {
    const ch = chars[i];

    if (/\s/.test(ch)) {
      flush();
      i += 1;
      while (i < limit && /\s/.test(chars[i])) i += 1;
      continue;
    }

    if (ch === ".") {
      flush();
      let end = -1;
      for (let k = i + 1; k < limit; k += 1) {
        if (chars[k] === ".") {
          end = k;
          break;
        }
      }
      if (end === -1) {
        throw new ParseError(`unclosed isolation fence '.' at position ${i}`);
      }
      const { items: innerItems } = parseBlocks(chars, i + 1, end);
      items.push({
        type: "GroupNode",
        inner: innerItems.length ? collapse(innerItems) : { type: "SequenceNode", nodes: [] },
        content: chars.slice(i + 1, end).join(""),
        position,
      });
      position += 1;
      i = end + 1;
      continue;
    }

    if (ch === "-") {
      flush();
      i += 1;
      continue;
    }

    current.push(ch);
    i += 1;
  }

  flush();
  return { items, end: limit };
}

/**
 * Split `text` into raw blocks on top-level "-" and ".". An unclosed "."
 * throws ParseError. A completely empty pattern also throws ParseError --
 * there is nothing to parse.
 *
 * @param {string} text
 * @returns {object} AtomNode | GroupNode | SequenceNode
 */
export function parseText(text) {
  const chars = Array.from(String(text));
  const { items } = parseBlocks(chars, 0, chars.length);
  if (!items.length) {
    throw new ParseError("unexpected end of input");
  }
  return collapse(items);
}

/**
 * Left-to-right list of the AtomNode leaves in a parsed expression. A
 * GroupNode's insides are isolated by design and are deliberately excluded
 * here -- callers that need a group's contents should walk `node.inner`
 * explicitly.
 *
 * @param {object} node
 * @returns {object[]} AtomNode[]
 */
export function flattenAtoms(node) {
  if (!node) return [];
  if (node.type === "AtomNode") return [node];
  if (node.type === "GroupNode") return [];
  if (node.type === "SequenceNode") return node.nodes.flatMap(flattenAtoms);
  return [];
}
