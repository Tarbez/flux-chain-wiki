import test from "node:test";
import assert from "node:assert/strict";

import { resolveUpgrade, buildUpgradeHistory, listUnversionedExtensions } from "./upgrade.mjs";
import { DenseEncodingError } from "./resolvers.mjs";

// Hand-built fixture: a fictional manifest type "X" whose J extension was
// shape A ("opaque-alphanumeric") as of spec 3.5.0, then redefined to shape
// B ("coded-fields") as of 4.0.0. Real types (BLOCK/VOTE/TRANSACTION/PROOF)
// have no `since` data in manifest-types.json yet -- this fixture exists so
// resolveUpgrade's picking logic is provable today, ready for whenever the
// registry grows real history.
const SHAPE_A = { since: "3.5.0", shape: "opaque-alphanumeric", definedIn: "fixture-spec-a.md", note: "shape A" };
const SHAPE_B = { since: "4.0.0", shape: "coded-fields", definedIn: "fixture-spec-b.md", note: "shape B" };
const FIXTURE_HISTORY = { X: { J: [SHAPE_A, SHAPE_B] } };

test("resolveUpgrade picks shape A for a version between its since and the next upgrade", () => {
  assert.deepEqual(resolveUpgrade(FIXTURE_HISTORY, "X", "J", "3.6.0"), SHAPE_A);
});

test("resolveUpgrade picks shape A exactly at its own since version", () => {
  assert.deepEqual(resolveUpgrade(FIXTURE_HISTORY, "X", "J", "3.5.0"), SHAPE_A);
});

test("resolveUpgrade picks shape B exactly at the version it takes effect", () => {
  assert.deepEqual(resolveUpgrade(FIXTURE_HISTORY, "X", "J", "4.0.0"), SHAPE_B);
});

test("resolveUpgrade picks shape B for a version after it takes effect", () => {
  assert.deepEqual(resolveUpgrade(FIXTURE_HISTORY, "X", "J", "5.2.1"), SHAPE_B);
});

test("resolveUpgrade is order-independent -- same result whichever order entries are listed", () => {
  const reordered = { X: { J: [SHAPE_B, SHAPE_A] } };
  assert.deepEqual(resolveUpgrade(reordered, "X", "J", "3.6.0"), SHAPE_A);
  assert.deepEqual(resolveUpgrade(reordered, "X", "J", "4.0.0"), SHAPE_B);
});

test("resolveUpgrade throws when the target version predates every registered upgrade", () => {
  assert.throws(() => resolveUpgrade(FIXTURE_HISTORY, "X", "J", "3.4.9"), DenseEncodingError);
});

test("resolveUpgrade throws for a manifest type with no history at all -- never guesses", () => {
  assert.throws(
    () => resolveUpgrade(FIXTURE_HISTORY, "BLOCK", "J", "4.0.0"),
    /no version history registered/,
  );
});

test("resolveUpgrade throws for a letter with no history under a known type", () => {
  assert.throws(
    () => resolveUpgrade(FIXTURE_HISTORY, "X", "Z", "4.0.0"),
    /no version history registered/,
  );
});

test("resolveUpgrade throws on an empty history table entirely", () => {
  assert.throws(() => resolveUpgrade({}, "X", "J", "4.0.0"), DenseEncodingError);
});

test("resolveUpgrade throws on a malformed targetVersion", () => {
  assert.throws(() => resolveUpgrade(FIXTURE_HISTORY, "X", "J", "4.0"), DenseEncodingError);
  assert.throws(() => resolveUpgrade(FIXTURE_HISTORY, "X", "J", "not-a-version"), DenseEncodingError);
});

test("resolveUpgrade throws on a malformed 'since' inside the history table", () => {
  const malformed = { X: { J: [{ since: "v3.5", shape: "opaque-alphanumeric" }] } };
  assert.throws(() => resolveUpgrade(malformed, "X", "J", "4.0.0"), DenseEncodingError);
});

// --- buildUpgradeHistory / listUnversionedExtensions (added 2026-09-08) ------
//
// These close the "separate, not-yet-done registry work" upgrade.mjs's own
// header used to name: turning a parsed manifest-types.json into the history
// table resolveUpgrade consumes. The fixture mirrors the real registry's
// shape -- a `types` array whose entries may carry `letterExtensions` keyed by
// letter -- including the two forms that coexist: a single object (what every
// real entry uses today) and an array of versioned objects (what a letter
// becomes once its shape actually changes).
const REGISTRY_FIXTURE = {
  specVersion: "0.4.2",
  types: [
    // Un-annotated, exactly like all 8 real letterExtensions entries today.
    { type: "POOL", letterExtensions: { J: { shape: "coded-fields", definedIn: "amm-manifest-v1.md" } } },
    // Annotated single object -- the shape a new type registers with.
    { type: "LEXEME", letterExtensions: { J: { since: "0.4.2", shape: "coded-fields", definedIn: "fixture.md" } } },
    // Annotated array -- a letter whose shape genuinely changed over time.
    { type: "GROWN", letterExtensions: { J: [SHAPE_A, SHAPE_B] } },
    // Mixed: one annotated letter, one not, on the same type.
    { type: "PARTIAL", letterExtensions: { J: { since: "0.4.2", shape: "coded-fields" }, O: { shape: "coded-fields" } } },
    { type: "NOEXTENSIONS" },
  ],
};

test("buildUpgradeHistory includes only extensions that carry a since", () => {
  const history = buildUpgradeHistory(REGISTRY_FIXTURE);
  assert.deepEqual(Object.keys(history).sort(), ["GROWN", "LEXEME", "PARTIAL"]);
  assert.equal(history.POOL, undefined, "an un-annotated extension must not appear at all");
  assert.deepEqual(Object.keys(history.PARTIAL), ["J"], "the un-annotated letter O is dropped, J is kept");
});

test("buildUpgradeHistory normalizes a single object into a one-entry list", () => {
  const history = buildUpgradeHistory(REGISTRY_FIXTURE);
  assert.equal(history.LEXEME.J.length, 1);
  assert.equal(history.LEXEME.J[0].since, "0.4.2");
});

test("buildUpgradeHistory preserves an array of versioned entries", () => {
  const history = buildUpgradeHistory(REGISTRY_FIXTURE);
  assert.deepEqual(history.GROWN.J, [SHAPE_A, SHAPE_B]);
});

test("buildUpgradeHistory output feeds resolveUpgrade directly", () => {
  const history = buildUpgradeHistory(REGISTRY_FIXTURE);
  assert.deepEqual(resolveUpgrade(history, "GROWN", "J", "3.6.0"), SHAPE_A);
  assert.deepEqual(resolveUpgrade(history, "GROWN", "J", "4.0.0"), SHAPE_B);
  assert.equal(resolveUpgrade(history, "LEXEME", "J", "0.4.2").shape, "coded-fields");
});

// The honest-gap property, stated as a test so nobody "fixes" it into a
// fallback: an un-annotated extension must THROW, not resolve to today's shape.
test("an un-annotated extension throws rather than silently resolving to today's shape", () => {
  const history = buildUpgradeHistory(REGISTRY_FIXTURE);
  assert.throws(() => resolveUpgrade(history, "POOL", "J", "0.4.2"), DenseEncodingError);
});

test("a version predating a real entry's since still throws", () => {
  const history = buildUpgradeHistory(REGISTRY_FIXTURE);
  assert.throws(() => resolveUpgrade(history, "LEXEME", "J", "0.4.1"), DenseEncodingError);
});

test("listUnversionedExtensions reports the gaps, sorted, and nothing else", () => {
  assert.deepEqual(listUnversionedExtensions(REGISTRY_FIXTURE), [
    { type: "PARTIAL", letter: "O" },
    { type: "POOL", letter: "J" },
  ]);
});

test("buildUpgradeHistory and listUnversionedExtensions tolerate a malformed registry", () => {
  for (const bad of [undefined, null, {}, { types: null }, { types: [null, 7, {}] }]) {
    assert.deepEqual(buildUpgradeHistory(bad), {});
    assert.deepEqual(listUnversionedExtensions(bad), []);
  }
});
