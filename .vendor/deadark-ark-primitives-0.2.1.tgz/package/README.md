# @deadark/ark-primitives

Unstyled, accessible `createArk*()` primitive factories, built on
`@deadark/ark-a11y`. First extraction batch: `createArkDialog` and
`createArkPopover` (and their `Ark*Options`/`Ark*Handle` types), moved out
of `@deadark/ark-ui`'s `ark-ui.components.ts` behavior-for-behavior.

`@deadark/ark-ui/components` and `@deadark/ark-ui/primitives` both
re-export these names during the deprecation window, so existing consumers
of either path keep working unchanged.

## Usage

```js
import { createArkDialog, createArkPopover } from "@deadark/ark-primitives";
// or the granular subpath:
import { createArkDialog } from "@deadark/ark-primitives/dialog";
```

`createArkDialog`/`createArkPopover` take an `ArkPrimitiveRuntime` — the
small structural subset of ARK UI's `createArkUI()` instance they actually
call (`configureRef`, `bindRefEvent`, `onAction`, `get`/`update`,
`createFocusScope`, `createDismissableLayer`, `createPresence`,
`openOverlay`/`closeOverlay`). This package has no dependency on
`@deadark/ark-ui` itself — only on `@deadark/ark-a11y` — matching the
plan's dependency direction (`ark-primitives -> ark-a11y`, never back up
to a Layered Component or the runtime package).

## Meaning tones — 2026-10-19 (0.2.0)

- **Alert tones** (`./alert`): `info`, `success`, `warning`, `danger`, plus
  `drift` (honey: needs review or approval) and `reference` (points at a source).
  `ARK_ALERT_TONE_TOKENS` maps each tone to the SDK semantic token it paints with
  (`hsl(var(--<token>))`). `danger`/`warning` announce assertively; every other
  tone politely. An unknown tone is refused with the accepted list and a remedy;
  it used to pass into `data-tone` unmatched and render with no meaning colour.
- **Badges** (`./badge`, `createArkBadge`): a badge must mean something real
  (AGENTS.md). `meaning` is required and is one of `identity`, `credibility`,
  `affinity`, `role`, `participation`, `contribution`
  (`ARK_BADGE_MEANING_TOKENS` maps each to its SDK token; none uses `--accent`,
  the action lane). Anything else — a streak, a decoration — is refused, so it
  cannot be built. The SDK's `DEADARK_BADGE_MEANINGS` is parity-tested against
  this table.
- **Generated ids**: toast handles come from `@deadark/ark-a11y/ids`
  (`ark-r-toast--N`), the one reserved generated-id prefix.

## ARIA corrections — 2026-10-19

- **Breadcrumbs** follow the APG breadcrumb pattern: an ordinary `nav` of links, each its
  own Tab stop (no roving group, no tabindex), the current crumb marked only by
  `aria-current="page"`. They used to write `selected` (rendered as `aria-selected`,
  invalid on a link) and to leave a single roving tab stop. No `aria-orientation` on the nav.
- **Pagination** applies the same rule: the current page link carries only
  `aria-current="page"`; `selected`/`aria-selected` are never written on page links, and the
  nav has no `aria-orientation`.
- **Accordion** list wrapper is `role="group"`, named by the new `label` / `labelledBy`
  options (was `role="presentation"`, which stripped the grouping). Triggers that are
  native `<button>`s get no redundant `role="button"`.
- **Tabs**: the Tab stop is the selected tab, not the first (the runtime's roving group
  falls back to index 0 when focus is outside; the primitive corrects it after each sync).
