import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkMenuOptions {
  triggerRef: string;
  contentRef: string;
  itemRefs: string[];
  labelRef?: string;
  descriptionRef?: string;
  initialFocusRef?: string;
  stateRef?: string;
  portal?: string;
  placement?: "top" | "right" | "bottom" | "left";
  align?: "start" | "center" | "end";
  disabledItemRefs?: string[];
  loop?: boolean;
  typeahead?: boolean;
}

export interface ArkSubmenuOptions extends ArkMenuOptions {
  parentContentRef: string;
}

export interface ArkContextMenuOptions extends Omit<ArkMenuOptions, "triggerRef"> {
  /** The real element whose right-click (`contextmenu`) opens the menu —
   * e.g. a table row or a canvas surface. */
  targetRef: string;
  /** A small, `position:fixed` element the menu overlay anchors to. It gets
   * moved to the pointer's client coordinates on every right-click before
   * the menu opens — same trick a "virtual anchor" would do, but expressed
   * as a real element, since the overlay positioner reads a real anchor's
   * `getBoundingClientRect()`. */
  anchorRef: string;
}

export interface ArkMenuCheckboxItemOptions {
  itemRef: string;
  checked?: boolean;
  onCheckedChange?: (checked: boolean) => void;
}

export interface ArkMenuItemOptions {
  itemRef: string;
  menuRef: string;
  disabled?: boolean;
  closeOnSelect?: boolean;
  onSelect?: (ref: string) => void;
}

export interface ArkMenuRadioGroupOptions {
  itemRefs: string[];
  selectedRef?: string;
  onValueChange?: (ref: string) => void;
}

export interface ArkMenuGroupOptions {
  groupRef: string;
  labelRef?: string;
}

export interface ArkMenuLabelOptions {
  labelRef: string;
}

export interface ArkMenuSeparatorOptions {
  separatorRef: string;
}

export interface ArkMenuHandle {
  open: () => void;
  close: () => void;
  focusFirst: () => void;
  focusLast: () => void;
}

/** A menu popup: `role="menu"` content anchored to a trigger, with a
 * vertical/looping/typeahead roving-tabindex item collection, a non-trapping
 * focus scope, and outside-press/outside-focus/Escape dismissal. */
export declare function createArkMenu(ui: ArkPrimitiveRuntime, options: ArkMenuOptions): ArkMenuHandle;

/** A menu opened by right-clicking `targetRef`, positioned by moving a small
 * fixed `anchorRef` element to the pointer's client coordinates. */
export declare function createArkContextMenu(ui: ArkPrimitiveRuntime, options: ArkContextMenuOptions): ArkMenuHandle;

/** A nested menu: opens on ArrowRight/Enter/Space (and click) from its
 * trigger, closes back to the trigger on ArrowLeft, and treats the parent
 * menu's content as a dismissal branch rather than an outside press. */
export declare function createArkSubmenu(ui: ArkPrimitiveRuntime, options: ArkSubmenuOptions): void;

/** A `role="menuitemcheckbox"` row whose checked/selected state toggles on activation. */
export declare function createArkMenuCheckboxItem(ui: ArkPrimitiveRuntime, options: ArkMenuCheckboxItemOptions): void;

/** Selection behavior for a single menu row, including close-on-select. */
export declare function createArkMenuItem(ui: ArkPrimitiveRuntime, options: ArkMenuItemOptions): void;

/** A set of `role="menuitemradio"` rows with exactly one selected at a time. */
export declare function createArkMenuRadioGroup(ui: ArkPrimitiveRuntime, options: ArkMenuRadioGroupOptions): void;

/** A labelled `role="group"` section within a menu. */
export declare function createArkMenuGroup(ui: ArkPrimitiveRuntime, options: ArkMenuGroupOptions): void;

/** A non-interactive menu section label. */
export declare function createArkMenuLabel(ui: ArkPrimitiveRuntime, options: ArkMenuLabelOptions): void;

/** A `role="separator"` rule between menu sections. */
export declare function createArkMenuSeparator(ui: ArkPrimitiveRuntime, options: ArkMenuSeparatorOptions): void;

/** The dropdown-menu pattern — a thin delegation to `createArkMenu` so the
 * two names can never drift apart in behavior. */
export declare function createArkDropdownMenu(ui: ArkPrimitiveRuntime, options: ArkMenuOptions): void;
