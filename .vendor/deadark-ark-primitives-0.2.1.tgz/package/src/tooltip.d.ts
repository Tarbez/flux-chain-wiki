import type { ArkPrimitiveRuntime } from "./runtime.js";

export type ArkTooltipChangeReason =
  | "trigger-hover"
  | "trigger-focus"
  | "escape-key"
  | "imperative-action"
  | "controlled-sync"
  | "none";

export interface ArkTooltipChangeDetails {
  reason: ArkTooltipChangeReason;
  triggerRef?: string;
  isCanceled: boolean;
  cancel: () => void;
}

export interface ArkTooltipOptions {
  triggerRef: string;
  contentRef: string;
  /** Additional triggers that share the same tooltip content. */
  triggerRefs?: string[];
  placement?: "top" | "right" | "bottom" | "left";
  align?: "start" | "center" | "end";
  offset?: number;
  collisionPadding?: number;
  portal?: string;
  stateRef?: string;
  defaultOpen?: boolean;
  open?: boolean;
  controlled?: boolean;
  disabled?: boolean;
  /** Hover-open delay in ms, matching base-ui's Trigger default. */
  delay?: number;
  /** Hover-close delay in ms — 0 means it closes as soon as the pointer leaves. */
  closeDelay?: number;
  /** Whether the pointer can move from the trigger onto the tooltip content
   * itself without it closing (base-ui's inverse of `disableHoverablePopup`). */
  hoverable?: boolean;
  escapeKey?: boolean;
  onOpenChange?: (open: boolean, details: ArkTooltipChangeDetails) => void;
  onOpenChangeComplete?: (open: boolean, details: ArkTooltipChangeDetails) => void;
}

export interface ArkTooltipHandle {
  open: (triggerRef?: string) => void;
  close: () => void;
  toggle: (triggerRef?: string) => void;
  setOpen: (open: boolean, triggerRef?: string) => void;
  syncControlled: (open: boolean, triggerRef?: string) => void;
  getState: () => {
    open: boolean;
    activeTriggerRef?: string;
    reason: ArkTooltipChangeReason;
    controlled: boolean;
  };
}

export declare function createArkTooltip(ui: ArkPrimitiveRuntime, options: ArkTooltipOptions): ArkTooltipHandle;
