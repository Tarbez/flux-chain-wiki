import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkProgressOptions {
  rootRef: string;
  indicatorRef: string;
  labelRef?: string;
  valueRef?: string;
  min?: number;
  max?: number;
  value?: number;
  indeterminate?: boolean;
  stateRef?: string;
  onValueChange?: (value: number) => void;
}

export interface ArkProgressHandle {
  setValue: (value: number) => void;
  setIndeterminate: (indeterminate: boolean) => void;
  getState: () => { value: number; min: number; max: number; indeterminate: boolean };
}

export interface ArkSkeletonOptions {
  rootRef: string;
  rootRefs?: string[];
  containerRef?: string;
  animation?: "pulse" | "shimmer" | "none";
  decorative?: boolean;
  label?: string;
  loading?: boolean;
  stateRef?: string;
}

export interface ArkSkeletonHandle {
  setLoading: (loading: boolean) => void;
  complete: () => void;
  getState: () => { loading: boolean; animation: "pulse" | "shimmer" | "none" };
}

export interface ArkSpinnerOptions {
  rootRef: string;
  labelRef?: string;
  stateRef?: string;
}

export interface ArkLoadingMarkOptions {
  rootRef: string;
  logoRef?: string;
  labelRef?: string;
  descriptionRef?: string;
  spinning?: boolean;
  stateRef?: string;
}

export interface ArkLoadingMarkHandle {
  start: () => void;
  stop: () => void;
  setSpinning: (nextSpinning: boolean) => void;
  setLabel: (text: string) => void;
  setDescription: (text: string) => void;
  getState: () => { spinning: boolean };
}

export declare function createArkProgress(ui: ArkPrimitiveRuntime, options: ArkProgressOptions): ArkProgressHandle;
export declare function createArkSkeleton(ui: ArkPrimitiveRuntime, options: ArkSkeletonOptions): ArkSkeletonHandle;
export declare function createArkSpinner(ui: ArkPrimitiveRuntime, options: ArkSpinnerOptions): void;
export declare function createArkLoadingMark(ui: ArkPrimitiveRuntime, options: ArkLoadingMarkOptions): ArkLoadingMarkHandle;
