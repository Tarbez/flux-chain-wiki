import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkCarouselOptions {
  viewportRef: string;
  trackRef: string;
  slideRefs: string[];
  prevRef?: string;
  nextRef?: string;
  dotRefs?: string[];
  loop?: boolean;
  orientation?: "horizontal" | "vertical";
  stateRef?: string;
  label?: string;
  /** Milliseconds between auto-advances. Pauses on pointer hover/keyboard
   * focus inside the viewport and resumes on leave/blur, same as every
   * production carousel's default autoplay behavior. */
  autoplay?: number;
  onSlideChange?: (index: number) => void;
}

export interface ArkCarouselHandle {
  scrollTo: (index: number) => void;
  scrollNext: () => void;
  scrollPrev: () => void;
  pauseAutoplay: () => void;
  resumeAutoplay: () => void;
  getState: () => { index: number; count: number };
}

export declare function createArkCarousel(ui: ArkPrimitiveRuntime, options: ArkCarouselOptions): ArkCarouselHandle;
