import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkDisclosureOptions {
  triggerRef: string;
  contentRef: string;
  defaultOpen?: boolean;
  open?: boolean;
  controlled?: boolean;
  disabled?: boolean;
  keepMounted?: boolean;
  hiddenUntilFound?: boolean;
  stateRef?: string;
  onOpenChange?: (open: boolean, details?: { reason: "trigger-press" | "imperative-action" | "controlled-sync"; event?: Event; isCanceled: boolean; cancel: () => void }) => void;
  onOpenChangeComplete?: (open: boolean) => void;
}

export interface ArkCollapsibleOptions extends ArkDisclosureOptions {
  titleRef?: string;
}

export interface ArkCodeBlockOptions extends ArkDisclosureOptions {
  codeRef: string;
  labelRef?: string;
  collapsedLabel?: string;
  expandedLabel?: string;
  code?: string;
  copyTriggerRef?: string;
  copyLabel?: string;
  copiedLabel?: string;
  copyUnavailableLabel?: string;
  resetCopyLabelDelay?: number;
  onCopy?: (details: { ok: boolean; text: string }) => void;
}

export interface ArkDisclosureHandle {
  open: () => void;
  close: () => void;
  toggle: () => void;
  setOpen: (open: boolean) => void;
  syncControlled: (open: boolean) => void;
  getState: () => { open: boolean; controlled: boolean; mounted: boolean };
}

export declare function createArkDisclosure(ui: ArkPrimitiveRuntime, options: ArkDisclosureOptions): ArkDisclosureHandle;
export declare function createArkCollapsible(ui: ArkPrimitiveRuntime, options: ArkCollapsibleOptions): ArkDisclosureHandle;
export declare function createArkCodeBlock(ui: ArkPrimitiveRuntime, options: ArkCodeBlockOptions): ArkDisclosureHandle;
