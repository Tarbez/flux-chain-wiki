import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkDirectionOptions {
  rootRef: string;
  dir: "ltr" | "rtl";
}

export interface ArkDirectionHandle {
  setDirection: (dir: "ltr" | "rtl") => void;
  getState: () => { dir: "ltr" | "rtl" };
}

export declare function createArkDirection(ui: ArkPrimitiveRuntime, options: ArkDirectionOptions): ArkDirectionHandle;
