/**
 * `createArkScrollArea`, `createArkSidebar`, `createArkAppShell` — moved out
 * of `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * `createArkNavigationMenu` (originally adjacent to these in components.ts)
 * is deliberately NOT included here: it calls `createArkTabs` internally,
 * and Tabs hasn't been extracted yet. Moving NavigationMenu now would mean
 * either duplicating Tabs or reaching back into `ark-ui.components.ts` from
 * a sibling package, both wrong. It stays put until the Tabs/Select family
 * moves, then becomes trivial to move alongside it.
 *
 * `createArkScrollArea`'s one substitution: the original used
 * `withVariants("&::-webkit-scrollbar", {...})` from `ark-ui.runtime.ts`,
 * which `ark-primitives` must not depend on (dependency direction is
 * `ark-primitives -> ark-a11y`, never back up to `ark-ui`). For this single
 * static chain (no breakpoint/media/container segments, no aliasing), that
 * call reduces to exactly `{ "&::-webkit-scrollbar": {...} }` -- the same
 * substitution already verified for `createArkAspectRatio` in `media.js`.
 */
import { normalizeRef, setHidden, syncModelRef } from "@deadark/ark-a11y/dom";

function ref(value) {
  return normalizeRef(value);
}

export function createArkScrollArea(ui, options) {
  const viewportRef = ref(options.viewportRef);
  const contentRef = ref(options.contentRef);
  const scrollbarXRef = ref(options.scrollbarXRef);
  const scrollbarYRef = ref(options.scrollbarYRef);
  const thumbXRef = ref(options.thumbXRef);
  const thumbYRef = ref(options.thumbYRef);
  const cornerRef = ref(options.cornerRef);

  const sync = () => {
    const viewport = ui.getElement(viewportRef);
    if (!viewport) return;
    const xRatio = viewport.scrollWidth > 0 ? viewport.clientWidth / viewport.scrollWidth : 1;
    const yRatio = viewport.scrollHeight > 0 ? viewport.clientHeight / viewport.scrollHeight : 1;
    const xOffset = viewport.scrollWidth > viewport.clientWidth
      ? (viewport.scrollLeft / (viewport.scrollWidth - viewport.clientWidth)) * Math.max(0, viewport.clientWidth - 36)
      : 0;
    const yOffset = viewport.scrollHeight > viewport.clientHeight
      ? (viewport.scrollTop / (viewport.scrollHeight - viewport.clientHeight)) * Math.max(0, viewport.clientHeight - 36)
      : 0;
    if (thumbXRef) {
      ui.style(thumbXRef, {
        width: `${Math.max(24, xRatio * 100)}%`,
        transform: `translateX(${xOffset}px)`,
      }, { mode: "merge" });
    }
    if (thumbYRef) {
      ui.style(thumbYRef, {
        height: `${Math.max(24, yRatio * 100)}%`,
        transform: `translateY(${yOffset}px)`,
      }, { mode: "merge" });
    }
  };

  ui.configureRef(viewportRef, { part: "scroll-viewport" });
  ui.style(viewportRef, {
    position: "relative",
    overflow: "auto",
    scrollbarWidth: "none",
    msOverflowStyle: "none",
    "&::-webkit-scrollbar": { display: "none" },
  }, { mode: "merge" });
  if (contentRef) ui.configureRef(contentRef, { part: "scroll-content" });
  if (scrollbarXRef) {
    ui.configureRef(scrollbarXRef, { part: "scrollbar-x" });
    ui.style(scrollbarXRef, { position: "relative", width: "100%", height: "10px" }, { mode: "merge" });
  }
  if (scrollbarYRef) {
    ui.configureRef(scrollbarYRef, { part: "scrollbar-y" });
    ui.style(scrollbarYRef, { position: "relative", width: "10px", height: "100%" }, { mode: "merge" });
  }
  if (thumbXRef) {
    ui.configureRef(thumbXRef, { part: "scroll-thumb-x" });
    ui.style(thumbXRef, { display: "block", height: "100%", minWidth: "24px" }, { mode: "merge" });
  }
  if (thumbYRef) {
    ui.configureRef(thumbYRef, { part: "scroll-thumb-y" });
    ui.style(thumbYRef, { display: "block", width: "100%", minHeight: "24px" }, { mode: "merge" });
  }
  if (cornerRef) {
    ui.configureRef(cornerRef, { part: "scroll-corner" });
    ui.style(cornerRef, { width: "10px", height: "10px" }, { mode: "merge" });
    setHidden(ui, cornerRef, !(scrollbarXRef && scrollbarYRef));
  }

  // Drags the thumb like a native scrollbar: track the pointer's delta from
  // where the drag started rather than its live position, so a fast flick
  // past the track's edge doesn't cause the thumb to snap or overshoot.
  const bindThumbDrag = (thumbRef, axis) => {
    if (!thumbRef) return;
    ui.bindRefEvent(thumbRef, "pointerdown", (rawEvent) => {
      if (typeof document === "undefined") return;
      const event = rawEvent;
      const viewport = ui.getElement(viewportRef);
      if (!viewport) return;
      event.preventDefault();
      const dragStartPos = axis === "x" ? event.clientX : event.clientY;
      const dragStartScroll = axis === "x" ? viewport.scrollLeft : viewport.scrollTop;
      const trackExtent = axis === "x" ? viewport.clientWidth : viewport.clientHeight;
      const contentExtent = axis === "x" ? viewport.scrollWidth : viewport.scrollHeight;
      const scrollable = contentExtent - trackExtent;
      const onPointerMove = (moveEvent) => {
        if (scrollable <= 0 || trackExtent <= 0) return;
        const pos = axis === "x" ? moveEvent.clientX : moveEvent.clientY;
        const scrollDelta = ((pos - dragStartPos) / trackExtent) * contentExtent;
        const nextScroll = Math.min(scrollable, Math.max(0, dragStartScroll + scrollDelta));
        if (axis === "x") viewport.scrollLeft = nextScroll;
        else viewport.scrollTop = nextScroll;
        sync();
      };
      const onPointerUp = () => {
        document.removeEventListener("pointermove", onPointerMove);
        document.removeEventListener("pointerup", onPointerUp);
      };
      document.addEventListener("pointermove", onPointerMove);
      document.addEventListener("pointerup", onPointerUp);
    });
  };
  bindThumbDrag(thumbXRef, "x");
  bindThumbDrag(thumbYRef, "y");

  ui.bindRefEvent(viewportRef, "scroll", sync);
  ui.bindRefEvent(viewportRef, "mouseenter", sync);
  sync();
}

export function createArkSidebar(ui, options) {
  const sidebarRef = ref(options.sidebarRef);
  const triggerRef = ref(options.triggerRef);
  const railRef = ref(options.railRef);
  const side = options.side ?? "left";
  const stateRef = ref(options.stateRef);
  let open = options.open ?? true;

  const sync = () => {
    const collapsedWidth = options.closedWidth ?? (railRef ? "72px" : "0px");
    const width = open ? (options.openWidth ?? "280px") : collapsedWidth;
    // Content stays mounted-but-condensed (not hidden) whenever the closed
    // state keeps a non-zero width — either a separate rail is swapping in,
    // or the consumer asked for a condensed width via `closedWidth`.
    const keepsContentWhenClosed = !!railRef || collapsedWidth !== "0px";
    ui.configureRef(sidebarRef, { part: "sidebar" });
    ui.update(sidebarRef, { open, hidden: !open && !keepsContentWhenClosed });
    ui.style(sidebarRef, {
      position: "relative",
      width,
      minWidth: width,
      transition: "width 180ms ease",
      overflow: "hidden",
      ...(side === "left" ? { borderRight: "1px solid currentColor" } : {}),
      ...(side === "right" ? { borderLeft: "1px solid currentColor" } : {}),
    }, { mode: "merge" });
    if (railRef) {
      ui.configureRef(railRef, { part: "sidebar-rail" });
      ui.update(railRef, { hidden: open });
    }
    syncModelRef(ui, stateRef, { open, side });
    options.onOpenChange?.(open);
  };

  if (triggerRef) {
    ui.onAction(triggerRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      open = !open;
      sync();
    });
  }
  sync();
  return {
    open: () => { open = true; sync(); },
    close: () => { open = false; sync(); },
    toggle: () => { open = !open; sync(); },
    getState: () => ({ open }),
  };
}

/**
 * A persistent icon rail plus an independently expandable labeled nav strip,
 * with a main content region that always fills the rest of the width.
 *
 * `createArkSidebar`'s rail and panel are mutually exclusive (one replaces
 * the other). This primitive keeps the rail mounted at all times and only
 * toggles the nav strip beside it — the app-shell pattern most desktop/
 * dashboard products need, where main content never fully hides the rail.
 */
export function createArkAppShell(ui, options) {
  const shellRef = ref(options.shellRef);
  const railRef = ref(options.railRef);
  const navRef = ref(options.navRef);
  const mainRef = ref(options.mainRef);
  const triggerRef = ref(options.triggerRef);
  const stateRef = ref(options.stateRef);
  const railWidth = options.railWidth ?? "72px";
  const navWidth = options.navWidth ?? "224px";
  let expanded = options.expanded ?? true;

  const sync = () => {
    ui.configureRef(shellRef, { part: "app-shell" });
    ui.style(shellRef, {
      display: "grid",
      gridTemplateColumns: navRef ? `${railWidth} ${expanded ? navWidth : "0px"} 1fr` : `${railWidth} 1fr`,
      minHeight: "0",
      height: "100%",
      overflow: "hidden",
      transition: "grid-template-columns 180ms ease",
    }, { mode: "merge" });

    ui.configureRef(railRef, { part: "app-shell-rail" });
    ui.style(railRef, {
      display: "flex",
      flexDirection: "column",
      overflow: "hidden",
      minWidth: "0",
      minHeight: "0",
    }, { mode: "merge" });

    if (navRef) {
      ui.configureRef(navRef, { part: "app-shell-nav" });
      ui.update(navRef, { hidden: !expanded });
      ui.style(navRef, {
        overflow: "hidden",
        minWidth: "0",
        minHeight: "0",
      }, { mode: "merge" });
    }

    ui.configureRef(mainRef, { part: "app-shell-main" });
    ui.style(mainRef, {
      minWidth: "0",
      overflow: "auto",
      height: "100%",
    }, { mode: "merge" });

    syncModelRef(ui, stateRef, { expanded });
    options.onExpandedChange?.(expanded);
  };

  if (triggerRef) {
    ui.onAction(triggerRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      expanded = !expanded;
      sync();
    });
  }
  sync();
  return {
    expand: () => { expanded = true; sync(); },
    collapse: () => { expanded = false; sync(); },
    toggle: () => { expanded = !expanded; sync(); },
    getState: () => ({ expanded }),
  };
}
