import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkSeparatorOptions {
  separatorRef: string;
  orientation?: "horizontal" | "vertical";
  decorative?: boolean;
}

export declare function createArkSeparator(ui: ArkPrimitiveRuntime, options: ArkSeparatorOptions): void;
