/**
 * `createArkChart` — moved out of `ark-ui.components.ts` verbatim (same
 * logic, same call order, same observable behavior). See
 * ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * A native (no charting-library dependency) line/bar/area primitive. Unlike
 * every other primitive in this package, it draws its own `<svg>` subtree
 * with raw DOM calls rather than through `ui.render()`'s pattern-grammar
 * markup — this runtime has no SVG-tag support, and adding it there would be
 * a core-rendering-pipeline change far outside this primitive's blast radius.
 * `containerRef` just needs to exist as a plain element; everything inside it
 * from here on is this function's to own and redraw.
 *
 * Built on `@deadark/ark-a11y` for ref normalization only — everything else
 * here is plain SVG/DOM, not runtime-config wiring — the plan's dependency
 * direction: `ark-primitives -> ark-a11y`.
 */
import { normalizeRef } from "@deadark/ark-a11y/dom";

function ref(value) {
  return normalizeRef(value);
}

const CHART_SVG_NS = "http://www.w3.org/2000/svg";
const CHART_PALETTE = ["#6366f1", "#22c55e", "#f97316", "#ec4899", "#06b6d4", "#a855f7"];

function chartSvgEl(tag, attrs) {
  const el = document.createElementNS(CHART_SVG_NS, tag);
  if (attrs) Object.entries(attrs).forEach(([key, value]) => el.setAttribute(key, String(value)));
  return el;
}

export function createArkChart(ui, options) {
  const containerRef = ref(options.containerRef);
  ui.configureRef(containerRef, { part: "chart" });
  const container = ui.getElement(containerRef);
  const margin = { top: 16, right: 16, bottom: 28, left: 40 };
  const tickCount = Math.max(2, options.tickCount ?? 4);
  const valueFormat = options.valueFormat || ((value) => String(Math.round(value * 100) / 100));
  const categories = options.categories;
  let series = options.series.map((entry, index) => ({ ...entry, color: entry.color || CHART_PALETTE[index % CHART_PALETTE.length] }));
  let width = options.width ?? 480;
  let height = options.height ?? 240;

  if (container.style.position !== "relative" && container.style.position !== "absolute") container.style.position = "relative";

  const svg = chartSvgEl("svg", { role: "img" });
  svg.style.display = "block";
  svg.style.width = "100%";
  svg.style.height = "100%";
  const axesLayer = chartSvgEl("g");
  const seriesLayer = chartSvgEl("g");
  svg.appendChild(axesLayer);
  svg.appendChild(seriesLayer);
  container.appendChild(svg);

  const tooltip = document.createElement("div");
  tooltip.setAttribute("data-ark-part", "chart-tooltip");
  tooltip.style.position = "absolute";
  tooltip.style.pointerEvents = "none";
  tooltip.style.display = "none";
  tooltip.style.transform = "translate(-50%, -100%)";
  // No F-shape schema resolution applies here (this element is never
  // routed through ui.render()), so baseline readability comes from inline
  // styles instead — still fully overridable via a
  // `[data-ark-part="chart-tooltip"]` consumer CSS rule.
  tooltip.style.background = "rgba(15, 15, 20, 0.92)";
  tooltip.style.color = "#fff";
  tooltip.style.font = "12px/1.4 -apple-system, BlinkMacSystemFont, sans-serif";
  tooltip.style.padding = "4px 8px";
  tooltip.style.borderRadius = "4px";
  tooltip.style.whiteSpace = "nowrap";
  container.appendChild(tooltip);

  const showTooltip = (x, y, text) => {
    tooltip.textContent = text;
    tooltip.style.display = "block";
    tooltip.style.left = `${x}px`;
    tooltip.style.top = `${y - 8}px`;
  };
  const hideTooltip = () => { tooltip.style.display = "none"; };

  const measure = () => {
    const rect = container.getBoundingClientRect();
    width = rect.width > 0 ? rect.width : (options.width ?? 480);
    height = rect.height > 0 ? rect.height : (options.height ?? 240);
  };

  const bindHover = (el, seriesIndex, categoryIndex, value, px, py) => {
    el.addEventListener("pointerenter", () => {
      showTooltip(px, py, `${series[seriesIndex].label}: ${valueFormat(value)}`);
      options.onHoverChange?.({ seriesIndex, categoryIndex, value });
    });
    el.addEventListener("pointerleave", () => {
      hideTooltip();
      options.onHoverChange?.(undefined);
    });
  };

  const draw = () => {
    measure();
    svg.setAttribute("viewBox", `0 0 ${width} ${height}`);
    while (axesLayer.firstChild) axesLayer.removeChild(axesLayer.firstChild);
    while (seriesLayer.firstChild) seriesLayer.removeChild(seriesLayer.firstChild);

    const plotWidth = Math.max(1, width - margin.left - margin.right);
    const plotHeight = Math.max(1, height - margin.top - margin.bottom);
    const allValues = series.flatMap((entry) => entry.values);
    const dataMin = Math.min(0, ...(allValues.length ? allValues : [0]));
    const dataMax = Math.max(0, ...(allValues.length ? allValues : [1]));
    const minValue = options.min ?? dataMin;
    const maxValue = options.max ?? (dataMax === minValue ? minValue + 1 : dataMax);

    const yFor = (value) => margin.top + plotHeight - ((value - minValue) / (maxValue - minValue)) * plotHeight;
    const bandWidth = categories.length > 0 ? plotWidth / categories.length : plotWidth;
    const xFor = (categoryIndex) => margin.left + bandWidth * categoryIndex + bandWidth / 2;
    const zeroY = yFor(Math.max(minValue, Math.min(maxValue, 0)));

    for (let tick = 0; tick <= tickCount; tick += 1) {
      const value = minValue + ((maxValue - minValue) * tick) / tickCount;
      const y = yFor(value);
      axesLayer.appendChild(chartSvgEl("line", { x1: margin.left, y1: y, x2: width - margin.right, y2: y, stroke: "currentColor", "stroke-opacity": "0.12" }));
      const label = chartSvgEl("text", { x: margin.left - 8, y: y + 4, "text-anchor": "end", "font-size": "11", fill: "currentColor", opacity: "0.65" });
      label.textContent = valueFormat(value);
      axesLayer.appendChild(label);
    }
    categories.forEach((category, index) => {
      const label = chartSvgEl("text", { x: xFor(index), y: height - margin.bottom + 18, "text-anchor": "middle", "font-size": "11", fill: "currentColor", opacity: "0.65" });
      label.textContent = category;
      axesLayer.appendChild(label);
    });
    axesLayer.appendChild(chartSvgEl("line", { x1: margin.left, y1: zeroY, x2: width - margin.right, y2: zeroY, stroke: "currentColor", "stroke-opacity": "0.3" }));

    if (options.type === "bar") {
      const groupPadding = bandWidth * 0.2;
      const barAreaWidth = Math.max(0, bandWidth - groupPadding * 2);
      const barWidth = series.length > 0 ? barAreaWidth / series.length : barAreaWidth;
      series.forEach((entry, seriesIndex) => {
        entry.values.forEach((value, categoryIndex) => {
          const barX = margin.left + bandWidth * categoryIndex + groupPadding + barWidth * seriesIndex;
          const valueY = yFor(value);
          const barY = Math.min(zeroY, valueY);
          const barHeight = Math.max(0, Math.abs(zeroY - valueY));
          const rect = chartSvgEl("rect", { x: barX, y: barY, width: Math.max(0, barWidth - 2), height: barHeight, fill: entry.color });
          seriesLayer.appendChild(rect);
          bindHover(rect, seriesIndex, categoryIndex, value, barX + barWidth / 2, barY);
        });
      });
    } else {
      series.forEach((entry, seriesIndex) => {
        const points = entry.values.map((value, categoryIndex) => [xFor(categoryIndex), yFor(value)]);
        if (options.type === "area" && points.length > 0) {
          const pathData = `M ${points[0][0]} ${zeroY} ` + points.map(([x, y]) => `L ${x} ${y}`).join(" ") + ` L ${points[points.length - 1][0]} ${zeroY} Z`;
          seriesLayer.appendChild(chartSvgEl("path", { d: pathData, fill: entry.color, "fill-opacity": "0.18", stroke: "none" }));
        }
        if (points.length > 0) {
          const lineData = points.map(([x, y], index) => `${index === 0 ? "M" : "L"} ${x} ${y}`).join(" ");
          seriesLayer.appendChild(chartSvgEl("path", { d: lineData, fill: "none", stroke: entry.color, "stroke-width": "2" }));
        }
        points.forEach(([x, y], categoryIndex) => {
          const marker = chartSvgEl("circle", { cx: x, cy: y, r: 3.5, fill: entry.color });
          seriesLayer.appendChild(marker);
          bindHover(marker, seriesIndex, categoryIndex, entry.values[categoryIndex], x, y);
        });
      });
    }
  };

  draw();

  return {
    setSeries: (nextSeries) => {
      series = nextSeries.map((entry, index) => ({ ...entry, color: entry.color || CHART_PALETTE[index % CHART_PALETTE.length] }));
      draw();
    },
    resize: draw,
    getState: () => ({ width, height }),
  };
}
