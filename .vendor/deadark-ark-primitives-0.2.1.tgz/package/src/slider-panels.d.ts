import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkSliderOptions {
  trackRef: string;
  thumbRef: string;
  valueRef?: string;
  min?: number;
  max?: number;
  step?: number;
  value?: number;
  orientation?: "horizontal" | "vertical";
  disabled?: boolean;
  stateRef?: string;
  onValueChange?: (value: number) => void;
}

export interface ArkSliderHandle {
  setValue: (value: number) => void;
  getState: () => { value: number; min: number; max: number };
}

export declare function createArkSlider(ui: ArkPrimitiveRuntime, options: ArkSliderOptions): ArkSliderHandle;

export interface ArkResizablePanelsOptions {
  containerRef: string;
  panelRefs: string[];
  /** One fewer than `panelRefs` — the handle between each adjacent pair. */
  handleRefs: string[];
  orientation?: "horizontal" | "vertical";
  /** Each panel's share of the container (0-1), summing to 1. Defaults to
   * an equal split. */
  sizes?: number[];
  /** Per-panel minimum share (0-1). Defaults to 0.05 for every panel. */
  minSizes?: number[];
  stateRef?: string;
  onSizesChange?: (sizes: number[]) => void;
}

export interface ArkResizablePanelsHandle {
  setSizes: (sizes: number[]) => void;
  getState: () => { sizes: number[] };
}

export declare function createArkResizablePanels(ui: ArkPrimitiveRuntime, options: ArkResizablePanelsOptions): ArkResizablePanelsHandle;
