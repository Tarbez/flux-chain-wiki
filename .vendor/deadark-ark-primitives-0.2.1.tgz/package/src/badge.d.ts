import type { ArkPrimitiveRuntime } from "./runtime.js";

/** What a badge may assert about its holder (AGENTS.md: badges must mean something real). */
export type ArkBadgeMeaning = "identity" | "credibility" | "affinity" | "role" | "participation" | "contribution";

/** The SDK semantic token each meaning paints with (`hsl(var(--<token>))`). */
export declare const ARK_BADGE_MEANING_TOKENS: Readonly<Record<ArkBadgeMeaning, "badge" | "trust" | "role" | "live" | "reference">>;
export declare const ARK_BADGE_MEANINGS: readonly ArkBadgeMeaning[];

/** Returns `meaning` when valid; throws a refusal naming the six meanings otherwise. */
export declare function resolveArkBadgeMeaning(meaning: unknown): ArkBadgeMeaning;

export interface ArkBadgeOptions {
  rootRef: string;
  /** Required. A badge with no meaning is refused. */
  meaning: ArkBadgeMeaning;
  labelRef?: string;
  /** Longer explanation of what the badge asserts; wired as aria-describedby. */
  descriptionRef?: string;
  stateRef?: string;
}

export interface ArkBadgeHandle {
  setMeaning: (meaning: ArkBadgeMeaning) => void;
  getState: () => { meaning: ArkBadgeMeaning; token: string };
}

export declare function createArkBadge(ui: ArkPrimitiveRuntime, options: ArkBadgeOptions): ArkBadgeHandle;
