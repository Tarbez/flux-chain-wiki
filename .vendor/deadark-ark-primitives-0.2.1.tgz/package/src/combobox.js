/**
 * `createArkCombobox` and `createArkCommandSurface` — moved out of
 * `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * One module because `createArkCommandSurface` is a thin configuration of
 * `createArkCombobox` — a command palette is a combobox whose "filter as you
 * type" behavior is the whole point and whose selection commits an action
 * rather than a form value — not an independent implementation.
 *
 * Built on `@deadark/ark-a11y` for ref normalization, attribute wiring,
 * roving focus, and overlay open/close sequencing — the plan's dependency
 * direction: `ark-primitives -> ark-a11y`.
 */
import { normalizeRef, normalizeRefs, setAttrs, setHidden, syncModelRef, textOf } from "@deadark/ark-a11y/dom";
import { setOverlayOpen } from "@deadark/ark-a11y/overlay";

function ref(value) {
  return normalizeRef(value);
}

export function createArkCombobox(ui, options) {
  const inputRef = ref(options.inputRef);
  const contentRef = ref(options.contentRef);
  const labelRef = ref(options.labelRef);
  const descriptionRef = ref(options.descriptionRef);
  const stateRef = ref(options.stateRef);
  const emptyRef = ref(options.emptyRef);
  const triggerRef = ref(options.triggerRef);
  const clearRef = ref(options.clearRef);
  const optionRefs = options.optionRefs.map((value) => ref(value));
  const disabledRefs = new Set((options.disabledOptionRefs || []).map((value) => ref(value)));
  const initialActiveRef = ref(options.initialActiveRef) || optionRefs[0];
  const collectionId = `${contentRef}-collection`;
  const optionLabels = new Map();
  const groups = (options.groups || []).map((group) => ({
    groupRef: ref(group.groupRef),
    labelRef: ref(group.labelRef),
    optionRefs: group.optionRefs.map((value) => ref(value)),
  }));
  let activeRef = ref(options.selectedRef) || initialActiveRef;
  let committedRef = ref(options.selectedRef) || initialActiveRef;
  let inputValue = "";
  let open = false;
  const setComboboxOpen = (nextOpen) => {
    if (options.disabled) nextOpen = false;
    if (open === nextOpen) {
      setOverlayOpen(ui, inputRef, contentRef, nextOpen);
      return;
    }
    open = nextOpen;
    setOverlayOpen(ui, inputRef, contentRef, nextOpen);
    options.onOpenChange?.(nextOpen);
  };
  const visibleRefs = () => optionRefs.filter((optionRef) => {
    const current = ui.get(optionRef);
    return !current?.hidden && !current?.disabled;
  });
  const syncState = () => syncModelRef(ui, stateRef, {
    open,
    committedRef,
    committedText: optionLabels.get(committedRef) || textOf(ui, committedRef),
    highlightedRef: activeRef,
    inputValue,
    visibleRefs: visibleRefs(),
    disabledOptionRefs: [...disabledRefs],
  });

  const setActive = (nextRef) => {
    const nextState = nextRef ? ui.get(nextRef) : undefined;
    if (activeRef === nextRef && (!nextRef || nextState?.selected === true)) {
      syncState();
      return;
    }
    activeRef = nextRef;
    const raw = ui.get(inputRef);
    const inputState = raw && typeof raw === "object" ? raw : {};
    ui.update(inputRef, { ...inputState, activeDescendant: nextRef, open });
    optionRefs.forEach((optionRef) => {
      const current = ui.get(optionRef) || {};
      ui.update(optionRef, { ...current, selected: optionRef === nextRef, disabled: disabledRefs.has(optionRef) });
    });
    syncState();
    options.onHighlightChange?.(nextRef);
  };

  const commit = (nextRef, sourceEl) => {
    if (disabledRefs.has(nextRef)) return;
    const inputEl = ui.getElement(inputRef);
    const label = optionLabels.get(nextRef) || textOf(ui, nextRef);
    committedRef = nextRef;
    inputValue = label;
    if (sourceEl) sourceEl.value = label;
    if (inputEl) inputEl.value = label;
    const raw = ui.get(inputRef);
    const current = raw && typeof raw === "object" ? raw : {};
    ui.update(inputRef, { ...current, text: label, activeDescendant: nextRef, open: false });
    setComboboxOpen(false);
    syncState();
    options.onValueChange?.(nextRef, label);
  };

  const filterOptions = (query) => {
    inputValue = query;
    // The browser's native input already owns the in-progress query. Updating
    // the rendered ref here replaces its DOM node; during real keyboard input
    // that detaches the key target after the first character and loses the
    // remainder of the sequence. Keep the node stable and publish the query
    // through the combobox state model below instead.
    const normalized = query.trim().toLowerCase();
    let firstVisible;
    optionRefs.forEach((optionRef) => {
      const label = optionLabels.get(optionRef) || textOf(ui, optionRef);
      const matches = !disabledRefs.has(optionRef) && (options.filter ? options.filter(query, label, optionRef) : label.toLowerCase().includes(normalized));
      const hidden = normalized.length > 0 && !matches;
      const current = ui.get(optionRef) || {};
      ui.update(optionRef, { ...current, hidden });
      if (!hidden && !firstVisible) firstVisible = optionRef;
    });
    groups.forEach((group) => {
      const groupHasVisible = group.optionRefs.some((optionRef) => !ui.get(optionRef)?.hidden);
      setHidden(ui, group.groupRef, !groupHasVisible);
    });
    setHidden(ui, emptyRef, !!firstVisible);
    setActive(firstVisible);
    setComboboxOpen(normalized.length > 0 || !!firstVisible);
    syncState();
    options.onInputValueChange?.(query);
  };

  ui.configureRef(inputRef, {
    role: "combobox",
    part: "combobox-input",
    controls: contentRef,
    hasPopup: "listbox",
    labelledBy: labelRef,
    describedBy: descriptionRef,
    activeDescendant: initialActiveRef,
  });
  ui.configureRef(inputRef, { attrs: { disabled: options.disabled ? "" : undefined, readonly: options.readOnly ? "" : undefined, required: options.required ? "" : undefined, name: options.name, form: options.form, "aria-invalid": options.invalid ? "true" : undefined, "data-disabled": options.disabled ? "true" : undefined, "data-readonly": options.readOnly ? "true" : undefined, "data-required": options.required ? "true" : undefined, "data-invalid": options.invalid ? "true" : undefined } });
  ui.configureRef(contentRef, {
    role: "listbox",
    part: "combobox-popup",
    labelledBy: labelRef,
    describedBy: descriptionRef,
    overlay: {
      anchorRef: inputRef,
      portal: options.portal ?? "layers",
      placement: options.placement ?? "bottom",
      fallbackPlacements: options.placement === "left" || options.placement === "right" ? ["bottom", "top"] : ["top", "right", "left"],
      align: options.align ?? "start",
      offset: 6,
      collisionPadding: 12,
      sameWidth: true,
      sticky: true,
    },
  });
  optionRefs.forEach((optionRef) => {
    ui.configureRef(optionRef, { role: "option", collection: collectionId, part: "combobox-option" });
    if (disabledRefs.has(optionRef)) {
      const current = ui.get(optionRef) || {};
      ui.update(optionRef, { ...current, disabled: true });
    }
    ui.bindRefEvent(optionRef, "focus", () => setActive(optionRef));
  });
  groups.forEach((group) => {
    ui.configureRef(group.groupRef, { role: "group", labelledBy: group.labelRef, part: "combobox-group" });
  });
  if (emptyRef) {
    ui.configureRef(emptyRef, { part: "empty-state" });
    setHidden(ui, emptyRef, true);
  }
  if (triggerRef) {
    ui.configureRef(triggerRef, { controls: contentRef, hasPopup: "listbox", part: "combobox-trigger" });
    ui.onAction(triggerRef, (_ref, detail) => {
      if (detail.action !== "CLICK" || options.disabled || options.readOnly) return;
      const nextOpen = !open;
      setComboboxOpen(nextOpen);
      if (nextOpen) setActive(activeRef);
    });
  }
  if (clearRef) {
    ui.configureRef(clearRef, { part: "combobox-clear" });
    ui.onAction(clearRef, (_ref, detail) => {
      if (detail.action !== "CLICK" || options.disabled || options.readOnly) return;
      const inputEl = ui.getElement(inputRef);
      if (inputEl) inputEl.value = "";
      const inputState = ui.get(inputRef);
      ui.update(inputRef, { ...(inputState && typeof inputState === "object" ? inputState : {}), text: "" });
      filterOptions("");
      setComboboxOpen(false);
    });
  }
  ui.createRovingFocusGroup(collectionId, { refs: optionRefs, orientation: "vertical", loop: true, typeahead: true });
  ui.createDismissableLayer(contentRef, {
    containerRef: contentRef,
    branchRefs: [inputRef],
    restoreFocusRef: inputRef,
    outsidePointer: true,
    outsideFocus: true,
    escapeKey: true,
  });
  ui.createPresence(contentRef, { unmountOnExit: true });
  optionRefs.forEach((optionRef) => optionLabels.set(optionRef, textOf(ui, optionRef)));
  optionRefs.forEach((optionRef) => ui.onAction(optionRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    if (disabledRefs.has(optionRef)) return;
    commit(optionRef);
  }));
  ui.onAction(contentRef, () => {
    setComboboxOpen(false);
    syncState();
  });
  ui.bindRefEvent(inputRef, "input", (_event, el) => {
    if (options.disabled || options.readOnly) return;
    filterOptions(el.value);
  });
  ui.bindRefEvent(inputRef, "keydown", (rawEvent) => {
    if (options.disabled || options.readOnly) return;
    const event = rawEvent;
    const visible = visibleRefs();
    if (visible.length === 0 && event.key !== "Escape") return;
    const currentIndex = activeRef ? visible.indexOf(activeRef) : -1;
    if (event.key === "ArrowDown") {
      event.preventDefault();
      setActive(visible[Math.min(currentIndex + 1, visible.length - 1)] || visible[0]);
      setComboboxOpen(true);
    } else if (event.key === "ArrowUp") {
      event.preventDefault();
      setActive(visible[Math.max(currentIndex - 1, 0)] || visible[0]);
      setComboboxOpen(true);
    } else if (event.key === "Enter" && activeRef) {
      event.preventDefault();
      commit(activeRef, rawEvent.currentTarget);
    } else if (event.key === "Escape") {
      event.preventDefault();
      const currentInput = rawEvent.currentTarget;
      const committedLabel = optionLabels.get(committedRef) || textOf(ui, committedRef);
      inputValue = committedLabel;
      if (currentInput) currentInput.value = committedLabel;
      const raw = ui.get(inputRef);
      const current = raw && typeof raw === "object" ? raw : {};
      ui.update(inputRef, { ...current, text: committedLabel, activeDescendant: committedRef, open: false });
      setActive(committedRef);
      setComboboxOpen(false);
      syncState();
    }
  });
  ui.bindRefEvent(inputRef, "focus", () => {
    if (options.disabled || options.readOnly || options.openOnFocus === false) return;
    const current = ui.get(inputRef);
    if (current?.open && current.activeDescendant === activeRef) return;
    setComboboxOpen(true);
    setActive(activeRef);
    syncState();
  });
  ui.bindRefEvent(inputRef, "click", () => {
    if (options.openOnInputClick !== true || options.disabled || options.readOnly) return;
    setComboboxOpen(true);
    setActive(activeRef);
  });
  const initialLabel = optionLabels.get(committedRef) || textOf(ui, committedRef);
  inputValue = initialLabel;
  const inputCurrent = ui.get(inputRef);
  if (initialLabel) ui.update(inputRef, { ...(inputCurrent && typeof inputCurrent === "object" ? inputCurrent : {}), text: initialLabel, activeDescendant: committedRef });
  setActive(activeRef);
  syncState();
  return {
    open: () => {
      if (options.disabled || options.readOnly) return;
      setComboboxOpen(true);
      setActive(activeRef);
      syncState();
    },
    close: () => {
      setComboboxOpen(false);
      syncState();
    },
    clear: () => {
      if (options.disabled || options.readOnly) return;
      const inputEl = ui.getElement(inputRef);
      if (inputEl) inputEl.value = "";
      inputValue = "";
      const inputState = ui.get(inputRef);
      ui.update(inputRef, { ...(inputState && typeof inputState === "object" ? inputState : {}), text: "" });
      filterOptions("");
      setComboboxOpen(false);
      syncState();
    },
    highlight: (nextRef) => {
      const normalized = nextRef ? ref(nextRef) : undefined;
      setActive(normalized);
    },
    select: (nextRef) => {
      const normalized = ref(nextRef);
      if (!normalized) return;
      commit(normalized);
    },
    setQuery: (value) => {
      const inputEl = ui.getElement(inputRef);
      if (inputEl) inputEl.value = value;
      filterOptions(value);
    },
    getState: () => ({
      open,
      committedRef,
      committedText: optionLabels.get(committedRef) || textOf(ui, committedRef),
      highlightedRef: activeRef,
      inputValue,
      visibleRefs: visibleRefs(),
    }),
  };
}

export function createArkCommandSurface(ui, options) {
  const inputRef = ref(options.inputRef);
  const contentRef = ref(options.contentRef);
  const emptyRef = ref(options.emptyRef);
  const loadingRef = ref(options.loadingRef);
  const optionRefs = normalizeRefs(options.optionRefs);
  let loading = !!options.loading;

  const syncAuxiliary = () => {
    const visibleOptions = optionRefs.filter((optionRef) => !ui.get(optionRef)?.hidden);
    setHidden(ui, loadingRef, !loading);
    setHidden(ui, emptyRef, loading || visibleOptions.length > 0);
  };

  const combobox = createArkCombobox(ui, {
    inputRef,
    contentRef,
    optionRefs,
    labelRef: options.labelRef,
    descriptionRef: options.descriptionRef,
    selectedRef: options.selectedRef,
    openOnFocus: options.openOnFocus,
    filter: options.filter,
    onValueChange: (selectedRef, value) => {
      syncAuxiliary();
      options.onCommand?.(selectedRef, value);
    },
    onInputValueChange: (value) => {
      syncAuxiliary();
      options.onQueryChange?.(value);
    },
  });
  ui.configureRef(contentRef, { part: "command-surface" });
  optionRefs.forEach((optionRef) => ui.configureRef(optionRef, { part: "command-item" }));
  syncAuxiliary();
  // Additive (ARK_UI_EVOLUTION_PLAN.md Batch 5 / Core Components): previously
  // this function had no return value at all, so nothing could open/close/
  // query a command surface from outside a click on its own trigger. Handing
  // back the underlying combobox handle is a pure addition -- every existing
  // caller that ignores the return value keeps working unchanged -- and it's
  // what `createArkCoreCommandPalette()` needs to open the surface from a
  // global keyboard shortcut.
  return combobox;
}
