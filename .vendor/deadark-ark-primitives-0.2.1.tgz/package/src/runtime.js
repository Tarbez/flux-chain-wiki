/**
 * Types-only module. `ArkPrimitiveRuntime` (see runtime.d.ts) is the single
 * structural declaration of the ARK UI runtime surface every primitive family
 * in this package composes against, so the families don't each re-derive it
 * and can't drift apart on what they assume the host provides.
 *
 * It is deliberately *declared*, not imported from `@deadark/ark-ui`: the
 * evolution plan's dependency direction is `ark-primitives -> ark-a11y`, never
 * back to `ark-ui`. The object `createArkUI()` returns satisfies this shape
 * structurally today with no adapter code at the call site.
 */
export {};
