/**
 * `createArkBadge` -- a badge that must mean something real.
 *
 * Dead Ark law (AGENTS.md, "Badges must mean something real"): a badge states
 * identity, credibility, affinity, role, participation or meaningful
 * contribution. It is never decoration and never streak pressure. That is
 * enforced by structure, not by a list of banned words: the factory accepts
 * only the six meanings below and refuses anything else, so a decorative
 * badge cannot be built through it.
 *
 * Each meaning paints with one SDK semantic token (`hsl(var(--<token>))`),
 * matching `@deadark/sdk/theme`'s `.dak-sdk-badge--<token>` classes and its
 * `DEADARK_BADGE_MEANINGS` (the SDK test proves the two tables agree).
 * Unstyled, like every primitive here: it wires the part, the meaning and the
 * accessible description; the consumer's CSS reads `data-meaning`.
 */
import { normalizeRef, setAttrs, syncModelRef } from "@deadark/ark-a11y/dom";

export const ARK_BADGE_MEANING_TOKENS = Object.freeze({
  identity: "badge",
  credibility: "trust",
  affinity: "badge",
  role: "role",
  participation: "live",
  contribution: "reference",
});

export const ARK_BADGE_MEANINGS = Object.freeze(Object.keys(ARK_BADGE_MEANING_TOKENS));

export function resolveArkBadgeMeaning(meaning) {
  if (Object.prototype.hasOwnProperty.call(ARK_BADGE_MEANING_TOKENS, meaning)) return meaning;
  const failure = meaning === undefined || meaning === null || meaning === ""
    ? "no meaning was given"
    : `"${String(meaning)}" is not a badge meaning`;
  throw new Error(
    `createArkBadge refused: ${failure}. Badges must mean something real. ` +
    `Needs options.meaning as one of: ${ARK_BADGE_MEANINGS.join(", ")}. ` +
    "Remedy: name what the badge asserts about its holder; if it asserts none of these, " +
    "it is decoration, so use plain text (META/LABEL) instead of a badge.",
  );
}

export function createArkBadge(ui, options) {
  const rootRef = normalizeRef(options.rootRef);
  const labelRef = normalizeRef(options.labelRef);
  const descriptionRef = normalizeRef(options.descriptionRef);
  let meaning = resolveArkBadgeMeaning(options.meaning);
  const sync = () => {
    ui.configureRef(rootRef, { part: "badge", describedBy: descriptionRef });
    setAttrs(ui, rootRef, {
      "data-meaning": meaning,
      "data-meaning-token": ARK_BADGE_MEANING_TOKENS[meaning],
    });
    if (labelRef) ui.configureRef(labelRef, { part: "badge-label" });
    if (descriptionRef) ui.configureRef(descriptionRef, { part: "badge-description" });
    syncModelRef(ui, normalizeRef(options.stateRef), { meaning, token: ARK_BADGE_MEANING_TOKENS[meaning] });
  };
  sync();
  return {
    setMeaning(next) {
      meaning = resolveArkBadgeMeaning(next);
      sync();
    },
    getState: () => ({ meaning, token: ARK_BADGE_MEANING_TOKENS[meaning] }),
  };
}
