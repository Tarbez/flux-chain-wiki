/**
 * `createArkMenubar` and `createArkMegaMenu` — the two horizontal trigger-bar
 * members of the menu family — moved out of `ark-ui.components.ts` verbatim
 * (same logic, same call order, same observable behavior, comments included).
 * See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * They sit beside `./menu.js` rather than inside it because what they share
 * with a plain menu is the *strip*, not the popup: both register a horizontal,
 * non-typeahead-by-default roving group over their triggers via
 * `@deadark/ark-a11y/collection`'s `configureStripFocusGroup()`, and both drive
 * open state through `@deadark/ark-a11y/overlay`'s `setOverlayOpen()`. A
 * menubar's panels *are* menus, so it composes `createArkMenu` per trigger; a
 * mega menu's panels are arbitrary navigation markup, so it wires its own
 * dismissable layer and presence instead (see the comment above
 * `createArkMegaMenu`, which is the original and still the authoritative
 * explanation of that difference).
 */
import { normalizeRef, normalizeRefs, setAttrs, syncModelRef } from "@deadark/ark-a11y/dom";
import { configureStripFocusGroup } from "@deadark/ark-a11y/collection";
import { configureDismissableLayer, configurePresence, setOverlayOpen } from "@deadark/ark-a11y/overlay";
import { createArkMenu } from "./menu.js";

function ref(value) {
  return normalizeRef(value);
}

export function createArkMenubar(ui, options) {
  const rootRef = ref(options.rootRef);
  const menus = options.menus.map((menu) => ({
    triggerRef: ref(menu.triggerRef),
    contentRef: ref(menu.contentRef),
    itemRefs: normalizeRefs(menu.itemRefs),
    disabledItemRefs: normalizeRefs(menu.disabledItemRefs || []),
    labelRef: ref(menu.labelRef),
    descriptionRef: ref(menu.descriptionRef),
    initialFocusRef: ref(menu.initialFocusRef),
  }));
  const triggerRefs = menus.map((menu) => menu.triggerRef);
  const menuByTrigger = new Map(menus.map((menu) => [menu.triggerRef, menu]));
  const handles = new Map();
  const collectionId = `${rootRef}-menubar`;
  let selectedRef = ref(options.activeRef) || triggerRefs[0];

  const selectedIndex = () => Math.max(0, triggerRefs.indexOf(selectedRef));
  const isOpen = (triggerRef) => {
    const menu = menuByTrigger.get(triggerRef);
    if (!menu) return false;
    const state = ui.get(menu.contentRef);
    return !!state && typeof state === "object" && state.open === true;
  };
  const syncState = () => {
    triggerRefs.forEach((triggerRef) => {
      setAttrs(ui, triggerRef, {
        "aria-current": triggerRef === selectedRef ? "page" : undefined,
        "aria-expanded": isOpen(triggerRef) ? "true" : "false",
      });
    });
    syncModelRef(ui, ref(options.stateRef), {
      selectedRef,
      selectedIndex: selectedIndex(),
      open: isOpen(selectedRef),
      triggerRefs: [...triggerRefs],
    });
    options.onValueChange?.(selectedRef, selectedIndex());
  };
  const closeOtherMenus = (exceptTriggerRef) => {
    menus.forEach((menu) => {
      if (menu.triggerRef === exceptTriggerRef) return;
      handles.get(menu.triggerRef)?.close();
    });
  };
  const selectRef = (target) => {
    const nextRef = typeof target === "number" ? triggerRefs[target] : ref(target);
    if (!nextRef || !menuByTrigger.has(nextRef)) return;
    selectedRef = nextRef;
    syncState();
  };
  const openRef = (target) => {
    const targetRef = typeof target === "undefined"
      ? selectedRef
      : typeof target === "number"
        ? triggerRefs[target]
        : ref(target);
    if (!targetRef || !menuByTrigger.has(targetRef)) return;
    const menu = menuByTrigger.get(targetRef);
    if (!menu) return;
    closeOtherMenus(targetRef);
    selectedRef = targetRef;
    handles.get(targetRef)?.open();
    syncState();
  };
  const closeCurrent = () => {
    handles.get(selectedRef)?.close();
    syncState();
  };
  const moveSelection = (delta) => {
    const count = triggerRefs.length;
    if (count === 0) return;
    const currentIndex = selectedIndex();
    let nextIndex = currentIndex + delta;
    if (options.loop ?? true) nextIndex = (nextIndex + count) % count;
    else nextIndex = Math.max(0, Math.min(nextIndex, count - 1));
    selectRef(nextIndex);
    ui.getElement(selectedRef)?.focus?.();
  };
  const moveOpenMenu = (delta) => {
    const wasOpen = isOpen(selectedRef);
    moveSelection(delta);
    if (wasOpen) openRef(selectedRef);
  };

  ui.configureRef(rootRef, { part: "menubar", role: "menubar", orientation: "horizontal" });
  configureStripFocusGroup(ui, collectionId, triggerRefs, { loop: options.loop, typeahead: true });

  menus.forEach((menu) => {
    handles.set(menu.triggerRef, createArkMenu(ui, {
      triggerRef: menu.triggerRef,
      contentRef: menu.contentRef,
      itemRefs: menu.itemRefs,
      disabledItemRefs: menu.disabledItemRefs,
      labelRef: menu.labelRef,
      descriptionRef: menu.descriptionRef,
      initialFocusRef: menu.initialFocusRef,
    }));
    ui.configureRef(menu.triggerRef, { role: "menuitem", collection: collectionId, hasPopup: "menu", controls: menu.contentRef });
    ui.bindRefEvent(menu.triggerRef, "focus", () => {
      selectedRef = menu.triggerRef;
    });
    ui.bindRefEvent(menu.triggerRef, "keydown", (rawEvent) => {
      const event = rawEvent;
      if (event.key === "Enter" || event.key === " ") {
        event.preventDefault();
        openRef(menu.triggerRef);
      } else if (event.key === "ArrowRight") {
        event.preventDefault();
        moveSelection(1);
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        moveSelection(-1);
      } else if (event.key === "Home") {
        event.preventDefault();
        selectRef(0);
        ui.getElement(selectedRef)?.focus?.();
      } else if (event.key === "End") {
        event.preventDefault();
        selectRef(triggerRefs.length - 1);
        ui.getElement(selectedRef)?.focus?.();
      }
    });
    ui.onAction(menu.triggerRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      selectedRef = menu.triggerRef;
      closeOtherMenus(menu.triggerRef);
      syncState();
    });
    const handleMenuKey = (rawEvent) => {
      const event = rawEvent;
      if (event.key === "ArrowRight") {
        event.preventDefault();
        moveOpenMenu(1);
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        moveOpenMenu(-1);
      } else if (event.key === "Escape") {
        event.preventDefault();
        closeCurrent();
        ui.getElement(menu.triggerRef)?.focus?.();
      }
    };
    ui.bindRefEvent(menu.contentRef, "keydown", handleMenuKey);
    menu.itemRefs.forEach((itemRef) => ui.bindRefEvent(itemRef, "keydown", handleMenuKey));
  });

  syncState();
  return {
    open: openRef,
    close: closeCurrent,
    select: selectRef,
    getState: () => ({ selectedRef, selectedIndex: selectedIndex(), open: isOpen(selectedRef) }),
  };
}

// Mega Menu: a horizontal trigger bar (like Menubar) whose panels hold
// arbitrary rich content -- link columns, a promo card, whatever -- instead
// of Menu's flat itemRefs list. That's the one real behavioral difference
// from createArkMenubar: panels get a plain dismissable layer + focus scope
// (normal Tab order inside), not a roving-focus "menu"/"menuitem" collection,
// because mega-menu panels are site navigation, not an application menu.
export function createArkMegaMenu(ui, options) {
  const rootRef = ref(options.rootRef);
  const items = options.items.map((item) => ({
    triggerRef: ref(item.triggerRef),
    contentRef: ref(item.contentRef),
    disabled: !!item.disabled,
  }));
  const triggerRefs = items.map((item) => item.triggerRef);
  const itemByTrigger = new Map(items.map((item) => [item.triggerRef, item]));
  const collectionId = `${rootRef}-mega-menu`;
  const stateRef = ref(options.stateRef);
  const loop = options.loop ?? true;
  const openOnHover = options.openOnHover ?? true;
  const hoverOpenDelay = options.hoverOpenDelay ?? 120;
  const hoverCloseDelay = options.hoverCloseDelay ?? 220;

  let openTriggerRef = null;
  let hoverTimer;
  // Every configureRef/update on a trigger swaps in a brand-new element (see
  // the FLIP-transition comment on replaceBoundElement), and a browser fires
  // a fresh pointerenter on whatever element now sits under a *stationary*
  // cursor once the old one is swapped out from under it -- no real mouse
  // movement required. aria-expanded syncing alone replaces triggers often
  // enough that a user who opens a panel and never moves the mouse keeps
  // rescheduling scheduleOpen()'s timer for as long as they stay put. Left
  // unchecked, that stale timer eventually fires and silently reopens a
  // panel the user just dismissed with Escape or an outside click, seconds
  // later, for no visible reason. A trigger enters this set only when it
  // closes *while the pointer is actually over it* (hoveringItems below is
  // the source of truth for that -- closing via keyboard from clear across
  // the bar must not suppress a first-ever hover later), and only leaves it
  // on a genuine pointerleave, so spurious replace-triggered re-enters keep
  // getting ignored until the user actually moves the mouse away and back.
  const suppressedHoverTriggers = new Set();
  // True real-time pointer presence, independent of suppression -- used only
  // to decide, at close time, whether there is actually a stale timer worth
  // guarding against.
  const hoveringItems = new Set();

  const clearHoverTimer = () => {
    if (hoverTimer === undefined) return;
    clearTimeout(hoverTimer);
    hoverTimer = undefined;
  };
  const openIndex = () => (openTriggerRef ? triggerRefs.indexOf(openTriggerRef) : -1);
  const syncState = () => {
    triggerRefs.forEach((triggerRef) => {
      setAttrs(ui, triggerRef, { "aria-expanded": triggerRef === openTriggerRef ? "true" : "false" });
    });
    syncModelRef(ui, stateRef, { openRef: openTriggerRef, openIndex: openIndex(), triggerRefs: [...triggerRefs] });
    options.onValueChange?.(openTriggerRef, openIndex());
  };
  const closeAll = (exceptTriggerRef) => {
    items.forEach((item) => {
      if (item.triggerRef === exceptTriggerRef) return;
      setOverlayOpen(ui, item.triggerRef, item.contentRef, false);
    });
  };
  const closeCurrent = () => {
    if (!openTriggerRef) return;
    if (hoveringItems.has(openTriggerRef)) suppressedHoverTriggers.add(openTriggerRef);
    closeAll();
    openTriggerRef = null;
    syncState();
  };
  const openTarget = (target) => {
    const triggerRef = typeof target === "number" ? triggerRefs[target] : ref(target);
    if (!triggerRef) return;
    const item = itemByTrigger.get(triggerRef);
    if (!item || item.disabled) return;
    clearHoverTimer();
    // Already the open item: nothing to do. Without this guard, hover-intent
    // firing on a panel a click already opened (Playwright's .click() -- and
    // a real mouse dragged from elsewhere -- crosses the trigger and fires
    // pointerenter before the click lands) replays the full open sequence.
    // The focus scope is still marked active from the first open, so its
    // re-render-triggered activateFocusScope() call no-ops instead of
    // refocusing, and the panel's freshly re-rendered content detaches the
    // element that actually had focus. Nothing refocuses it, so focus falls
    // back to <body> and Escape/outside-focus dismissal stop working.
    if (openTriggerRef === triggerRef) return;
    closeAll(triggerRef);
    openTriggerRef = triggerRef;
    // aria-expanded goes out *before* setOverlayOpen so the trigger element it
    // replaces (every configureRef call re-renders its node) is settled
    // before setOverlayOpen's own update() opens the overlay and activates the
    // focus scope. Swap the order and the focus scope captures a trigger
    // node syncState is about to detach out from under it -- Escape/close
    // then calls .focus() on a node that is no longer in the document, and
    // focus silently falls back to <body> instead of returning to the
    // trigger.
    syncState();
    setOverlayOpen(ui, item.triggerRef, item.contentRef, true);
  };
  const toggleTarget = (target) => {
    const triggerRef = typeof target === "number" ? triggerRefs[target] : ref(target);
    if (!triggerRef) return;
    if (openTriggerRef === triggerRef) closeCurrent();
    else openTarget(triggerRef);
  };
  const moveSelection = (delta) => {
    const count = triggerRefs.length;
    if (count === 0) return;
    const currentIndex = Math.max(0, openIndex());
    let nextIndex = currentIndex + delta;
    if (loop) nextIndex = (nextIndex + count) % count;
    else nextIndex = Math.max(0, Math.min(nextIndex, count - 1));
    const wasOpen = !!openTriggerRef;
    ui.getElement(triggerRefs[nextIndex])?.focus?.();
    if (wasOpen) openTarget(nextIndex);
  };

  ui.configureRef(rootRef, { part: "mega-menu", role: "navigation" });
  configureStripFocusGroup(ui, collectionId, triggerRefs, { loop, typeahead: false });

  items.forEach((item) => {
    ui.configureRef(item.triggerRef, {
      role: "button",
      collection: collectionId,
      controls: item.contentRef,
      hasPopup: true,
    });
    if (item.disabled) ui.update(item.triggerRef, { disabled: true });
    ui.configureRef(item.contentRef, {
      overlay: {
        anchorRef: item.triggerRef,
        portal: "layers",
        placement: options.placement ?? "bottom",
        fallbackPlacements: ["top"],
        align: options.align ?? "start",
        offset: 8,
        collisionPadding: 12,
        // No focusScope here (unlike Menu/Popover/Dialog): a mega-menu panel
        // opens on plain pointer hover far more often than click, and
        // auto-stealing keyboard focus into panel content on every hover
        // would yank focus away from wherever the mouse-only user's keyboard
        // focus actually was. Keyboard users get explicit initial focus from
        // the ArrowDown/Enter/Space handler below instead.
        sameWidth: false,
        sticky: true,
      },
    });
    configureDismissableLayer(ui, item.contentRef, {
      containerRef: item.contentRef,
      branchRefs: [item.triggerRef],
      restoreFocusRef: item.triggerRef,
      outsidePointer: true,
      outsideFocus: true,
      escapeKey: true,
    });
    configurePresence(ui, item.contentRef, { unmountOnExit: true });
    // Escape / outside-click / outside-focus dismissal is handled generically
    // by the dismissable layer above and goes straight through
    // update(contentRef, {open:false}) -- it never calls this component's own
    // closeCurrent(), so openTriggerRef/aria-expanded would otherwise go
    // stale the moment a panel is dismissed any way other than calling
    // open()/close()/toggle() here. Observe the content ref directly so
    // every dismissal path stays in sync.
    ui.observe(item.contentRef, (value) => {
      const data = value && typeof value === "object" ? value : undefined;
      if (data?.open === false && openTriggerRef === item.triggerRef) {
        if (hoveringItems.has(item.triggerRef)) suppressedHoverTriggers.add(item.triggerRef);
        openTriggerRef = null;
        syncState();
      }
    });

    if (item.disabled) return;

    ui.onAction(item.triggerRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      toggleTarget(item.triggerRef);
    });
    ui.bindRefEvent(item.triggerRef, "keydown", (rawEvent) => {
      const event = rawEvent;
      if (event.key === "ArrowRight") {
        event.preventDefault();
        moveSelection(1);
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        moveSelection(-1);
      } else if (event.key === "ArrowDown" || event.key === "Enter" || event.key === " ") {
        // Focus deliberately stays on the trigger here, same as click and
        // hover opens (see the overlay config note above) -- Tab moves into
        // the panel from there. Panel content is consumer-authored and not
        // guaranteed to have onAction handlers wired up (plain nav links,
        // for instance); auto-focusing into it risks handing focus to an
        // element the runtime's dispatch() has no registered handler for,
        // which falls through to its generic actionable-element toggle and
        // silently overwrites that ref's own data the next time an action
        // (Escape included) reaches it while focused.
        event.preventDefault();
        openTarget(item.triggerRef);
      }
      // Escape is handled generically by the dismissable layer registered
      // above (escapeKey: true) -- it fires regardless of whether focus is
      // on the trigger, in the panel, or has bubbled from further down, so
      // this handler does not need its own Escape branch.
    });

    if (!openOnHover) return;
    const scheduleOpen = () => {
      hoveringItems.add(item.triggerRef);
      if (suppressedHoverTriggers.has(item.triggerRef)) return;
      clearHoverTimer();
      hoverTimer = setTimeout(() => {
        if (suppressedHoverTriggers.has(item.triggerRef)) return;
        openTarget(item.triggerRef);
      }, hoverOpenDelay);
    };
    const scheduleClose = () => {
      // A real pointerleave -- the one event that is never a replace-under-
      // cursor artifact, since it means the pointer is demonstrably no
      // longer over the element -- is what re-arms hover-open for this item.
      hoveringItems.delete(item.triggerRef);
      suppressedHoverTriggers.delete(item.triggerRef);
      clearHoverTimer();
      hoverTimer = setTimeout(() => {
        if (openTriggerRef === item.triggerRef) closeCurrent();
      }, hoverCloseDelay);
    };
    ui.bindRefEvent(item.triggerRef, "pointerenter", scheduleOpen);
    ui.bindRefEvent(item.triggerRef, "pointerleave", scheduleClose);
    ui.bindRefEvent(item.contentRef, "pointerenter", () => {
      hoveringItems.add(item.triggerRef);
      clearHoverTimer();
    });
    ui.bindRefEvent(item.contentRef, "pointerleave", scheduleClose);
  });

  if (options.activeRef) openTarget(options.activeRef);
  else syncState();

  return {
    open: openTarget,
    close: closeCurrent,
    toggle: toggleTarget,
    getState: () => ({ openRef: openTriggerRef, openIndex: openIndex(), triggerRefs: [...triggerRefs] }),
  };
}
