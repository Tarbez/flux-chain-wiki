import type { ArkPrimitiveRuntime } from "./runtime.js";
import type { ArkDialogOptions, ArkOverlayHandle, ArkDialogChangeReason, ArkDialogChangeDetails } from "./dialog.js";

export interface ArkSheetOptions extends ArkDialogOptions {
  side?: "left" | "right" | "top" | "bottom";
  size?: string;
  stateRef?: string;
  /** Additional triggers that open the same sheet. */
  triggerRefs?: string[];
  closeRef?: string;
  closeRefs?: string[];
  viewportRef?: string;
  defaultOpen?: boolean;
  open?: boolean;
  controlled?: boolean;
  disabled?: boolean;
  keepMounted?: boolean;
  escapeKey?: boolean;
  closeOnOutsidePress?: boolean;
  /** `false` variant of `initialFocusRef` — matches base-ui's `initialFocus={false}`,
   * meaning focus is left wherever it already is when the sheet opens. */
  initialFocus?: false;
  /** `false` variant of `restoreFocusRef` — matches base-ui's `finalFocus={false}`,
   * meaning focus is left wherever it is when the sheet closes instead of restoring it. */
  finalFocus?: false;
  onOpenChange?: (open: boolean, details: ArkDialogChangeDetails) => void;
  onOpenChangeComplete?: (open: boolean, details: ArkDialogChangeDetails) => void;
  onEscapeKeyDown?: (event: KeyboardEvent, details: ArkDialogChangeDetails) => boolean | void;
  onOutsidePress?: (details: ArkDialogChangeDetails) => boolean | void;
}

export interface ArkDrawerOptions extends ArkSheetOptions {}

export interface ArkSheetHandle extends ArkOverlayHandle {
  toggle: (triggerRef?: string) => void;
  setOpen: (open: boolean, triggerRef?: string) => void;
  syncControlled: (open: boolean, triggerRef?: string) => void;
  getState: () => {
    open: boolean;
    activeTriggerRef?: string;
    reason: ArkDialogChangeReason;
    controlled: boolean;
    mounted: boolean;
    side?: "left" | "right" | "top" | "bottom";
    size?: string;
  };
}

export declare function createArkSheet(ui: ArkPrimitiveRuntime, options: ArkSheetOptions): ArkSheetHandle;
export declare function createArkDrawer(ui: ArkPrimitiveRuntime, options: ArkDrawerOptions): ArkSheetHandle;
