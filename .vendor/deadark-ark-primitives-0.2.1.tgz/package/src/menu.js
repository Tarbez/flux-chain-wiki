/**
 * The menu family — `createArkMenu`, `createArkContextMenu`,
 * `createArkSubmenu`, `createArkDropdownMenu`, and the menu's own item /
 * checkbox-item / radio-group / group / label / separator parts — moved out
 * of `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * This is the family `@deadark/ark-a11y/collection` was written for: a menu
 * popup is the canonical vertical / looping / typeahead roving-tabindex
 * collection, so the roving group goes through `configureMenuFocusGroup()`
 * rather than being re-derived here, exactly as the header comment on
 * `collection.js` describes. The overlay side — focus scope, dismissable
 * layer, presence, and the trigger/content `setOverlayOpen()` pairing — comes
 * from `@deadark/ark-a11y/overlay`, so a menu's `aria-expanded` cannot drift
 * out of sync with what is actually on screen.
 *
 * `createArkMenubar` / `createArkMegaMenu` live next door in `./menubar.js`
 * and compose `createArkMenu` from here.
 */
import { normalizeRef, syncModelRef } from "@deadark/ark-a11y/dom";
import { configureMenuFocusGroup } from "@deadark/ark-a11y/collection";
import {
  configureFocusScope,
  configureDismissableLayer,
  configurePresence,
  activateFocusScope,
  setOverlayOpen,
} from "@deadark/ark-a11y/overlay";

function ref(value) {
  return normalizeRef(value);
}

export function createArkMenu(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const contentRef = ref(options.contentRef);
  const labelRef = ref(options.labelRef);
  const descriptionRef = ref(options.descriptionRef);
  const initialFocusRef = ref(options.initialFocusRef) || ref(options.itemRefs[0]);
  const stateRef = ref(options.stateRef);
  const itemRefs = options.itemRefs.map((value) => ref(value));
  const disabledRefs = new Set((options.disabledItemRefs || []).map((value) => ref(value)));
  const focusScope = `${contentRef}-scope`;
  const collectionId = `${contentRef}-collection`;
  const syncState = (patch) => syncModelRef(ui, stateRef, patch);
  const focusItem = (itemRef) => {
    if (!itemRef || disabledRefs.has(itemRef)) return;
    ui.getElement(itemRef)?.focus?.();
    syncState({ activeRef: itemRef });
  };
  const openMenu = (focusRef) => {
    setOverlayOpen(ui, triggerRef, contentRef, true);
    activateFocusScope(ui, focusScope);
    const targetRef = focusRef && !disabledRefs.has(focusRef) ? focusRef : itemRefs.find((itemRef) => !disabledRefs.has(itemRef));
    focusItem(targetRef);
    syncState({ open: true, activeRef: targetRef, itemRefs: [...itemRefs], disabledItemRefs: [...disabledRefs] });
  };
  const closeMenu = () => {
    setOverlayOpen(ui, triggerRef, contentRef, false);
    syncState({ open: false });
  };

  ui.configureRef(triggerRef, { role: "button", controls: contentRef, hasPopup: "menu" });
  ui.configureRef(contentRef, {
    role: "menu",
    labelledBy: labelRef,
    describedBy: descriptionRef,
    overlay: {
      anchorRef: triggerRef,
      portal: options.portal ?? "layers",
      placement: options.placement ?? "bottom",
      fallbackPlacements: options.placement === "left" || options.placement === "right" ? ["bottom", "top"] : ["top", "right", "left"],
      align: options.align ?? "start",
      offset: 8,
      collisionPadding: 12,
      focusScope,
      sticky: true,
    },
  });
  itemRefs.forEach((itemRef) => {
    ui.configureRef(itemRef, { role: "menuitem", collection: collectionId });
    if (disabledRefs.has(itemRef)) ui.update(itemRef, { disabled: true });
    ui.bindRefEvent(itemRef, "focus", () => syncState({ activeRef: itemRef }));
  });
  configureMenuFocusGroup(ui, collectionId, itemRefs, { loop: options.loop, typeahead: options.typeahead });
  configureFocusScope(ui, focusScope, { containerRef: contentRef, initialFocusRef, trap: false, restore: true });
  configureDismissableLayer(ui, contentRef, {
    containerRef: contentRef,
    branchRefs: [triggerRef],
    restoreFocusRef: triggerRef,
    outsidePointer: true,
    outsideFocus: true,
    escapeKey: true,
  });
  configurePresence(ui, contentRef, { unmountOnExit: true });
  ui.onAction(triggerRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    const current = ui.get(contentRef);
    const nextOpen = !(current && typeof current === "object" ? current.open : undefined);
    if (nextOpen) openMenu(initialFocusRef || itemRefs[0]);
    else closeMenu();
  });
  ui.bindRefEvent(triggerRef, "keydown", (rawEvent) => {
    const event = rawEvent;
    if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
    event.preventDefault();
    const targetRef = event.key === "ArrowUp" ? itemRefs[itemRefs.length - 1] : itemRefs[0];
    openMenu(targetRef);
  });
  ui.onAction(contentRef, () => closeMenu());
  syncState({
    open: false,
    activeRef: initialFocusRef || itemRefs[0],
    itemRefs: [...itemRefs],
    disabledItemRefs: [...disabledRefs],
  });
  return {
    open: () => openMenu(initialFocusRef || itemRefs[0]),
    close: closeMenu,
    focusFirst: () => focusItem(itemRefs.find((itemRef) => !disabledRefs.has(itemRef))),
    focusLast: () => focusItem([...itemRefs].reverse().find((itemRef) => !disabledRefs.has(itemRef))),
  };
}

export function createArkContextMenu(ui, options) {
  const targetRef = ref(options.targetRef);
  const anchorRef = ref(options.anchorRef);
  ui.style(anchorRef, { position: "fixed", left: "0px", top: "0px", width: "0px", height: "0px", pointerEvents: "none" }, { mode: "merge" });
  const menu = createArkMenu(ui, { ...options, triggerRef: anchorRef });
  ui.bindRefEvent(targetRef, "contextmenu", (rawEvent) => {
    const event = rawEvent;
    event.preventDefault();
    ui.style(anchorRef, {
      position: "fixed",
      left: `${event.clientX}px`,
      top: `${event.clientY}px`,
      width: "0px",
      height: "0px",
      pointerEvents: "none",
    }, { mode: "merge" });
    menu.open();
  });
  return menu;
}

export function createArkSubmenu(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const contentRef = ref(options.contentRef);
  const itemRefs = options.itemRefs.map((value) => ref(value));
  const firstItemRef = ref(options.itemRefs[0]);
  createArkMenu(ui, options);
  configureDismissableLayer(ui, contentRef, {
    containerRef: contentRef,
    branchRefs: [triggerRef, ref(options.parentContentRef)],
    restoreFocusRef: triggerRef,
    outsidePointer: true,
    outsideFocus: true,
    escapeKey: true,
  });
  ui.onAction(triggerRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    setOverlayOpen(ui, triggerRef, contentRef, true);
    if (firstItemRef) ui.getElement(firstItemRef)?.focus?.();
  });
  ui.bindRefEvent(triggerRef, "keydown", (rawEvent) => {
    const event = rawEvent;
    if (event.key !== "ArrowRight" && event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    setOverlayOpen(ui, triggerRef, contentRef, true);
    if (firstItemRef) ui.getElement(firstItemRef)?.focus?.();
  });
  const closeFromItem = (rawEvent) => {
    const event = rawEvent;
    if (event.key !== "ArrowLeft") return;
    event.preventDefault();
    setOverlayOpen(ui, triggerRef, contentRef, false);
    ui.getElement(triggerRef)?.focus?.();
  };
  ui.bindRefEvent(contentRef, "keydown", closeFromItem);
  itemRefs.forEach((itemRef) => ui.bindRefEvent(itemRef, "keydown", closeFromItem));
}

export function createArkMenuCheckboxItem(ui, options) {
  const itemRef = ref(options.itemRef);
  ui.configureRef(itemRef, { role: "menuitemcheckbox" });
  ui.update(itemRef, { checked: !!options.checked, selected: !!options.checked });
  ui.onAction(itemRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    const current = ui.get(itemRef) || {};
    const nextChecked = !current.checked;
    ui.update(itemRef, { ...current, checked: nextChecked, selected: nextChecked });
    options.onCheckedChange?.(nextChecked);
  });
}

export function createArkMenuItem(ui, options) {
  const itemRef = ref(options.itemRef);
  const menuRef = ref(options.menuRef);
  if (options.disabled) {
    ui.update(itemRef, { disabled: true });
    return;
  }
  ui.onAction(itemRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    options.onSelect?.(itemRef);
    if (options.closeOnSelect === false) return;
    const current = ui.get(menuRef) || {};
    ui.update(menuRef, { ...current, open: false, hidden: true });
    ui.closeOverlay(menuRef);
  });
}

export function createArkMenuRadioGroup(ui, options) {
  const itemRefs = options.itemRefs.map((value) => ref(value));
  let selectedRef = ref(options.selectedRef) || itemRefs[0];
  const applySelection = (nextRef) => {
    selectedRef = nextRef;
    itemRefs.forEach((itemRef) => {
      const selected = itemRef === selectedRef;
      const current = ui.get(itemRef) || {};
      ui.configureRef(itemRef, { role: "menuitemradio" });
      ui.update(itemRef, { ...current, checked: selected, selected });
    });
  };
  applySelection(selectedRef);
  itemRefs.forEach((itemRef) => ui.onAction(itemRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    applySelection(itemRef);
    options.onValueChange?.(itemRef);
  }));
}

export function createArkMenuGroup(ui, options) {
  const groupRef = ref(options.groupRef);
  const labelRef = ref(options.labelRef);
  ui.configureRef(groupRef, { role: "group", labelledBy: labelRef });
}

export function createArkMenuLabel(ui, options) {
  ui.configureRef(ref(options.labelRef), { part: "menu-label" });
}

export function createArkMenuSeparator(ui, options) {
  ui.configureRef(ref(options.separatorRef), { role: "separator", part: "menu-separator" });
}

/**
 * A dropdown menu *is* a menu — same trigger/content/items wiring, same ARIA,
 * same keyboard model. It keeps its own name because that is what the pattern
 * is called in the vocabulary consumers write against (`createArkDropdownMenu`
 * reads correctly next to `createArkContextMenu`), and it is deliberately a
 * thin delegation rather than a copy so the two can never drift. Moved
 * verbatim, `void` return included.
 */
export function createArkDropdownMenu(ui, options) {
  createArkMenu(ui, options);
}
