import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkFieldOptions {
  fieldRef: string;
  labelRef: string;
  controlRef: string;
  helperRef?: string;
  errorRef?: string;
  required?: boolean;
  invalid?: boolean;
}

export interface ArkFormFieldConfig extends ArkFieldOptions {
  name: string;
  requiredMessage?: string;
  validate?: (value: unknown, values: Record<string, unknown>) => string | undefined;
  serialize?: (value: unknown, values: Record<string, unknown>) => unknown;
}

export interface ArkFormOptions {
  formRef: string;
  fields: ArkFormFieldConfig[];
  submitRef?: string;
  statusRef?: string;
  errorSummaryRef?: string;
  successRef?: string;
  validateOn?: "submit" | "blur" | "input";
  onSubmit?: (values: Record<string, unknown>) => void | Promise<unknown>;
  onValidationChange?: (errors: Record<string, string>) => void;
}

export interface ArkFormHandle {
  values: () => Record<string, unknown>;
  submit: () => void;
  getErrors: () => Record<string, string>;
}

export declare function createArkField(ui: ArkPrimitiveRuntime, options: ArkFieldOptions): void;
export declare function createArkForm(ui: ArkPrimitiveRuntime, options: ArkFormOptions): ArkFormHandle;
