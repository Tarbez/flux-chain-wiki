import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkInputGroupOptions {
  rootRef: string;
  orientation?: "horizontal" | "vertical";
}

export declare function createArkInputGroup(ui: ArkPrimitiveRuntime, options: ArkInputGroupOptions): void;

export type ArkOtpFieldValidationType = "numeric" | "alpha" | "alphanumeric" | "none";
export type ArkOtpFieldChangeReason = "input-change" | "input-clear" | "input-paste" | "keyboard" | "programmatic" | "flux";

export interface ArkOtpFieldEventDetails {
  reason: ArkOtpFieldChangeReason;
  event?: Event;
  trigger?: Element;
}

/**
 * Structural shape of the optional Flux store integration point --
 * `get`/`set`/`subscribe` on a `path` string. Any real `FluxStoreAdapter`
 * (from `@deadark/flux-state`) satisfies this without `ark-primitives`
 * importing that package, matching `ArkPrimitiveRuntime`'s own "declared,
 * not imported" pattern in `./runtime.d.ts`.
 */
export interface ArkInputOtpFluxStore {
  get(path: string): unknown;
  set(path: string, value: unknown): void;
  subscribe(path: string, listener: (value: unknown) => void): () => void;
}

export interface ArkInputOtpOptions {
  rootRef: string;
  /** One text-input ref per digit/character slot. */
  slotRefs: string[];
  hiddenInputRef?: string;
  value?: string;
  defaultValue?: string;
  controlled?: boolean;
  validationType?: ArkOtpFieldValidationType;
  normalizeValue?: (value: string) => string;
  mask?: boolean | string;
  disabled?: boolean;
  readOnly?: boolean;
  required?: boolean;
  invalid?: boolean;
  autoFocus?: boolean;
  autoComplete?: string;
  autoSubmit?: boolean;
  inputMode?: "none" | "text" | "tel" | "url" | "email" | "numeric" | "decimal" | "search";
  name?: string;
  form?: string;
  id?: string;
  placeholder?: string;
  selectOnFocus?: boolean;
  stateRef?: string;
  fluxStore?: ArkInputOtpFluxStore;
  fluxPath?: string;
  onValueChange?: (value: string, details: ArkOtpFieldEventDetails) => void;
  onValueInvalid?: (attemptedValue: string, details: ArkOtpFieldEventDetails) => void;
  /** Fires once every slot has a character — the same moment a form would
   * normally auto-submit a verification code. */
  onComplete?: (value: string, details: ArkOtpFieldEventDetails) => void;
  onValueComplete?: (value: string, details: ArkOtpFieldEventDetails) => void;
  onFocusChange?: (focused: boolean) => void;
}

export interface ArkInputOtpHandle {
  setValue: (value: string, reason?: ArkOtpFieldChangeReason) => void;
  syncControlled: (value: string) => void;
  clear: () => void;
  focus: (index?: number) => void;
  blur: () => void;
  destroy: () => void;
  getState: () => { value: string; complete: boolean; filled: boolean; focused: boolean; dirty: boolean; touched: boolean; valid: boolean; disabled: boolean; readOnly: boolean; required: boolean; length: number };
}

export type ArkOtpFieldOptions = ArkInputOtpOptions;
export type ArkOtpFieldHandle = ArkInputOtpHandle;

export declare function createArkInputOtp(ui: ArkPrimitiveRuntime, options: ArkInputOtpOptions): ArkInputOtpHandle;

/** Canonical OTP Field name. `createArkInputOtp` remains as a compatibility alias. */
export declare const createArkOtpField: typeof createArkInputOtp;
