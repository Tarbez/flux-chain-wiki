/**
 * The checkbox / toggle family — `createArkCheckbox`, `createArkCheckboxGroup`,
 * `createArkRadioGroup`, `createArkToggle`, `createArkButtonGroup`, and
 * `createArkToggleGroup` — moved out of `ark-ui.components.ts` verbatim (same
 * logic, same call order, same observable behavior). See
 * ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * One family because they are the same underlying question — "is this control
 * on?" — answered with the three different ARIA vocabularies that question has:
 *
 *   - `aria-checked` for checkbox/radio semantics, including the `"mixed"`
 *     third state a checkbox can carry and a radio cannot;
 *   - `aria-pressed` for toggle-button semantics, where the control is a
 *     button that stays down rather than a box that gets ticked;
 *   - `role="group"` / `role="radiogroup"` for the container that says how many
 *     of the members may be on at once.
 *
 * The keyboard model splits along the same line, and that split is the real
 * content of this module rather than an implementation detail: a checkbox group
 * is a set of independently tabbable controls (Tab visits each one), while a
 * radio group, toggle group, and button group are single tab stops with arrow
 * keys roving inside them. Getting that backwards is a WAI-ARIA violation, not
 * a styling preference, which is why `createArkCheckboxGroup` deliberately
 * wires no roving focus group at all.
 *
 * Built on `@deadark/ark-a11y` for ref normalization, attribute wiring, and
 * roving-focus composition — the plan's dependency direction:
 * `ark-primitives -> ark-a11y`.
 */
import { normalizeRef, normalizeRefs, setAttrs, syncModelRef, setHidden } from "@deadark/ark-a11y/dom";
import { configureRovingFocusGroup } from "@deadark/ark-a11y/collection";

function ref(value) {
  return normalizeRef(value);
}

// `ArkCheckedInputOptions`/`ArkCheckboxHandle` were already defined for this
// (types-only, never wired to a function) — a real `<input type=checkbox>`
// only got the runtime's generic `checked` handling, never `indeterminate`
// (which has no HTML attribute form; it's JS-property-only, so it needs
// setting on the live element directly, same as `createArkAttachment()`
// does for `.files`) or a stateRef/handle.
export function createArkCheckbox(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const indicatorRef = ref(options.indicatorRef);
  const controlled = options.controlled === true;
  let checked = options.checked ?? !!options.defaultChecked;
  let indeterminate = !!options.indeterminate;

  const sync = () => {
    ui.configureRef(triggerRef, { part: "checkbox" });
    ui.configureRef(triggerRef, { attrs: { name: options.name, value: options.value, form: options.form, required: options.required ? "" : undefined, readonly: options.readOnly ? "" : undefined, "aria-invalid": options.invalid ? "true" : undefined } });
    const current = ui.get(triggerRef) || {};
    ui.update(triggerRef, { ...current, checked, selected: checked, disabled: !!options.disabled });
    setAttrs(ui, triggerRef, {
      "data-checked": checked && !indeterminate ? "true" : undefined,
      "data-unchecked": !checked && !indeterminate ? "true" : undefined,
      "data-indeterminate": indeterminate ? "true" : undefined,
      "data-disabled": options.disabled ? "true" : undefined,
      "data-readonly": options.readOnly ? "true" : undefined,
      "data-required": options.required ? "true" : undefined,
      "data-invalid": options.invalid ? "true" : undefined,
    });
    if (indicatorRef) {
      ui.configureRef(indicatorRef, { part: "checkbox-indicator" });
      setAttrs(ui, indicatorRef, { "data-checked": checked ? "true" : undefined, "data-indeterminate": indeterminate ? "true" : undefined });
      if (!options.keepMounted) setHidden(ui, indicatorRef, !checked && !indeterminate);
    }
    // This must be the final trigger-ref write: ui.update(), configureRef(),
    // and setAttrs() may replace the bound node. The mixed state has no HTML
    // attribute form, and the renderer otherwise derives aria-checked from
    // the boolean checked model.
    const el = ui.getElement(triggerRef);
    if (el) {
      el.indeterminate = indeterminate;
      el.setAttribute("aria-checked", indeterminate ? "mixed" : checked ? "true" : "false");
    }
    syncModelRef(ui, ref(options.stateRef), { checked, indeterminate, controlled });
  };

  const setChecked = (nextChecked, force = false, notify = true) => {
    if (options.disabled || options.readOnly) return;
    if (notify) options.onCheckedChange?.(nextChecked);
    if (controlled && !force) { sync(); return; }
    checked = nextChecked;
    indeterminate = false;
    sync();
  };

  ui.bindRefEvent(triggerRef, "change", (_event, el) => {
    setChecked(el.checked);
  });
  sync();

  return {
    check: () => setChecked(true),
    uncheck: () => setChecked(false),
    toggle: () => setChecked(!checked),
    setIndeterminate: (nextIndeterminate) => { indeterminate = nextIndeterminate; sync(); },
    syncControlled: (nextChecked) => setChecked(nextChecked, true, false),
    getState: () => ({ checked, indeterminate, controlled }),
  };
}

// Unlike `createArkRadioGroup()`/`createArkToggleGroup()`, a checkbox
// group's members are independently focusable (Tab moves between them one
// at a time — arrow keys don't), so this deliberately doesn't wire a roving
// focus group; that's the real difference between "grouped multi-select"
// and "grouped single-select," not just a selection-count detail.
export function createArkCheckboxGroup(ui, options) {
  const rootRef = ref(options.rootRef);
  const itemRefs = options.itemRefs.map((value) => ref(value));
  const disabledRefs = new Set((options.disabledItemRefs || []).map((value) => ref(value)));
  const selectedRefs = new Set((options.selectedRefs || []).map((value) => ref(value)));

  const sync = () => {
    if (rootRef) ui.configureRef(rootRef, { role: "group", part: "checkbox-group" });
    itemRefs.forEach((itemRef) => {
      ui.configureRef(itemRef, { part: "checkbox-group-item" });
      const checked = selectedRefs.has(itemRef);
      const current = ui.get(itemRef) || {};
      ui.update(itemRef, { ...current, checked, selected: checked, disabled: disabledRefs.has(itemRef) });
    });
    syncModelRef(ui, ref(options.stateRef), { selectedRefs: [...selectedRefs], itemRefs: [...itemRefs], disabledItemRefs: [...disabledRefs] });
    options.onValueChange?.([...selectedRefs]);
  };

  const setItemChecked = (targetRef, nextChecked) => {
    if (disabledRefs.has(targetRef)) return;
    if (nextChecked) selectedRefs.add(targetRef);
    else selectedRefs.delete(targetRef);
    sync();
  };

  itemRefs.forEach((itemRef) => {
    ui.bindRefEvent(itemRef, "change", (_event, el) => {
      setItemChecked(itemRef, el.checked);
    });
  });
  sync();

  return {
    check: (targetRef) => setItemChecked(ref(targetRef), true),
    uncheck: (targetRef) => setItemChecked(ref(targetRef), false),
    toggle: (targetRef) => { const targetItemRef = ref(targetRef); setItemChecked(targetItemRef, !selectedRefs.has(targetItemRef)); },
    setValue: (refs) => {
      selectedRefs.clear();
      refs.map((value) => ref(value)).filter(Boolean).forEach((itemRef) => {
        if (!disabledRefs.has(itemRef)) selectedRefs.add(itemRef);
      });
      sync();
    },
    getState: () => ({ selectedRefs: [...selectedRefs] }),
  };
}

export function createArkRadioGroup(ui, options) {
  const rootRef = ref(options.rootRef);
  const itemRefs = options.itemRefs.map((value) => ref(value));
  const disabledRefs = new Set((options.disabledItemRefs || []).map((value) => ref(value)));
  const collectionId = `${rootRef || itemRefs[0]}-radio-group`;
  let selectedRef = ref(options.selectedRef) || itemRefs.find((itemRef) => !disabledRefs.has(itemRef)) || itemRefs[0];
  const sync = () => {
    if (rootRef) ui.configureRef(rootRef, { role: "radiogroup", orientation: options.orientation ?? "vertical", part: "radio-group" });
    itemRefs.forEach((itemRef) => {
      ui.configureRef(itemRef, { role: "radio", collection: collectionId, part: "radio-item" });
      const checked = itemRef === selectedRef;
      const current = ui.get(itemRef) || {};
      ui.update(itemRef, { ...current, checked, selected: checked, disabled: disabledRefs.has(itemRef) });
    });
    syncModelRef(ui, ref(options.stateRef), { selectedRef, itemRefs: [...itemRefs], disabledItemRefs: [...disabledRefs] });
    options.onValueChange?.(selectedRef);
  };
  const selectRef = (nextRef) => {
    if (disabledRefs.has(nextRef)) return;
    selectedRef = nextRef;
    sync();
  };
  configureRovingFocusGroup(ui, collectionId, { refs: itemRefs, orientation: options.orientation ?? "vertical", loop: options.loop ?? true, typeahead: true });
  itemRefs.forEach((itemRef) => {
    ui.onAction(itemRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      selectRef(itemRef);
    });
    ui.bindRefEvent(itemRef, "keydown", (rawEvent) => {
      const event = rawEvent;
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      selectRef(itemRef);
    });
  });
  sync();
  return {
    toggle: (targetRef) => selectRef(ref(targetRef)),
    select: (refs) => selectRef(Array.isArray(refs) ? ref(refs[0]) : ref(refs)),
    getState: () => ({ selectedRefs: [selectedRef] }),
  };
}

export function createArkToggle(ui, options) {
  const triggerRef = ref(options.triggerRef);
  let pressed = !!options.pressed;
  const sync = () => {
    ui.configureRef(triggerRef, { role: "button", part: "toggle" });
    setAttrs(ui, triggerRef, { "aria-pressed": pressed ? "true" : "false" });
    const current = ui.get(triggerRef) || {};
    ui.update(triggerRef, { ...current, selected: pressed, disabled: !!options.disabled });
    syncModelRef(ui, ref(options.stateRef), { pressed });
    options.onPressedChange?.(pressed);
  };
  const setPressed = (nextPressed) => {
    if (options.disabled) return;
    pressed = nextPressed;
    sync();
  };
  ui.onAction(triggerRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    setPressed(!pressed);
  });
  ui.bindRefEvent(triggerRef, "keydown", (rawEvent) => {
    const event = rawEvent;
    if (event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    setPressed(!pressed);
  });
  sync();
  return {
    press: () => setPressed(true),
    release: () => setPressed(false),
    toggle: () => setPressed(!pressed),
    getState: () => ({ pressed }),
  };
}

// Unlike `createArkToggleGroup()` (a single pressed/multi-pressed selection
// model — shadcn/Radix's ToggleGroup), a Button Group's members are plain,
// independent buttons that just happen to render visually joined — shadcn's
// own Button Group is exactly this: a `role="group"` wrapper with connected
// borders, no shared selection state. Arrow-key roving focus across the
// members (Base UI Toolbar's contribution) is the one behavior worth wiring.
export function createArkButtonGroup(ui, options) {
  const rootRef = ref(options.rootRef);
  const itemRefs = normalizeRefs(options.itemRefs);
  const orientation = options.orientation ?? "horizontal";
  const collectionId = `${rootRef}-button-group`;
  ui.configureRef(rootRef, { part: "button-group", role: "group", orientation, label: options.label });
  setAttrs(ui, rootRef, { "data-orientation": orientation });
  configureRovingFocusGroup(ui, collectionId, { refs: itemRefs, orientation, loop: options.loop ?? true, typeahead: false });
  itemRefs.forEach((itemRef) => ui.configureRef(itemRef, { collection: collectionId, part: "button-group-item" }));
}

export function createArkToggleGroup(ui, options) {
  const rootRef = ref(options.rootRef);
  const itemRefs = options.itemRefs.map((value) => ref(value));
  const disabledRefs = new Set((options.disabledItemRefs || []).map((value) => ref(value)));
  const selectedRefs = new Set((options.selectedRefs || []).map((value) => ref(value)));
  const collectionId = `${rootRef || itemRefs[0]}-toggle-group`;
  const sync = (notify = false) => {
    if (rootRef) ui.configureRef(rootRef, { part: "toggle-group", orientation: options.orientation ?? "horizontal" });
    itemRefs.forEach((itemRef) => {
      ui.configureRef(itemRef, { role: "button", collection: collectionId, part: "toggle-group-item" });
      const pressed = selectedRefs.has(itemRef);
      const current = ui.get(itemRef) || {};
      setAttrs(ui, itemRef, { "aria-pressed": pressed ? "true" : "false" });
      ui.update(itemRef, { ...current, selected: pressed, disabled: disabledRefs.has(itemRef) });
    });
    syncModelRef(ui, ref(options.stateRef), { selectedRefs: [...selectedRefs], itemRefs: [...itemRefs], disabledItemRefs: [...disabledRefs] });
    // A change callback reports changes: never the initial selection the caller just passed in
    // (it fired once on creation until 2026-10-19, reporting a change that had not happened).
    if (notify) options.onValueChange?.([...selectedRefs]);
  };
  const toggleRef = (targetRef) => {
    if (disabledRefs.has(targetRef)) return;
    if (options.multiple) {
      if (selectedRefs.has(targetRef)) selectedRefs.delete(targetRef);
      else selectedRefs.add(targetRef);
    } else {
      selectedRefs.clear();
      selectedRefs.add(targetRef);
    }
    sync(true);
  };
  const selectRefs = (nextRefs) => {
    selectedRefs.clear();
    nextRefs.map((value) => ref(value)).filter(Boolean).forEach((itemRef) => {
      if (!disabledRefs.has(itemRef)) selectedRefs.add(itemRef);
    });
    sync(true);
  };
  configureRovingFocusGroup(ui, collectionId, { refs: itemRefs, orientation: options.orientation ?? "horizontal", loop: options.loop ?? true, typeahead: true });
  itemRefs.forEach((itemRef) => {
    ui.onAction(itemRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      toggleRef(itemRef);
    });
    ui.bindRefEvent(itemRef, "keydown", (rawEvent) => {
      const event = rawEvent;
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      toggleRef(itemRef);
    });
  });
  sync();
  return {
    toggle: (targetRef) => toggleRef(ref(targetRef)),
    select: (refs) => selectRefs(Array.isArray(refs) ? refs : [refs]),
    getState: () => ({ selectedRefs: [...selectedRefs] }),
  };
}
