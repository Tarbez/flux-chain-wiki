import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkCheckedInputOptions {
  triggerRef: string;
  defaultChecked?: boolean;
  checked?: boolean;
  controlled?: boolean;
  indeterminate?: boolean;
  disabled?: boolean;
  readOnly?: boolean;
  required?: boolean;
  invalid?: boolean;
  name?: string;
  value?: string;
  form?: string;
  indicatorRef?: string;
  keepMounted?: boolean;
  stateRef?: string;
  onCheckedChange?: (checked: boolean) => void;
}

export interface ArkCheckboxHandle {
  check: () => void;
  uncheck: () => void;
  toggle: () => void;
  setIndeterminate: (indeterminate: boolean) => void;
  syncControlled: (checked: boolean) => void;
  getState: () => { checked: boolean; indeterminate: boolean; controlled: boolean };
}

export interface ArkCheckboxGroupOptions {
  rootRef?: string;
  itemRefs: string[];
  selectedRefs?: string[];
  disabledItemRefs?: string[];
  stateRef?: string;
  onValueChange?: (refs: string[]) => void;
}

export interface ArkCheckboxGroupHandle {
  check: (targetRef: string) => void;
  uncheck: (targetRef: string) => void;
  toggle: (targetRef: string) => void;
  setValue: (refs: string[]) => void;
  getState: () => { selectedRefs: string[] };
}

export interface ArkRadioGroupOptions {
  rootRef?: string;
  itemRefs: string[];
  selectedRef?: string;
  disabledItemRefs?: string[];
  orientation?: "horizontal" | "vertical";
  loop?: boolean;
  stateRef?: string;
  onValueChange?: (ref: string) => void;
}

export interface ArkToggleOptions {
  triggerRef: string;
  pressed?: boolean;
  disabled?: boolean;
  stateRef?: string;
  onPressedChange?: (pressed: boolean) => void;
}

export interface ArkToggleHandle {
  press: () => void;
  release: () => void;
  toggle: () => void;
  getState: () => { pressed: boolean };
}

export interface ArkButtonGroupOptions {
  rootRef: string;
  itemRefs: string[];
  orientation?: "horizontal" | "vertical";
  loop?: boolean;
  label?: string;
}

export interface ArkToggleGroupOptions {
  rootRef?: string;
  itemRefs: string[];
  selectedRefs?: string[];
  multiple?: boolean;
  disabledItemRefs?: string[];
  orientation?: "horizontal" | "vertical";
  loop?: boolean;
  stateRef?: string;
  onValueChange?: (refs: string[]) => void;
}

export interface ArkToggleGroupHandle {
  toggle: (ref: string) => void;
  select: (refs: string[] | string) => void;
  getState: () => { selectedRefs: string[] };
}

export declare function createArkCheckbox(ui: ArkPrimitiveRuntime, options: ArkCheckedInputOptions): ArkCheckboxHandle;
export declare function createArkCheckboxGroup(ui: ArkPrimitiveRuntime, options: ArkCheckboxGroupOptions): ArkCheckboxGroupHandle;
export declare function createArkRadioGroup(ui: ArkPrimitiveRuntime, options: ArkRadioGroupOptions): ArkToggleGroupHandle;
export declare function createArkToggle(ui: ArkPrimitiveRuntime, options: ArkToggleOptions): ArkToggleHandle;
export declare function createArkButtonGroup(ui: ArkPrimitiveRuntime, options: ArkButtonGroupOptions): void;
export declare function createArkToggleGroup(ui: ArkPrimitiveRuntime, options: ArkToggleGroupOptions): ArkToggleGroupHandle;
