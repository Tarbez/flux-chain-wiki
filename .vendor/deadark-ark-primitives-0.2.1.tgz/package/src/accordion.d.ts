import type { ArkPrimitiveRuntime } from "./runtime.js";

/**
 * Spring/drag knobs handed through to `FluxAnimate` as
 * `data-flx-animate-config`. Declared structurally here rather than imported
 * from `@deadark/ark-ui/animate` for the same reason `ArkPrimitiveRuntime` is:
 * this package must not depend back on `@deadark/ark-ui`. `FluxAnimationConfig`
 * satisfies this shape, so passing one still type-checks at the call site.
 */
export interface ArkAccordionAnimationConfig {
  mass?: number;
  stiffness?: number;
  damping?: number;
  draggable?: boolean;
  axis?: "x" | "y" | "both";
  distance?: number;
}

export interface ArkAccordionAnimationOptions {
  enterPreset?: string;
  exitPreset?: string;
  duration?: string;
  easing?: string;
  delay?: string;
  stagger?: string;
  once?: boolean;
  config?: ArkAccordionAnimationConfig;
}

export interface ArkAccordionOptions {
  rootRef?: string;
  /** The element wrapping the items; exposed as role="group" (named by `label` / `labelledBy`). */
  listRef?: string;
  /** Accessible name of the accordion group (aria-label), e.g. "Questions". */
  label?: string;
  /** Ref of a visible heading that names the accordion group (aria-labelledby). */
  labelledBy?: string;
  itemRefs?: string[];
  triggerRefs?: string[];
  panelRefs?: string[];
  headerRefs?: string[];
  inferStructure?: boolean;
  /** "single" | "multiple" — mirrors shadcn/Base UI's `type` prop. Overrides `multiple` when set. */
  type?: "single" | "multiple";
  multiple?: boolean;
  /** In "single" mode, whether clicking the open trigger can close it back to nothing. Default true. */
  collapsible?: boolean;
  /** Disables the whole accordion. */
  disabled?: boolean;
  disabledRefs?: string[];
  /** Alias for item-level disabling when you want to target wrapper refs directly. */
  disabledItemRefs?: string[];
  orientation?: "horizontal" | "vertical";
  defaultOpen?: number[];
  /** Stable value for each item. Defaults to `itemRefs[i]`, then `triggerRefs[i]`. */
  values?: string[];
  defaultValue?: string | string[];
  value?: string | string[];
  keepMounted?: boolean;
  hiddenUntilFound?: boolean;
  loopFocus?: boolean;
  /** When enabled, panel refs get Flux animation attributes that `FluxAnimate` can orchestrate on top of presence/layout behavior. */
  animation?: boolean | ArkAccordionAnimationOptions;
  stateRef?: string;
  controlled?: boolean;
  onValueChange?: (openValues: string[], details: ArkAccordionValueChangeDetails) => void;
}

export interface ArkAccordionValueChangeDetails {
  openValues: string[];
  openIndexes: number[];
  openTriggerRefs: string[];
  openPanelRefs: string[];
  openItemRefs: string[];
  changedValue?: string;
  changedIndex?: number;
  changedTriggerRef?: string;
  changedPanelRef?: string;
  changedItemRef?: string;
  type: "single" | "multiple";
}

export interface ArkAccordionHandle {
  setValue: (value: string | string[]) => void;
  open: (value: string) => void;
  close: (value?: string) => void;
  toggle: (value: string) => void;
  getState: () => {
    openValues: string[];
    openIndexes: number[];
    openTriggerRefs: string[];
    openPanelRefs: string[];
    openItemRefs: string[];
    type: "single" | "multiple";
    disabled: boolean;
  };
}

/**
 * The custom property an accordion panel's measured content height is
 * published to, and which the `ACCORDIONCONTENT` style recipe resolves its
 * `max-height` against.
 */
export declare const ARK_ACCORDION_CONTENT_HEIGHT_VAR: "--ark-accordion-content-height";

export declare function createArkAccordion(ui: ArkPrimitiveRuntime, options: ArkAccordionOptions): ArkAccordionHandle;
