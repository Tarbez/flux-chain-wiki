/**
 * `ArkPrimitiveRuntime` — the structural ARK UI runtime surface every family
 * in this package composes against — now lives in `./runtime.d.ts`, so the
 * dialog, progress, separator, ... families all assume exactly one host shape
 * instead of each re-deriving a subset of it. Re-exported from here unchanged,
 * since this module was its original home when dialog/popover were the only
 * extracted family.
 */
import type { ArkPrimitiveRuntime } from "./runtime.js";
export type { ArkPrimitiveRuntime };

export interface ArkPopoverOptions {
  triggerRef: string;
  contentRef: string;
  labelRef?: string;
  descriptionRef?: string;
  initialFocusRef?: string;
  restoreFocusRef?: string;
  /** `false` variant of `initialFocusRef` — matches base-ui's `initialFocus={false}`,
   * meaning focus is left wherever it already is when the popover opens. */
  initialFocus?: false;
  /** `false` variant of `restoreFocusRef` — matches base-ui's `finalFocus={false}`,
   * meaning focus is left wherever it is when the popover closes instead of restoring it. */
  finalFocus?: false;
  viewportRef?: string;
  portal?: string;
  placement?: "top" | "right" | "bottom" | "left";
  align?: "start" | "center" | "end";
  offset?: number;
  collisionPadding?: number;
  /** Additional triggers that open the same popover. */
  triggerRefs?: string[];
  closeRef?: string;
  closeRefs?: string[];
  stateRef?: string;
  defaultOpen?: boolean;
  open?: boolean;
  controlled?: boolean;
  disabled?: boolean;
  keepMounted?: boolean;
  /** Modal popovers (default false) trap focus and add a backdrop, matching base-ui's `modal` prop.
   * `'trap-focus'` traps focus like `true` but skips the backdrop, matching base-ui's trap-focus-only mode. */
  modal?: boolean | "trap-focus";
  escapeKey?: boolean;
  closeOnOutsidePress?: boolean;
  /** Opens the popover on hover, independent of click-to-open. Default false. */
  openOnHover?: boolean;
  /** Hover-open delay in ms, matching base-ui's Trigger default. Only used when `openOnHover` is true. */
  delay?: number;
  /** Hover-close delay in ms — 0 means it closes as soon as the pointer leaves. */
  closeDelay?: number;
  /** Whether the pointer can move from the trigger onto the popover content
   * itself without it closing (base-ui's inverse of `disableHoverablePopup`). */
  hoverable?: boolean;
  /** Payloads keyed by trigger ref, mirroring AlertDialog's `triggerPayloads` — the
   * non-JSX equivalent of base-ui's `Trigger payload` + render-prop `Root` children. */
  triggerPayloads?: Record<string, unknown>;
  onOpenChange?: (open: boolean, details: ArkDialogChangeDetails) => void;
  onOpenChangeComplete?: (open: boolean, details: ArkDialogChangeDetails) => void;
  onEscapeKeyDown?: (event: KeyboardEvent, details: ArkDialogChangeDetails) => boolean | void;
  onOutsidePress?: (details: ArkDialogChangeDetails) => boolean | void;
}

export interface ArkDialogOptions {
  triggerRef: string;
  contentRef: string;
  labelRef?: string;
  descriptionRef?: string;
  initialFocusRef?: string;
  portal?: string;
  restoreFocusRef?: string;
}

export type ArkDialogChangeReason =
  | "trigger-press"
  | "trigger-hover"
  | "close-press"
  | "escape-key"
  | "outside-press"
  | "imperative-action"
  | "controlled-sync"
  | "none";

export interface ArkDialogChangeDetails {
  reason: ArkDialogChangeReason;
  triggerRef?: string;
  event?: Event;
  /** The payload registered for the active trigger via `triggerPayloads`, mirroring
   * base-ui's `Popover.Trigger payload`/`Root`-render-prop pattern (see AlertDialog). */
  payload?: unknown;
  isCanceled: boolean;
  cancel: () => void;
}

export interface ArkDialogControlOptions extends ArkDialogOptions {
  /** Additional triggers that open the same dialog. `triggerRef` remains the primary focus-restore anchor. */
  triggerRefs?: string[];
  /** Explicit close control(s) beyond the implicit outside-press/Escape dismissal. */
  closeRef?: string;
  closeRefs?: string[];
  viewportRef?: string;
  stateRef?: string;
  defaultOpen?: boolean;
  open?: boolean;
  controlled?: boolean;
  disabled?: boolean;
  keepMounted?: boolean;
  /** Non-modal dialogs (default true = modal) skip the backdrop and focus trap, matching base-ui's `modal` prop. */
  modal?: boolean;
  escapeKey?: boolean;
  closeOnOutsidePress?: boolean;
  /** `false` variant of `initialFocusRef` — matches base-ui's `initialFocus={false}`,
   * meaning focus is left wherever it already is when the dialog opens. */
  initialFocus?: false;
  /** `false` variant of `restoreFocusRef` — matches base-ui's `finalFocus={false}`,
   * meaning focus is left wherever it is when the dialog closes instead of restoring it. */
  finalFocus?: false;
  /** Payloads keyed by trigger ref, mirroring AlertDialog's `triggerPayloads` — the
   * non-JSX equivalent of base-ui's `Trigger payload` + render-prop `Root` children. */
  triggerPayloads?: Record<string, unknown>;
  onOpenChange?: (open: boolean, details: ArkDialogChangeDetails) => void;
  onOpenChangeComplete?: (open: boolean, details: ArkDialogChangeDetails) => void;
  onEscapeKeyDown?: (event: KeyboardEvent, details: ArkDialogChangeDetails) => boolean | void;
  onOutsidePress?: (details: ArkDialogChangeDetails) => boolean | void;
}

export interface ArkDialogHandle {
  open: (triggerRef?: string, payload?: unknown) => void;
  close: () => void;
  toggle: (triggerRef?: string, payload?: unknown) => void;
  setOpen: (open: boolean, triggerRef?: string, payload?: unknown) => void;
  syncControlled: (open: boolean, triggerRef?: string, payload?: unknown) => void;
  getState: () => {
    open: boolean;
    activeTriggerRef?: string;
    payload?: unknown;
    reason: ArkDialogChangeReason;
    controlled: boolean;
    mounted: boolean;
  };
}

export interface ArkOverlayHandle {
  open: () => void;
  close: () => void;
  getState: () => { open: boolean };
}

export declare function createArkPopover(ui: ArkPrimitiveRuntime, options: ArkPopoverOptions): ArkDialogHandle;
export declare function createArkDialog(ui: ArkPrimitiveRuntime, options: ArkDialogControlOptions): ArkDialogHandle;
