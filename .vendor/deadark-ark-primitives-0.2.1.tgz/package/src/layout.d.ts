import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkScrollAreaOptions {
  viewportRef: string;
  contentRef?: string;
  scrollbarXRef?: string;
  scrollbarYRef?: string;
  thumbXRef?: string;
  thumbYRef?: string;
  /** The square left empty where both scrollbars meet — only meaningful
   * when both `scrollbarXRef` and `scrollbarYRef` are given. */
  cornerRef?: string;
}

export declare function createArkScrollArea(ui: ArkPrimitiveRuntime, options: ArkScrollAreaOptions): void;

export interface ArkSidebarOptions {
  sidebarRef: string;
  triggerRef?: string;
  railRef?: string;
  side?: "left" | "right";
  open?: boolean;
  stateRef?: string;
  /** Width while open. Defaults to "280px". */
  openWidth?: string;
  /**
   * Width while closed, with the same content still mounted (just condensed
   * — e.g. labels hidden by the consumer's own CSS) rather than swapped for
   * a separate `railRef` element. Defaults to "72px" when `railRef` is set,
   * otherwise "0px" (fully hidden, the original behavior).
   */
  closedWidth?: string;
  onOpenChange?: (open: boolean) => void;
}

export interface ArkSidebarHandle {
  open: () => void;
  close: () => void;
  toggle: () => void;
  getState: () => { open: boolean };
}

export declare function createArkSidebar(ui: ArkPrimitiveRuntime, options: ArkSidebarOptions): ArkSidebarHandle;

export interface ArkAppShellOptions {
  /** Root grid container: rail + (optional nav) + main. */
  shellRef: string;
  /** Persistent icon-only rail — always visible, never collapses. */
  railRef: string;
  /** Optional expandable labeled nav strip, shown alongside the rail. */
  navRef?: string;
  /** Main content region — always present, fills remaining width. */
  mainRef: string;
  /** Optional control that toggles the expandable nav strip. */
  triggerRef?: string;
  /** Starting state of the expandable nav strip (default true). */
  expanded?: boolean;
  /** Rail width, e.g. "72px" (default). */
  railWidth?: string;
  /** Expanded nav width, e.g. "224px" (default). */
  navWidth?: string;
  stateRef?: string;
  onExpandedChange?: (expanded: boolean) => void;
}

export interface ArkAppShellHandle {
  expand: () => void;
  collapse: () => void;
  toggle: () => void;
  getState: () => { expanded: boolean };
}

export declare function createArkAppShell(ui: ArkPrimitiveRuntime, options: ArkAppShellOptions): ArkAppShellHandle;
