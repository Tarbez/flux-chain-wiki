import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkBreadcrumbsOptions {
  navRef: string;
  itemRefs: string[];
  separatorRefs?: string[];
  currentRef?: string;
  orientation?: "horizontal" | "vertical";
  /** Collapse the trail to the first item plus the last `maxVisible - 1`
   * once there are more than `maxVisible` items, showing `ellipsisRef` in
   * their place (shadcn's `BreadcrumbEllipsis`). Requires `ellipsisRef`. */
  maxVisible?: number;
  ellipsisRef?: string;
  onCurrentChange?: (ref: string, index: number) => void;
}

export interface ArkBreadcrumbsHandle {
  expand: () => void;
  getState: () => { expanded: boolean; visibleRefs: string[] };
}

export declare function createArkBreadcrumbs(ui: ArkPrimitiveRuntime, options: ArkBreadcrumbsOptions): ArkBreadcrumbsHandle;

export interface ArkPaginationOptions {
  navRef: string;
  pageRefs: string[];
  previousRef?: string;
  nextRef?: string;
  currentRef?: string;
  orientation?: "horizontal" | "vertical";
  loop?: boolean;
  /** Pages shown on each side of the current page before truncating behind
   * an ellipsis (first and last page always stay visible). Requires at
   * least one of `leadingEllipsisRef`/`trailingEllipsisRef`. */
  siblingCount?: number;
  leadingEllipsisRef?: string;
  trailingEllipsisRef?: string;
  onPageChange?: (ref: string, index: number) => void;
}

export interface ArkPaginationHandle {
  goTo: (index: number) => void;
  getState: () => { currentIndex: number; visibleIndexes: number[] };
}

export declare function createArkPagination(ui: ArkPrimitiveRuntime, options: ArkPaginationOptions): ArkPaginationHandle;
