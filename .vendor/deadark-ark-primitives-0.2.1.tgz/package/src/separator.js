/**
 * `createArkSeparator` — moved out of `ark-ui.components.ts` verbatim.
 * See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * Small, but a real primitive rather than a style: the whole point is the
 * `role="separator"` / `aria-hidden` fork. A separator that divides *meaning*
 * (between two groups of menu items, say) is announced; one that is only
 * decorative geometry must be hidden from assistive tech, or a screen-reader
 * user hears a "separator" for every hairline in the layout. The 1px
 * cross-axis sizing travels with it because a separator whose box collapses
 * to zero is invisible regardless of what its role says.
 */
import { normalizeRef, setAttrs } from "@deadark/ark-a11y/dom";

export function createArkSeparator(ui, options) {
  const separatorRef = normalizeRef(options.separatorRef);
  const orientation = options.orientation ?? "horizontal";
  ui.configureRef(separatorRef, { role: options.decorative ? undefined : "separator", part: "separator" });
  setAttrs(ui, separatorRef, {
    "aria-hidden": options.decorative ? "true" : undefined,
    "aria-orientation": orientation === "vertical" ? "vertical" : undefined,
    "data-orientation": orientation,
  });
  ui.style(separatorRef, orientation === "vertical"
    ? { width: "1px", height: "100%", minHeight: "1em", flex: "none" }
    : { width: "100%", height: "1px", flex: "none" }, { mode: "merge" });
}
