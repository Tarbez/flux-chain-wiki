import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkChartSeries {
  label: string;
  /** One value per `ArkChartOptions.categories` entry, same order. */
  values: number[];
  /** Defaults to cycling a small built-in categorical palette by series
   * index — this primitive draws raw SVG outside the style-schema system,
   * so it can't inherit a registered theme's semantic colors the way
   * markup-driven parts do. */
  color?: string;
}

export interface ArkChartOptions {
  /** A plain container ref from markup; the chart mounts a real `<svg>`
   * (plus a tooltip element) as direct children of it, entirely outside
   * `ui.render()`'s pattern-grammar tree — the same "own a subtree
   * imperatively" approach `createArkNativeSelect()` uses for `<option>`s. */
  containerRef: string;
  type: "line" | "bar" | "area";
  categories: string[];
  series: ArkChartSeries[];
  /** Fallback size used only until the container has a real measured
   * width/height (e.g. before it's laid out, or in a non-browser test
   * environment with no real geometry). */
  width?: number;
  height?: number;
  /** Fixed value-axis domain; omit either to auto-scale to the data
   * (always including zero, so bars/areas never render past the baseline). */
  min?: number;
  max?: number;
  /** Horizontal gridline/tick rows, including the baseline. Defaults to 4. */
  tickCount?: number;
  valueFormat?: (value: number) => string;
  onHoverChange?: (point: { seriesIndex: number; categoryIndex: number; value: number } | undefined) => void;
}

export interface ArkChartHandle {
  setSeries: (series: ArkChartSeries[]) => void;
  /** Re-measures the container and redraws — call this from your own
   * `ResizeObserver`/orientation-change handling; the chart doesn't set
   * one up itself. */
  resize: () => void;
  getState: () => { width: number; height: number };
}

export declare function createArkChart(ui: ArkPrimitiveRuntime, options: ArkChartOptions): ArkChartHandle;
