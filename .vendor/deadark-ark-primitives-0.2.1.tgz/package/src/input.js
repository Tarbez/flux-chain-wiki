/**
 * `createArkInputGroup` and `createArkInputOtp` (canonically `createArkOtpField`)
 * — moved out of `ark-ui.components.ts` verbatim (same logic, same call
 * order, same observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * `createArkInputOtp`'s optional `fluxStore`/`fluxPath` integration takes a
 * structurally-typed adapter (`get`/`set`/`subscribe`), not an import of
 * `@deadark/flux-state`'s `FluxStoreAdapter` -- same reasoning as
 * `ArkPrimitiveRuntime` in `./runtime.d.ts`: it's declared, not imported, so
 * a real `FluxMemoryStore` satisfies it without `ark-primitives` gaining a
 * dependency on `@deadark/flux-state`.
 */
import { normalizeRef, normalizeRefs, setAttrs, syncModelRef } from "@deadark/ark-a11y/dom";

function ref(value) {
  return normalizeRef(value);
}

export function createArkInputGroup(ui, options) {
  const rootRef = ref(options.rootRef);
  const orientation = options.orientation ?? "horizontal";
  ui.configureRef(rootRef, { part: "input-group" });
  setAttrs(ui, rootRef, { "data-orientation": orientation });
}

export function createArkInputOtp(ui, options) {
  const rootRef = ref(options.rootRef);
  const slotRefs = normalizeRefs(options.slotRefs);
  const hiddenInputRef = ref(options.hiddenInputRef);
  const validationType = options.validationType ?? "numeric";
  const controlled = options.controlled ?? options.value !== undefined;
  let focused = false;
  let dirty = false;
  let touched = false;
  let lastComplete = false;
  let syncingFlux = false;
  let unsubscribeFlux;

  const normalize = (raw, report = false, details) => {
    const compact = String(raw ?? "").replace(/\s/g, "");
    const filtered = validationType === "numeric" ? compact.replace(/[^0-9]/g, "")
      : validationType === "alpha" ? compact.replace(/[^a-zA-Z]/g, "")
      : validationType === "alphanumeric" ? compact.replace(/[^0-9a-zA-Z]/g, "") : compact;
    const custom = options.normalizeValue?.(filtered) ?? filtered;
    const normalized = (validationType === "numeric" ? custom.replace(/[^0-9]/g, "")
      : validationType === "alpha" ? custom.replace(/[^a-zA-Z]/g, "")
      : validationType === "alphanumeric" ? custom.replace(/[^0-9a-zA-Z]/g, "") : custom).slice(0, slotRefs.length);
    if (report && normalized !== compact) options.onValueInvalid?.(raw, details || { reason: "input-change" });
    return normalized;
  };
  let digits = slotRefs.map((_, index) => normalize(options.value ?? options.defaultValue ?? "")[index] ?? "");

  const focusSlot = (index) => {
    const clamped = Math.min(Math.max(index, 0), slotRefs.length - 1);
    ui.getElement(slotRefs[clamped])?.focus?.();
  };

  const sync = (details = { reason: "programmatic" }, notify = true, configureSlots = true) => {
    const value = digits.join("");
    const complete = digits.length > 0 && digits.every(Boolean);
    const valid = !options.invalid && (!options.required || complete);
    setAttrs(ui, rootRef, {
      role: "group", "data-complete": complete ? "" : undefined, "data-filled": value ? "" : undefined,
      "data-focused": focused ? "" : undefined, "data-disabled": options.disabled ? "" : undefined,
      "data-readonly": options.readOnly ? "" : undefined, "data-required": options.required ? "" : undefined,
      "data-invalid": options.invalid ? "" : undefined, "data-valid": valid ? "" : undefined,
      "data-dirty": dirty ? "" : undefined, "data-touched": touched ? "" : undefined,
    });
    if (configureSlots) slotRefs.forEach((slotRef, index) => {
      ui.configureRef(slotRef, {
        attrs: {
          id: options.id ? (index === 0 ? options.id : `${options.id}-${index + 1}`) : undefined,
          inputmode: options.inputMode ?? (validationType === "numeric" ? "numeric" : "text"),
          autocomplete: index === 0 ? (options.autoComplete ?? "one-time-code") : "off",
          maxlength: "1",
          placeholder: options.placeholder?.[index],
          disabled: options.disabled ? "true" : undefined,
          readonly: options.readOnly ? "true" : undefined,
          required: options.required ? "true" : undefined,
          "aria-invalid": options.invalid ? "true" : undefined,
          "aria-label": `Character ${index + 1} of ${slotRefs.length}`,
        },
        part: "otp-slot",
      });
      // Direct DOM write, same reason as `createArkCheckbox()`'s
      // `.indeterminate`/`aria-checked`: this runs *after* `configureRef()`
      // replaces the element, and `value` has no reliable attribute-driven
      // form for a live, already-mounted `<input>`.
      const el = ui.getElement(slotRef);
      if (el) {
        el.type = options.mask === true ? "password" : "text";
        el.value = typeof options.mask === "string" && digits[index] ? options.mask : (digits[index] || "");
        if (digits[index]) el.setAttribute("data-filled", "true");
        else el.removeAttribute("data-filled");
      }
    });
    if (hiddenInputRef && configureSlots) {
      ui.configureRef(hiddenInputRef, { part: "otp-hidden-input", attrs: { type: "hidden", name: options.name, form: options.form, disabled: options.disabled ? "true" : undefined } });
      const hidden = ui.getElement(hiddenInputRef);
      if (hidden) hidden.value = value;
    }
    syncModelRef(ui, ref(options.stateRef), { value, complete, filled: !!value, focused, dirty, touched, valid, length: slotRefs.length });
    if (notify) options.onValueChange?.(value, details);
    if (notify && options.fluxStore && options.fluxPath && !syncingFlux) options.fluxStore.set(options.fluxPath, value);
    if (complete && (!lastComplete || details.reason === "input-paste")) {
      options.onComplete?.(value, details);
      options.onValueComplete?.(value, details);
      if (options.autoSubmit) ui.getElement(hiddenInputRef || slotRefs[0])?.form?.requestSubmit?.();
    }
    lastComplete = complete;
  };

  ui.configureRef(rootRef, { part: "otp" });
  slotRefs.forEach((slotRef, index) => {
    ui.bindRefEvent(slotRef, "input", (_event, el) => {
      if (options.disabled || options.readOnly) return;
      const attempted = el.value;
      const details = { reason: attempted ? "input-change" : "input-clear", event: _event, trigger: el };
      const raw = normalize(attempted, true, details);
      const char = raw.slice(-1);
      digits[index] = char;
      dirty = true;
      sync(details);
      if (char && index < slotRefs.length - 1) focusSlot(index + 1);
    });
    ui.bindRefEvent(slotRef, "keydown", (rawEvent) => {
      const event = rawEvent;
      if (options.disabled || options.readOnly) return;
      if (event.key === "Backspace" && !digits[index] && index > 0) {
        event.preventDefault();
        digits[index - 1] = "";
        dirty = true;
        sync({ reason: "keyboard", event, trigger: ui.getElement(slotRef) });
        focusSlot(index - 1);
      } else if (event.key === "ArrowLeft") {
        event.preventDefault();
        focusSlot(index - 1);
      } else if (event.key === "ArrowRight") {
        event.preventDefault();
        focusSlot(index + 1);
      }
    });
    // Lets a full code pasted into any slot fan out across the remaining
    // slots from that point, instead of only filling the one slot the
    // paste landed in — the behavior every production OTP input has.
    ui.bindRefEvent(slotRef, "paste", (rawEvent) => {
      const event = rawEvent;
      if (options.disabled || options.readOnly) return;
      const attempted = event.clipboardData?.getData("text") ?? "";
      const details = { reason: "input-paste", event, trigger: ui.getElement(slotRef) };
      const pasted = normalize(attempted, true, details);
      if (!pasted) return;
      event.preventDefault();
      let filled = 0;
      for (let offset = 0; offset < pasted.length && index + offset < slotRefs.length; offset += 1) {
        digits[index + offset] = pasted[offset];
        filled += 1;
      }
      dirty = true;
      sync(details);
      focusSlot(index + filled);
    });
    ui.bindRefEvent(slotRef, "focus", () => {
      focused = true;
      options.onFocusChange?.(true);
      if (options.selectOnFocus) ui.getElement(slotRef)?.select?.();
    });
    ui.bindRefEvent(slotRef, "blur", () => {
      touched = true;
      queueMicrotask(() => {
        focused = slotRefs.some((candidate) => ui.getElement(candidate) === document.activeElement);
        options.onFocusChange?.(focused);
      });
    });
  });

  sync({ reason: "programmatic" }, false);
  if (options.fluxStore && options.fluxPath) {
    const stored = options.fluxStore.get(options.fluxPath);
    if (typeof stored === "string") digits = slotRefs.map((_, index) => normalize(stored)[index] ?? "");
    unsubscribeFlux = options.fluxStore.subscribe(options.fluxPath, (next) => {
      if (typeof next !== "string" || next === digits.join("")) return;
      syncingFlux = true;
      digits = slotRefs.map((_, index) => normalize(next)[index] ?? "");
      sync({ reason: "flux" });
      syncingFlux = false;
    });
    sync({ reason: "flux" }, false);
  }
  if (options.autoFocus) queueMicrotask(() => focusSlot(0));
  return {
    setValue: (value, reason = "programmatic") => {
      const next = normalize(value);
      if (controlled && reason !== "flux") { options.onValueChange?.(next, { reason }); return; }
      digits = slotRefs.map((_, index) => next[index] ?? "");
      dirty = true;
      sync({ reason });
    },
    syncControlled: (value) => { digits = slotRefs.map((_, index) => normalize(value)[index] ?? ""); sync({ reason: "programmatic" }, false); },
    clear: () => {
      digits = slotRefs.map(() => "");
      dirty = true;
      sync({ reason: "input-clear" });
      focusSlot(0);
    },
    focus: (index = 0) => focusSlot(index),
    blur: () => document.activeElement?.blur?.(),
    destroy: () => unsubscribeFlux?.(),
    getState: () => ({ value: digits.join(""), complete: digits.length > 0 && digits.every(Boolean), filled: digits.some(Boolean), focused, dirty, touched, valid: !options.invalid && (!options.required || digits.every(Boolean)), disabled: !!options.disabled, readOnly: !!options.readOnly, required: !!options.required, length: slotRefs.length }),
  };
}

/** Canonical OTP Field name. `createArkInputOtp` remains as a compatibility alias. */
export const createArkOtpField = createArkInputOtp;
