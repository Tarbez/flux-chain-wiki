import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkItemOptions {
  itemRef: string;
  /** Join a shared `createArkRovingFocusGroup` id when this item is one of
   * several in a plain list (not already covered by Menu/Select/Combobox,
   * which each wire their own collection). Omit for a single standalone item. */
  collection?: string;
  disabled?: boolean;
  selected?: boolean;
  stateRef?: string;
  onSelect?: () => void;
}

export interface ArkItemHandle {
  select: () => void;
  getState: () => { selected: boolean; disabled: boolean };
}

export interface ArkMarkerOptions {
  /** The map/canvas/image surface the marker is positioned on top of. */
  containerRef: string;
  markerRef: string;
  x: number;
  y: number;
  /** "percent" (default) positions x/y as 0-100 of the container's own
   * size, so the marker tracks correctly if the surface resizes/zooms;
   * "pixel" positions as literal offsets for a fixed-size surface. */
  unit?: "percent" | "pixel";
  label?: string;
  onSelect?: () => void;
}

export interface ArkMarkerHandle {
  setPosition: (x: number, y: number) => void;
  getState: () => { x: number; y: number };
}

export interface ArkCollectionOptions {
  containerRef: string;
  itemRefs: string[];
  emptyRef?: string;
  loadingRef?: string;
  detailRef?: string;
  selectedRefs?: string[];
  selectionMode?: "none" | "single" | "multiple";
  orientation?: "horizontal" | "vertical";
  loop?: boolean;
  loading?: boolean;
  onSelectionChange?: (refs: string[]) => void;
}

export interface ArkTableOptions extends Omit<ArkCollectionOptions, "containerRef"> {
  tableRef: string;
  captionRef?: string;
  theadRef?: string;
  footerRef?: string;
  /** Header cells that toggle a single-column sort on click/Enter
   * (none → asc → desc → none). For column-aware sorting over row data,
   * use `createArkDataTable()` instead — this is the plain table's lighter
   * "mark which column is sorted" version with no data reordering. */
  sortableHeaderRefs?: string[];
  /** Pins `theadRef` to the top of the table's scroll container. */
  stickyHeader?: boolean;
  /** Pins these cells (one ref per row, matching `itemRefs`'s order) to the
   * left edge while the rest of the row scrolls horizontally underneath. */
  stickyFirstColumnRefs?: string[];
  onSortChange?: (headerRef: string, direction: "asc" | "desc" | undefined) => void;
}

export interface ArkTableHandle {
  sortBy: (headerRef: string, direction?: "asc" | "desc" | undefined) => void;
  getState: () => { sortRef?: string; sortDirection?: "asc" | "desc" };
}

export interface ArkDataTableColumn {
  headerRef: string;
  accessor: (rowRef: string) => string | number;
  /** One cell ref per row, same order as `itemRefs` — needed to reach each
   * row's cell for this column when hiding, pinning, or resizing it (the
   * header alone isn't enough for any of those). */
  cellRefs?: string[];
  /** Initial pixel width. Omit for content-sized (no `resizeHandleRefs`
   * entry needed either, in that case). */
  width?: number;
  minWidth?: number;
}

export interface ArkDataTableOptions extends ArkTableOptions {
  headerRefs?: string[];
  columns?: ArkDataTableColumn[];
  prevRef?: string;
  nextRef?: string;
  pageSize?: number;
  stateRef?: string;
  /** Column header refs hidden from the start; toggle later via the
   * returned handle's `showColumn()`/`hideColumn()`. */
  hiddenColumnRefs?: string[];
  /** Column header refs pinned to the left edge, in the order they should
   * stack — each one's sticky `left` offset is computed from the measured
   * width of the pinned columns before it. */
  pinnedColumnRefs?: string[];
  /** One resize-grip ref per `columns` entry that should be resizable
   * (typically a thin element at the header cell's trailing edge, placed
   * by the consumer) — dragging it adjusts that column's `width`, clamped
   * to its `minWidth`. */
  resizeHandleRefs?: string[];
  onColumnsChange?: (state: { hiddenColumnRefs: string[]; widths: Record<string, number> }) => void;
}

export interface ArkDataTableHandle {
  sortBy: (headerRef: string) => void;
  pageTo: (page: number) => void;
  showColumn: (headerRef: string) => void;
  hideColumn: (headerRef: string) => void;
  setColumnWidth: (headerRef: string, width: number) => void;
  getState: () => {
    page: number;
    pageCount: number;
    sortRef?: string;
    sortDirection: "asc" | "desc";
    hiddenColumnRefs: string[];
    widths: Record<string, number>;
  };
}

export declare function createArkItem(ui: ArkPrimitiveRuntime, options: ArkItemOptions): ArkItemHandle;
export declare function createArkMarker(ui: ArkPrimitiveRuntime, options: ArkMarkerOptions): ArkMarkerHandle;
export declare function createArkCollection(ui: ArkPrimitiveRuntime, options: ArkCollectionOptions): void;
export declare function createArkTable(ui: ArkPrimitiveRuntime, options: ArkTableOptions): ArkTableHandle;
export declare function createArkDataTable(ui: ArkPrimitiveRuntime, options: ArkDataTableOptions): ArkDataTableHandle;
