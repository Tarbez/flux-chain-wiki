import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkMenubarMenu {
  triggerRef: string;
  contentRef: string;
  itemRefs: string[];
  disabledItemRefs?: string[];
  labelRef?: string;
  descriptionRef?: string;
  initialFocusRef?: string;
}

export interface ArkMenubarOptions {
  rootRef: string;
  menus: ArkMenubarMenu[];
  activeRef?: string;
  stateRef?: string;
  loop?: boolean;
  onValueChange?: (ref: string, index: number) => void;
}

export interface ArkMegaMenuItem {
  triggerRef: string;
  /** Panel content ref. Unlike Menu/Menubar, this holds arbitrary markup — link
   * columns, a promo card, whatever — not a flat itemRefs list. */
  contentRef: string;
  disabled?: boolean;
}

export interface ArkMegaMenuOptions {
  rootRef: string;
  items: ArkMegaMenuItem[];
  activeRef?: string;
  stateRef?: string;
  loop?: boolean;
  /** Open panels on pointer hover in addition to click/keyboard. Default true,
   * matching how mega menus behave on marketing and e-commerce nav bars. */
  openOnHover?: boolean;
  hoverOpenDelay?: number;
  hoverCloseDelay?: number;
  placement?: "top" | "bottom";
  align?: "start" | "center" | "end";
  onValueChange?: (ref: string | null, index: number) => void;
}

export interface ArkMenubarHandle {
  open: (refOrIndex?: string | number) => void;
  close: () => void;
  select: (refOrIndex: string | number) => void;
  getState: () => { selectedRef: string; selectedIndex: number; open: boolean };
}

export interface ArkMegaMenuHandle {
  open: (refOrIndex: string | number) => void;
  close: () => void;
  toggle: (refOrIndex: string | number) => void;
  getState: () => { openRef: string | null; openIndex: number; triggerRefs: string[] };
}

/** A `role="menubar"` strip of triggers, each opening a full `createArkMenu`
 * popup, with ArrowLeft/ArrowRight carrying an open menu across the bar. */
export declare function createArkMenubar(ui: ArkPrimitiveRuntime, options: ArkMenubarOptions): ArkMenubarHandle;

/** A horizontal trigger bar whose panels hold arbitrary navigation markup
 * rather than a flat menu-item list, with hover-intent open/close. */
export declare function createArkMegaMenu(ui: ArkPrimitiveRuntime, options: ArkMegaMenuOptions): ArkMegaMenuHandle;
