import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkAspectRatioOptions {
  containerRef: string;
  ratio?: number;
  stateRef?: string;
  onRatioChange?: (ratio: number) => void;
}

export interface ArkAspectRatioHandle {
  setRatio: (ratio: number) => void;
  getState: () => { ratio: number };
}

export declare function createArkAspectRatio(ui: ArkPrimitiveRuntime, options: ArkAspectRatioOptions): ArkAspectRatioHandle;

export interface ArkAttachmentOptions {
  inputRef: string;
  listRef?: string;
  emptyRef?: string;
  stateRef?: string;
  multiple?: boolean;
  /** Optional drop target. When set, dragging files over it and dropping
   * feeds the same file state as picking through the native input. */
  dropzoneRef?: string;
  onFilesChange?: (files: File[]) => void;
}

export interface ArkAttachmentHandle {
  clear: () => void;
  removeFile: (index: number) => void;
  getState: () => { files: Array<{ name: string; size: number; type: string }> };
}

export declare function createArkAttachment(ui: ArkPrimitiveRuntime, options: ArkAttachmentOptions): ArkAttachmentHandle;

export interface ArkAvatarOptions {
  rootRef: string;
  imageRef?: string;
  fallbackRef?: string;
  src?: string;
  alt?: string;
  /** Semantic size consumed by the Avatar recipe or consumer CSS. */
  size?: "sm" | "default" | "lg";
  /** Matches Radix/Base UI Avatar: hold the fallback for this many ms after
   * a load starts before showing it, so a fast image never flashes initials. */
  fallbackDelay?: number;
  statusRef?: string;
  status?: "online" | "offline" | "away" | "busy";
  onLoadingStatusChange?: (status: "idle" | "loading" | "loaded" | "error") => void;
}

export interface ArkAvatarHandle {
  setSrc: (src: string | undefined) => void;
  getState: () => { status: "idle" | "loading" | "loaded" | "error" };
}

export declare function createArkAvatar(ui: ArkPrimitiveRuntime, options: ArkAvatarOptions): ArkAvatarHandle;
