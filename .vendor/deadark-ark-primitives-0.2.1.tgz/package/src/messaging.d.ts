import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkMessageBubbleOptions {
  rootRef: string;
  /** "own" tail-rights the bubble (the current user sent it); "other"
   * tail-lefts it (someone else sent it) — the two sides of a chat thread. */
  align: "own" | "other";
  timestampRef?: string;
  timestampText?: string;
  /** Consecutive messages from the same sender: collapses the tail/avatar
   * treatment so a burst of messages reads as one group, not N separate
   * bubbles each restating who sent them. */
  grouped?: boolean;
  status?: "sending" | "sent" | "delivered" | "read" | "failed";
  statusRef?: string;
}

export declare function createArkMessageBubble(ui: ArkPrimitiveRuntime, options: ArkMessageBubbleOptions): void;

export interface ArkOverlayIndicatorOptions {
  anchorRef: string;
  indicatorRef: string;
  /** A plain presence dot when true/omitted-with-no-count; a number renders
   * as a count badge instead (capped at `max`, e.g. "9+"). */
  count?: number;
  max?: number;
  corner?: "top-right" | "top-left" | "bottom-right" | "bottom-left";
  /** Force the dot even when `count` is 0 — e.g. a plain "has activity"
   * marker rather than a count. */
  dot?: boolean;
}

export interface ArkOverlayIndicatorHandle {
  setCount: (count: number | undefined) => void;
  getState: () => { count: number | undefined; visible: boolean };
}

export declare function createArkOverlayIndicator(ui: ArkPrimitiveRuntime, options: ArkOverlayIndicatorOptions): ArkOverlayIndicatorHandle;

export interface ArkMessageScrollerOptions {
  viewportRef: string;
  /** How close to the bottom (px) still counts as "at bottom" for
   * auto-scroll purposes. */
  bottomThreshold?: number;
  /** A "N new messages" button/banner, shown only once the viewport has
   * scrolled up and `notifyNewContent()` fires while it's not at the
   * bottom. Needs a real `M-` meaning for its count text, same as
   * `createArkOverlayIndicator()`'s indicatorRef. */
  unreadRef?: string;
  stateRef?: string;
  onAtBottomChange?: (atBottom: boolean) => void;
}

export interface ArkMessageScrollerHandle {
  scrollToBottom: (options?: { smooth?: boolean }) => void;
  /** Call this right after appending a new message to the DOM: it
   * auto-scrolls if the viewport was already at the bottom, or bumps the
   * unread count/shows `unreadRef` if the user had scrolled up to read
   * history. */
  notifyNewContent: () => void;
  getState: () => { atBottom: boolean; unreadCount: number };
}

export declare function createArkMessageScroller(ui: ArkPrimitiveRuntime, options: ArkMessageScrollerOptions): ArkMessageScrollerHandle;

export interface ArkToastOptions {
  title?: string;
  description?: string;
  tone?: "info" | "success" | "warning" | "danger";
  duration?: number;
}

export interface ArkToastRegionOptions {
  regionRef: string;
  toastRefs: string[];
  titleRefs?: string[];
  descriptionRefs?: string[];
  closeRefs?: string[];
  defaultDuration?: number;
}

export interface ArkToastHandle {
  show: (toast: ArkToastOptions) => string | undefined;
  dismiss: (id: string) => void;
}

export declare function createArkToastRegion(ui: ArkPrimitiveRuntime, options: ArkToastRegionOptions): ArkToastHandle;
