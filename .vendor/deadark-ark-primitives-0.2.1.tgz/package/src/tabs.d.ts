import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkTabsOptions {
  rootRef?: string;
  listRef?: string;
  tabRefs?: string[];
  panelRefs?: string[];
  indicatorRef?: string;
  inferStructure?: boolean;
  orientation?: "horizontal" | "vertical";
  selectedValue?: string;
  values?: string[];
  defaultValue?: string | null;
  value?: string | null;
  selectedIndex?: number;
  selectedRef?: string;
  stateRef?: string;
  disabled?: boolean;
  disabledTabRefs?: string[];
  disabledValues?: string[];
  activationMode?: "automatic" | "manual";
  loopFocus?: boolean;
  controlled?: boolean;
  onSelectedChange?: (ref: string, index: number) => void;
  onValueChange?: (value: string | undefined, details: ArkTabsValueChangeDetails) => void;
}

export interface ArkTabsValueChangeDetails {
  value?: string;
  previousValue?: string;
  selectedIndex: number;
  previousIndex: number;
  selectedRef?: string;
  previousRef?: string;
  selectedPanelRef?: string;
  previousPanelRef?: string;
  orientation: "horizontal" | "vertical";
  activationMode: "automatic" | "manual";
  activationDirection: "start" | "end" | "none";
}

export interface ArkTabsHandle {
  select: (refOrIndex: string | number) => void;
  setValue: (value: string | null | undefined) => void;
  getState: () => {
    selectedRef?: string;
    selectedPanelRef?: string;
    selectedIndex: number;
    selectedValue?: string;
    orientation: "horizontal" | "vertical";
    activationMode: "automatic" | "manual";
    activationDirection: "start" | "end" | "none";
    disabled: boolean;
  };
}

export declare function createArkTabs(ui: ArkPrimitiveRuntime, options: ArkTabsOptions): ArkTabsHandle;

export interface ArkNavigationMenuOptions {
  listRef: string;
  triggerRefs: string[];
  contentRefs: string[];
  activeRef?: string;
  stateRef?: string;
  orientation?: "horizontal" | "vertical";
  onValueChange?: (ref: string, index: number) => void;
}

export interface ArkNavigationMenuHandle {
  select: (refOrIndex: string | number) => void;
  getState: () => { selectedRef: string; selectedIndex: number };
}

/**
 * A `role="navigation"` list whose triggers/panels are driven by
 * `createArkTabs` — the same selection, roving focus, and panel visibility
 * model, exposed through a narrower handle.
 */
export declare function createArkNavigationMenu(ui: ArkPrimitiveRuntime, options: ArkNavigationMenuOptions): ArkNavigationMenuHandle;
