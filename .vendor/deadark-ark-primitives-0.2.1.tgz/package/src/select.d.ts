import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkNativeSelectOption {
  value: string;
  label: string;
  disabled?: boolean;
}

export interface ArkNativeSelectOptions {
  selectRef: string;
  options: ArkNativeSelectOption[];
  value?: string;
  placeholder?: string;
  disabled?: boolean;
  stateRef?: string;
  onValueChange?: (value: string) => void;
}

export interface ArkNativeSelectHandle {
  setValue: (value: string) => void;
  getState: () => { value: string };
}

export interface ArkSelectOptions {
  triggerRef: string;
  contentRef: string;
  optionRefs: string[];
  valueRef?: string;
  labelRef?: string;
  descriptionRef?: string;
  initialFocusRef?: string;
  stateRef?: string;
  portal?: string;
  placement?: "top" | "right" | "bottom" | "left";
  align?: "start" | "center" | "end";
  selectedRef?: string;
  disabledOptionRefs?: string[];
  onValueChange?: (ref: string, value: string) => void;
  onHighlightChange?: (ref: string | undefined) => void;
  onOpenChange?: (open: boolean) => void;
}

export interface ArkSelectHandle {
  open: () => void;
  close: () => void;
  highlight: (ref: string) => void;
  select: (ref: string) => void;
  getState: () => { open: boolean; selectedRef: string; selectedText: string; highlightedRef: string };
}

export declare function createArkNativeSelect(ui: ArkPrimitiveRuntime, options: ArkNativeSelectOptions): ArkNativeSelectHandle;
export declare function createArkSelect(ui: ArkPrimitiveRuntime, options: ArkSelectOptions): ArkSelectHandle;
