/**
 * `createArkTooltip` — moved out of `ark-ui.components.ts` verbatim (same
 * logic, same call order, same observable behavior). See
 * ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * Hover/focus-driven, not press-driven like Dialog/Popover -- no focus trap,
 * no dismissable layer, just presence + overlay positioning + open/close
 * timers. Builds on `@deadark/ark-a11y` for ref normalization and
 * ARIA/attribute wiring, matching the plan's dependency direction:
 * `ark-primitives -> ark-a11y`.
 */
import { normalizeRef, setAttrs, syncModelRef } from "@deadark/ark-a11y/dom";
import { configurePresence } from "@deadark/ark-a11y/overlay";

function ref(value) {
  return normalizeRef(value);
}

function uniqueRefs(values) {
  return [...new Set(values.map((value) => ref(value)))];
}

export function createArkTooltip(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const triggerRefs = uniqueRefs([triggerRef, ...(options.triggerRefs || [])]);
  const contentRef = ref(options.contentRef);
  const stateRef = ref(options.stateRef);
  const delay = options.delay ?? 600;
  const closeDelay = options.closeDelay ?? 0;
  const hoverable = options.hoverable !== false;
  const controlled = options.controlled === true || options.open !== undefined;
  let open = options.open ?? options.defaultOpen ?? false;
  let activeTriggerRef = triggerRef;
  let reason = "none";
  let openTimer;
  let closeTimer;
  const clearTimers = () => {
    if (openTimer !== undefined) { clearTimeout(openTimer); openTimer = undefined; }
    if (closeTimer !== undefined) { clearTimeout(closeTimer); closeTimer = undefined; }
  };

  triggerRefs.forEach((currentTriggerRef) => ui.configureRef(currentTriggerRef, { describedBy: contentRef }));
  ui.configureRef(contentRef, {
    role: "tooltip",
    part: "tooltip",
    overlay: {
      anchorRef: triggerRef,
      portal: options.portal ?? "layers",
      placement: options.placement ?? "top",
      align: options.align ?? "center",
      offset: options.offset ?? 6,
      collisionPadding: options.collisionPadding ?? 10,
    },
  });
  configurePresence(ui, contentRef, { unmountOnExit: true, ariaHidden: true });

  const detailsFor = (nextReason, nextTriggerRef = activeTriggerRef) => {
    const details = {
      reason: nextReason,
      triggerRef: nextTriggerRef,
      isCanceled: false,
      cancel() { details.isCanceled = true; },
    };
    return details;
  };
  const syncState = () => {
    triggerRefs.forEach((currentTriggerRef) => setAttrs(ui, currentTriggerRef, {
      "data-popup-open": open ? "true" : undefined,
    }));
    const current = ui.get(contentRef) || {};
    ui.update(contentRef, { ...current, open, hidden: !open });
    setAttrs(ui, contentRef, {
      "data-open": open ? "true" : undefined,
      "data-closed": !open ? "true" : undefined,
      "data-state": open ? "open" : "closed",
    });
    syncModelRef(ui, stateRef, { open, activeTriggerRef, reason, controlled });
  };
  const applyOpen = (nextOpen, details, force = false, notify = true) => {
    if (notify) options.onOpenChange?.(nextOpen, details);
    if (details.isCanceled || (controlled && !force)) return;
    open = nextOpen;
    reason = details.reason;
    activeTriggerRef = details.triggerRef;
    syncState();
    if (nextOpen) ui.openOverlay(contentRef);
    else ui.closeOverlay(contentRef);
    options.onOpenChangeComplete?.(nextOpen, details);
  };
  const requestOpen = (nextOpen, nextReason, nextTriggerRef = activeTriggerRef, force = false, notify = true) => {
    applyOpen(nextOpen, detailsFor(nextReason, nextTriggerRef), force, notify);
  };
  const scheduleOpen = (nextReason, nextTriggerRef) => {
    if (options.disabled) return;
    clearTimers();
    if (open || delay <= 0) { requestOpen(true, nextReason, nextTriggerRef); return; }
    openTimer = setTimeout(() => requestOpen(true, nextReason, nextTriggerRef), delay);
  };
  const scheduleClose = () => {
    clearTimers();
    if (closeDelay <= 0) { requestOpen(false, activeTriggerRef ? reason : "none", activeTriggerRef); return; }
    closeTimer = setTimeout(() => requestOpen(false, activeTriggerRef ? reason : "none", activeTriggerRef), closeDelay);
  };

  triggerRefs.forEach((currentTriggerRef) => {
    ui.bindRefEvent(currentTriggerRef, "mouseenter", () => scheduleOpen("trigger-hover", currentTriggerRef));
    ui.bindRefEvent(currentTriggerRef, "focus", () => scheduleOpen("trigger-focus", currentTriggerRef));
    ui.bindRefEvent(currentTriggerRef, "mouseleave", () => scheduleClose());
    ui.bindRefEvent(currentTriggerRef, "blur", () => scheduleClose());
    ui.bindRefEvent(currentTriggerRef, "keydown", (rawEvent) => {
      const event = rawEvent;
      if (event.key !== "Escape" || options.escapeKey === false) return;
      const details = detailsFor("escape-key", currentTriggerRef);
      applyOpen(false, details);
    });
  });
  if (hoverable) {
    ui.bindRefEvent(contentRef, "mouseenter", () => clearTimers());
    ui.bindRefEvent(contentRef, "mouseleave", () => scheduleClose());
  }
  syncState();
  if (open) ui.openOverlay(contentRef);
  return {
    open: (nextTriggerRef = triggerRef) => requestOpen(true, "imperative-action", ref(nextTriggerRef), true),
    close: () => requestOpen(false, "imperative-action", activeTriggerRef, true),
    toggle: (nextTriggerRef = triggerRef) => requestOpen(!open, "imperative-action", ref(nextTriggerRef), true),
    setOpen: (nextOpen, nextTriggerRef = triggerRef) => requestOpen(nextOpen, "imperative-action", ref(nextTriggerRef), true),
    syncControlled: (nextOpen, nextTriggerRef = triggerRef) => requestOpen(nextOpen, "controlled-sync", ref(nextTriggerRef), true, false),
    getState: () => ({ open, activeTriggerRef, reason, controlled }),
  };
}
