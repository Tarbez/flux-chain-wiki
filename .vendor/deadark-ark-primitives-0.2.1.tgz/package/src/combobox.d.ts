import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkComboboxGroup {
  /** The wrapping container for this group's options — hidden automatically
   * once every option inside it is filtered out, so an empty group heading
   * never sits alone in the filtered list. */
  groupRef: string;
  /** Optional heading text ref; wires `role="group"`/`aria-labelledby` on
   * `groupRef` the same way a native `<optgroup>` labels its options. */
  labelRef?: string;
  optionRefs: string[];
}

export interface ArkComboboxOptions {
  inputRef: string;
  contentRef: string;
  optionRefs: string[];
  triggerRef?: string;
  clearRef?: string;
  labelRef?: string;
  descriptionRef?: string;
  initialActiveRef?: string;
  stateRef?: string;
  emptyRef?: string;
  portal?: string;
  placement?: "top" | "right" | "bottom" | "left";
  align?: "start" | "center" | "end";
  selectedRef?: string;
  disabledOptionRefs?: string[];
  openOnFocus?: boolean;
  openOnInputClick?: boolean;
  disabled?: boolean;
  readOnly?: boolean;
  required?: boolean;
  invalid?: boolean;
  name?: string;
  form?: string;
  /** Labelled subsets of `optionRefs` — every ref used here must also be
   * present in the flat `optionRefs` list, which stays the single source
   * of truth for filtering, highlight order, and roving focus. */
  groups?: ArkComboboxGroup[];
  filter?: (query: string, optionText: string, optionRef: string) => boolean;
  onValueChange?: (ref: string, value: string) => void;
  onInputValueChange?: (value: string) => void;
  onHighlightChange?: (ref: string | undefined) => void;
  onOpenChange?: (open: boolean) => void;
}

export interface ArkComboboxHandle {
  open: () => void;
  close: () => void;
  clear: () => void;
  highlight: (ref: string | undefined) => void;
  select: (ref: string) => void;
  setQuery: (value: string) => void;
  getState: () => {
    open: boolean;
    committedRef: string;
    committedText: string;
    highlightedRef?: string;
    inputValue: string;
    visibleRefs: string[];
  };
}

export interface ArkCommandSurfaceOptions {
  inputRef: string;
  contentRef: string;
  optionRefs: string[];
  labelRef?: string;
  descriptionRef?: string;
  emptyRef?: string;
  loadingRef?: string;
  selectedRef?: string;
  openOnFocus?: boolean;
  loading?: boolean;
  filter?: (query: string, optionText: string, optionRef: string) => boolean;
  onCommand?: (ref: string, value: string) => void;
  onQueryChange?: (value: string) => void;
}

export declare function createArkCombobox(ui: ArkPrimitiveRuntime, options: ArkComboboxOptions): ArkComboboxHandle;
export declare function createArkCommandSurface(ui: ArkPrimitiveRuntime, options: ArkCommandSurfaceOptions): ArkComboboxHandle;
