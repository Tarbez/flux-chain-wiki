import type { ArkPrimitiveRuntime } from "./runtime.js";

export interface ArkCalendarRange {
  start?: Date;
  end?: Date;
}

export interface ArkCalendarOptions {
  gridRef: string;
  dayRefs: string[];
  labelRef?: string;
  prevRef?: string;
  nextRef?: string;
  month?: number;
  year?: number;
  selectedDate?: Date;
  disabledDates?: Date[];
  /** Predicate form of disabling, composed with `disabledDates`/`minDate`/`maxDate` rather than replacing them. */
  disabled?: (date: Date) => boolean;
  /** Dates strictly before/after these (by calendar day, not time-of-day)
   * are disabled the same as an explicit `disabledDates` entry. */
  minDate?: Date;
  maxDate?: Date;
  /** BCP 47 locale for the month/year label, e.g. "fr-FR". Defaults to the
   * runtime's own locale (same as omitting a locale from `toLocaleDateString`). */
  locale?: string;
  /** 0 (Sunday) through 6 (Saturday). Defaults to 0, matching `Date#getDay()`. */
  weekStartsOn?: 0 | 1 | 2 | 3 | 4 | 5 | 6;
  /** "range" and "multiple" are genuinely different selection models, not
   * variants of "single". "range": clicking picks a start, then an end
   * (swapping them if the second pick lands before the first), and every
   * day between the two gets a `data-range-middle` marker for a consumer to
   * style as a solid highlighted band. "multiple": each click toggles that
   * day in/out of an unordered set, like shadcn/react-day-picker's
   * `mode="multiple"`. Defaults to "single". */
  mode?: "single" | "range" | "multiple";
  selectedRange?: ArkCalendarRange;
  selectedDates?: Date[];
  onDateChange?: (date: Date) => void;
  onRangeChange?: (range: ArkCalendarRange) => void;
  onDatesChange?: (dates: Date[]) => void;
  onMonthChange?: (month: number, year: number) => void;
}

export interface ArkCalendarHandle {
  select: (date: Date) => void;
  goToMonth: (month: number, year: number) => void;
  getState: () => { month: number; year: number; selectedDate?: Date; selectedRange?: ArkCalendarRange; selectedDates?: Date[] };
}

export declare function createArkCalendar(ui: ArkPrimitiveRuntime, options: ArkCalendarOptions): ArkCalendarHandle;

export interface ArkDatePickerOptions extends Omit<ArkCalendarOptions, "onDateChange"> {
  triggerRef: string;
  contentRef: string;
  valueRef?: string;
  portal?: string;
  formatDate?: (date: Date) => string;
  /** Formats a complete `{ start, end }` range for `valueRef`, e.g.
   * "Jan 4 – Jan 9". Defaults to joining two `formatDate()` calls with " - ". */
  formatRange?: (range: ArkCalendarRange) => string;
  onDateChange?: (date: Date) => void;
}

export declare function createArkDatePicker(ui: ArkPrimitiveRuntime, options: ArkDatePickerOptions): ArkCalendarHandle;
