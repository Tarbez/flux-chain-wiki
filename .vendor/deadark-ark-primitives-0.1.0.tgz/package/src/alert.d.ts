import type { ArkPrimitiveRuntime } from "./runtime.js";
import type { ArkDisclosureHandle } from "./disclosure.js";
import type { ArkDialogOptions } from "./dialog.js";

export interface ArkAlertOptions {
  rootRef: string;
  titleRef?: string;
  descriptionRef?: string;
  iconRef?: string;
  actionRefs?: string[];
  dismissRef?: string;
  tone?: "info" | "success" | "warning" | "danger";
  live?: "polite" | "assertive" | false;
  defaultOpen?: boolean;
  /** Externally controlled open state. Presence of `open` implies `controlled: true`. */
  open?: boolean;
  /** Emits onOpenChange without mutating until the consumer calls handle.syncControlled(). */
  controlled?: boolean;
  stateRef?: string;
  onOpenChange?: (open: boolean) => void;
}

export interface ArkAlertHandle extends ArkDisclosureHandle {
  syncControlled: (open: boolean) => void;
}

export declare function createArkAlert(ui: ArkPrimitiveRuntime, options: ArkAlertOptions): ArkAlertHandle;

export type ArkAlertDialogChangeReason =
  | "trigger-press"
  | "escape-key"
  | "outside-press"
  | "action-press"
  | "cancel-press"
  | "imperative-action"
  | "controlled-sync"
  | "none";

export interface ArkAlertDialogChangeDetails {
  reason: ArkAlertDialogChangeReason;
  triggerRef?: string;
  payload?: unknown;
  event?: Event;
  isCanceled: boolean;
  isPropagationAllowed: boolean;
  cancel: () => void;
  /** Lets a dismissal (Escape, outside-press) continue past this dialog to a
   * dialog it's nested inside, instead of only closing this one. Mirrors
   * base-ui's `allowPropagation()` on change-event details. */
  allowPropagation: () => void;
}

export interface ArkAlertDialogActionDetails extends ArkAlertDialogChangeDetails {
  actionRef: string;
}

export interface ArkAlertDialogOptions extends ArkDialogOptions {
  /** Additional triggers that open the same dialog. `triggerRef` remains the primary focus-restore anchor. */
  triggerRefs?: string[];
  actionRef?: string;
  actionRefs?: string[];
  cancelRef?: string;
  cancelRefs?: string[];
  viewportRef?: string;
  /** Optional icon/illustration slot, matching shadcn's AlertDialogMedia. */
  mediaRef?: string;
  stateRef?: string;
  /** Surfaced as `data-size` on content — sizing itself is left to the
   * consumer's CSS, matching the "primitives ship unstyled" rule. */
  size?: "default" | "sm";
  tone?: "info" | "warning" | "danger";
  defaultOpen?: boolean;
  open?: boolean;
  controlled?: boolean;
  disabled?: boolean;
  keepMounted?: boolean;
  escapeKey?: boolean;
  /** Alert dialogs are non-dismissible by default (unlike plain dialogs) —
   * an outside click only requests closure when this is explicitly true. */
  closeOnOutsidePress?: boolean;
  closeOnAction?: boolean;
  closeOnCancel?: boolean;
  /** Payloads keyed by trigger ref, mirroring detached/multiple-trigger payloads. */
  triggerPayloads?: Record<string, unknown>;
  onOpenChange?: (open: boolean, details: ArkAlertDialogChangeDetails) => void;
  onOpenChangeComplete?: (open: boolean, details: ArkAlertDialogChangeDetails) => void;
  onAction?: (details: ArkAlertDialogActionDetails) => boolean | void;
  onCancel?: (details: ArkAlertDialogActionDetails) => boolean | void;
  onEscapeKeyDown?: (event: KeyboardEvent, details: ArkAlertDialogChangeDetails) => boolean | void;
  onOutsidePress?: (details: ArkAlertDialogChangeDetails) => boolean | void;
}

export interface ArkAlertDialogHandle {
  open: (triggerRef?: string, payload?: unknown) => void;
  close: () => void;
  toggle: (triggerRef?: string, payload?: unknown) => void;
  setOpen: (open: boolean, triggerRef?: string, payload?: unknown) => void;
  syncControlled: (open: boolean, triggerRef?: string, payload?: unknown) => void;
  getState: () => {
    open: boolean;
    activeTriggerRef?: string;
    payload?: unknown;
    reason: ArkAlertDialogChangeReason;
    controlled: boolean;
    mounted: boolean;
  };
}

export declare function createArkAlertDialog(ui: ArkPrimitiveRuntime, options: ArkAlertDialogOptions): ArkAlertDialogHandle;
