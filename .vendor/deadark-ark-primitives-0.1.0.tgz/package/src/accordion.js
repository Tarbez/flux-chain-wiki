/**
 * The accordion family — `createArkAccordion` — moved out of
 * `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * Disclosure-shaped, but not a disclosure: an accordion owns a *set* of
 * trigger/panel pairs and the policy that relates them. "single" mode keeps at
 * most one open (and, with `collapsible: false`, at least one), "multiple"
 * lets them open independently — which is why the open state here is a set of
 * indexes rather than the single boolean `createArkDisclosure()` carries, and
 * why the triggers additionally form one roving-tabindex group so arrow keys
 * walk headers instead of Tab visiting every one of them.
 *
 * Three things are load-bearing and easy to break by "tidying":
 *
 *  - Values, not indexes, are the public identity. `values[i]` defaults to
 *    `itemRefs[i]` then `triggerRefs[i]`, and every handle method and change
 *    detail speaks in values, so consumers survive reordering.
 *  - Panel heights are measured after the attribute pass, not during it: every
 *    `update()`/`setAttrs()` replaces the panel's DOM node, dropping anything
 *    written to the previous one. The `ResizeObserver` is re-attached on each
 *    pass for the same reason, and it watches the panel's *content child*, not
 *    the panel, because the panel's own box is what `max-height` drives.
 *  - `syncingStateRef` guards the controlled-mode `observe()` loop: the state
 *    write this factory performs must not read back as an external change.
 *
 * Built on `@deadark/ark-a11y` for ref normalization, attribute wiring,
 * roving-focus recipes, CSP-safe style writes, and markup-structure
 * inference — the plan's dependency direction: `ark-primitives -> ark-a11y`.
 */
import { normalizeRef, normalizeRefs, setAttrs, syncModelRef } from "@deadark/ark-a11y/dom";
import { setArkElementStyle } from "@deadark/ark-a11y/element-style";
import { configureStripFocusGroup } from "@deadark/ark-a11y/collection";
import { readElementRef, readFoundation, walkElementTree, findFirstFoundation } from "@deadark/ark-a11y/structure";

function ref(value) {
  return normalizeRef(value);
}

/**
 * The custom property an accordion panel's measured content height is
 * published to. Exported because the `ACCORDIONCONTENT` style recipe in
 * `ark-ui.components.ts` resolves its `max-height` against this exact name —
 * the two must not be allowed to drift — and because a consumer writing its
 * own panel CSS needs it too.
 */
export const ARK_ACCORDION_CONTENT_HEIGHT_VAR = "--ark-accordion-content-height";

function parseTimeValue(raw, fallback) {
  if (!raw) return fallback;
  const match = String(raw).trim().match(/^(-?\d+(?:\.\d+)?)(ms|s)?$/i);
  if (!match) return fallback;
  const value = Number(match[1]);
  if (!Number.isFinite(value)) return fallback;
  return match[2] === "s" ? value * 1000 : value;
}

function normalizeAccordionValues(value) {
  if (value === undefined) return [];
  return Array.isArray(value) ? value : [value];
}

function inferAccordionStructure(ui, rootRef) {
  const rootEl = ui.getElement(rootRef);
  if (!rootEl) return { itemRefs: [], triggerRefs: [], panelRefs: [], headerRefs: [] };
  const descendants = walkElementTree(rootEl);
  const itemEls = descendants.filter((node) => readFoundation(node) === "ACCORDIONITEM");
  if (itemEls.length > 0) {
    const structure = itemEls.map((itemEl) => ({
      itemRef: readElementRef(itemEl),
      triggerRef: readElementRef(findFirstFoundation(itemEl, "ACCORDIONTRIGGER")),
      panelRef: readElementRef(findFirstFoundation(itemEl, "ACCORDIONCONTENT")),
      headerRef: readElementRef(findFirstFoundation(itemEl, "ACCORDIONHEADER")),
    })).filter((entry) => entry.triggerRef && entry.panelRef);
    return {
      itemRefs: structure.map((entry) => entry.itemRef || entry.triggerRef),
      triggerRefs: structure.map((entry) => entry.triggerRef),
      panelRefs: structure.map((entry) => entry.panelRef),
      headerRefs: structure.map((entry) => entry.headerRef).filter((value) => !!value),
    };
  }
  const triggerRefs = descendants
    .filter((node) => readFoundation(node) === "ACCORDIONTRIGGER")
    .map((node) => readElementRef(node))
    .filter((value) => !!value);
  const panelRefs = descendants
    .filter((node) => readFoundation(node) === "ACCORDIONCONTENT")
    .map((node) => readElementRef(node))
    .filter((value) => !!value);
  const headerRefs = descendants
    .filter((node) => readFoundation(node) === "ACCORDIONHEADER")
    .map((node) => readElementRef(node))
    .filter((value) => !!value);
  return { itemRefs: [...triggerRefs], triggerRefs, panelRefs, headerRefs };
}

function accordionIndexesFromStateValue(state, values, triggerCount) {
  if (!state || typeof state !== "object") return undefined;
  const source = state;
  if (Array.isArray(source.openIndexes) && source.openIndexes.every((entry) => typeof entry === "number")) return source.openIndexes;
  if (Array.isArray(source.openValues) && source.openValues.every((entry) => typeof entry === "string")) {
    return source.openValues.map((value) => values.indexOf(value)).filter((index) => index >= 0);
  }
  if (Array.isArray(source.value)) {
    if (source.value.every((entry) => typeof entry === "number")) return source.value.filter((index) => index >= 0 && index < triggerCount);
    if (source.value.every((entry) => typeof entry === "string")) return source.value.map((value) => values.indexOf(value)).filter((index) => index >= 0);
  }
  if (typeof source.value === "string") {
    const index = values.indexOf(source.value);
    return index >= 0 ? [index] : [];
  }
  return undefined;
}

export function createArkAccordion(ui, options) {
  const rootRef = ref(options.rootRef);
  const inferred = rootRef && (options.inferStructure !== false || !options.triggerRefs || !options.panelRefs)
    ? inferAccordionStructure(ui, rootRef)
    : { itemRefs: [], triggerRefs: [], panelRefs: [], headerRefs: [] };
  const triggerRefs = normalizeRefs(options.triggerRefs ?? inferred.triggerRefs);
  const panelRefs = normalizeRefs(options.panelRefs ?? inferred.panelRefs);
  const headerRefs = normalizeRefs(options.headerRefs ?? inferred.headerRefs);
  const itemRefs = normalizeRefs(options.itemRefs ?? inferred.itemRefs);
  const listRef = ref(options.listRef || rootRef || triggerRefs[0]);
  const orientation = options.orientation ?? "vertical";
  const collectionId = `${listRef}-accordion`;
  const multiple = options.type ? options.type === "multiple" : !!options.multiple;
  const collapsible = options.collapsible ?? true;
  const loopFocus = options.loopFocus ?? true;
  const controlled = !!options.controlled;
  const accordionDisabled = !!options.disabled;
  const disabledRefs = new Set((options.disabledRefs ?? []).map((value) => ref(value)));
  const disabledItemRefs = new Set((options.disabledItemRefs ?? []).map((value) => ref(value)));
  const stateRef = ref(options.stateRef);
  const values = triggerRefs.map((triggerRef, index) => options.values?.[index] ?? itemRefs[index] ?? triggerRef);
  const itemRefForIndex = (index) => itemRefs[index] ?? triggerRefs[index];
  const indexByValue = new Map(values.map((value, index) => [value, index]));
  const type = multiple ? "multiple" : "single";

  const filterIndexes = (indexes) => indexes
    .filter((index) => index >= 0 && index < triggerRefs.length)
    .filter((index, position, source) => source.indexOf(index) === position)
    .filter((index) => !accordionDisabled && !disabledRefs.has(triggerRefs[index]) && !disabledItemRefs.has(itemRefForIndex(index)));
  const indexesFromValues = (rawValues) => filterIndexes(rawValues.map((value) => indexByValue.get(value) ?? -1));
  const normalizeOpenIndexes = (indexes) => {
    const next = filterIndexes(indexes);
    if (multiple) return next;
    if (next.length > 0) return [next[0]];
    if (!collapsible) {
      const fallback = triggerRefs.findIndex((triggerRef, index) => !disabledRefs.has(triggerRef) && !disabledItemRefs.has(itemRefForIndex(index)));
      return fallback >= 0 ? [fallback] : [];
    }
    return [];
  };
  const stateDrivenIndexes = controlled ? accordionIndexesFromStateValue(ui.get(stateRef || ""), values, triggerRefs.length) : undefined;
  const initialIndexes = stateDrivenIndexes ?? (options.value !== undefined
    ? indexesFromValues(normalizeAccordionValues(options.value))
    : options.defaultValue !== undefined
      ? indexesFromValues(normalizeAccordionValues(options.defaultValue))
      : filterIndexes(options.defaultOpen ?? [0]));
  let openSet = new Set(normalizeOpenIndexes(initialIndexes));
  let syncingStateRef = false;
  // Writes a panel's measured content height to the custom property its
  // max-height transition resolves against. Tolerates hosts without a full
  // CSSOM (the headless render path, test harnesses) by simply not measuring.
  const measurePanelContent = (panelEl) => {
    if (!panelEl) return;
    setArkElementStyle(panelEl, ARK_ACCORDION_CONTENT_HEIGHT_VAR, `${panelEl.scrollHeight || 0}px`);
  };
  // Keeps the measurement honest when the content reflows without a state
  // change — a viewport resize rewrapping text, or content swapped in later.
  // Without this an open panel would keep the height it had when it opened
  // and clip whatever grew past it.
  const contentResizeObserver = typeof ResizeObserver === "function"
    ? new ResizeObserver((entries) => {
        entries.forEach((entry) => measurePanelContent(entry.target.parentElement ?? undefined));
      })
    : undefined;
  const animationOptions = options.animation === false ? null : (
    options.animation && typeof options.animation === "object" ? options.animation : {}
  );
  const accordionAnimationAttrs = (panelRef, index) => {
    if (!animationOptions) return {};
    const expression = `$${panelRef}.open ? ${animationOptions.enterPreset || "accordion:enter"} : ${animationOptions.exitPreset || "accordion:exit"}`;
    return {
      "data-flx-animate": expression,
      "data-flx-animate-duration": animationOptions.duration,
      "data-flx-animate-easing": animationOptions.easing,
      "data-flx-animate-delay": animationOptions.delay ?? (animationOptions.stagger ? `${index * parseTimeValue(animationOptions.stagger, 0)}ms` : undefined),
      "data-flx-animate-config": animationOptions.config ? JSON.stringify(animationOptions.config) : undefined,
      "data-flx-animate-once": animationOptions.once ? "true" : undefined,
    };
  };

  const detailsFromIndexes = (indexes, changedIndex) => ({
    openValues: indexes.map((index) => values[index]),
    openIndexes: indexes,
    openTriggerRefs: indexes.map((index) => triggerRefs[index]),
    openPanelRefs: indexes.map((index) => panelRefs[index]).filter(Boolean),
    openItemRefs: indexes.map((index) => itemRefForIndex(index)).filter(Boolean),
    changedValue: changedIndex !== undefined ? values[changedIndex] : undefined,
    changedIndex,
    changedTriggerRef: changedIndex !== undefined ? triggerRefs[changedIndex] : undefined,
    changedPanelRef: changedIndex !== undefined ? panelRefs[changedIndex] : undefined,
    changedItemRef: changedIndex !== undefined ? itemRefForIndex(changedIndex) : undefined,
    type,
  });

  const applyOpenIndexes = (indexes, changedIndex, source = "local") => {
    openSet = new Set(normalizeOpenIndexes(indexes));
    sync(changedIndex, source === "local", source === "local");
  };

  function sync(changedIndex, emitChange = true, writeState = true) {
    const openIndexes = Array.from(openSet).sort((a, b) => a - b);
    const openValues = openIndexes.map((index) => values[index]);
    const detail = detailsFromIndexes(openIndexes, changedIndex);
    const rootTargetRef = rootRef || listRef;
    setAttrs(ui, rootTargetRef, {
      "data-accordion-root": "true",
      "data-orientation": orientation,
      "data-disabled": accordionDisabled ? "true" : undefined,
    });
    if (rootTargetRef !== listRef) {
      setAttrs(ui, listRef, {
        "data-accordion-root": "true",
        "data-orientation": orientation,
        "data-disabled": accordionDisabled ? "true" : undefined,
      });
    }
    triggerRefs.forEach((triggerRef, index) => {
      const open = openSet.has(index);
      const itemRef = itemRefForIndex(index);
      const disabled = accordionDisabled || disabledRefs.has(triggerRef) || disabledItemRefs.has(itemRef);
      const triggerState = ui.get(triggerRef) || {};
      ui.update(triggerRef, { ...triggerState, expanded: open, open, disabled });
      setAttrs(ui, triggerRef, {
        "data-index": String(index),
        "data-value": values[index],
        "data-open": open ? "true" : undefined,
        "data-state": open ? "open" : "closed",
        "data-disabled": disabled ? "true" : undefined,
        "data-orientation": orientation,
      });
      if (itemRef) {
        setAttrs(ui, itemRef, {
          "data-index": String(index),
          "data-value": values[index],
          "data-open": open ? "true" : undefined,
          "data-state": open ? "open" : "closed",
          "data-disabled": disabled ? "true" : undefined,
          "data-orientation": orientation,
        });
      }
      const panelRef = panelRefs[index];
      if (!panelRef) return;
      const panelState = ui.get(panelRef) || {};
      ui.update(panelRef, { ...panelState, hidden: !open, open });
      setAttrs(ui, panelRef, {
        "data-index": String(index),
        "data-value": values[index],
        "data-open": open ? "true" : undefined,
        "data-state": open ? "open" : "closed",
        "data-disabled": disabled ? "true" : undefined,
        "data-orientation": orientation,
        hidden: !open && options.hiddenUntilFound ? "until-found" : undefined,
        ...accordionAnimationAttrs(panelRef, index),
      });
    });
    // Publish each panel's real content height for its max-height transition.
    // scrollHeight reads the full content even while the panel is clamped to
    // 0, so a collapsed panel still measures correctly and has its open height
    // ready before it's ever expanded. This runs after the loop above because
    // every update/setAttrs call there replaces the panel node, which drops
    // any inline value written to the previous one.
    //
    // Re-observing here (rather than once at setup) is deliberate for the same
    // reason: the nodes observed on the previous pass are detached by now. The
    // observer watches the *content* child, not the panel — the panel's own
    // box is what max-height drives, so observing it would feed back into the
    // measurement it triggers.
    contentResizeObserver?.disconnect();
    panelRefs.forEach((panelRef) => {
      if (!panelRef) return;
      const panelEl = ui.getElement(panelRef);
      measurePanelContent(panelEl);
      const contentEl = panelEl?.firstElementChild;
      if (contentEl) contentResizeObserver?.observe(contentEl);
    });
    if (writeState) {
      syncingStateRef = true;
      syncModelRef(ui, stateRef, {
        value: openValues,
        openValues,
        openIndexes,
        openTriggerRefs: detail.openTriggerRefs,
        openPanelRefs: detail.openPanelRefs,
        openItemRefs: detail.openItemRefs,
        values: [...values],
        triggerRefs: [...triggerRefs],
        panelRefs: [...panelRefs],
        itemRefs: triggerRefs.map((_, index) => itemRefForIndex(index)),
        disabled: accordionDisabled,
        type,
        orientation,
        loopFocus,
        keepMounted: options.keepMounted ?? true,
        hiddenUntilFound: !!options.hiddenUntilFound,
        controlled,
      });
      syncingStateRef = false;
    }
    if (emitChange) options.onValueChange?.(openValues, detail);
  }

  if (triggerRefs.length === 0 || panelRefs.length === 0) {
    throw new Error("createArkAccordion requires trigger/panel refs or a rootRef with inferable ACCORDION parts.");
  }
  ui.configureRef(listRef, { role: "presentation", orientation });
  triggerRefs.forEach((triggerRef, index) => {
    const headerRef = headerRefs[index];
    const panelRef = panelRefs[index];
    if (headerRef) setAttrs(ui, headerRef, { role: "heading" });
    ui.configureRef(triggerRef, {
      role: "button",
      controls: panelRef,
      collection: collectionId,
    });
    if (panelRef) {
      ui.configureRef(panelRef, { role: "region", labelledBy: triggerRef });
      const unmountOnExit = options.keepMounted === false ? true : false;
      ui.createPresence(panelRef, { unmountOnExit, animateOut: !unmountOnExit });
    }
    ui.onAction(triggerRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      const itemRef = itemRefForIndex(index);
      if (accordionDisabled || disabledRefs.has(triggerRef) || disabledItemRefs.has(itemRef)) return;
      let next = new Set(openSet);
      if (multiple) {
        if (next.has(index)) next.delete(index);
        else next.add(index);
      } else if (next.has(index)) {
        if (collapsible) next = new Set();
      } else {
        next = new Set([index]);
      }
      applyOpenIndexes(Array.from(next), index, "local");
    });
  });
  configureStripFocusGroup(ui, collectionId, triggerRefs, { orientation, loop: loopFocus, typeahead: false });
  if (controlled && stateRef && typeof ui.observe === "function") {
    ui.observe(stateRef, (value) => {
      if (syncingStateRef) return;
      const nextIndexes = accordionIndexesFromStateValue(value, values, triggerRefs.length);
      if (!nextIndexes) return;
      applyOpenIndexes(nextIndexes, undefined, "external");
    });
  }
  sync();
  return {
    setValue: (value) => applyOpenIndexes(indexesFromValues(normalizeAccordionValues(value))),
    open: (value) => {
      const index = indexByValue.get(value);
      if (index === undefined) return;
      const next = multiple ? [...openSet, index] : [index];
      applyOpenIndexes(next, index);
    },
    close: (value) => {
      if (value === undefined) {
        applyOpenIndexes([], undefined);
        return;
      }
      const index = indexByValue.get(value);
      if (index === undefined) return;
      applyOpenIndexes(Array.from(openSet).filter((openIndex) => openIndex !== index), index);
    },
    toggle: (value) => {
      const index = indexByValue.get(value);
      if (index === undefined) return;
      const next = new Set(openSet);
      if (next.has(index)) next.delete(index);
      else if (multiple) next.add(index);
      else {
        next.clear();
        next.add(index);
      }
      applyOpenIndexes(Array.from(next), index);
    },
    getState: () => {
      const openIndexes = Array.from(openSet).sort((a, b) => a - b);
      return {
        openValues: openIndexes.map((index) => values[index]),
        openIndexes,
        openTriggerRefs: openIndexes.map((index) => triggerRefs[index]),
        openPanelRefs: openIndexes.map((index) => panelRefs[index]).filter(Boolean),
        openItemRefs: openIndexes.map((index) => itemRefForIndex(index)).filter(Boolean),
        type,
        disabled: accordionDisabled,
      };
    },
  };
}
