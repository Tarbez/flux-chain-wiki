/**
 * `createArkMessageBubble`, `createArkOverlayIndicator`,
 * `createArkMessageScroller`, `createArkToastRegion` — moved out of
 * `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * `createArkToastRegion` uses `@deadark/ark-a11y/live-region`'s
 * `configureLiveRegion`/`announce` instead of calling
 * `ui.createLiveRegion`/`ui.announce` directly, matching the pattern
 * `createArkAlert` already established in `alert.js`.
 */
import { normalizeRef, normalizeRefs, setAttrs, setHidden, syncModelRef } from "@deadark/ark-a11y/dom";
import { configureLiveRegion, announce } from "@deadark/ark-a11y/live-region";

function ref(value) {
  return normalizeRef(value);
}

export function createArkMessageBubble(ui, options) {
  const rootRef = ref(options.rootRef);
  const timestampRef = ref(options.timestampRef);
  const statusRef = ref(options.statusRef);
  ui.configureRef(rootRef, { part: "message-bubble" });
  setAttrs(ui, rootRef, {
    "data-align": options.align,
    "data-grouped": options.grouped ? "true" : undefined,
  });
  if (timestampRef) {
    ui.configureRef(timestampRef, { part: "message-bubble-timestamp" });
    if (options.timestampText) {
      const current = ui.get(timestampRef) || {};
      ui.update(timestampRef, { ...current, text: options.timestampText });
    }
  }
  if (statusRef) {
    ui.configureRef(statusRef, { part: "message-bubble-status" });
    if (options.status) setAttrs(ui, statusRef, { "data-status": options.status });
  }
}

export function createArkOverlayIndicator(ui, options) {
  const anchorRef = ref(options.anchorRef);
  const indicatorRef = ref(options.indicatorRef);
  const max = options.max ?? 99;
  let count = options.count;

  const corner = options.corner ?? "top-right";
  const cornerStyle = corner === "top-right" ? { top: "0", right: "0", transform: "translate(35%, -35%)" }
    : corner === "top-left" ? { top: "0", left: "0", transform: "translate(-35%, -35%)" }
    : corner === "bottom-right" ? { bottom: "0", right: "0", transform: "translate(35%, 35%)" }
    : { bottom: "0", left: "0", transform: "translate(-35%, 35%)" };

  const sync = () => {
    const isCount = typeof count === "number";
    const visible = options.dot || (isCount ? count > 0 : false);
    ui.configureRef(indicatorRef, { part: "overlay-indicator" });
    setAttrs(ui, indicatorRef, { "data-corner": corner });
    setHidden(ui, indicatorRef, !visible);
    const current = ui.get(indicatorRef) || {};
    const text = isCount && count > 0 ? (count > max ? `${max}+` : String(count)) : "";
    ui.update(indicatorRef, { ...current, text, hidden: !visible });
  };

  // Positioning is applied imperatively (like `createArkAspectRatio()`)
  // rather than through a dedicated F-shape schema entry, deliberately: a
  // bare `F-`-only ref resolves to `role="CONTAINER"` in the renderer, and
  // CONTAINER-role elements never get `textContent` written (see the
  // "CONTAINER nodes exist to hold children" comment in ark-ui.runtime.ts)
  // — so a count badge that needs both positioning *and* dynamic text can't
  // rely on a foundation shape the way a plain container like `MESSAGEBUBBLE`
  // can. `indicatorRef` is whatever text-capable `M-` ref the consumer
  // already has (same convention `createArkAlert()` uses for title/
  // description); this only adds the corner placement on top of it.
  ui.style(anchorRef, { position: "relative" }, { mode: "merge" });
  ui.style(indicatorRef, {
    position: "absolute",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    minWidth: "16px",
    height: "16px",
    padding: "0 4px",
    borderRadius: "9999px",
    border: "2px solid var(--ark-overlay-indicator-ring, transparent)",
    fontSize: "10px",
    lineHeight: "1",
    ...cornerStyle,
  }, { mode: "merge" });
  sync();

  return {
    setCount: (nextCount) => { count = nextCount; sync(); },
    getState: () => ({ count, visible: options.dot || (typeof count === "number" && count > 0) }),
  };
}

export function createArkMessageScroller(ui, options) {
  const viewportRef = ref(options.viewportRef);
  const unreadRef = ref(options.unreadRef);
  const bottomThreshold = options.bottomThreshold ?? 32;
  let atBottom = true;
  let unreadCount = 0;

  const measureAtBottom = () => {
    const el = ui.getElement(viewportRef);
    if (!el) return true;
    return el.scrollHeight - el.scrollTop - el.clientHeight <= bottomThreshold;
  };

  const syncUnread = () => {
    if (unreadRef) {
      const current = ui.get(unreadRef) || {};
      ui.update(unreadRef, { ...current, text: unreadCount > 0 ? String(unreadCount) : "", hidden: unreadCount === 0 });
    }
    syncModelRef(ui, ref(options.stateRef), { atBottom, unreadCount });
  };

  const scrollToBottom = (scrollOptions) => {
    const el = ui.getElement(viewportRef);
    if (!el) return;
    if (typeof el.scrollTo === "function") {
      el.scrollTo({ top: el.scrollHeight, behavior: scrollOptions?.smooth === false ? "auto" : "smooth" });
    } else {
      el.scrollTop = el.scrollHeight;
    }
    unreadCount = 0;
    atBottom = true;
    syncUnread();
  };

  const setAtBottom = (next) => {
    if (next === atBottom) return;
    atBottom = next;
    if (atBottom) unreadCount = 0;
    syncUnread();
    options.onAtBottomChange?.(atBottom);
  };

  ui.configureRef(viewportRef, { part: "message-scroller-viewport" });
  ui.style(viewportRef, { overflowY: "auto", overflowAnchor: "none" }, { mode: "merge" });
  ui.bindRefEvent(viewportRef, "scroll", () => setAtBottom(measureAtBottom()));
  if (unreadRef) {
    ui.configureRef(unreadRef, { part: "message-scroller-unread" });
    ui.onAction(unreadRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      scrollToBottom();
    });
  }
  syncUnread();

  return {
    scrollToBottom,
    notifyNewContent: () => {
      // Deliberately trusts the *stored* flag from the last real scroll
      // event, not a fresh measurement: appending content just grew
      // `scrollHeight`, so measuring now would read "not at bottom" even
      // for a user who genuinely was at the bottom a moment ago.
      if (atBottom) {
        scrollToBottom({ smooth: false });
      } else {
        unreadCount += 1;
        syncUnread();
      }
    },
    getState: () => ({ atBottom, unreadCount }),
  };
}

export function createArkToastRegion(ui, options) {
  const regionRef = ref(options.regionRef);
  const toastRefs = normalizeRefs(options.toastRefs);
  const titleRefs = normalizeRefs(options.titleRefs || []);
  const descriptionRefs = normalizeRefs(options.descriptionRefs || []);
  const closeRefs = normalizeRefs(options.closeRefs || []);
  const defaultDuration = options.defaultDuration ?? 4000;
  const timers = new Map();
  const active = new Map();

  const dismiss = (id) => {
    const toastRef = active.get(id);
    if (!toastRef) return;
    setHidden(ui, toastRef, true);
    const timer = timers.get(id);
    if (timer) clearTimeout(timer);
    timers.delete(id);
    active.delete(id);
  };

  const show = (toast) => {
    const freeIndex = toastRefs.findIndex((toastRef) => (ui.get(toastRef)?.hidden) !== false && ![...active.values()].includes(toastRef));
    if (freeIndex === -1) return undefined;
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
    const toastRef = toastRefs[freeIndex];
    active.set(id, toastRef);
    ui.configureRef(regionRef, { part: "toast-region" });
    configureLiveRegion(ui, regionRef, { politeness: toast.tone === "danger" || toast.tone === "warning" ? "assertive" : "polite", role: "status" });
    ui.configureRef(toastRef, { part: "toast" });
    ui.update(toastRef, { hidden: false, tone: toast.tone || "info" });
    if (titleRefs[freeIndex]) ui.update(titleRefs[freeIndex], { text: toast.title || "" });
    if (descriptionRefs[freeIndex]) ui.update(descriptionRefs[freeIndex], { text: toast.description || "" });
    announce(ui, regionRef, [toast.title, toast.description].filter(Boolean).join(" "));
    const timer = setTimeout(() => dismiss(id), toast.duration ?? defaultDuration);
    timers.set(id, timer);
    return id;
  };

  toastRefs.forEach((toastRef) => {
    ui.configureRef(toastRef, { part: "toast" });
    setHidden(ui, toastRef, true);
  });
  closeRefs.forEach((closeRef, index) => ui.onAction(closeRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    const toastRef = toastRefs[index];
    const id = [...active.entries()].find(([, refValue]) => refValue === toastRef)?.[0];
    if (id) dismiss(id);
  }));
  return { show, dismiss };
}
