/**
 * `createArkAlert` and `createArkAlertDialog` — moved out of
 * `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * `createArkAlertDialog` composes the same overlay/focus-scope/dismissable-
 * layer/presence machinery as `createArkDialog` (it's a modal alert variant,
 * not a different mechanism), so it builds on `@deadark/ark-a11y` directly
 * rather than importing `createArkDialog` itself -- an alert dialog is
 * non-dismissible-by-default and has its own action/cancel-ref vocabulary,
 * which is different enough from Dialog's options shape that composing at
 * the a11y layer (not the dialog primitive layer) keeps both factories
 * simple. `createArkAlert` (the inline banner, not the dialog) additionally
 * uses `@deadark/ark-a11y/live-region` for its polite/assertive announcement.
 */
import { normalizeRef, setAttrs, syncModelRef } from "@deadark/ark-a11y/dom";
import { configureFocusScope, configureDismissableLayer, configurePresence } from "@deadark/ark-a11y/overlay";
import { configureLiveRegion } from "@deadark/ark-a11y/live-region";

function ref(value) {
  return normalizeRef(value);
}

function uniqueRefs(values) {
  return [...new Set(values.map((value) => ref(value)))];
}

export function createArkAlert(ui, options) {
  const rootRef = ref(options.rootRef);
  const titleRef = ref(options.titleRef);
  const descriptionRef = ref(options.descriptionRef);
  const iconRef = ref(options.iconRef);
  const dismissRef = ref(options.dismissRef);
  const controlled = options.controlled === true || options.open !== undefined;
  let open = options.open ?? (options.defaultOpen !== false);
  const tone = options.tone ?? "info";
  const live = options.live ?? (tone === "danger" || tone === "warning" ? "assertive" : "polite");
  const sync = () => {
    ui.configureRef(rootRef, { part: "alert", labelledBy: titleRef, describedBy: descriptionRef });
    setAttrs(ui, rootRef, { "data-tone": tone });
    if (iconRef) ui.configureRef(iconRef, { part: "alert-icon" });
    if (titleRef) ui.configureRef(titleRef, { part: "alert-title" });
    if (descriptionRef) ui.configureRef(descriptionRef, { part: "alert-description" });
    options.actionRefs?.forEach((actionRef) => ui.configureRef(ref(actionRef), { part: "alert-action" }));
    if (dismissRef) ui.configureRef(dismissRef, { part: "alert-dismiss" });
    if (live !== false) configureLiveRegion(ui, rootRef, { politeness: live, role: live === "assertive" ? "alert" : "status" });
    const current = ui.get(rootRef) || {};
    ui.update(rootRef, { ...current, open, hidden: !open });
    syncModelRef(ui, ref(options.stateRef), { open, tone, controlled });
  };
  const setOpenState = (nextOpen, force = false) => {
    options.onOpenChange?.(nextOpen);
    if (controlled && !force) return;
    open = nextOpen;
    sync();
  };
  if (dismissRef) ui.onAction(dismissRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    setOpenState(false);
  });
  sync();
  options.onOpenChange?.(open);
  return {
    open: () => setOpenState(true, true),
    close: () => setOpenState(false, true),
    toggle: () => setOpenState(!open, true),
    setOpen: (nextOpen) => setOpenState(nextOpen, true),
    syncControlled: (nextOpen) => { open = nextOpen; sync(); },
    getState: () => ({ open, controlled, mounted: true }),
  };
}

export function createArkAlertDialog(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const triggerRefs = uniqueRefs([triggerRef, ...(options.triggerRefs || [])]);
  const contentRef = ref(options.contentRef);
  const actionRefs = uniqueRefs([...(options.actionRef ? [options.actionRef] : []), ...(options.actionRefs || [])]);
  const cancelRefs = uniqueRefs([...(options.cancelRef ? [options.cancelRef] : []), ...(options.cancelRefs || [])]);
  const labelRef = ref(options.labelRef);
  const descriptionRef = ref(options.descriptionRef);
  const initialFocusRef = ref(options.initialFocusRef) || cancelRefs[0] || actionRefs[0];
  const restoreFocusRef = ref(options.restoreFocusRef) || triggerRef;
  const viewportRef = ref(options.viewportRef);
  const stateRef = ref(options.stateRef);
  const focusScope = `${contentRef}-scope`;
  const controlled = options.controlled === true || options.open !== undefined;
  let open = options.open ?? options.defaultOpen ?? false;
  let mounted = options.keepMounted === true || open;
  let activeTriggerRef = triggerRef;
  let payload = options.triggerPayloads?.[triggerRef];
  let reason = "none";

  triggerRefs.forEach((currentTriggerRef) => ui.configureRef(currentTriggerRef, {
    role: "button",
    controls: contentRef,
    hasPopup: "dialog",
  }));
  ui.configureRef(contentRef, {
    role: "alertdialog",
    modal: true,
    labelledBy: labelRef,
    describedBy: descriptionRef,
    part: "alert-dialog",
    overlay: {
      anchorRef: triggerRef,
      portal: options.portal ?? "layers",
      placement: "bottom",
      fallbackPlacements: ["top"],
      align: "center",
      offset: 12,
      collisionPadding: 16,
      focusScope,
      modal: true,
      backdrop: true,
      sticky: true,
    },
  });
  if (viewportRef) ui.configureRef(viewportRef, { part: "alert-dialog-viewport" });
  const mediaRef = ref(options.mediaRef);
  if (mediaRef) ui.configureRef(mediaRef, { part: "alert-dialog-media" });
  setAttrs(ui, contentRef, { "data-size": options.size ?? "default" });
  configureFocusScope(ui, focusScope, { containerRef: contentRef, initialFocusRef, trap: true, restore: true });
  configureDismissableLayer(ui, contentRef, {
    containerRef: contentRef,
    dismissRef: contentRef,
    branchRefs: triggerRefs,
    restoreFocusRef,
    outsidePointer: options.closeOnOutsidePress === true,
    outsideFocus: false,
    escapeKey: false,
  });
  configurePresence(ui, contentRef, { unmountOnExit: options.keepMounted !== true, ariaHidden: true });
  ui.onAction(contentRef, (_ref, detail) => {
    if (detail.action !== "DISMISS" || options.closeOnOutsidePress !== true) return;
    const details = detailsFor("outside-press");
    if (options.onOutsidePress?.(details) === false || details.isCanceled) return;
    applyOpen(false, details);
  });

  const detailsFor = (nextReason, event, nextTriggerRef = activeTriggerRef, nextPayload = payload) => {
    const details = {
      reason: nextReason,
      triggerRef: nextTriggerRef,
      payload: nextPayload,
      event,
      isCanceled: false,
      isPropagationAllowed: false,
      cancel() { details.isCanceled = true; },
      allowPropagation() { details.isPropagationAllowed = true; },
    };
    return details;
  };
  const syncState = () => {
    triggerRefs.forEach((currentTriggerRef) => {
      const current = ui.get(currentTriggerRef) || {};
      ui.update(currentTriggerRef, { ...current, open, disabled: options.disabled === true });
      setAttrs(ui, currentTriggerRef, {
        "data-popup-open": open ? "true" : undefined,
        "data-active-trigger": currentTriggerRef === activeTriggerRef ? "true" : undefined,
      });
    });
    const current = ui.get(contentRef) || {};
    ui.update(contentRef, { ...current, open, hidden: !open });
    setAttrs(ui, contentRef, {
      "data-tone": options.tone ?? "danger",
      "data-open": open ? "true" : undefined,
      "data-closed": !open ? "true" : undefined,
      "data-state": open ? "open" : "closed",
    });
    syncModelRef(ui, stateRef, { open, activeTriggerRef, payload, reason, controlled, mounted });
  };
  const applyOpen = (nextOpen, details, force = false, notify = true) => {
    if (notify) options.onOpenChange?.(nextOpen, details);
    if (details.isCanceled || (controlled && !force)) return;
    open = nextOpen;
    reason = details.reason;
    activeTriggerRef = details.triggerRef;
    payload = details.payload;
    mounted = options.keepMounted === true || nextOpen;
    syncState();
    if (nextOpen) ui.openOverlay(contentRef);
    else ui.closeOverlay(contentRef);
    options.onOpenChangeComplete?.(nextOpen, details);
  };
  const requestOpen = (nextOpen, nextReason, event, nextTriggerRef = activeTriggerRef, nextPayload = payload, force = false, notify = true) => {
    const details = detailsFor(nextReason, event, nextTriggerRef, nextPayload);
    applyOpen(nextOpen, details, force, notify);
  };

  triggerRefs.forEach((currentTriggerRef) => ui.onAction(currentTriggerRef, (_ref, detail) => {
    if (detail.action !== "CLICK" || options.disabled) return;
    requestOpen(true, "trigger-press", undefined, currentTriggerRef, options.triggerPayloads?.[currentTriggerRef]);
  }));
  actionRefs.forEach((actionRef) => {
    ui.configureRef(actionRef, { part: "alert-dialog-action" });
    ui.onAction(actionRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      const eventDetails = Object.assign(detailsFor("action-press"), { actionRef });
      if (options.onAction?.(eventDetails) === false || eventDetails.isCanceled || options.closeOnAction === false) return;
      applyOpen(false, eventDetails);
    });
  });
  cancelRefs.forEach((cancelRef) => {
    ui.configureRef(cancelRef, { part: "alert-dialog-cancel" });
    ui.onAction(cancelRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      const eventDetails = Object.assign(detailsFor("cancel-press"), { actionRef: cancelRef });
      if (options.onCancel?.(eventDetails) === false || eventDetails.isCanceled || options.closeOnCancel === false) return;
      applyOpen(false, eventDetails);
    });
  });
  ui.bindRefEvent(contentRef, "keydown", (rawEvent) => {
    const event = rawEvent;
    if (event.key !== "Escape" || options.escapeKey === false) return;
    const details = detailsFor("escape-key", event);
    if (options.onEscapeKeyDown?.(event, details) === false || details.isCanceled) return;
    event.preventDefault();
    applyOpen(false, details);
  });
  syncState();
  if (open) ui.openOverlay(contentRef);
  return {
    open: (nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(true, "imperative-action", undefined, ref(nextTriggerRef), nextPayload, true),
    close: () => requestOpen(false, "imperative-action", undefined, activeTriggerRef, payload, true),
    toggle: (nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(!open, "imperative-action", undefined, ref(nextTriggerRef), nextPayload, true),
    setOpen: (nextOpen, nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(nextOpen, "imperative-action", undefined, ref(nextTriggerRef), nextPayload, true),
    syncControlled: (nextOpen, nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(nextOpen, "controlled-sync", undefined, ref(nextTriggerRef), nextPayload, true, false),
    getState: () => ({ open, activeTriggerRef, payload, reason, controlled, mounted }),
  };
}
