# @deadark/ark-primitives

Unstyled, accessible `createArk*()` primitive factories, built on
`@deadark/ark-a11y`. First extraction batch: `createArkDialog` and
`createArkPopover` (and their `Ark*Options`/`Ark*Handle` types), moved out
of `@deadark/ark-ui`'s `ark-ui.components.ts` behavior-for-behavior.

`@deadark/ark-ui/components` and `@deadark/ark-ui/primitives` both
re-export these names during the deprecation window, so existing consumers
of either path keep working unchanged.

## Usage

```js
import { createArkDialog, createArkPopover } from "@deadark/ark-primitives";
// or the granular subpath:
import { createArkDialog } from "@deadark/ark-primitives/dialog";
```

`createArkDialog`/`createArkPopover` take an `ArkPrimitiveRuntime` — the
small structural subset of ARK UI's `createArkUI()` instance they actually
call (`configureRef`, `bindRefEvent`, `onAction`, `get`/`update`,
`createFocusScope`, `createDismissableLayer`, `createPresence`,
`openOverlay`/`closeOverlay`). This package has no dependency on
`@deadark/ark-ui` itself — only on `@deadark/ark-a11y` — matching the
plan's dependency direction (`ark-primitives -> ark-a11y`, never back up
to a Layered Component or the runtime package).
