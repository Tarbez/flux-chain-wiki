# @deadark/flx-codec

UI-independent FLX archive encoding, binary framing, dictionary compression, recovery,
delta handling, and BLAKE3 content addressing. This package is the canonical JavaScript
implementation consumed by Ark UI and Flux specification conformance tests.

Ark UI keeps compatibility exports for existing consumers, but codec implementation
ownership lives here.
