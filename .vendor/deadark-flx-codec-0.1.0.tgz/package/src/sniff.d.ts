export type SniffResult =
  | { ok: true; id: string; kind: string; matched: string; version?: number }
  | { ok: false; failure: string; seen: string; missing: string; remedy: string };
export function sniffFlx(input: Uint8Array | ArrayBuffer): SniffResult;
