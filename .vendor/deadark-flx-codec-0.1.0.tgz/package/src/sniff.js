// One dispatcher for the ".flx" extension. Several formats share it (spec: docs/FLUX_NAMING_RECONCILIATION_v0.md
// section 5; flx/flux-spec/registry/naming-ledger.dense), so a reader identifies a file by what it starts with
// before decoding it. Identification only: this never decodes and never guesses a default.
//
// Longest known prefix wins. Two shapes have no fixed magic and are recognised by structure instead: the
// legacy base64 envelope (prefix "0-1_F=deadark-flx_") and a dense-manifest file (optional "# " title lines,
// then a first block "0-1-K-"). An unrecognised file is refused with the failure, what was seen and a remedy.

const enc = new TextEncoder();
// [prefix, id, kind]. Order does not matter: the longest matching prefix is chosen.
const PREFIXES = [
  ['FLX2', 'flux-archive/2', 'archive'],
  ['FLXDOC-V2-', 'legacy-hex-json/2', 'document'],
  ['FLXREC-V2-', 'legacy-hex-json/2', 'record'],
  ['0-1_F=deadark-flx_', 'legacy-base64-json/1', 'envelope'],
  ['FLX-AUTH-KIT/', 'flux-auth-kit', 'auth-kit'],
  ['FV', 'flux-compact/1', 'compact'],
].map(([prefix, id, kind]) => ({ prefix: enc.encode(prefix), text: prefix, id, kind }));

const DENSE_MANIFEST_START = '0-1-K-';

function startsWith(bytes, prefix) {
  if (bytes.length < prefix.length) return false;
  for (let i = 0; i < prefix.length; i += 1) if (bytes[i] !== prefix[i]) return false;
  return true;
}

function preview(bytes) {
  return Array.from(bytes.slice(0, 16), (b) => (b >= 0x20 && b < 0x7f ? String.fromCharCode(b) : `\\x${b.toString(16).padStart(2, '0')}`)).join('');
}

// Skips leading "# ..." title lines, then checks for the first dense block.
function looksLikeDenseManifest(bytes) {
  const head = new TextDecoder('utf-8', { fatal: false }).decode(bytes.slice(0, 4096));
  const lines = head.split('\n');
  let i = 0;
  while (i < lines.length && lines[i].startsWith('# ')) i += 1;
  return i < lines.length && lines[i].startsWith(DENSE_MANIFEST_START);
}

export function sniffFlx(input) {
  const bytes = input instanceof Uint8Array ? input : new Uint8Array(input);
  let best = null;
  for (const entry of PREFIXES) if (startsWith(bytes, entry.prefix) && (!best || entry.prefix.length > best.prefix.length)) best = entry;
  if (best) {
    const result = { ok: true, id: best.id, kind: best.kind, matched: best.text };
    if (best.kind === 'auth-kit') {
      const m = /^FLX-AUTH-KIT\/(\d+)/.exec(new TextDecoder().decode(bytes.slice(0, 24)));
      if (m) { result.version = Number(m[1]); result.id = `flux-auth-kit/${m[1]}`; }
    }
    return result;
  }
  if (looksLikeDenseManifest(bytes)) return { ok: true, id: 'flux-wire/4', kind: 'dense-manifest', matched: DENSE_MANIFEST_START };
  return {
    ok: false,
    failure: 'The file does not start with any known .flx format.',
    seen: preview(bytes),
    missing: `one of: ${PREFIXES.map((p) => p.text).join(', ')}, or a dense manifest starting "${DENSE_MANIFEST_START}".`,
    remedy: 'add the format to the naming ledger and to PREFIXES in sniff.js, or give the file its real extension.',
  };
}
