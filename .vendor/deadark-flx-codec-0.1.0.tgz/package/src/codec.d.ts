import { type FlxArchiveDictionary, type FlxContentTypeRef, type FlxEncodedValue, type FlxPathRef, type FlxRouteIdRef, type FlxRouteRef, type FlxStateScopeRef, type FlxStringRef } from "./dictionary.js";
export type FlxArchiveBlockType = "dictionary" | "manifest" | "route" | "asset" | "state" | "delta" | "continuation" | "integrity";
export type FlxArchiveVerificationStatus = "valid" | "structurally-invalid" | "integrity-invalid" | "unsupported-version" | "unsupported-feature";
export interface FlxArchiveRouteInput {
    routeId: string;
    path: string;
    payload: unknown;
    title?: string;
    description?: string;
    dependsOn?: string[];
    dependencyGraph?: FlxRouteDependencyInput[];
    guards?: string[];
    restorePaths?: string[];
    layout?: string;
}
export interface FlxRouteDependencyInput {
    route: string;
    dependencyId?: string;
    relation?: string;
    phase?: string;
    required?: boolean;
    sourceRoute?: string;
    stateScope?: string;
    asset?: string;
    barrier?: string;
    continuationTag?: string;
    tags?: string[];
}
export interface FlxArchiveAssetInput {
    path: string;
    contentType: string;
    payload: string;
    encoding?: "utf8" | "base64";
    compression?: "identity" | "gzip";
    hash?: string;
}
export interface FlxArchiveStateInput {
    stateId: string;
    scope: string;
    payload: unknown;
    schema?: string;
    rootPath?: string;
    snapshotVersion?: number;
}
export interface FlxArchiveDeltaInput {
    parentArchiveId: string;
    operations: FlxDeltaOperation[];
    baseIntegrity?: string;
    deltaKind?: string;
    nextArchiveId?: string;
    nextCreatedAt?: string;
}
export interface FlxArchiveContinuationInput {
    parentArchiveId: string;
    chunkIndex: number;
    chunkCount: number;
    byteOffset: number;
    totalBytes: number;
    resumeToken?: string;
    chunkChecksum?: string;
    receivedBlocks?: string[];
    receiptState?: string;
    receiptGraph?: FlxContinuationReceiptEntry[];
    receiptSummary?: FlxContinuationReceiptSummary;
}
export interface FlxContinuationReceiptEntry {
    blockId: string;
    blockType?: FlxArchiveBlockType;
    routeId?: string;
    path?: string;
    stateScope?: string;
    status?: "pending" | "received" | "acknowledged";
    logicalStart?: number;
    logicalEnd?: number;
    chunkIndexes?: number[];
}
export interface FlxContinuationReceiptSummary {
    receivedBlockCount?: number;
    pendingBlockCount?: number;
    acknowledgedBlockCount?: number;
    lastChunkIndex?: number;
}
export interface FlxArchiveSyncSourceInput {
    kind: string;
    archiveId?: string;
    archiveHash?: string;
    label?: string;
    uri?: string;
    appliedAt?: string;
}
export interface FlxArchiveInput {
    archiveId?: string;
    createdAt?: string;
    flags?: string[];
    entry: string;
    baseDictionary?: Partial<FlxArchiveDictionary> | null;
    routes?: FlxArchiveRouteInput[];
    assets?: FlxArchiveAssetInput[];
    states?: FlxArchiveStateInput[];
    generatedBy?: string;
    sourceFormat?: string;
    /** What the archive is for (e.g. "app", "auth"). Optional; absent archives encode exactly as before. */
    purpose?: string;
    syncSources?: FlxArchiveSyncSourceInput[];
    delta?: FlxArchiveDeltaInput | null;
    continuation?: FlxArchiveContinuationInput | null;
}
export interface FlxArchiveHeader {
    magic: string;
    format: "flx-archive";
    major: number;
    minor: number;
    archiveId: string;
    createdAt: string;
    flags: string[];
    blockCount: number;
}
export interface FlxArchiveBlock<TPayload = unknown> {
    id: string;
    type: FlxArchiveBlockType;
    index: number;
    length: number;
    encoding: "tokenized-json";
    payload: TPayload;
    checksum: string;
}
export interface FlxEncodedManifestRoute {
    routeId: FlxRouteIdRef | FlxStringRef | string;
    path: FlxRouteRef;
    title?: FlxStringRef | string;
    description?: FlxStringRef | string;
    dependsOn?: FlxRouteRef[];
    dependencyGraph?: FlxEncodedValue;
}
export interface FlxEncodedManifestFile {
    path: FlxPathRef;
    contentType: FlxContentTypeRef | string;
    size?: number;
    hash?: FlxStringRef | string;
}
export interface FlxManifestBlockPayload {
    entry: FlxPathRef;
    routes: FlxEncodedManifestRoute[];
    files: FlxEncodedManifestFile[];
    generatedBy?: FlxStringRef | string;
    sourceFormat?: FlxStringRef | string;
    purpose?: FlxStringRef | string;
    syncSources?: FlxEncodedValue;
    rawByteLength: number;
    compressedByteLength: number;
}
export interface FlxRouteBlockPayload {
    routeId: FlxRouteIdRef | FlxStringRef | string;
    path: FlxRouteRef;
    payload: FlxEncodedValue;
    title?: FlxStringRef | string;
    description?: FlxStringRef | string;
    dependsOn?: FlxRouteRef[];
    dependencyGraph?: FlxEncodedValue;
    guards?: Array<FlxStringRef | string>;
    restorePaths?: FlxRouteRef[];
    layout?: FlxStringRef | string;
}
export interface FlxAssetBlockPayload {
    path: FlxPathRef;
    contentType: FlxContentTypeRef | string;
    payload: string;
    encoding?: "utf8" | "base64";
    compression?: "identity" | "gzip";
    rawByteLength: number;
    compressedByteLength: number;
    hash?: FlxStringRef | string;
}
export interface FlxStateBlockPayload {
    stateId: FlxStringRef | string;
    scope: FlxStateScopeRef | FlxStringRef | string;
    payload: FlxEncodedValue;
    schema?: FlxStringRef | string;
    rootPath?: FlxPathRef;
    snapshotVersion?: number;
}
export interface FlxDeltaBlockPayload {
    parentArchiveId: FlxStringRef | string;
    operations: FlxEncodedValue;
    baseIntegrity?: FlxStringRef | string;
    deltaKind?: FlxStringRef | string;
    nextArchiveId?: FlxStringRef | string;
    nextCreatedAt?: FlxStringRef | string;
}
export interface FlxContinuationBlockPayload {
    parentArchiveId: FlxStringRef | string;
    chunkIndex: number;
    chunkCount: number;
    byteOffset: number;
    totalBytes: number;
    resumeToken?: FlxStringRef | string;
    chunkChecksum?: FlxStringRef | string;
    receivedBlocks?: Array<FlxStringRef | string>;
    receiptState?: FlxStringRef | string;
    receiptGraph?: FlxEncodedValue;
    receiptSummary?: FlxEncodedValue;
}
export interface FlxIntegrityBlockPayload {
    archiveHash: string;
    blockHashes: string[];
    manifestHash: string;
    parentArchiveHash?: string;
}
export interface FlxArchiveWire {
    header: FlxArchiveHeader;
    blocks: FlxArchiveBlock[];
}
export interface FlxDecodedArchive {
    header: FlxArchiveHeader;
    dictionary: FlxArchiveDictionary;
    manifest: {
        entry: string;
        routes: Array<{
            routeId: string;
            path: string;
            title?: string;
            description?: string;
            dependsOn?: string[];
            dependencyGraph?: FlxRouteDependencyInput[];
        }>;
        files: Array<{
            path: string;
            contentType: string;
            size?: number;
            hash?: string;
        }>;
        generatedBy?: string;
        sourceFormat?: string;
        purpose?: string;
        syncSources?: FlxArchiveSyncSourceInput[];
        rawByteLength: number;
        compressedByteLength: number;
    };
    routes: Array<{
        blockId: string;
        routeId: string;
        path: string;
        payload: unknown;
        title?: string;
        description?: string;
        dependsOn?: string[];
        dependencyGraph?: FlxRouteDependencyInput[];
        guards?: string[];
        restorePaths?: string[];
        layout?: string;
    }>;
    assets: Array<{
        blockId: string;
        path: string;
        contentType: string;
        payload: string;
        encoding?: "utf8" | "base64";
        compression?: "identity" | "gzip";
        rawByteLength: number;
        compressedByteLength: number;
        hash?: string;
    }>;
    states: Array<{
        blockId: string;
        stateId: string;
        scope: string;
        payload: unknown;
        schema?: string;
        rootPath?: string;
        snapshotVersion?: number;
    }>;
    delta: FlxArchiveDeltaInput | null;
    continuation: FlxArchiveContinuationInput | null;
    integrity: FlxIntegrityBlockPayload;
    blocks: FlxArchiveBlock[];
}
export type FlxDeltaOperation = {
    op: "replace-entry";
    entry: string;
} | {
    op: "add-route";
    blockId: string;
    routeId: string;
} | {
    op: "replace-route";
    blockId: string;
    routeId: string;
} | {
    op: "remove-route";
    blockId: string;
    routeId: string;
} | {
    op: "add-asset";
    blockId: string;
    path: string;
} | {
    op: "replace-asset";
    blockId: string;
    path: string;
} | {
    op: "remove-asset";
    blockId: string;
    path: string;
} | {
    op: "add-state";
    blockId: string;
    stateId: string;
} | {
    op: "replace-state";
    blockId: string;
    stateId: string;
} | {
    op: "remove-state";
    blockId: string;
    stateId: string;
} | {
    op: "upsert-block";
    blockId: string;
    blockType: "route" | "asset" | "state";
} | {
    op: "remove-block";
    blockId: string;
    blockType: "route" | "asset" | "state";
};
export interface FlxArchiveLineageVerificationResult {
    valid: boolean;
    errors: string[];
    warnings: string[];
    summary: {
        baseArchiveId?: string;
        deltaArchiveId?: string;
        operationCount: number;
    };
}
export interface FlxContinuationChunk {
    parentArchiveId: string;
    chunkIndex: number;
    chunkCount: number;
    byteOffset: number;
    totalBytes: number;
    resumeToken: string;
    chunkChecksum: string;
    bytes: Uint8Array;
    receivedBlocks?: string[];
    receiptGraph?: FlxContinuationReceiptEntry[];
    receiptSummary?: FlxContinuationReceiptSummary;
}
export interface FlxRecoveryShard {
    parentArchiveId: string;
    archiveHash: string;
    sourceId: string;
    groupIndex: number;
    groupCount: number;
    replicaIndex: number;
    replicaCount: number;
    byteOffset: number;
    totalBytes: number;
    checksum: string;
    bytes: Uint8Array;
}
export interface FlxRecoveryManifestSource {
    sourceId: string;
    replicaIndexes: number[];
}
export interface FlxRecoveryQuorumPolicy {
    minSources: number;
    minMatchingSources: number;
}
export interface FlxRecoveryRepairPacket {
    packetIndex: number;
    parityType: "xor" | "gf257";
    packetClass: "primary" | "diagonal" | "weighted" | "quadratic" | "cubic";
    groupIndexes: number[];
    byteLength: number;
    checksum: string;
    bytes: Uint8Array;
    coefficientScheme?: "unit-sum" | "position-weighted" | "position-squared" | "position-cubed";
    symbolWidth?: 1 | 2;
}
export interface FlxRecoveryRepairPolicy {
    kind: "xor" | "parity";
    layout: "batch-xor" | "iterative-xor-stripe" | "dual-xor-stripe" | "weighted-parity-stripe" | "vandermonde-parity-stripe";
    packetClasses: Array<"primary" | "diagonal" | "weighted" | "quadratic" | "cubic">;
    groupsPerPacket: number;
    maxMissingGroupsPerPacket: number;
    packetCount: number;
    diagonalStride?: number;
    reconstructionLimit?: number;
}
export interface FlxRecoveryRepairGuarantees {
    guaranteedPatterns: Array<"single-group-loss" | "contiguous-edge-loss" | "two-group-loss" | "parity-two-group-loss" | "parity-three-group-loss" | "parity-four-group-loss">;
    bestEffortPatterns: Array<"chained-stripe-loss" | "distributed-multi-loss">;
    requiresAtLeastOneIntactGroup: boolean;
    matrix: FlxRecoveryRecoverabilityMatrixRow[];
}
export interface FlxRecoveryRecoverabilityMatrixRow {
    lossCount: number;
    coverage: "all-combinations" | "contiguous-edge" | "explicit";
    sets?: number[][];
    proofMode?: "symbolic" | "enumerated";
    analyzedCombinations?: number;
}
export interface FlxRecoveryReplicaInventory {
    sourceCount: number;
    replicaCount: number;
    groupCount: number;
    replicasPerGroup: number;
}
export interface FlxRecoveryRepairInventory {
    packetCount: number;
    layout: "batch-xor" | "iterative-xor-stripe" | "dual-xor-stripe" | "weighted-parity-stripe" | "vandermonde-parity-stripe";
    packetClasses: Array<"primary" | "diagonal" | "weighted" | "quadratic" | "cubic">;
    groupsPerPacket: number;
    maxMissingGroupsPerPacket: number;
    coverageByGroup: number[];
    packetGroupIndexes: number[][];
    packetClassCounts: Partial<Record<"primary" | "diagonal" | "weighted" | "quadratic" | "cubic", number>>;
    maxSequentialRepairs: number;
    reconstructionLimit: number;
    readiness: {
        grade: "production-grade" | "experimental";
        notes: string[];
    };
    guarantees: FlxRecoveryRepairGuarantees;
}
export interface FlxRecoveryManifest {
    format?: "ark-flx-recovery-manifest";
    version?: 1;
    parentArchiveId: string;
    archiveHash: string;
    totalBytes: number;
    groupCount: number;
    shardSize: number;
    sources: FlxRecoveryManifestSource[];
    quorum: FlxRecoveryQuorumPolicy;
    replicaInventory: FlxRecoveryReplicaInventory;
    repair?: FlxRecoveryRepairPolicy;
    repairInventory?: FlxRecoveryRepairInventory;
    repairPackets?: FlxRecoveryRepairPacket[];
}
export interface FlxRecoveryVerificationResult {
    valid: boolean;
    errors: string[];
    warnings: string[];
    summary: {
        parentArchiveId?: string;
        archiveHash?: string;
        groupCount: number;
        replicaCount: number;
        completeGroups: number;
    };
}
export interface FlxRecoveryManifestVerificationResult {
    valid: boolean;
    errors: string[];
    warnings: string[];
    summary: {
        parentArchiveId?: string;
        archiveHash?: string;
        groupCount: number;
        availableSources: number;
        quorumSources: number;
        quorumMatches: number;
        satisfiedGroups: number;
        repairedGroups: number;
        degradedGroups: number[];
        missingGroups: number[];
        recoverability: "complete" | "repairable" | "unrecoverable";
        policySatisfied: boolean;
        policyBasis: "none" | "all-combinations" | "contiguous-edge" | "explicit";
        repairConfidence: "none" | "guaranteed" | "best-effort";
        recoveryReadiness: "production-grade" | "experimental";
    };
}
export interface FlxArchiveVerificationResult {
    valid: boolean;
    status: FlxArchiveVerificationStatus;
    errors: string[];
    warnings: string[];
    summary: {
        major?: number;
        minor?: number;
        blockCount?: number;
        archiveId?: string;
    };
}
export type FlxArchiveInputLike = Uint8Array | string | FlxArchiveWire;
export declare function encodeArchive(input: FlxArchiveInput): Uint8Array;
/**
 * Debug-only wire encoding for tooling and tests: emits the semantic wire object as
 * pretty-printed JSON instead of the binary `FLX2` framing. Never treat this as the
 * canonical archive artifact format — use `encodeArchive` for real archive bytes.
 */
export declare function encodeArchiveDebugJson(input: FlxArchiveInput): string;
/**
 * Debug-only counterpart to `encodeArchiveDebugJson`. Decodes a JSON-framed wire string
 * (rather than binary `FLX2` bytes) into the same semantic archive shape as `decodeArchive`.
 */
export declare function decodeArchiveDebugJson(source: string): FlxDecodedArchive;
export declare function verifyArchiveStructure(input: FlxArchiveInputLike): FlxArchiveVerificationResult;
export declare function decodeArchive(input: FlxArchiveInputLike): FlxDecodedArchive;
/**
 * Browser-safe counterpart to `decodeArchive` for archives containing gzip-compressed asset
 * blocks (identity/base64 assets, and any archive with no asset blocks at all — e.g. the defxn
 * site archive schema — decode identically and synchronously via `decodeArchive` already).
 */
export declare function decodeArchiveAsync(input: FlxArchiveInputLike): Promise<FlxDecodedArchive>;
export declare function decodeAssetPayloadAsync(payload: string, encoding?: "utf8" | "base64", compression?: "identity" | "gzip"): Promise<string>;
export declare function diffArchives(baseInput: FlxArchiveInputLike | FlxDecodedArchive, nextInput: FlxArchiveInputLike | FlxDecodedArchive): FlxArchiveInput;
export declare function verifyArchiveLineage(baseInput: FlxArchiveInputLike | FlxDecodedArchive, deltaInput: FlxArchiveInputLike | FlxDecodedArchive): FlxArchiveLineageVerificationResult;
export declare function maxFlxDeltaChainLength(): number;
export declare function applyDelta(baseInput: FlxArchiveInputLike | FlxDecodedArchive, deltaInput: FlxArchiveInputLike | FlxDecodedArchive): FlxArchiveInput;
export declare function splitArchiveContinuations(input: FlxArchiveInputLike | FlxDecodedArchive, chunkSize: number): FlxContinuationChunk[];
export declare function createArchiveRecoveryShards(input: FlxArchiveInputLike | FlxDecodedArchive, shardSize: number, replicaCount?: number, sourceIds?: string[]): FlxRecoveryShard[];
export declare function createRecoveryManifest(shards: FlxRecoveryShard[], quorum?: Partial<FlxRecoveryQuorumPolicy>, repair?: {
    kind?: "xor" | "parity";
    groupsPerPacket?: number;
    includeDiagonal?: boolean;
    diagonalStride?: number;
    parityDepth?: 2 | 3 | 4;
} | null): FlxRecoveryManifest;
export declare function recoverArchiveFromShards(shards: FlxRecoveryShard[]): Uint8Array;
export declare function verifyRecoveryShards(shards: FlxRecoveryShard[]): FlxRecoveryVerificationResult;
export declare function verifyRecoveryManifest(manifest: FlxRecoveryManifest, shards: FlxRecoveryShard[]): FlxRecoveryManifestVerificationResult;
export declare function recoverArchiveFromManifest(manifest: FlxRecoveryManifest, shards: FlxRecoveryShard[]): Uint8Array;
export declare function resumeArchiveContinuations(chunks: FlxContinuationChunk[], existingBytes?: Uint8Array): Uint8Array;
