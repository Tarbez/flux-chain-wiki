import { type FlxArchiveWire } from "./codec.js";
export declare function looksLikeFlxArchiveBinary(bytes: Uint8Array): boolean;
export declare function encodeArchiveBinary(wire: FlxArchiveWire): Uint8Array;
export declare function decodeArchiveBinary(bytes: Uint8Array): FlxArchiveWire;
