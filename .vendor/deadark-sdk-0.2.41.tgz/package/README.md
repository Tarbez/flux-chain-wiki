# @deadark/sdk

TypeScript SDK for the [DeadArk Developer API](https://dev.deadark.com/api/dev/openapi.json).

**Status:** Private beta — not yet published to npm. Install locally or via git.

The SDK exports the Batch 2 `IdentityWalletProvider` presentation boundary.
Desktop applications request app-scoped capability handoffs through it; identity-root
and wallet private keys are deliberately absent from the public contract. Runtime key
custody, device authorization, encrypted grants, and revoke-all behavior live in
`shared/flux-auth`, not in individual application shells.

---

## Quick start

```ts
import { DeveloperSuiteClient, createFetchTransport, WorkKit } from '@deadark/sdk';

const client = new DeveloperSuiteClient(
  createFetchTransport({
    baseUrl: 'https://dev.deadark.com',
    getAccessToken: () => process.env.DEADARK_API_KEY!, // zwk_... developer key
  }),
);

// Top-level: who am I?
const me = await client.getMe();

// Kit: list boards in a workspace context
const work = new WorkKit(client);
const contexts = await work.listContexts();
const boards = await work.listBoards(contexts.data[0]);
```

---

## Installation

```bash
# From local path (during private beta)
npm install ../deadark-sdk

# Or point package.json at the git repo:
# "@deadark/sdk": "git+https://github.com/deadark/deadark-sdk.git"
```

---

## Theme System

DeadArk theme, typography, and badge semantics live in `@deadark/sdk/theme`.
Shared visual rules are documented in [docs/slate-theme-laws.md](docs/slate-theme-laws.md).
The MCP governance proposal is in [docs/theme-mcp-proposal.md](docs/theme-mcp-proposal.md).

```ts
import {
  DEADARK_THEMES,
  DEADARK_BADGES,
  applyDeadArkTheme,
  applyDeadArkTypography,
  createDeadArkThemeInstallPlan,
} from '@deadark/sdk/theme';

applyDeadArkTheme('ghost');
applyDeadArkTypography({ header: 'source-serif', content: 'ibm-plex-sans' });
```

CSS infrastructure:

```ts
// App/global CSS entry.
import '@deadark/sdk/theme.css';
import '@deadark/sdk/components.css';

// Tailwind v4 token bridge. Import this from the app CSS file that owns Tailwind.
import '@deadark/sdk/tailwind-v4.css';
```

Components:

```tsx
import {
  DeadArkAppearanceModal,
  DeadArkBadge,
  DeadArkComposerShell,
  DeadArkSidebarPanel,
  DeadArkSurfaceCard,
  DeadArkThreadCard,
  DeadArkThemeSwatchPicker,
  DeadArkUserDropdown,
} from '@deadark/sdk/components';
```

The component package is React-based and uses `react` as a peer dependency. It intentionally lives under `@deadark/sdk/components` so API-only SDK consumers do not load React.

CLI:

```bash
npx deadark-theme themes
npx deadark-theme contrast
npx deadark-theme color-law
npx deadark-theme plan install
npx deadark-theme plan repair
npx deadark-theme css > src/styles/deadark-theme.generated.css
npx deadark-theme tailwind > src/styles/deadark-tailwind-v4.generated.css
npx deadark-theme audit .
```

Infrastructure exports:

```ts
import {
  assertDeadArkThemeColorLaw,
  auditDeadArkThemeFiles,
  getDeadArkCssBundle,
  getDeadArkColorLawReports,
  getDeadArkTailwindV4ThemeCss,
  getDeadArkThemeVariablesCss,
} from '@deadark/sdk/theme';
```

Rules:

- The active theme lineup is the color-law canonical set: `ghost`, `bone`, `ochre`, `copper`, `marine`, and `void`. Legacy screenshot-derived palettes remain internal references and are not emitted as runtime themes.
- Each theme carries `source.files` and `source.palette` metadata pointing back to the extracted screenshot strips and source hex colors.
- Interactive control boundaries (inputs, selects, checkboxes, outlined buttons) use `--border-control`: derived per theme, >= 3:1 against every surface (WCAG 1.4.11). `--border-strong` whispers (~1.4-1.7:1) and is never a control's only edge.
- Use semantic tokens first: `--canvas`, `--surface`, `--raised`, `--nested`, `--overlay`, `--primary`, `--complement`, `--accent`, `--trust`, `--live`, `--role`, `--badge`, `--drift`, `--warning`, `--danger`, `--hidden`, `--reference`.
- Keep typography selection to two slots: header and content. The SDK derives role fonts and sizing for headings, body, metadata, navigation, cards, and sidebars.
- Sizing is part of appearance. SDK components and theme-adopting thread surfaces must consume `--size-*` tokens for reusable widths, radii, avatars, cards, and touch targets so compact/standard/comfortable appearance settings scale automatically.
- Badges must mean something real: identity, credibility, affinity, role, participation, or meaningful contribution.
- Use `createDeadArkThemeInstallPlan()`, `createDeadArkThemeRepairPlan()`, or `createDeadArkThemeUpdatePlan()` when wiring a repo to the latest SDK theme contract.
- Use `getDeadArkThemeContrastReports()` and `assertDeadArkThemeColorLaw(theme)` before accepting a new palette.
- Use `deadark-theme audit .` before migrating a repo and again before closing the batch.
- Generated files are package outputs, not app-owned palettes. Do not fork them into local theme source unless the repo cannot import package CSS yet.
- Use SDK components before creating app-local versions of appearance controls, user dropdowns, badges, surface cards, thread cards, composers, or sidebar panels.

### Role-ladder themes: Ember (0.2.30)

The DEFXN palette generator (`flux/defxn/scripts/build-flux-themes.cjs`) is ported into
`src/theme/role-ladder.ts`, making the SDK its canonical home. The port is byte-exact:
`getDeadArkRoleLadderLegacyCss()` (CLI: `deadark-theme role-ladder --legacy`) reproduces
`flux/defxn/css/flux-themes.css` byte for byte (sha256 pinned; the test also diffs the live
file when the DEFXN checkout is present). DEFXN can generate that file from here and retire
its own generator.

- Namespaced themes `ember` / `ember-light`, with SDK meanings: `--accent` = the ACTION colour
  (secondary, teal), never identity; `--badge` = identity (primary); `--role` = reference;
  `--trust`/`--live` = success; `--drift` = warning. Plus the full role layer (`--secondary`,
  `-100`...`-700`, `-ink`, `-tone-50`...`-950`, `-scale`, `--anchor`).
- They are in `@deadark/sdk/theme.css` like every active theme; `@deadark/sdk/role-ladder-themes.css`
  (`:root[data-theme="ember"]`, `:root[data-theme="ember-light"]`) still ships them alone, and
  `resolveDeadArkRoleLadderTheme(name)` / `resolveDeadArkTheme(name)` resolve the same vars.
- **Colour law: passed.** The first audit rejected Ember on one rule, an HSL-saturation
  ceiling, for every vivid role. Owner decision (2026-10-19): measure chroma, not HSL. The rule
  (`color-law-high-saturation`) now rejects a colour whose OKLCH chroma reaches
  `DEADARK_NEON_CHROMA_FLOOR` -- the chroma of pure sRGB yellow (0.211), the least vivid
  pure-channel neon a chroma rule can reject (pure cyan, 0.155, is below roles the law already
  admits, so it is a pinned known limit). Ember's roles measure 0.08-0.20 and pass unchanged;
  `ember` and `ember-light` are in `DEADARK_THEMES` and `theme.css` and keep their own sheet.
  See `DEADARK_ROLE_LADDER_COLOR_LAW_GATE` and `deadark-theme color-law --role-ladder`.
- Tide, Moss, Dune and Dusk are generated byte-exact in the legacy file but are not published
  under namespaced names: `moss` and `tide` already name different SDK themes.

### Badge meanings

`DEADARK_BADGE_MEANINGS` maps the law's six meanings (identity, credibility, affinity, role,
participation, contribution) to badge tokens; every `DEADARK_BADGES` kind names its meaning.
It equals `@deadark/ark-primitives` `ARK_BADGE_MEANING_TOKENS` (parity-tested).

---

## Auth

Two credential types are accepted via `Authorization: Bearer`:

| Type | Format | Obtain from |
|---|---|---|
| Developer key | `zwk_<key>` | app.deadark.com → Settings → Developer |
| OAuth token | `eyJ...` | Authorization Code + PKCE flow |

A `read` developer key satisfies any `*:read` scope check. A `write` key satisfies any scope.

OAuth token endpoint: `https://app.deadark.com/oauth/token`
OAuth authorization endpoint: `https://app.deadark.com/oauth/authorize`

---

## Client methods

`DeveloperSuiteClient` covers surfaces that don't need a context:

```ts
client.getMe()
client.getOnboarding()
client.getCapabilities()
client.getEventCatalog()
client.listWorkspaces()
client.getMyWorkspace()
client.createWorkspace({ name, workspace_type, handle, ... })
client.captureTask({ title, description? }) // personal Inbox
client.focusInterpret({ text })
client.focusRetrieve({ text?, interpretation? })
client.listContexts(filters?)
client.connectContext(context)
client.getSnapshot(connectionId, module)
client.iterateEvents({ connectionId, ... })   // async generator
client.ackEvents(connectionId, cursor)
client.syncModule(connectionId, module, apply)
client.getAction(actionId)
client.promoteProject(input)
client.bindContext(input)
client.disconnectContext(connectionId, input)

// Network tenant (system-app credential only — see "Network tenant" below)
client.createNetwork({ name, slug?, description?, idempotencyKey })
client.bindNetworkProfile({ networkId, idempotencyKey })
client.createNetworkBusiness({ networkId, workspaceHandle, workspaceName, name, idempotencyKey, ... })
client.createNetworkCommunity({ networkId, workspaceHandle, workspaceName, name, slug, idempotencyKey, ... })
client.createNetworkInstitution({ networkId, workspaceHandle, workspaceName, name, institutionSlug, idempotencyKey, ... })
client.createNetworkProject({ networkId, workspaceHandle, workspaceName, projectName, projectSlug, idempotencyKey, ... })
client.createNetworkPublication({ networkId, canonicalDomain, idempotencyKey, ... })
client.provisionNetworkUser({ networkId, externalUserId, idempotencyKey, ... })
client.getNetworkUser(networkId, externalUserId)
client.updateNetworkUser({ networkId, externalUserId, idempotencyKey, ... })
client.deactivateNetworkUser({ networkId, externalUserId, idempotencyKey })
client.listNetworkDomains(networkId)
client.claimNetworkDomain({ networkId, domain })
client.verifyNetworkDomain(networkId, domainId)
client.listNetworkTrustedIdpIntegrations(networkId)
client.registerNetworkTrustedIdp({ networkId, idpLabel })
client.approveNetworkTrustedIdp(networkId, integrationId)
client.activateNetworkUserViaTrustedIdp({ networkId, integrationId, externalUserId })
client.getNetworkMonitoring({ networkId, since?, until?, limit?, action?, outcome?, ... })
```

---

## Network tenant

`networks` is the tenant boundary for the whole platform — workspaces, projects,
communities, institutions, businesses, and publications all resolve to exactly
one network. Workspaces are **not** the tenant root; a workspace with no
network path cannot exist. The methods listed above are how a system app
creates and administers a network and everything inside it.

### System-app only

Every network-tenant method requires a **system-app credential**: a developer
key or OAuth client whose linked `app_provider` has `is_system_app = true`. A
plain account token or a non-system-app integration gets `403 SYSTEM_APP_ONLY`
on every call — there is no code path that lets an ordinary app create a
network, provision a user, or claim a domain. Domain and trusted-IdP
provisioning stay system-app-only permanently — that gate is not lifted for
public developer apps.

An OAuth account-token call acts as its own subject. A bare developer-key call
has no inherent subject and must be told which account to act for via
`accountId` on the request body — omit it and you get `400
ACCOUNT_ID_REQUIRED`.

### Idempotency and `externalUserId`

Every entity-creation and user-provisioning method (`createNetwork*`,
`bindNetworkProfile`, `provisionNetworkUser`, `updateNetworkUser`,
`deactivateNetworkUser`) requires an `idempotencyKey` (8-200 chars). A retry
with the same key and the same request body **replays the original outcome**
without re-running the write — check the returned `replayed` flag. The same
key with a **different** body throws `409 IDEMPOTENCY_CONFLICT` instead of
silently applying the new body. A concurrent duplicate — the exact same key
still mid-flight — throws `409 ACTION_IN_PROGRESS` rather than racing a second
write.

Domain claim/verify and trusted-IdP register/approve/activate do **not** use
the idempotency wrapper — `claimNetworkDomain` and `approveNetworkTrustedIdp`
etc. don't take an `idempotencyKey`. `claimNetworkDomain` is naturally
idempotent instead: re-claiming an already-pending domain for the same
network returns the existing row; `verifyNetworkDomain` replayed on an
already-verified domain is a safe no-op.

`externalUserId` is the **caller's own identifier** for a provisioned user
(your user ID in your system, not a DeadArk account ID) — it's how you look
the user back up with `getNetworkUser`/`updateNetworkUser`/
`deactivateNetworkUser`, and it's unique per network (`(network_id,
external_user_id)`), not globally. Provisioned users always start `pending`
or `invited`; there is no way to provision a globally active user. Elevating a
provisioned user straight to `owner`/`admin` on creation or update throws
`403 ELEVATED_ROLE_REQUIRES_APPROVAL` unless the acting account already holds
owner/admin standing in the network.

### Rate limits and quota errors

Beyond the baseline per-key-per-route limit already applied to every `/api/dev/*`
call, an operator can bind an explicit ceiling at the network, app_provider,
or developer_key level for any network-tenant action. When one is bound and
exceeded, the call throws `429` with `RATE_LIMIT_HOURLY` or `RATE_LIMIT_DAILY`
as the error code. A dimension with no bound policy is simply skipped — these
are opt-in ceilings on top of the baseline limit, not a replacement for it.

### Kill-switch statuses

Every integration (`app_providers`, developer keys, OAuth clients) carries a
runtime status. `active` is the only status that allows a network-tenant call
through:

| Status | Error thrown |
|---|---|
| `paused` | `403 INTEGRATION_PAUSED` |
| `revoked` | `403 INTEGRATION_REVOKED` |
| `quarantined` | `403 INTEGRATION_QUARANTINED` |

An operator can pause/revoke/quarantine one integration without affecting any
other integration on the same platform — a previously-issued, still-unexpired
OAuth access token for a disabled client stops working immediately rather
than continuing until it naturally expires.

### Referral activation

Creating a network or a network-scoped business/community/institution/project/
publication also activates the referring account's referral reward — but only
when: (1) the call is a real OAuth account-token actor (never a bare
developer-key `accountId` override), and (2) the call is not an idempotency
replay (the original call already triggered activation once). Activation is
relayed non-blockingly — a failure to activate never fails the entity-creation
response itself, so check server-side referral state separately if you need
to confirm it fired. Every activation attempt (allowed or denied) also writes
a `<entityType>.referral_activation` row into the network's audit trail, so
you can see activation volume/failures via `getNetworkMonitoring` below.

### Rollout flags (Batch 10)

Separate from the per-integration kill switch above, an operator can disable
an entire **capability** platform-wide — every integration on every network at
once — without touching any single `app_providers` row. This is a staged-
rollout/incident lever, not a per-tenant control:

| Capability | Covers |
|---|---|
| `network_create` | `createNetwork` |
| `entity_creation` | `bindNetworkProfile`, `createNetworkBusiness/Community/Institution/Project/Publication` |
| `user_provisioning` | `provisionNetworkUser`, `getNetworkUser`, `updateNetworkUser`, `deactivateNetworkUser` |
| `domain_checks` | `listNetworkDomains`, `claimNetworkDomain`, `verifyNetworkDomain` |
| `trusted_idp` | `listNetworkTrustedIdpIntegrations`, `registerNetworkTrustedIdp`, `approveNetworkTrustedIdp`, `activateNetworkUserViaTrustedIdp` |

A disabled capability throws `503 NETWORK_ROLLOUT_<CAPABILITY>_DISABLED` for
every caller, regardless of which integration or network they're bound to.

A capability can also be **staged to a canary** instead of fully flipped:
setting `NETWORK_ROLLOUT_<CAPABILITY>_CANARY_APP_PROVIDERS` to a
comma-separated list of `app_provider` ids restricts that capability to only
those integrations — everyone else throws
`503 NETWORK_ROLLOUT_<CAPABILITY>_CANARY_ONLY`, even though the capability
itself is still "on". Clearing the env var (not enumerating every integration
in it) is how a canary graduates into a full rollout.

`getNetworkMonitoring` (below) is exempt from every one of these flags, so it
stays reachable for incident diagnosis even while a capability is off or
canaried.

### Monitoring dashboard (Batch 10)

`getNetworkMonitoring({ networkId, ... })` is a read-only audit/metrics
surface over the network's own audit trail — system-app-only like everything
else here, but the one method that ignores the rollout flags above. It
returns:

- `window` — the `{ since, until }` range actually applied (defaults to the
  last 24h).
- `summary` — aggregate counts for the window: `total_events`,
  `allowed_events`, `denied_events`, `rate_limit_breaches`,
  `integration_kill_switch_denials`, `rollout_disabled_denials`,
  `rollout_canary_denials`, `idempotency_conflicts`, `provisioning_volume`,
  and `referral_activations: { allowed, denied }`.
- `events` — the matching raw rows (route, action, outcome, deny reason,
  actor account, workspace, entity, developer key, OAuth client, app
  provider, request id, timestamp), filterable by `action`, `outcome`,
  `actorAccountId`, `appProviderId`, `developerKeyId`, `oauthClientId`, and
  `requestId`, and paginated via `limit` (default 50, max 200).

This is the audit trail the acceptance bar for this batch calls for: queryable
by network, integration, API key, actor, and request id, all from one call.

---

## Kits

Kits wrap a logical surface of the API. Context-aware kits take a `ClientContext`
as their first argument; global kits (★) operate on the authenticated account.

### WorkKit
```ts
const work = new WorkKit(client);
work.listBoards(context)
work.createBoard(context, { name, view? })
work.updateBoard(context, boardId, patch)
work.deleteBoard(context, boardId)
work.listTasks(context, query?)
work.createTask(context, { title, status?, priority?, ... })
work.updateTask(context, taskId, patch)
work.deleteTask(context, taskId)
work.capture({ title, description? }) // personal Inbox, no context lookup required
```

### FocusKit ★
```ts
const focus = new FocusKit(client);
const { interpretation, suggestedLane } = await focus.interpret({ text: 'Plan the next release' });
```

### NotesKit
```ts
const notes = new NotesKit(client);
// Workspace PM notes (context-aware)
notes.listNotes(context, query?)
notes.createNote(context, input)
notes.updateNote(context, noteId, patch)
notes.deleteNote(context, noteId)
// Identity-scoped global notes (★)
notes.listMyNotes(query?)
notes.createMyNote(input)
notes.updateMyNote(noteId, patch)
notes.deleteMyNote(noteId)
```

### WebhooksKit ★
```ts
const webhooks = new WebhooksKit(client);
webhooks.list()
webhooks.create({ url, events })
webhooks.update(webhookId, patch)
webhooks.delete(webhookId)
webhooks.test(webhookId, eventType)
webhooks.events  // typed tuple of all subscribable event strings
```

### CalendarKit
```ts
const calendar = new CalendarKit(client);
calendar.list(context)
calendar.create(context, { title, startsAt })
calendar.update(context, itemId, patch)
calendar.delete(context, itemId)
```

### SearchKit ★
```ts
const search = new SearchKit(client);
search.query({ q, kind?, workspaceId?, limit? })
```

### NotificationsKit ★
```ts
const notifications = new NotificationsKit(client);
notifications.list({ unreadOnly: true })
notifications.markRead(notificationId)
notifications.markAllRead()
```

### AutomationKit ★
```ts
const automation = new AutomationKit(client);
automation.listChallenges()
automation.progressChallenge(challengeCode, progressValue)
automation.getFocusState()
```

Also available: `CollaborationKit`, `ContentKit`, `FilesKit`, `VaultKit`.

---

## Event types

The `WEBHOOK_EVENTS` constant lists all subscribable event strings:

```ts
import { WEBHOOK_EVENTS } from '@deadark/sdk';
// ['context.created', 'pm.board.created', 'pm.task.created', ...]

// Or from the API at runtime (includes descriptions):
const catalog = await client.getEventCatalog();
```

---

## Testing

```ts
import { createMockTransport, createFixtureTransport } from '@deadark/sdk';

// Mock: custom handler per call
const client = new DeveloperSuiteClient(
  createMockTransport(async ({ path }) => ({
    status: 200,
    body: { success: true, data: [] },
  })),
);

// Fixture: deterministic playback from a recorded response map
const client2 = new DeveloperSuiteClient(
  createFixtureTransport({ '/api/dev/workspaces': { success: true, data: [] } }),
);
```

---

## Build

```bash
npm run build     # tsup → dist/ (ESM + CJS + .d.ts + generated CSS)
npm run typecheck # tsc --noEmit
```

---

## API reference

Full OpenAPI 3.1 spec: `https://dev.deadark.com/api/dev/openapi.json`
Discovery endpoint: `https://dev.deadark.com/api/dev`
