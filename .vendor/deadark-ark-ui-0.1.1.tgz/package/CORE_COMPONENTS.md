# ARK UI Core Components

This file documents `@deadark/ark-ui/core` — layer 3 of the four-layer
component model (see
[docs/architecture/COMPONENT_LAYER_MODEL.md](docs/architecture/COMPONENT_LAYER_MODEL.md)):
product-grade, still domain-agnostic composites, one layer above the themed
single-concept components a team hand-assembles per page.

```
Primitives  ->  Layered Components  ->  Core Components  ->  Page Builders
@deadark/ark-ui/primitives  @deadark/ark-ui/components  @deadark/ark-ui/core  @deadark/ark-ui/page-builders
```

Reach for a Core Component when you want the whole product pattern (a data
table with search/sort/pagination/selection, a command palette with a
shortcut and recent items, ...) rather than assembling one from primitives
yourself. Every option object here is a plain object — none of these take or
produce F/R/S/D pattern strings.

Each composite here wraps exactly one primitive named in
[docs/architecture/COMPONENT_LAYER_BATCH_PLAN.md](docs/architecture/COMPONENT_LAYER_BATCH_PLAN.md)'s
Batch C build list — that primitive is already the product-shaped surface a
team reaches for on its own, so this layer adds only the orchestration it
doesn't already own (toolbar/search, global shortcuts, recent-item memory,
upload progress, route binding, or persisted/read-state history), and never
reaches down to a second, lower-level primitive.

## Reflecting custom state

`ui.update(ref, data)` writes through `RefData` — a single, closed, typed
shape shared by every consumer of the runtime (`state`, `text`, `open`,
`selected`, ... see `ark-ui.runtime.ts`). It intentionally has no index
signature: if it took arbitrary extra fields, every Core Component would be
free to widen a type every other consumer of the runtime also depends on,
and the shape would drift into a junk drawer.

When a composite needs to reflect a feature-specific concept the DOM doesn't
already model — an "unsaved changes" flag, a computed `aria-valuenow`, a
route-driven `aria-current` — reach for `ui.configureRef(ref, { attrs: {...}
} })` instead, e.g.:

```js
ui.configureRef(sectionRef, { attrs: { "data-dirty": String(isDirty) } });
```

This is the runtime's actual generic escape hatch (`RefConfig.attrs`, merged
into the element's attribute bag on every render). Prefer it over
`ui.getElement(ref)?.setAttribute?.(...)`: a raw `setAttribute` call pokes
the *current* live DOM node directly, so it silently disappears the next
time anything re-renders that ref (`update()`, or another `configureRef()`
call) — `renderNode` builds a fresh element from `refConfigs` and never knew
about the manual mutation. `configureRef`'s `attrs` are stored in
`refConfigs` itself, so they get reapplied on every render of that ref, the
same way `className`/`styles`/`label` already do. All three composites that
need this (`AttachmentPanel`'s `aria-valuenow`, `AppNav`'s `aria-current`,
`SettingsForm`'s `data-dirty`) use this pattern.

## Included Composites

- `createArkCoreDataTable(...)`
- `createArkCoreDatePickerField(...)`
- `createArkCoreCommandPalette(...)`
- `createArkCoreAttachmentPanel(...)`
- `createArkCoreAppNav(...)`
- `createArkCoreNotificationCenter(...)`
- `createArkCoreSettingsForm(...)`

## DataTable

Use `createArkCoreDataTable(...)` for a full data grid: everything
`createArkDataTable()` already provides (column show/hide, pinning,
resizing, pagination, sort, row selection, empty/loading coordination) plus
a toolbar.

What it adds on top of `createArkDataTable()`:

- a `searchRef` text input that filters rows via a caller-supplied
  `filterBy(rowRef, query)` predicate — while a query is active, filtering
  takes over row visibility from pagination entirely (search results are
  shown unpaginated); clearing the query hands visibility back to the
  table's own page state
- a `searchEmptyRef` shown when a query matches zero rows
- a `selectionCountRef` kept in sync with the current selection size
- `bulkActions`: buttons that act on the current selection (e.g. a "Delete
  selected" row), each wired to `ui.onAction` and passed the current
  `selectedRefs`

```js
import { createArkUI } from "@deadark/ark-ui/runtime";
import { registerArkComponents } from "@deadark/ark-ui/components";
import { createArkCoreDataTable } from "@deadark/ark-ui/core";

const ui = createArkUI();
registerArkComponents(ui);

const table = createArkCoreDataTable(ui, {
  tableRef: "tbl", theadRef: "thead", itemRefs: rowRefs, headerRefs: headerRefs,
  columns: [{ headerRef: "hname", accessor: (rowRef) => rows[rowRef].name, cellRefs: nameCellRefs }],
  selectionMode: "multiple",
  searchRef: "search", filterBy: (rowRef, query) => rows[rowRef].name.toLowerCase().includes(query.toLowerCase()),
  selectionCountRef: "count",
  bulkActions: [{ actionRef: "delete", onRun: (selectedRefs) => deleteRows(selectedRefs) }],
});
```

## DatePickerField

Use `createArkCoreDatePickerField(...)` to get `createArkField()`'s
label/required/error/helper wiring around a `createArkDatePicker()` trigger,
plus named format presets.

What it adds on top of `createArkDatePicker()`:

- `createArkField()` wiring: the picker's `triggerRef` becomes the field's
  control, with `fieldLabelRef` (kept distinct from `ArkDatePickerOptions`'s
  own `labelRef`, which is the calendar's optional month/year label — a
  different element), `helperRef`, `errorRef`, `required`, and `invalid` all
  passed through
- `format: "iso" | "us" | "eu"` presets for `valueRef` text, used when
  `formatDate`/`formatRange` aren't supplied directly (range mode joins two
  formatted dates with " - ", same default as the underlying primitive)

```js
createArkCoreDatePickerField(ui, {
  fieldRef: "field", fieldLabelRef: "label", helperRef: "helper", errorRef: "error", required: true,
  triggerRef: "trigger", contentRef: "content", valueRef: "value",
  gridRef: "grid", dayRefs, format: "iso",
});
```

## CommandPalette

Use `createArkCoreCommandPalette(...)` for a global Cmd+K-style command
launcher on top of `createArkCommandSurface()`.

What it adds on top of `createArkCommandSurface()`:

- a global keyboard `shortcut` (default `{ key: "k", metaKey: true }`)
  wired to `document`, so it opens/closes the palette regardless of current
  focus; pass `shortcut: false` to opt out
- `getRecent()`: the most-recently-committed command refs, most recent
  first, capped at `recentLimit` (default 5) and deduplicated (re-committing
  an already-recent command moves it to the front instead of duplicating it)

```js
const palette = createArkCoreCommandPalette(ui, {
  inputRef: "cmd", contentRef: "cmdlist", optionRefs, emptyRef: "empty",
  onCommand: (ref, value) => runCommand(value),
});
// palette.open() / palette.close() / palette.getRecent() — the full
// ArkComboboxHandle plus getRecent().
```

## AttachmentPanel

Use `createArkCoreAttachmentPanel(...)` for a file list with real upload
progress on top of `createArkAttachment()`.

What it adds on top of `createArkAttachment()`:

- `rows`: a fixed pool of row slots (`rowRef`/`nameRef`/`progressRef`/
  `statusRef`/`removeRef`), matching the same pre-declared-slot-pool shape
  `createArkToastRegion()` uses — ARK's ref system needs elements declared
  ahead of time, so files are assigned to slots by index as they're added
- `upload(file, reportProgress)`: called once per newly-added file; report
  0-100 via the callback, resolve/reject to drive that file's row into
  `"done"`/`"error"` (surfaced via `onUploadError`)
- upload state is tracked by **File identity, not row index** — removing
  one file never restarts another file's already-in-flight or completed
  upload, even though every other file's row index shifts after a removal
- `getRowState(index)` reports `{ status, progress }` for the file
  currently in that row

```js
createArkCoreAttachmentPanel(ui, {
  inputRef: "file-input", dropzoneRef: "dropzone", emptyRef: "empty", multiple: true,
  rows: [{ rowRef: "row0", nameRef: "name0", progressRef: "progress0", statusRef: "status0", removeRef: "remove0" }, /* ... */],
  upload: (file, reportProgress) => uploadToServer(file, reportProgress),
  onUploadError: (file, error) => notify(`${file.name} failed: ${error.message}`),
});
```

## AppNav

Use `createArkCoreAppNav(...)` for chrome navigation bound to `flux-router`
route state, on top of `createArkAppShell()` + `createArkNavigationMenu()`.

`createArkNavigationMenu()` wraps `createArkTabs()`, which requires a
non-empty, index-parallel panel ref for every trigger — there's no
"triggers only" mode at the primitive level. Every `items[]` entry therefore
needs a `contentRef`: an app that mounts route content elsewhere (the common
`flux-router` case) can point it at an unused hidden marker element; an app
that swaps in-page sections can point it at the real content panel.

What it adds on top of `createArkAppShell()` + `createArkNavigationMenu()`:

- `syncRoute(path)`: marks the matching item active (`navMenu.select()` +
  `aria-current="page"` on its trigger, `aria-current="false"` on the
  rest). An exact literal match always wins over a broader prefix match,
  regardless of declaration order — a `path: "/settings"` item declared
  before a `path: "/settings/profile", exact: true` item doesn't shadow it
- `router?: { getCurrentPath(): string }`: if given, `syncRoute()` runs once
  automatically at construction, seeded from `router.getCurrentPath()`
- `getActiveItem()`

`FluxRouter` (`ark-ui.flux-router.ts`) satisfies the router shape directly
via its own `getCurrentPath()` and `onNavigate` option — wire route
*changes* into `syncRoute()` like this:

```js
let appNav; // assigned below, referenced by the closure the router calls later
const router = new FluxRouter({ root, resolver, onNavigate: (path) => appNav?.syncRoute(path) });
appNav = createArkCoreAppNav(ui, {
  shellRef: "shell", railRef: "rail", navRef: "nav", mainRef: "main", listRef: "list",
  items: [{ triggerRef: "t-home", contentRef: "p-home", path: "/", exact: true }, /* ... */],
  router, // seeds the initial active item from router.getCurrentPath()
});
router.start(); // appNav is already assigned by the time this fires onNavigate
```

## NotificationCenter

Use `createArkCoreNotificationCenter(...)` for a persisted notification
history with unread tracking on top of `createArkToastRegion()`.

What it adds on top of `createArkToastRegion()`:

- persisted `getHistory()`: every shown toast, most recent first, capped at
  `historyLimit` (default 50)
- `markRead(id)` / `markAllRead()` / `getUnreadCount()`
- `unreadCountRef`: kept in sync with the unread count as plain text
- `onHistoryChange(history)`: fires whenever a toast is shown or read-state
  changes

```js
const center = createArkCoreNotificationCenter(ui, {
  regionRef: "region", toastRefs, titleRefs, descriptionRefs, closeRefs,
  unreadCountRef: "unread-badge",
});
center.show({ title: "Saved", tone: "success" });
// center.getHistory() / center.markRead(id) / center.markAllRead()
```

## SettingsForm

Use `createArkCoreSettingsForm(...)` for a settings-style form with
unsaved-changes tracking on top of `createArkForm()`. Not one of the
original six — added because
[COMPONENT_LAYER_BATCH_PLAN.md](docs/architecture/COMPONENT_LAYER_BATCH_PLAN.md)'s
Page Builders batch gate requires a Core-layer form composite to cover the
settings-page case, and it's exactly the shape
[COMPONENT_LAYER_MODEL.md](docs/architecture/COMPONENT_LAYER_MODEL.md)'s own
illustrative list already named ("SettingsForm = Form + Field groups +
submit/success/error orchestration").

What it adds on top of `createArkForm()` (which already owns validation,
submit lifecycle, and success/error messaging):

- dirty-state tracking: `isDirty()` / `getDirtyFieldNames()`, computed by
  comparing current field values against the baseline captured at
  construction. A successful submit (including an async `onSubmit` that
  returns a Promise) resets the baseline to the just-saved values — a form
  that was dirty when submitted is clean immediately after, not still
  reporting the pre-submit fields as changed
- `dirtyRef`: an "unsaved changes" banner, shown/hidden automatically
- `sections`: optional field groups (`{ sectionRef, fieldNames }`) — each
  section's element gets a real `data-dirty="true"/"false"` attribute
  whenever any of its own fields differ from the baseline, so a multi-tab
  settings page can mark which tabs have unsaved changes without
  re-deriving it from `getDirtyFieldNames()` itself
- `onDirtyChange(dirty, dirtyFieldNames)`

```js
const form = createArkCoreSettingsForm(ui, {
  formRef: "form", submitRef: "submit", dirtyRef: "unsaved-banner",
  fields: [
    { name: "displayName", fieldRef: "f-name", labelRef: "l-name", controlRef: "c-name" },
    { name: "email", fieldRef: "f-email", labelRef: "l-email", controlRef: "c-email" },
  ],
  sections: [{ sectionRef: "profile-tab", fieldNames: ["displayName", "email"] }],
  onSubmit: (values) => saveSettings(values),
});
// form.isDirty() / form.getDirtyFieldNames() / the full ArkFormHandle (values/submit/getErrors)
```

## React

None of these mount into React's tree directly — they wire behavior onto
DOM elements a page already rendered via `ui.render()`, the same as every
other layer in this package. A React app observes a Core Component's
callback-driven state (`onSelectionChange`, `onRecentChange`,
`onHistoryChange`, ...) by wrapping it in a small `subscribe`/`getSnapshot`
pair and reading it with `React.useSyncExternalStore` — see
`tests/test-core-data-table-react.mjs`,
`tests/test-core-command-palette-react.mjs`, and
`tests/test-core-notification-center-react.mjs` for the full pattern.
