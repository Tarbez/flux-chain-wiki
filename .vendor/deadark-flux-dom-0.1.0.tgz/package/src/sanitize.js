// Sanitized DOM writes for Flux bindings: strips dangerous tags/attributes
// from HTML written through `data-flx-render="html:..."` bindings, and
// clears element children safely. Depends on `@deadark/flux-state/safety`
// for the actual attribute/property allowlist policy -- this module owns
// only the DOM traversal and mutation, not the safety decisions themselves.
import { getFluxTrustedTypesPolicy, isSafeFluxAttribute } from "@deadark/flux-state/safety";

const FLUX_BLOCKED_HTML_TAGS = new Set(["script", "iframe", "object", "embed", "base", "meta", "link", "style", "template"]);

function fluxAttributeNames(el) {
  if (typeof el.getAttributeNames === "function") return el.getAttributeNames();
  return Object.keys(el.attrs || {});
}

export function sanitizeFluxHtml(root) {
  const visit = (el) => {
    for (const name of fluxAttributeNames(el)) {
      const value = el.getAttribute(name) || "";
      if (!isSafeFluxAttribute(name, value)) el.removeAttribute(name);
    }
    for (const child of Array.from(el.children || [])) {
      const element = child;
      if (FLUX_BLOCKED_HTML_TAGS.has(element.tagName.toLowerCase())) {
        el.removeChild(element);
        continue;
      }
      visit(element);
    }
  };
  visit(root);
}

export function setSanitizedFluxHtml(el, html) {
  const trusted = getFluxTrustedTypesPolicy()?.createHTML(html) ?? html;
  el.innerHTML = trusted;
  sanitizeFluxHtml(el);
}

export function clearFluxElement(el) {
  const nodes = el.childNodes || el.children;
  while (nodes.length > 0) el.removeChild(nodes[0]);
}
