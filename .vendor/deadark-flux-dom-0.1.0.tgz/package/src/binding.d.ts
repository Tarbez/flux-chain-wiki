import type { FluxValue, FluxStoreAdapter, FluxStoreMetrics } from "@deadark/flux-state/store";

type FluxRenderKind = "text" | "html" | "value" | "hidden" | "show" | "attr" | "prop" | "checked";

interface FluxRenderInstruction {
  kind: FluxRenderKind;
  name?: string;
  field?: string;
}

export interface FluxDOMBinding {
  path: string;
  el: HTMLElement;
  render: FluxRenderInstruction[];
  unsubscribe: () => void;
}

export interface FluxListInstruction {
  template: HTMLElement;
  itemPathAttribute: string;
  keyField?: string;
  windowSize: number;
  overscan: number;
  startPath?: string;
  itemHeight?: number;
  mode: "fixed" | "scroll";
}

export interface FluxDOMOptions {
  root?: HTMLElement;
  store?: FluxStoreAdapter;
}

export interface FluxDOMProfile {
  bindings: number;
  listBindings: number;
  pendingJobs: number;
  storeMetrics: FluxStoreMetrics | null;
  timelineEntries: number;
  queuedWrites: number | null;
  conflicts: number | null;
  syncTargets: number | null;
}

export declare class FluxDOM {
  readonly store: FluxStoreAdapter;
  constructor(options?: FluxDOMOptions);
  bind(root?: HTMLElement): FluxDOMBinding[];
  rebind(root?: HTMLElement): FluxDOMBinding[];
  unbind(root?: HTMLElement): void;
  set(path: string, value: FluxValue): void;
  get(path: string): FluxValue;
  flush(): void;
  profile(): FluxDOMProfile;
}
