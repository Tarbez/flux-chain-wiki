// Barrel export for @deadark/flux-dom: DOM binding + sanitization.
// See docs/architecture/ARK_UI_EVOLUTION_PLAN.md section 3.3 (Batch 2).
export * from "./binding.js";
export * from "./sanitize.js";
