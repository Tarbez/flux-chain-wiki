// DOM binding layer for the Flux state engine: `data-flx` discovery,
// binding indexes, sanitized DOM writes, list/virtualization rendering, and
// lifecycle cleanup (mutation-observed bind/unbind). Depends on
// `@deadark/flux-state` for the store contract and default store
// implementation -- it does not own any state-engine behavior itself. See
// docs/architecture/ARK_UI_EVOLUTION_PLAN.md section 3.3.
import { FluxMemoryStore } from "@deadark/flux-state/store";
import { isSafeFluxAttribute, isSafeFluxProperty } from "@deadark/flux-state/safety";
import { setSanitizedFluxHtml } from "./sanitize.js";

function splitPath(path) {
  return path.split(".").map((part) => part.trim()).filter(Boolean);
}

function getNestedValue(value, segments) {
  let current = value;
  for (const segment of segments) {
    if (!current || typeof current !== "object") return undefined;
    current = current[segment];
  }
  return current;
}

function normalizeDefaultValue(value) {
  if (value == null) return "";
  if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value);
  if (typeof value === "object") {
    const record = value;
    if (typeof record.text === "string") return record.text;
    if (typeof record.value === "string" || typeof record.value === "number" || typeof record.value === "boolean") return String(record.value);
  }
  return JSON.stringify(value);
}

function resolveFieldValue(value, field) {
  if (!field) return value;
  return getNestedValue(value, splitPath(field));
}

function coerceBoolean(value) {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") return value === "true" || value === "1";
  if (typeof value === "number") return value !== 0;
  return !!value;
}

function traverse(node, visit) {
  visit(node);
  for (const child of Array.from(node.children || [])) traverse(child, visit);
}

function parseNumberAttr(el, name, fallback) {
  const raw = Number(el.getAttribute(name));
  return Number.isFinite(raw) ? raw : fallback;
}

// Minimal CSP-safe-ish inline style setter. This intentionally does not
// depend on ark-ui's own dynamic-stylesheet/CSP-nonce machinery
// (ark-ui.csp.ts's setArkElementStyles) -- flux-dom is a lower-level
// package than ark-ui in the dependency direction (see Rule 2, evolution
// plan section 4), so it cannot import from it. This covers the one use
// (virtualized list spacer padding) with the same observable result: a
// real `CSSStyleDeclaration` gets `setProperty`/`removeProperty` calls with
// a kebab-case property name; anything else (including the fake DOM test
// harness's plain `{}` style object) falls back to direct property
// assignment.
function setFluxElementStyle(el, property, value) {
  const normalizedValue = value == null ? "" : String(value);
  if (typeof el.style?.setProperty === "function") {
    const normalizedProperty = property.replace(/[A-Z]/g, (letter) => `-${letter.toLowerCase()}`);
    if (normalizedValue) el.style.setProperty(normalizedProperty, normalizedValue);
    else el.style.removeProperty(normalizedProperty);
    return;
  }
  el.style[property] = normalizedValue;
}

function setFluxElementStyles(el, styles) {
  for (const [property, value] of Object.entries(styles)) setFluxElementStyle(el, property, value);
}

function parseRenderInstruction(raw) {
  const trimmed = raw.trim();
  if (!trimmed) return null;
  const [targetPart, field] = trimmed.split("@");
  const [kindRaw, name] = targetPart.split(":");
  const kind = kindRaw.trim();
  if (kind === "attr" || kind === "prop") return name ? { kind, name: name.trim(), field: field?.trim() } : null;
  if (kind === "text" || kind === "html" || kind === "value" || kind === "hidden" || kind === "show" || kind === "checked") {
    return { kind, field: field?.trim() };
  }
  return null;
}

function defaultInstructionsFor(el) {
  const tag = el.tagName.toLowerCase();
  if (tag === "input") {
    const type = String(el.getAttribute("type") || "").toLowerCase();
    if (type === "checkbox" || type === "radio") return [{ kind: "checked" }];
    return [{ kind: "value" }];
  }
  if (tag === "textarea" || tag === "select") return [{ kind: "value" }];
  return [{ kind: "text" }];
}

function resolveInstructions(el) {
  const raw = el.getAttribute("data-flx-render");
  if (!raw) return defaultInstructionsFor(el);
  return raw
    .split(",")
    .map(parseRenderInstruction)
    .filter((entry) => !!entry);
}

function applyInstruction(el, instruction, value) {
  const resolved = resolveFieldValue(value, instruction.field);
  switch (instruction.kind) {
    case "text":
      el.textContent = normalizeDefaultValue(resolved);
      return;
    case "html":
      setSanitizedFluxHtml(el, normalizeDefaultValue(resolved));
      return;
    case "value":
      el.value = normalizeDefaultValue(resolved);
      return;
    case "checked":
      el.checked = coerceBoolean(resolved);
      return;
    case "hidden":
      if (coerceBoolean(resolved)) el.setAttribute("hidden", "true");
      else el.removeAttribute("hidden");
      return;
    case "show":
      if (coerceBoolean(resolved)) el.removeAttribute("hidden");
      else el.setAttribute("hidden", "true");
      return;
    case "attr":
      if (!instruction.name) return;
      if (resolved === undefined || resolved === null || resolved === false) el.removeAttribute(instruction.name);
      else {
        const nextValue = normalizeDefaultValue(resolved);
        if (isSafeFluxAttribute(instruction.name, nextValue)) el.setAttribute(instruction.name, nextValue);
        else el.removeAttribute(instruction.name);
      }
      return;
    case "prop":
      if (!instruction.name || !isSafeFluxProperty(instruction.name, resolved)) return;
      el[instruction.name] = resolved;
      return;
  }
}

function defaultWriteMode(el) {
  const tag = el.tagName.toLowerCase();
  if (tag === "input") {
    const type = String(el.getAttribute("type") || "").toLowerCase();
    return type === "checkbox" || type === "radio" ? "checked" : "value";
  }
  if (tag === "textarea" || tag === "select") return "value";
  return null;
}

function resolveWriteMode(el) {
  const raw = el.getAttribute("data-flx-write");
  if (raw === "value" || raw === "checked") return raw;
  if (raw === "off") return null;
  return defaultWriteMode(el);
}

export class FluxDOM {
  store;
  #root;
  #bindings = new Map();
  #listBindings = new Map();
  #observer = null;
  #pending = new Map();
  #scheduled = false;

  constructor(options = {}) {
    this.store = options.store ?? new FluxMemoryStore();
    this.#root = options.root ?? null;
    if (this.#root) this.bind(this.#root);
  }

  bind(root) {
    const host = root ?? this.#root;
    if (!host) return [];
    this.#root = host;
    const created = [];
    traverse(host, (el) => {
      const path = el.getAttribute("data-flx");
      if (!path || path === "$item" || path.startsWith("$item.") || this.#bindings.has(el)) return;
      const render = resolveInstructions(el);
      const listInstruction = this.#resolveListInstruction(el);
      const apply = (value) => this.#enqueue(el, () => {
        if (listInstruction) {
          this.#renderList(el, value, listInstruction);
          return;
        }
        for (const instruction of render) applyInstruction(el, instruction, value);
      });
      const unsubscribe = this.store.subscribe(path, apply);
      const binding = { path, el, render, unsubscribe };
      this.#bindings.set(el, binding);
      if (listInstruction) this.#listBindings.set(el, binding);
      created.push(binding);
      apply(this.store.get(path));
      if (listInstruction) this.#attachVirtualization(el, path, listInstruction);
      this.#attachWriteback(el, path);
    });
    this.#observe(host);
    this.flush();
    return created;
  }

  rebind(root) {
    return this.bind(root);
  }

  unbind(root) {
    const host = root ?? this.#root;
    if (!host) return;
    for (const [el, binding] of Array.from(this.#bindings.entries())) {
      if (el === host || host.contains(el)) {
        binding.unsubscribe();
        this.#bindings.delete(el);
        this.#listBindings.delete(el);
        this.#pending.delete(el);
      }
    }
    if (!root) {
      this.#observer?.disconnect();
      this.#observer = null;
    }
  }

  set(path, value) {
    this.store.set(path, value);
    this.flush();
  }

  get(path) {
    return this.store.get(path);
  }

  flush() {
    if (!this.#pending.size) return;
    const jobs = Array.from(this.#pending.values());
    this.#pending.clear();
    this.#scheduled = false;
    for (const job of jobs) job();
  }

  profile() {
    const profiledStore = this.store;
    return {
      bindings: this.#bindings.size,
      listBindings: this.#listBindings.size,
      pendingJobs: this.#pending.size,
      storeMetrics: typeof profiledStore.getMetrics === "function" ? profiledStore.getMetrics() : null,
      timelineEntries: typeof profiledStore.getTimeline === "function" ? profiledStore.getTimeline().length : 0,
      queuedWrites: typeof profiledStore.getOfflineQueue === "function" ? profiledStore.getOfflineQueue().length : null,
      conflicts: typeof profiledStore.getConflicts === "function" ? profiledStore.getConflicts().length : null,
      syncTargets: typeof profiledStore.getSyncTargets === "function" ? profiledStore.getSyncTargets().length : null,
    };
  }

  #attachWriteback(el, path) {
    const mode = resolveWriteMode(el);
    if (!mode || el.__fluxWritebound) return;
    el.__fluxWritebound = true;
    const profiledStore = this.store;
    const sync = () => {
      const nextValue = mode === "checked"
        ? { checked: el.checked }
        : el.value;
      if (el.hasAttribute("data-flx-optimistic") && typeof profiledStore.optimisticSet === "function") {
        profiledStore.optimisticSet(path, nextValue);
        return;
      }
      this.store.set(path, nextValue);
    };
    el.addEventListener(mode === "checked" ? "change" : "input", sync);
  }

  #attachVirtualization(el, path, instruction) {
    if (instruction.mode !== "scroll" || !instruction.itemHeight) return;
    if (el.__fluxVirtualized) return;
    el.__fluxVirtualized = true;
    el.addEventListener("scroll", () => {
      this.#enqueue(el, () => this.#renderList(el, this.store.get(path), instruction));
    });
  }

  #observe(root) {
    if (typeof MutationObserver === "undefined" || this.#observer) return;
    this.#observer = new MutationObserver((records) => {
      for (const record of records) {
        for (const node of Array.from(record.addedNodes || [])) {
          if (node instanceof HTMLElement) this.bind(node);
        }
        for (const node of Array.from(record.removedNodes || [])) {
          if (node instanceof HTMLElement) this.unbind(node);
        }
      }
    });
    this.#observer.observe(root, { childList: true, subtree: true });
  }

  #enqueue(el, job) {
    this.#pending.set(el, job);
    if (this.#scheduled) return;
    this.#scheduled = true;
    queueMicrotask(() => this.flush());
  }

  #resolveListInstruction(el) {
    if (!el.hasAttribute("data-flx-list")) return null;
    const template = Array.from(el.children || [])[0];
    if (!template) return null;
    return {
      template,
      itemPathAttribute: el.getAttribute("data-flx-item-path") || "data-flx",
      keyField: el.getAttribute("data-flx-key") || undefined,
      windowSize: Math.max(0, parseNumberAttr(el, "data-flx-window", Number.MAX_SAFE_INTEGER)),
      overscan: Math.max(0, parseNumberAttr(el, "data-flx-overscan", 0)),
      startPath: el.getAttribute("data-flx-window-start") || undefined,
      itemHeight: parseNumberAttr(el, "data-flx-item-height", 0) || undefined,
      mode: el.getAttribute("data-flx-window-mode") === "scroll" ? "scroll" : "fixed",
    };
  }

  #renderList(el, value, instruction) {
    const items = Array.isArray(value) ? value : [];
    let startIndex = instruction.startPath ? Math.max(0, Number(this.store.get(instruction.startPath)) || 0) : 0;
    let windowSize = instruction.windowSize;
    if (instruction.mode === "scroll" && instruction.itemHeight) {
      const viewportHeight = el.clientHeight || parseNumberAttr(el, "data-flx-viewport-height", instruction.itemHeight * 8);
      const scrollTop = el.scrollTop || 0;
      startIndex = Math.max(0, Math.floor(scrollTop / instruction.itemHeight));
      windowSize = Math.max(1, Math.ceil(viewportHeight / instruction.itemHeight));
    }
    const rangeStart = Math.max(0, startIndex - instruction.overscan);
    const rangeEnd = windowSize >= Number.MAX_SAFE_INTEGER
      ? items.length
      : Math.min(items.length, startIndex + windowSize + instruction.overscan);
    const visibleItems = items.slice(rangeStart, rangeEnd);
    const existing = new Map();
    for (const child of Array.from(el.children || [])) {
      const key = child.getAttribute("data-flx-list-key");
      if (key) existing.set(key, child);
    }
    const rendered = [];
    visibleItems.forEach((item, visibleIndex) => {
      const index = rangeStart + visibleIndex;
      const key = this.#resolveListKey(item, index, instruction.keyField);
      const current = existing.get(key) || this.#cloneTemplate(instruction.template);
      current.setAttribute("data-flx-list-key", key);
      this.#bindListItem(current, item, index, instruction.itemPathAttribute);
      rendered.push(current);
    });
    const keep = new Set(rendered);
    for (const child of Array.from(el.children || [])) {
      if (!keep.has(child)) el.removeChild(child);
    }
    for (const child of rendered) el.appendChild(child);
    el.setAttribute("data-flx-window-range", `${rangeStart}:${Math.max(rangeStart, rangeEnd - 1)}`);
    if (instruction.itemHeight) {
      const hiddenBefore = rangeStart * instruction.itemHeight;
      const hiddenAfter = Math.max(0, items.length - rangeEnd) * instruction.itemHeight;
      setFluxElementStyles(el, { paddingTop: `${hiddenBefore}px`, paddingBottom: `${hiddenAfter}px` });
    }
  }

  #resolveListKey(item, index, keyField) {
    if (keyField && item && typeof item === "object") {
      const candidate = item[keyField];
      if (candidate != null) return String(candidate);
    }
    return String(index);
  }

  #cloneTemplate(template) {
    if (typeof template.cloneNode === "function") return template.cloneNode(true);
    const clone = template.ownerDocument.createElement(template.tagName.toLowerCase());
    for (const [key, value] of Object.entries(template.attrs || {})) {
      clone.setAttribute(key, value);
    }
    clone.textContent = template.textContent;
    for (const child of Array.from(template.children || [])) clone.appendChild(this.#cloneTemplate(child));
    return clone;
  }

  #bindListItem(el, item, index, pathAttribute) {
    traverse(el, (node) => {
      const rawPath = node.getAttribute(pathAttribute);
      if (!rawPath) return;
      if (rawPath === "$item") {
        node.textContent = normalizeDefaultValue(item);
        return;
      }
      if (!rawPath.startsWith("$item.")) return;
      const fieldPath = rawPath.slice("$item.".length);
      const fieldValue = getNestedValue(item, splitPath(fieldPath));
      const instructions = resolveInstructions(node);
      for (const render of instructions) applyInstruction(node, render, fieldValue);
    });
    el.setAttribute("data-flx-list-index", String(index));
  }
}
