export declare function sanitizeFluxHtml(root: HTMLElement): void;
export declare function setSanitizedFluxHtml(el: HTMLElement, html: string): void;
export declare function clearFluxElement(el: HTMLElement): void;
