/**
 * `createArkBreadcrumbs` and `createArkPagination` — moved out of
 * `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * Pagination is a single-axis, no-typeahead roving-focus collection built
 * on `@fxn/ui-a11y/collection`'s generic `configureRovingFocusGroup`
 * (loop defaulting to `false`).
 *
 * Breadcrumbs are NOT a roving group (changed 2026-10-19). The WAI-ARIA APG
 * breadcrumb pattern is a `nav` of ordinary links: every crumb is its own Tab
 * stop and no arrow-key model is expected. The roving group used to leave one
 * crumb tabbable (tabindex=0) and set tabindex=-1 on the rest, so keyboard
 * users could not Tab to an ancestor page. The current crumb is marked only by
 * aria-current="page"; links never carry aria-selected (invalid on a link).
 */
import { normalizeRef, normalizeRefs, setAttrs, setHidden } from "@fxn/ui-a11y/dom";
import { configureRovingFocusGroup } from "@fxn/ui-a11y/collection";

function ref(value) {
  return normalizeRef(value);
}

export function createArkBreadcrumbs(ui, options) {
  const navRef = ref(options.navRef);
  const itemRefs = normalizeRefs(options.itemRefs);
  const separatorRefs = normalizeRefs(options.separatorRefs || []);
  const orientation = options.orientation ?? "horizontal";
  const ellipsisRef = ref(options.ellipsisRef);
  const maxVisible = options.maxVisible && ellipsisRef ? options.maxVisible : undefined;
  let currentRef = ref(options.currentRef) || itemRefs[itemRefs.length - 1];
  let expanded = !maxVisible || itemRefs.length <= maxVisible;

  const visibleRefs = () => {
    if (expanded) return itemRefs;
    // Keep the root item plus the trailing run (current page included) —
    // the same shape as shadcn's collapsed breadcrumb and GitHub's path bar
    // — and collapse everything in between behind the ellipsis.
    const tailCount = Math.max(1, maxVisible - 1);
    return itemRefs.filter((_, index) => index === 0 || index >= itemRefs.length - tailCount);
  };

  const sync = () => {
    // aria-orientation is not a property of `navigation`; the layout axis is
    // exposed for styling only.
    ui.configureRef(navRef, { part: "breadcrumbs" });
    setAttrs(ui, navRef, { "data-orientation": orientation });
    const visible = new Set(visibleRefs());
    itemRefs.forEach((itemRef, index) => {
      const isCurrent = itemRef === currentRef;
      const current = ui.get(itemRef) || {};
      setAttrs(ui, itemRef, { "aria-current": isCurrent ? "page" : undefined });
      setHidden(ui, itemRef, !visible.has(itemRef));
      // Never `selected`: the runtime renders it as aria-selected, which is
      // invalid on a link. The current crumb is marked by aria-current="page"
      // alone (set above); `selected: undefined` also clears a stale value.
      ui.update(itemRef, { ...current, selected: undefined, current: isCurrent ? "page" : undefined, hidden: !visible.has(itemRef) });
      if (isCurrent) options.onCurrentChange?.(itemRef, index);
    });
    if (ellipsisRef) {
      ui.configureRef(ellipsisRef, { part: "breadcrumb-ellipsis" });
      setHidden(ui, ellipsisRef, expanded || itemRefs.length <= (maxVisible ?? Infinity));
    }
    separatorRefs.forEach((separatorRef) => setAttrs(ui, separatorRef, { "aria-hidden": "true" }));
  };

  itemRefs.forEach((itemRef) => ui.onAction(itemRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    currentRef = itemRef;
    sync();
  }));
  if (ellipsisRef) {
    ui.onAction(ellipsisRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      expanded = true;
      sync();
    });
  }
  sync();
  return {
    expand: () => { expanded = true; sync(); },
    getState: () => ({ expanded, visibleRefs: visibleRefs() }),
  };
}

export function createArkPagination(ui, options) {
  const navRef = ref(options.navRef);
  const pageRefs = normalizeRefs(options.pageRefs);
  const previousRef = ref(options.previousRef);
  const nextRef = ref(options.nextRef);
  const leadingEllipsisRef = ref(options.leadingEllipsisRef);
  const trailingEllipsisRef = ref(options.trailingEllipsisRef);
  const siblingCount = Math.max(0, options.siblingCount ?? 1);
  const orientation = options.orientation ?? "horizontal";
  const collectionId = `${navRef}-pagination`;
  let currentIndex = Math.max(0, options.currentRef ? pageRefs.indexOf(ref(options.currentRef)) : 0);
  if (currentIndex === -1) currentIndex = 0;

  // First and last page always stay visible; everything within
  // `siblingCount` of the current page stays visible too. Whatever's left
  // in between collapses behind an ellipsis — the same shape shadcn's own
  // Pagination truncation uses.
  const visibleIndexes = () => {
    if (pageRefs.length === 0) return [];
    const windowStart = Math.max(1, currentIndex - siblingCount);
    const windowEnd = Math.min(pageRefs.length - 2, currentIndex + siblingCount);
    const indexes = new Set([0, pageRefs.length - 1]);
    for (let i = windowStart; i <= windowEnd; i++) indexes.add(i);
    return [...indexes].sort((a, b) => a - b);
  };

  const sync = () => {
    // aria-orientation is not a property of `navigation`; the axis is data-only.
    ui.configureRef(navRef, { part: "pagination" });
    setAttrs(ui, navRef, { "data-orientation": orientation });
    const visible = new Set(visibleIndexes());
    const canTruncate = !!(leadingEllipsisRef || trailingEllipsisRef);
    pageRefs.forEach((pageRef, index) => {
      const isCurrent = index === currentIndex;
      const isVisible = !canTruncate || visible.has(index);
      const current = ui.get(pageRef) || {};
      ui.configureRef(pageRef, { collection: collectionId, label: `Page ${index + 1}` });
      setAttrs(ui, pageRef, { "aria-current": isCurrent ? "page" : undefined });
      setHidden(ui, pageRef, !isVisible);
      // Same rule as breadcrumbs: never `selected` (rendered as aria-selected,
      // invalid on a link). aria-current="page" alone marks the current page;
      // `selected: undefined` also clears a stale value.
      ui.update(pageRef, { ...current, selected: undefined, current: isCurrent ? "page" : undefined, hidden: !isVisible });
      if (isCurrent) options.onPageChange?.(pageRef, index);
    });
    if (canTruncate) {
      const visibleList = [...visible].sort((a, b) => a - b);
      const hasLeadingGap = visibleList[1] !== undefined && visibleList[1] - visibleList[0] > 1;
      const hasTrailingGap = visibleList.length >= 2 && visibleList[visibleList.length - 1] - visibleList[visibleList.length - 2] > 1;
      setHidden(ui, leadingEllipsisRef, !hasLeadingGap);
      setHidden(ui, trailingEllipsisRef, !hasTrailingGap);
    }
    if (previousRef) {
      const previousState = ui.get(previousRef) || {};
      ui.update(previousRef, { ...previousState, disabled: currentIndex === 0 });
    }
    if (nextRef) {
      const nextState = ui.get(nextRef) || {};
      ui.update(nextRef, { ...nextState, disabled: currentIndex === pageRefs.length - 1 });
    }
  };

  const goTo = (index) => {
    if (pageRefs.length === 0) return;
    if (options.loop) currentIndex = (index + pageRefs.length) % pageRefs.length;
    else currentIndex = Math.max(0, Math.min(index, pageRefs.length - 1));
    sync();
  };

  configureRovingFocusGroup(ui, collectionId, { refs: pageRefs, orientation, loop: options.loop ?? false, typeahead: false });
  pageRefs.forEach((pageRef, index) => ui.onAction(pageRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    goTo(index);
  }));
  if (previousRef) ui.onAction(previousRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    goTo(currentIndex - 1);
  });
  if (nextRef) ui.onAction(nextRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    goTo(currentIndex + 1);
  });
  sync();
  return {
    goTo,
    getState: () => ({ currentIndex, visibleIndexes: visibleIndexes() }),
  };
}
