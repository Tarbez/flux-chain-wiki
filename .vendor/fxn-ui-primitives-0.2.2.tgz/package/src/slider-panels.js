/**
 * `createArkSlider` and `createArkResizablePanels` — moved out of
 * `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * `clampNumber` is already a shared `@fxn/ui-a11y/value` helper
 * (extracted earlier alongside the calendar-shaped primitives) — reused
 * here rather than reimplemented, not the local `ark-ui.components.ts`
 * copy (which stays there for the primitives not yet moved that still use
 * it).
 */
import { normalizeRef, normalizeRefs, setAttrs, syncModelRef } from "@fxn/ui-a11y/dom";
import { clampNumber } from "@fxn/ui-a11y/value";

function ref(value) {
  return normalizeRef(value);
}

export function createArkSlider(ui, options) {
  const trackRef = ref(options.trackRef);
  const thumbRef = ref(options.thumbRef);
  const valueRef = ref(options.valueRef);
  const stateRef = ref(options.stateRef);
  const min = options.min ?? 0;
  const max = options.max ?? 100;
  const step = options.step ?? 1;
  const orientation = options.orientation ?? "horizontal";
  const disabled = !!options.disabled;
  let value = clampNumber(options.value ?? min, min, max);

  const sync = () => {
    const percent = max === min ? 0 : ((value - min) / (max - min)) * 100;
    ui.configureRef(thumbRef, {
      role: "slider",
      orientation,
      attrs: {
        "aria-valuemin": String(min),
        "aria-valuemax": String(max),
        "aria-valuenow": String(value),
      },
      tabIndex: disabled ? -1 : 0,
    });
    ui.style(trackRef, {
      position: "relative",
      minHeight: orientation === "horizontal" ? "8px" : "160px",
      minWidth: orientation === "horizontal" ? "160px" : "8px",
      borderRadius: "999px",
      overflow: "visible",
    }, { mode: "merge" });
    ui.style(thumbRef, {
      position: "absolute",
      top: orientation === "horizontal" ? "50%" : `${100 - percent}%`,
      left: orientation === "horizontal" ? `${percent}%` : "50%",
      transform: "translate(-50%, -50%)",
      width: "20px",
      height: "20px",
      borderRadius: "999px",
      cursor: disabled ? "not-allowed" : "grab",
    }, { mode: "merge" });
    if (valueRef) {
      const current = ui.get(valueRef) || {};
      ui.update(valueRef, { ...current, text: String(value) });
    }
    syncModelRef(ui, stateRef, { value, min, max, step, orientation });
    options.onValueChange?.(value);
  };

  const setValue = (nextValue) => {
    const snapped = Math.round(clampNumber(nextValue, min, max) / step) * step;
    value = clampNumber(snapped, min, max);
    sync();
  };

  ui.configureRef(trackRef, { part: "slider-track" });
  ui.configureRef(thumbRef, { part: "slider-thumb" });
  ui.bindRefEvent(trackRef, "click", (event, el) => {
    if (disabled) return;
    const pointer = event;
    const rect = el.getBoundingClientRect();
    const raw = orientation === "horizontal"
      ? (pointer.clientX - rect.left) / rect.width
      : 1 - ((pointer.clientY - rect.top) / rect.height);
    setValue(min + (max - min) * clampNumber(raw, 0, 1));
  });
  ui.bindRefEvent(thumbRef, "keydown", (event) => {
    if (disabled) return;
    const keyboard = event;
    if (keyboard.key === "ArrowRight" || keyboard.key === "ArrowUp") {
      keyboard.preventDefault();
      setValue(value + step);
    } else if (keyboard.key === "ArrowLeft" || keyboard.key === "ArrowDown") {
      keyboard.preventDefault();
      setValue(value - step);
    } else if (keyboard.key === "Home") {
      keyboard.preventDefault();
      setValue(min);
    } else if (keyboard.key === "End") {
      keyboard.preventDefault();
      setValue(max);
    }
  });
  sync();
  return {
    setValue,
    getState: () => ({ value, min, max }),
  };
}

export function createArkResizablePanels(ui, options) {
  const containerRef = ref(options.containerRef);
  const panelRefs = normalizeRefs(options.panelRefs);
  const handleRefs = normalizeRefs(options.handleRefs);
  const orientation = options.orientation ?? "horizontal";
  const minSizes = options.minSizes ?? panelRefs.map(() => 0.05);
  let sizes = options.sizes ? [...options.sizes] : panelRefs.map(() => 1 / panelRefs.length);

  const sync = () => {
    ui.configureRef(containerRef, { part: "resizable-panels" });
    setAttrs(ui, containerRef, { "data-orientation": orientation });
    ui.style(containerRef, {
      display: "flex",
      flexDirection: orientation === "vertical" ? "column" : "row",
      width: "100%",
      height: "100%",
      overflow: "hidden",
    }, { mode: "merge" });
    panelRefs.forEach((panelRef, index) => {
      ui.configureRef(panelRef, { part: "resizable-panel" });
      ui.style(panelRef, {
        flex: `0 0 ${(sizes[index] * 100).toFixed(4)}%`,
        overflow: "auto",
        minWidth: "0",
        minHeight: "0",
      }, { mode: "merge" });
    });
    handleRefs.forEach((handleRef) => {
      ui.configureRef(handleRef, { role: "separator", orientation, part: "resizable-handle" });
      setAttrs(ui, handleRef, { "data-orientation": orientation, tabindex: "0" });
      ui.style(handleRef, {
        flex: "0 0 auto",
        cursor: orientation === "vertical" ? "row-resize" : "col-resize",
        touchAction: "none",
      }, { mode: "merge" });
    });
    syncModelRef(ui, ref(options.stateRef), { sizes: [...sizes] });
    options.onSizesChange?.([...sizes]);
  };

  const applyDelta = (leftIndex, rightIndex, baseSizes, deltaFraction) => {
    const minLeft = minSizes[leftIndex] ?? 0.05;
    const minRight = minSizes[rightIndex] ?? 0.05;
    let nextLeft = baseSizes[leftIndex] + deltaFraction;
    let nextRight = baseSizes[rightIndex] - deltaFraction;
    if (nextLeft < minLeft) { nextRight -= minLeft - nextLeft; nextLeft = minLeft; }
    if (nextRight < minRight) { nextLeft -= minRight - nextRight; nextRight = minRight; }
    if (nextLeft < minLeft || nextRight < minRight) return false;
    const next = [...sizes];
    next[leftIndex] = nextLeft;
    next[rightIndex] = nextRight;
    sizes = next;
    return true;
  };

  handleRefs.forEach((handleRef, handleIndex) => {
    const leftIndex = handleIndex;
    const rightIndex = handleIndex + 1;

    ui.bindRefEvent(handleRef, "pointerdown", (rawEvent) => {
      if (typeof document === "undefined") return;
      const event = rawEvent;
      const containerEl = ui.getElement(containerRef);
      if (!containerEl) return;
      const rect = containerEl.getBoundingClientRect();
      const containerExtent = orientation === "vertical" ? rect.height : rect.width;
      if (containerExtent === 0) return;
      const dragStartPos = orientation === "vertical" ? event.clientY : event.clientX;
      const dragStartSizes = [...sizes];
      const onPointerMove = (moveEvent) => {
        const pos = orientation === "vertical" ? moveEvent.clientY : moveEvent.clientX;
        if (applyDelta(leftIndex, rightIndex, dragStartSizes, (pos - dragStartPos) / containerExtent)) sync();
      };
      const onPointerUp = () => {
        document.removeEventListener("pointermove", onPointerMove);
        document.removeEventListener("pointerup", onPointerUp);
      };
      document.addEventListener("pointermove", onPointerMove);
      document.addEventListener("pointerup", onPointerUp);
    });

    // Arrow keys nudge the handle by a fixed step — the WAI-ARIA
    // window-splitter pattern's keyboard equivalent of dragging.
    ui.bindRefEvent(handleRef, "keydown", (rawEvent) => {
      const event = rawEvent;
      const decreaseKey = orientation === "vertical" ? "ArrowUp" : "ArrowLeft";
      const increaseKey = orientation === "vertical" ? "ArrowDown" : "ArrowRight";
      if (event.key !== decreaseKey && event.key !== increaseKey) return;
      event.preventDefault();
      const delta = event.key === increaseKey ? 0.02 : -0.02;
      if (applyDelta(leftIndex, rightIndex, sizes, delta)) sync();
    });
  });

  sync();
  return {
    setSizes: (nextSizes) => { sizes = nextSizes; sync(); },
    getState: () => ({ sizes: [...sizes] }),
  };
}
