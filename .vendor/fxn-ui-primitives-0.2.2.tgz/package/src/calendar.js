/**
 * `createArkCalendar` and `createArkDatePicker` — moved out of
 * `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * `createArkDatePicker` composes `createArkPopover` (already extracted to
 * `@fxn/ui-primitives/dialog`) with `createArkCalendar` from this same
 * file — a real cross-family composition, imported rather than duplicated.
 * `dateKey`/`sameDay`/`dayOnly`/`formatCalendarLabel` are already shared
 * `@fxn/ui-a11y/value` helpers (built for exactly this). `setOpen` is
 * a tiny (4-line) local helper also used by unmoved Menu-family code in
 * `ark-ui.components.ts` — duplicated here rather than shared across
 * packages, since it's small enough that Rule 1's "one owner per concept"
 * isn't worth the coupling for a single trigger/content open-state toggle.
 */
import { normalizeRef, normalizeRefs, setAttrs } from "@fxn/ui-a11y/dom";
import { configureRovingFocusGroup } from "@fxn/ui-a11y/collection";
import { dateKey, sameDay, dayOnly, formatCalendarLabel } from "@fxn/ui-a11y/value";
import { createArkPopover } from "./dialog.js";

function ref(value) {
  return normalizeRef(value);
}

function setOpen(ui, triggerRef, contentRef, open) {
  const triggerState = ui.get(triggerRef) || {};
  const contentState = ui.get(contentRef) || {};
  ui.update(triggerRef, { ...(typeof triggerState === "object" ? triggerState : {}), open });
  ui.update(contentRef, { ...(typeof contentState === "object" ? contentState : {}), open, hidden: !open });
  if (open) ui.openOverlay(contentRef);
  else ui.closeOverlay(contentRef);
}

export function createArkCalendar(ui, options) {
  const gridRef = ref(options.gridRef);
  const dayRefs = normalizeRefs(options.dayRefs);
  const labelRef = ref(options.labelRef);
  const prevRef = ref(options.prevRef);
  const nextRef = ref(options.nextRef);
  const disabledDates = new Set((options.disabledDates || []).map((value) => dateKey(value)));
  const minDate = options.minDate ? dayOnly(options.minDate) : undefined;
  const maxDate = options.maxDate ? dayOnly(options.maxDate) : undefined;
  const weekStartsOn = options.weekStartsOn ?? 0;
  const today = new Date();
  let month = options.month ?? today.getMonth();
  let year = options.year ?? today.getFullYear();
  let selectedDate = options.selectedDate;
  const mode = options.mode ?? "single";
  let selectedRange = {
    start: options.selectedRange?.start ? dayOnly(options.selectedRange.start) : undefined,
    end: options.selectedRange?.end ? dayOnly(options.selectedRange.end) : undefined,
  };
  const selectedDates = new Map((options.selectedDates || []).map((value) => [dateKey(value), dayOnly(value)]));
  const collectionId = `${gridRef}-days`;
  let visibleDates = [];

  const isDateDisabled = (date) => {
    if (disabledDates.has(dateKey(date))) return true;
    const day = dayOnly(date);
    if (minDate && day < minDate) return true;
    if (maxDate && day > maxDate) return true;
    if (options.disabled?.(date)) return true;
    return false;
  };

  // Clamps to the target month's real length so e.g. PageUp from Mar 31
  // lands on Feb 28/29 instead of overflowing into March again.
  const clampToMonth = (targetYear, targetMonth, day) => {
    const daysInTarget = new Date(targetYear, targetMonth + 1, 0).getDate();
    return new Date(targetYear, targetMonth, Math.min(day, daysInTarget));
  };

  const focusDate = (date) => {
    const index = visibleDates.findIndex((candidate) => sameDay(candidate, date));
    if (index >= 0) ui.getElement(dayRefs[index])?.focus?.();
  };

  const renderMonth = () => {
    const firstDay = new Date(year, month, 1);
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const weekdayOffset = (firstDay.getDay() - weekStartsOn + 7) % 7;
    visibleDates = dayRefs.map((_, index) => {
      const dateNumber = index - weekdayOffset + 1;
      return dateNumber >= 1 && dateNumber <= daysInMonth ? new Date(year, month, dateNumber) : undefined;
    });
    if (labelRef) {
      const current = ui.get(labelRef) || {};
      ui.update(labelRef, { ...current, text: formatCalendarLabel(month, year, options.locale) });
    }
    dayRefs.forEach((dayRef, index) => {
      const date = visibleDates[index];
      const disabled = !date || isDateDisabled(date);
      const rangeStart = mode === "range" && date && selectedRange.start ? sameDay(date, selectedRange.start) : false;
      const rangeEnd = mode === "range" && date && selectedRange.end ? sameDay(date, selectedRange.end) : false;
      const rangeMiddle = mode === "range" && date && selectedRange.start && selectedRange.end
        ? date > selectedRange.start && date < selectedRange.end
        : false;
      const selected = mode === "range" ? (rangeStart || rangeEnd)
        : mode === "multiple" ? (date ? selectedDates.has(dateKey(date)) : false)
        : (date ? sameDay(date, selectedDate) : false);
      const isToday = date ? sameDay(date, today) : false;
      ui.configureRef(dayRef, { role: "gridcell", collection: collectionId });
      ui.update(dayRef, {
        text: date ? String(date.getDate()) : "",
        hidden: !date,
        disabled,
        selected,
      });
      setAttrs(ui, dayRef, { "data-today": isToday ? "true" : undefined });
      if (mode === "range") {
        setAttrs(ui, dayRef, {
          "data-range-start": rangeStart ? "true" : undefined,
          "data-range-end": rangeEnd ? "true" : undefined,
          "data-range-middle": rangeMiddle ? "true" : undefined,
        });
      }
    });
    options.onMonthChange?.(month, year);
  };

  // Standard date-range-picker click sequence: an empty or already-complete
  // range starts a fresh one; the second pick becomes the end (or swaps
  // into the start, if it lands before the first pick) rather than ever
  // producing an inverted start-after-end range.
  const selectRange = (date) => {
    if (isDateDisabled(date)) return;
    if (!selectedRange.start || (selectedRange.start && selectedRange.end)) {
      selectedRange = { start: date, end: undefined };
    } else if (date < selectedRange.start) {
      selectedRange = { start: date, end: selectedRange.start };
    } else {
      selectedRange = { start: selectedRange.start, end: date };
    }
    renderMonth();
    options.onRangeChange?.({ ...selectedRange });
  };

  const selectMultiple = (date) => {
    if (isDateDisabled(date)) return;
    const key = dateKey(date);
    if (selectedDates.has(key)) selectedDates.delete(key);
    else selectedDates.set(key, dayOnly(date));
    renderMonth();
    options.onDatesChange?.([...selectedDates.values()]);
  };

  const select = (date) => {
    if (mode === "range") { selectRange(date); return; }
    if (mode === "multiple") { selectMultiple(date); return; }
    if (isDateDisabled(date)) return;
    selectedDate = date;
    renderMonth();
    options.onDateChange?.(date);
  };

  const goToMonth = (nextMonth, nextYear) => {
    month = nextMonth;
    year = nextYear;
    while (month < 0) { month += 12; year -= 1; }
    while (month > 11) { month -= 12; year += 1; }
    renderMonth();
  };

  ui.configureRef(gridRef, { role: "grid", part: "calendar-grid" });
  configureRovingFocusGroup(ui, collectionId, { refs: dayRefs, orientation: "both", loop: true, typeahead: false });
  dayRefs.forEach((dayRef, index) => {
    ui.onAction(dayRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      const date = visibleDates[index];
      if (!date) return;
      select(date);
    });
    // WAI-ARIA date-grid pattern: PageUp/PageDown step by month, keeping the
    // same day-of-month focused; Shift+PageUp/PageDown step by year instead.
    // Arrow/Home/End already come for free from the roving focus group.
    ui.bindRefEvent(dayRef, "keydown", (rawEvent) => {
      const event = rawEvent;
      if (event.key !== "PageUp" && event.key !== "PageDown") return;
      const current = visibleDates[index];
      if (!current) return;
      event.preventDefault();
      const goingBack = event.key === "PageUp";
      let targetYear = year;
      let targetMonth = month;
      if (event.shiftKey) {
        targetYear = year + (goingBack ? -1 : 1);
      } else {
        // Native Date rollover handles the month wraparound (and the year
        // change that comes with it) correctly, unlike a manual mod.
        const rolled = new Date(year, month + (goingBack ? -1 : 1), 1);
        targetYear = rolled.getFullYear();
        targetMonth = rolled.getMonth();
      }
      const target = clampToMonth(targetYear, targetMonth, current.getDate());
      goToMonth(target.getMonth(), target.getFullYear());
      focusDate(target);
    });
  });
  if (prevRef) ui.onAction(prevRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    goToMonth(month - 1, year);
  });
  if (nextRef) ui.onAction(nextRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    goToMonth(month + 1, year);
  });
  renderMonth();
  return {
    select,
    goToMonth,
    getState: () => ({
      month,
      year,
      selectedDate,
      selectedRange: mode === "range" ? { ...selectedRange } : undefined,
      selectedDates: mode === "multiple" ? [...selectedDates.values()] : undefined,
    }),
  };
}

export function createArkDatePicker(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const contentRef = ref(options.contentRef);
  const valueRef = ref(options.valueRef);
  const formatDate = options.formatDate || ((date) => date.toLocaleDateString());
  const formatRange = options.formatRange || ((range) => (range.start && range.end ? `${formatDate(range.start)} - ${formatDate(range.end)}` : ""));
  createArkPopover(ui, {
    triggerRef,
    contentRef,
    portal: options.portal,
    labelRef: options.labelRef,
  });
  const calendar = createArkCalendar(ui, {
    ...options,
    onDateChange: (date) => {
      if (valueRef) {
        const current = ui.get(valueRef) || {};
        ui.update(valueRef, { ...current, text: formatDate(date) });
      }
      options.onDateChange?.(date);
      setOpen(ui, triggerRef, contentRef, false);
    },
    onRangeChange: (range) => {
      if (valueRef) {
        const current = ui.get(valueRef) || {};
        ui.update(valueRef, { ...current, text: formatRange(range) });
      }
      options.onRangeChange?.(range);
      // Only the second pick (a complete start+end pair) closes the popover
      // — closing after the first pick would make it impossible to ever
      // choose an end date.
      if (range.start && range.end) setOpen(ui, triggerRef, contentRef, false);
    },
  });
  // Trigger open/close toggling is already wired by createArkPopover above —
  // registering it again here double-fires on every click (dispatch() runs
  // all handlers for a ref), which opens then immediately re-closes in the
  // same tick. See PRIMITIVE_CONTRACT.md: controlled state must flow through
  // a single path.
  return calendar;
}
