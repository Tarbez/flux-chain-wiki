/**
 * `createArkDialog` and `createArkPopover` — moved out of
 * `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3 and
 * COMPONENT_LAYER_BATCH_PLAN.md Batch A.
 *
 * These build on `@fxn/ui-a11y` for ref normalization, ARIA/attribute
 * wiring, and focus-scope/dismissable-layer/presence composition, matching
 * the plan's dependency direction: `ark-primitives -> ark-a11y`.
 */
import { normalizeRef, setLiveAttr, setAttrs, syncModelRef } from "@fxn/ui-a11y/dom";
import { configureFocusScope, configureDismissableLayer, configurePresence } from "@fxn/ui-a11y/overlay";

function ref(value) {
  return normalizeRef(value);
}

function uniqueRefs(values) {
  return [...new Set(values.map((value) => ref(value)))];
}

function detailsFor(state, nextReason, event, nextTriggerRef, nextPayload) {
  const details = {
    reason: nextReason,
    triggerRef: nextTriggerRef ?? state.activeTriggerRef,
    event,
    payload: nextPayload ?? state.payload,
    isCanceled: false,
    cancel() { details.isCanceled = true; },
  };
  return details;
}

export function createArkPopover(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const triggerRefs = uniqueRefs([triggerRef, ...(options.triggerRefs || [])]);
  const contentRef = ref(options.contentRef);
  const closeRefs = uniqueRefs([...(options.closeRef ? [options.closeRef] : []), ...(options.closeRefs || [])]);
  const labelRef = ref(options.labelRef);
  const descriptionRef = ref(options.descriptionRef);
  const initialFocusRef = options.initialFocus === false ? false : ref(options.initialFocusRef);
  const restoreFocusRef = options.finalFocus === false ? undefined : (ref(options.restoreFocusRef) || triggerRef);
  const viewportRef = ref(options.viewportRef);
  const stateRef = ref(options.stateRef);
  const focusScope = `${contentRef}-scope`;
  const trapFocus = options.modal === true || options.modal === "trap-focus";
  const showBackdrop = options.modal === true;
  const controlled = options.controlled === true || options.open !== undefined;
  const openOnHover = options.openOnHover === true;
  const delay = options.delay ?? 300;
  const closeDelay = options.closeDelay ?? 0;
  const hoverable = options.hoverable !== false;

  const state = {
    open: options.open ?? options.defaultOpen ?? false,
    mounted: options.keepMounted === true || (options.open ?? options.defaultOpen ?? false),
    activeTriggerRef: triggerRef,
    payload: options.triggerPayloads?.[triggerRef],
    reason: "none",
  };
  let openTimer;
  let closeTimer;
  const clearTimers = () => {
    if (openTimer !== undefined) { clearTimeout(openTimer); openTimer = undefined; }
    if (closeTimer !== undefined) { clearTimeout(closeTimer); closeTimer = undefined; }
  };

  triggerRefs.forEach((currentTriggerRef) => {
    ui.configureRef(currentTriggerRef, {
      role: "button",
      controls: contentRef,
      hasPopup: "dialog",
    });
    ui.bindRefEvent(currentTriggerRef, "pointerdown", () => setLiveAttr(ui, currentTriggerRef, "data-pressed", "true"));
    ["pointerup", "pointerleave", "pointercancel"].forEach((eventName) =>
      ui.bindRefEvent(currentTriggerRef, eventName, () => setLiveAttr(ui, currentTriggerRef, "data-pressed", undefined)));
  });
  ui.configureRef(contentRef, {
    role: "dialog",
    modal: trapFocus,
    labelledBy: labelRef,
    describedBy: descriptionRef,
    part: "popover",
    overlay: {
      anchorRef: triggerRef,
      portal: options.portal ?? "layers",
      placement: options.placement ?? "bottom",
      fallbackPlacements: options.placement === "left" || options.placement === "right" ? ["bottom", "top"] : ["top", "right", "left"],
      align: options.align ?? "start",
      offset: options.offset ?? 10,
      collisionPadding: options.collisionPadding ?? 12,
      focusScope,
      modal: showBackdrop,
      backdrop: showBackdrop,
      sameWidth: false,
      sticky: true,
    },
  });
  if (viewportRef) ui.configureRef(viewportRef, { part: "popover-viewport" });
  configureFocusScope(ui, focusScope, { containerRef: contentRef, initialFocusRef, trap: trapFocus, restore: options.finalFocus !== false });
  configureDismissableLayer(ui, contentRef, {
    containerRef: contentRef,
    dismissRef: contentRef,
    branchRefs: triggerRefs,
    restoreFocusRef,
    outsidePointer: options.closeOnOutsidePress !== false,
    outsideFocus: options.closeOnOutsidePress !== false,
    escapeKey: false,
  });
  configurePresence(ui, contentRef, { unmountOnExit: options.keepMounted !== true, ariaHidden: true });

  const syncState = () => {
    triggerRefs.forEach((currentTriggerRef) => {
      const current = ui.get(currentTriggerRef) || {};
      ui.update(currentTriggerRef, { ...current, open: state.open, disabled: options.disabled === true });
      setAttrs(ui, currentTriggerRef, {
        "data-popup-open": state.open ? "true" : undefined,
        "data-active-trigger": currentTriggerRef === state.activeTriggerRef ? "true" : undefined,
      });
    });
    const current = ui.get(contentRef) || {};
    ui.update(contentRef, { ...current, open: state.open, hidden: !state.open });
    setAttrs(ui, contentRef, {
      "data-open": state.open ? "true" : undefined,
      "data-closed": !state.open ? "true" : undefined,
      "data-state": state.open ? "open" : "closed",
    });
    syncModelRef(ui, stateRef, { open: state.open, activeTriggerRef: state.activeTriggerRef, payload: state.payload, reason: state.reason, controlled, mounted: state.mounted });
  };
  const applyOpen = (nextOpen, details, force = false, notify = true) => {
    if (notify) options.onOpenChange?.(nextOpen, details);
    if (details.isCanceled || (controlled && !force)) return;
    state.open = nextOpen;
    state.reason = details.reason;
    state.activeTriggerRef = details.triggerRef;
    state.payload = details.payload;
    state.mounted = options.keepMounted === true || nextOpen;
    syncState();
    if (nextOpen) ui.openOverlay(contentRef);
    else ui.closeOverlay(contentRef);
    options.onOpenChangeComplete?.(nextOpen, details);
  };
  const requestOpen = (nextOpen, nextReason, event, nextTriggerRef = state.activeTriggerRef, nextPayload = state.payload, force = false, notify = true) => {
    const details = detailsFor(state, nextReason, event, nextTriggerRef, nextPayload);
    applyOpen(nextOpen, details, force, notify);
  };
  const scheduleOpen = (nextTriggerRef) => {
    if (options.disabled) return;
    clearTimers();
    const nextPayload = options.triggerPayloads?.[nextTriggerRef];
    if (state.open || delay <= 0) { requestOpen(true, "trigger-hover", undefined, nextTriggerRef, nextPayload); return; }
    openTimer = setTimeout(() => requestOpen(true, "trigger-hover", undefined, nextTriggerRef, nextPayload), delay);
  };
  const scheduleClose = () => {
    clearTimers();
    if (closeDelay <= 0) { requestOpen(false, "trigger-hover", undefined, state.activeTriggerRef, state.payload); return; }
    closeTimer = setTimeout(() => requestOpen(false, "trigger-hover", undefined, state.activeTriggerRef, state.payload), closeDelay);
  };

  triggerRefs.forEach((currentTriggerRef) => {
    ui.onAction(currentTriggerRef, (_ref, detail) => {
      if (detail.action !== "CLICK" || options.disabled) return;
      requestOpen(!state.open, "trigger-press", undefined, currentTriggerRef, options.triggerPayloads?.[currentTriggerRef]);
    });
    if (openOnHover) {
      ui.bindRefEvent(currentTriggerRef, "mouseenter", () => scheduleOpen(currentTriggerRef));
      ui.bindRefEvent(currentTriggerRef, "mouseleave", () => scheduleClose());
    }
  });
  if (openOnHover && hoverable) {
    ui.bindRefEvent(contentRef, "mouseenter", () => clearTimers());
    ui.bindRefEvent(contentRef, "mouseleave", () => scheduleClose());
  }
  closeRefs.forEach((closeRef) => {
    ui.configureRef(closeRef, { part: "popover-close" });
    ui.onAction(closeRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      requestOpen(false, "close-press");
    });
  });
  ui.onAction(contentRef, (_ref, detail) => {
    if (detail.action !== "DISMISS" || options.closeOnOutsidePress === false) return;
    const details = detailsFor(state, "outside-press");
    if (options.onOutsidePress?.(details) === false || details.isCanceled) return;
    applyOpen(false, details);
  });
  ui.bindRefEvent(contentRef, "keydown", (rawEvent) => {
    if (rawEvent.key !== "Escape" || options.escapeKey === false) return;
    const details = detailsFor(state, "escape-key", rawEvent);
    if (options.onEscapeKeyDown?.(rawEvent, details) === false || details.isCanceled) return;
    rawEvent.preventDefault();
    applyOpen(false, details);
  });
  syncState();
  if (state.open) ui.openOverlay(contentRef);
  return {
    open: (nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(true, "imperative-action", undefined, ref(nextTriggerRef), nextPayload, true),
    close: () => requestOpen(false, "imperative-action", undefined, state.activeTriggerRef, state.payload, true),
    toggle: (nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(!state.open, "imperative-action", undefined, ref(nextTriggerRef), nextPayload, true),
    setOpen: (nextOpen, nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(nextOpen, "imperative-action", undefined, ref(nextTriggerRef), nextPayload, true),
    syncControlled: (nextOpen, nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(nextOpen, "controlled-sync", undefined, ref(nextTriggerRef), nextPayload, true, false),
    getState: () => ({ open: state.open, activeTriggerRef: state.activeTriggerRef, payload: state.payload, reason: state.reason, controlled, mounted: state.mounted }),
  };
}

export function createArkDialog(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const triggerRefs = uniqueRefs([triggerRef, ...(options.triggerRefs || [])]);
  const contentRef = ref(options.contentRef);
  const closeRefs = uniqueRefs([...(options.closeRef ? [options.closeRef] : []), ...(options.closeRefs || [])]);
  const labelRef = ref(options.labelRef);
  const descriptionRef = ref(options.descriptionRef);
  const initialFocusRef = options.initialFocus === false ? false : ref(options.initialFocusRef);
  const restoreFocusRef = options.finalFocus === false ? undefined : (ref(options.restoreFocusRef) || triggerRef);
  const viewportRef = ref(options.viewportRef);
  const stateRef = ref(options.stateRef);
  const focusScope = `${contentRef}-scope`;
  const modal = options.modal !== false;
  const controlled = options.controlled === true || options.open !== undefined;

  const state = {
    open: options.open ?? options.defaultOpen ?? false,
    mounted: options.keepMounted === true || (options.open ?? options.defaultOpen ?? false),
    activeTriggerRef: triggerRef,
    payload: options.triggerPayloads?.[triggerRef],
    reason: "none",
  };

  triggerRefs.forEach((currentTriggerRef) => {
    ui.configureRef(currentTriggerRef, {
      role: "button",
      controls: contentRef,
      hasPopup: "dialog",
    });
    ui.bindRefEvent(currentTriggerRef, "pointerdown", () => setLiveAttr(ui, currentTriggerRef, "data-pressed", "true"));
    ["pointerup", "pointerleave", "pointercancel"].forEach((eventName) =>
      ui.bindRefEvent(currentTriggerRef, eventName, () => setLiveAttr(ui, currentTriggerRef, "data-pressed", undefined)));
  });
  ui.configureRef(contentRef, {
    role: "dialog",
    modal,
    labelledBy: labelRef,
    describedBy: descriptionRef,
    part: "dialog",
    overlay: {
      anchorRef: triggerRef,
      portal: options.portal ?? "layers",
      placement: "bottom",
      fallbackPlacements: ["top"],
      align: "center",
      offset: 12,
      collisionPadding: 16,
      focusScope,
      modal,
      backdrop: modal,
      sticky: true,
    },
  });
  if (viewportRef) ui.configureRef(viewportRef, { part: "dialog-viewport" });
  configureFocusScope(ui, focusScope, { containerRef: contentRef, initialFocusRef, trap: modal, restore: options.finalFocus !== false });
  configureDismissableLayer(ui, contentRef, {
    containerRef: contentRef,
    dismissRef: contentRef,
    branchRefs: triggerRefs,
    restoreFocusRef,
    outsidePointer: options.closeOnOutsidePress !== false,
    outsideFocus: false,
    escapeKey: false,
  });
  configurePresence(ui, contentRef, { unmountOnExit: options.keepMounted !== true, ariaHidden: true });

  const syncState = () => {
    triggerRefs.forEach((currentTriggerRef) => {
      const current = ui.get(currentTriggerRef) || {};
      ui.update(currentTriggerRef, { ...current, open: state.open, disabled: options.disabled === true });
      setAttrs(ui, currentTriggerRef, {
        "data-popup-open": state.open ? "true" : undefined,
        "data-active-trigger": currentTriggerRef === state.activeTriggerRef ? "true" : undefined,
      });
    });
    const current = ui.get(contentRef) || {};
    ui.update(contentRef, { ...current, open: state.open, hidden: !state.open });
    setAttrs(ui, contentRef, {
      "data-open": state.open ? "true" : undefined,
      "data-closed": !state.open ? "true" : undefined,
      "data-state": state.open ? "open" : "closed",
    });
    syncModelRef(ui, stateRef, { open: state.open, activeTriggerRef: state.activeTriggerRef, payload: state.payload, reason: state.reason, controlled, mounted: state.mounted });
  };
  const applyOpen = (nextOpen, details, force = false, notify = true) => {
    if (notify) options.onOpenChange?.(nextOpen, details);
    if (details.isCanceled || (controlled && !force)) return;
    state.open = nextOpen;
    state.reason = details.reason;
    state.activeTriggerRef = details.triggerRef;
    state.payload = details.payload;
    state.mounted = options.keepMounted === true || nextOpen;
    syncState();
    if (nextOpen) ui.openOverlay(contentRef);
    else ui.closeOverlay(contentRef);
    options.onOpenChangeComplete?.(nextOpen, details);
  };
  const requestOpen = (nextOpen, nextReason, event, nextTriggerRef = state.activeTriggerRef, nextPayload = state.payload, force = false, notify = true) => {
    const details = detailsFor(state, nextReason, event, nextTriggerRef, nextPayload);
    applyOpen(nextOpen, details, force, notify);
  };

  triggerRefs.forEach((currentTriggerRef) => ui.onAction(currentTriggerRef, (_ref, detail) => {
    if (detail.action !== "CLICK" || options.disabled) return;
    requestOpen(true, "trigger-press", undefined, currentTriggerRef, options.triggerPayloads?.[currentTriggerRef]);
  }));
  closeRefs.forEach((closeRef) => {
    ui.configureRef(closeRef, { part: "dialog-close" });
    ui.onAction(closeRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      requestOpen(false, "close-press");
    });
  });
  ui.onAction(contentRef, (_ref, detail) => {
    if (detail.action !== "DISMISS" || options.closeOnOutsidePress === false) return;
    const details = detailsFor(state, "outside-press");
    if (options.onOutsidePress?.(details) === false || details.isCanceled) return;
    applyOpen(false, details);
  });
  ui.bindRefEvent(contentRef, "keydown", (rawEvent) => {
    if (rawEvent.key !== "Escape" || options.escapeKey === false) return;
    const details = detailsFor(state, "escape-key", rawEvent);
    if (options.onEscapeKeyDown?.(rawEvent, details) === false || details.isCanceled) return;
    rawEvent.preventDefault();
    applyOpen(false, details);
  });
  syncState();
  if (state.open) ui.openOverlay(contentRef);
  return {
    open: (nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(true, "imperative-action", undefined, ref(nextTriggerRef), nextPayload, true),
    close: () => requestOpen(false, "imperative-action", undefined, state.activeTriggerRef, state.payload, true),
    toggle: (nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(!state.open, "imperative-action", undefined, ref(nextTriggerRef), nextPayload, true),
    setOpen: (nextOpen, nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(nextOpen, "imperative-action", undefined, ref(nextTriggerRef), nextPayload, true),
    syncControlled: (nextOpen, nextTriggerRef = triggerRef, nextPayload = options.triggerPayloads?.[nextTriggerRef]) => requestOpen(nextOpen, "controlled-sync", undefined, ref(nextTriggerRef), nextPayload, true, false),
    getState: () => ({ open: state.open, activeTriggerRef: state.activeTriggerRef, payload: state.payload, reason: state.reason, controlled, mounted: state.mounted }),
  };
}
