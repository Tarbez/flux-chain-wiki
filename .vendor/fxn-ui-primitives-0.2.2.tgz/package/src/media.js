/**
 * `createArkAspectRatio`, `createArkAttachment`, `createArkAvatar` — moved
 * out of `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * Grouped together as "media" primitives (image/file-shaped state, not
 * overlay or collection behavior) rather than under `@fxn/ui-a11y` --
 * none of the three need focus-scope, dismissable-layer, presence, or
 * roving-tabindex composition, just plain ref/attr/style wiring already
 * covered by `@fxn/ui-a11y/dom`.
 *
 * `createArkAspectRatio`'s one substitution: the original used
 * `withVariants("& > *", {...})` from `ark-ui.runtime.ts` to nest a
 * child-combinator style block. That helper lives in the runtime layer,
 * which `ark-primitives` must not depend on (the plan's dependency
 * direction is `ark-primitives -> ark-a11y`, never back up to `ark-ui`).
 * For this single static chain (no breakpoint/media/container segments,
 * no aliasing), `withVariants("& > *", styles)` reduces to exactly
 * `{ "& > *": styles }` -- verified against `parseVariantChain`'s handling
 * of a plain unprefixed segment -- so the object literal below is not an
 * approximation, it's the same output inlined.
 */
import { normalizeRef, setAttrs, setHidden, syncModelRef } from "@fxn/ui-a11y/dom";

function ref(value) {
  return normalizeRef(value);
}

export function createArkAspectRatio(ui, options) {
  const containerRef = ref(options.containerRef);
  const stateRef = ref(options.stateRef);
  let ratio = options.ratio && Number.isFinite(options.ratio) && options.ratio > 0 ? options.ratio : 16 / 9;
  ui.configureRef(containerRef, { part: "aspect-ratio" });
  const applyRatio = (nextRatio, notify = true) => {
    if (!Number.isFinite(nextRatio) || nextRatio <= 0) return;
    ratio = nextRatio;
    ui.style(containerRef, {
      position: "relative",
      width: "100%",
      aspectRatio: String(ratio),
      overflow: "hidden",
      borderRadius: "inherit",
      "& > *": {
        width: "100%",
        height: "100%",
        objectFit: "cover",
      },
    }, { mode: "merge" });
    setAttrs(ui, containerRef, { "data-ratio": String(ratio) });
    syncModelRef(ui, stateRef, { ratio });
    if (notify) options.onRatioChange?.(ratio);
  };
  applyRatio(ratio, false);
  return {
    setRatio: (nextRatio) => applyRatio(nextRatio),
    getState: () => ({ ratio }),
  };
}

export function createArkAttachment(ui, options) {
  const inputRef = ref(options.inputRef);
  const listRef = ref(options.listRef);
  const emptyRef = ref(options.emptyRef);
  const stateRef = ref(options.stateRef);
  const dropzoneRef = ref(options.dropzoneRef);
  let currentFiles = [];

  // Keeps the native input's own `.files` (and anything reading it directly,
  // outside this handle) truthful after a drop or a removeFile() call, since
  // neither of those goes through the input's own "choose file" picker.
  const syncInputFiles = () => {
    const inputEl = ui.getElement(inputRef);
    if (!inputEl || typeof DataTransfer === "undefined") return;
    const transfer = new DataTransfer();
    currentFiles.forEach((file) => transfer.items.add(file));
    inputEl.files = transfer.files;
  };

  const sync = () => {
    const serializable = currentFiles.map((file) => ({ name: file.name, size: file.size, type: file.type }));
    syncModelRef(ui, stateRef, { files: serializable });
    if (listRef) {
      const current = ui.get(listRef) || {};
      ui.update(listRef, { ...current, text: currentFiles.map((file) => file.name).join(", ") || "" });
    }
    setHidden(ui, emptyRef, currentFiles.length > 0);
    options.onFilesChange?.(currentFiles);
  };

  // A native `<input type=file>` selection always *replaces* the prior
  // selection (that's how file pickers work); a drop onto a dropzone reads
  // more like adding attachments, so it appends when `multiple` is on.
  const applyFiles = (incoming, mode) => {
    if (incoming.length === 0) return;
    if (!options.multiple) currentFiles = [incoming[incoming.length - 1]];
    else if (mode === "append") currentFiles = [...currentFiles, ...incoming];
    else currentFiles = [...incoming];
    sync();
  };

  ui.configureRef(inputRef, {
    attrs: {
      type: "file",
      multiple: options.multiple ? "multiple" : undefined,
    },
  });
  if (listRef) ui.configureRef(listRef, { part: "attachment-list" });
  ui.bindRefEvent(inputRef, "change", (_event, el) => {
    applyFiles(Array.from(el.files || []), "replace");
  });

  if (dropzoneRef) {
    ui.configureRef(dropzoneRef, { part: "attachment-dropzone" });
    const setDragging = (dragging) => setAttrs(ui, dropzoneRef, { "data-dragging": dragging ? "true" : undefined });
    ui.bindRefEvent(dropzoneRef, "dragover", (event) => { event.preventDefault(); setDragging(true); });
    ui.bindRefEvent(dropzoneRef, "dragenter", (event) => { event.preventDefault(); setDragging(true); });
    ui.bindRefEvent(dropzoneRef, "dragleave", () => setDragging(false));
    ui.bindRefEvent(dropzoneRef, "drop", (event) => {
      event.preventDefault();
      setDragging(false);
      const dropped = Array.from(event.dataTransfer?.files || []);
      applyFiles(dropped, "append");
      syncInputFiles();
    });
  }

  setHidden(ui, emptyRef, false);
  syncModelRef(ui, stateRef, { files: [] });
  return {
    clear: () => {
      const inputEl = ui.getElement(inputRef);
      if (inputEl) inputEl.value = "";
      currentFiles = [];
      sync();
    },
    removeFile: (index) => {
      if (index < 0 || index >= currentFiles.length) return;
      currentFiles = currentFiles.filter((_, fileIndex) => fileIndex !== index);
      syncInputFiles();
      sync();
    },
    getState: () => ({
      files: (ui.get(stateRef || "")?.files) || [],
    }),
  };
}

export function createArkAvatar(ui, options) {
  const rootRef = ref(options.rootRef);
  const imageRef = ref(options.imageRef);
  const fallbackRef = ref(options.fallbackRef);
  const statusRef = ref(options.statusRef);
  const fallbackDelay = options.fallbackDelay ?? 0;
  let status = "idle";
  let fallbackTimer;

  const showFallback = (visible) => {
    if (fallbackRef) setHidden(ui, fallbackRef, !visible);
    if (imageRef) setHidden(ui, imageRef, visible);
  };

  const applyStatus = (next) => {
    status = next;
    // Distinct from the presence dot's `data-status` on `statusRef` below —
    // this is the image's own idle/loading/loaded/error lifecycle.
    setAttrs(ui, rootRef, { "data-loading-status": status });
    options.onLoadingStatusChange?.(status);
  };

  const setSrc = (src) => {
    if (fallbackTimer) clearTimeout(fallbackTimer);
    if (!imageRef || !src) {
      applyStatus("idle");
      showFallback(true);
      return;
    }
    applyStatus("loading");
    if (fallbackDelay > 0) {
      // Radix/Base UI Avatar: hold the fallback back for `fallbackDelay`ms
      // rather than showing it the instant loading starts, so a normal-speed
      // image never flashes initials right before the picture replaces them.
      showFallback(false);
      fallbackTimer = setTimeout(() => { if (status === "loading") showFallback(true); }, fallbackDelay);
    } else {
      showFallback(true);
    }
    ui.configureRef(imageRef, { attrs: { src, alt: options.alt ?? "" } });
  };

  ui.configureRef(rootRef, { part: "avatar" });
  setAttrs(ui, rootRef, { "data-size": options.size ?? "default" });
  if (fallbackRef) ui.configureRef(fallbackRef, { part: "avatar-fallback" });
  if (statusRef) ui.configureRef(statusRef, { part: "avatar-status" });
  if (options.status && statusRef) setAttrs(ui, statusRef, { "data-status": options.status });

  if (imageRef) {
    ui.configureRef(imageRef, { part: "avatar-image" });
    ui.bindRefEvent(imageRef, "load", () => {
      if (fallbackTimer) clearTimeout(fallbackTimer);
      applyStatus("loaded");
      showFallback(false);
    });
    ui.bindRefEvent(imageRef, "error", () => {
      if (fallbackTimer) clearTimeout(fallbackTimer);
      applyStatus("error");
      showFallback(true);
    });
  }

  setSrc(options.src);

  return {
    setSrc,
    getState: () => ({ status }),
  };
}
