/**
 * `createArkTabs` and `createArkNavigationMenu` — moved out of
 * `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * The two live in one module because `createArkNavigationMenu` is literally a
 * `createArkTabs` call with a `role="navigation"` list wrapper and a narrower
 * handle — the note left in `layout.js` ("NavigationMenu stays put until the
 * Tabs family moves, then becomes trivial to move alongside it") is discharged
 * here. It calls the extracted `createArkTabs` directly rather than carrying
 * its own copy of the tab-selection logic.
 *
 * `@fxn/ui-a11y` supplies ref normalization, attribute/state wiring, and
 * the roving-focus recipe: a tab list is exactly `configureStripFocusGroup`'s
 * single-axis, no-typeahead case (its header comment names "tab lists" as the
 * intended consumer), which reduces to the same
 * `createRovingFocusGroup(id, { refs, orientation, loop, typeahead: false })`
 * call the original made inline.
 *
 * The four `data-ark-foundation` tree-reading helpers
 * (`readElementRef`/`readFoundation`/`walkElementTree`/`findFirstFoundation`)
 * come from `@fxn/ui-a11y/structure`, their one home; this file kept
 * private copies until 2026-11-08.
 */
import { normalizeRef, normalizeRefs, setAttrs, setLiveAttr, syncModelRef } from "@fxn/ui-a11y/dom";
import { configureStripFocusGroup } from "@fxn/ui-a11y/collection";
import { readElementRef, readFoundation, walkElementTree, findFirstFoundation } from "@fxn/ui-a11y/structure";

function ref(value) {
  return normalizeRef(value);
}

/**
 * Reads a tabs structure straight off the mounted markup's
 * `data-ark-foundation` parts, so a consumer can pass only `rootRef` and let
 * TABSLIST/TABSTRIGGER/TABSCONTENT/TABSINDICATOR describe the rest.
 */
function inferTabsStructure(ui, rootRef) {
  const rootEl = ui.getElement(rootRef);
  if (!rootEl) return { tabRefs: [], panelRefs: [] };
  const descendants = walkElementTree(rootEl);
  const listRef = readElementRef(findFirstFoundation(rootEl, "TABSLIST")) || readElementRef(findFirstFoundation(rootEl, "TABS"));
  const indicatorRef = readElementRef(findFirstFoundation(rootEl, "TABSINDICATOR"));
  const tabRefs = descendants
    .filter((node) => readFoundation(node) === "TABSTRIGGER")
    .map((node) => readElementRef(node))
    .filter((value) => !!value);
  const panelRefs = descendants
    .filter((node) => readFoundation(node) === "TABSCONTENT")
    .map((node) => readElementRef(node))
    .filter((value) => !!value);
  return { listRef, tabRefs, panelRefs, indicatorRef };
}

/**
 * Resolves the selected index a controlled `stateRef` value is asking for.
 * `undefined` means "the state object says nothing about selection, leave it
 * alone"; `null` means "explicitly nothing selected".
 */
function tabsIndexFromStateValue(state, values, tabRefs) {
  if (!state || typeof state !== "object") return undefined;
  const source = state;
  if (source.selectedIndex === null || source.value === null || source.selectedValue === null || source.selectedRef === null) return null;
  if (source.selectedIndex === -1) return null;
  if (typeof source.selectedIndex === "number" && Number.isInteger(source.selectedIndex)) return source.selectedIndex;
  if (typeof source.selectedValue === "string") return values.indexOf(source.selectedValue);
  if (typeof source.value === "string") return values.indexOf(source.value);
  if (typeof source.selectedRef === "string") return tabRefs.indexOf(source.selectedRef);
  return undefined;
}

export function createArkTabs(ui, options) {
  const rootRef = ref(options.rootRef);
  const inferred = rootRef && (options.inferStructure !== false || !options.tabRefs || !options.panelRefs || !options.listRef)
    ? inferTabsStructure(ui, rootRef)
    : { tabRefs: [], panelRefs: [] };
  const tabRefs = normalizeRefs(options.tabRefs ?? inferred.tabRefs);
  const panelRefs = normalizeRefs(options.panelRefs ?? inferred.panelRefs);
  const listRef = ref(options.listRef || inferred.listRef || rootRef || tabRefs[0]);
  const indicatorRef = ref(options.indicatorRef || inferred.indicatorRef);
  const orientation = options.orientation ?? "horizontal";
  const stateRef = ref(options.stateRef);
  const activationMode = options.activationMode ?? "manual";
  const loopFocus = options.loopFocus ?? true;
  const controlled = !!options.controlled;
  const tabsDisabled = !!options.disabled;
  const values = tabRefs.map((tabRef, index) => options.values?.[index] ?? tabRef);
  const indexByValue = new Map(values.map((value, index) => [value, index]));
  const disabledRefs = new Set((options.disabledTabRefs || []).map((value) => ref(value)));
  (options.disabledValues || []).forEach((value) => {
    const index = indexByValue.get(value);
    if (index !== undefined) disabledRefs.add(tabRefs[index]);
  });
  const collectionId = `${listRef}-collection`;
  const firstEnabledIndex = () => {
    const index = tabRefs.findIndex((tabRef) => !tabsDisabled && !disabledRefs.has(tabRef));
    return index >= 0 ? index : null;
  };
  const normalizeIndex = (nextIndex, allowEmpty = false) => {
    if (nextIndex === null) return allowEmpty ? null : firstEnabledIndex();
    if (nextIndex === undefined) return firstEnabledIndex();
    if (nextIndex < 0 || nextIndex >= tabRefs.length) return allowEmpty ? null : firstEnabledIndex();
    if (tabsDisabled || disabledRefs.has(tabRefs[nextIndex])) return allowEmpty ? null : firstEnabledIndex();
    return nextIndex;
  };
  const stateDrivenIndex = controlled ? tabsIndexFromStateValue(ui.get(stateRef || ""), values, tabRefs) : undefined;
  const explicitValue = options.value ?? options.selectedValue;
  const defaultValue = options.defaultValue;
  const valueIndex = explicitValue === null ? null : (explicitValue ? (indexByValue.get(explicitValue) ?? null) : undefined);
  const defaultValueIndex = defaultValue === null ? null : (defaultValue ? (indexByValue.get(defaultValue) ?? null) : undefined);
  const selectedRefIndex = options.selectedRef ? tabRefs.indexOf(ref(options.selectedRef)) : -1;
  let selectedIndex = normalizeIndex(
    stateDrivenIndex !== undefined
      ? stateDrivenIndex
      : valueIndex !== undefined
        ? valueIndex
        : defaultValueIndex !== undefined
          ? defaultValueIndex
          : selectedRefIndex >= 0
            ? selectedRefIndex
            : options.selectedIndex,
    valueIndex === null || defaultValueIndex === null || stateDrivenIndex === null,
  );
  let syncingStateRef = false;
  let activationDirection = "none";

  const syncState = (previousIndex) => {
    const selectedRef = selectedIndex === null ? undefined : tabRefs[selectedIndex];
    const selectedPanelRef = selectedIndex === null ? undefined : panelRefs[selectedIndex];
    const selectedValue = selectedIndex === null ? undefined : values[selectedIndex];
    const previousRef = previousIndex === null ? undefined : tabRefs[previousIndex];
    const previousPanelRef = previousIndex === null ? undefined : panelRefs[previousIndex];
    const previousValue = previousIndex === null ? undefined : values[previousIndex];
    const details = {
      value: selectedValue,
      previousValue,
      selectedIndex: selectedIndex ?? -1,
      previousIndex: previousIndex ?? -1,
      selectedRef,
      previousRef,
      selectedPanelRef,
      previousPanelRef,
      orientation,
      activationMode,
      activationDirection,
    };
    const rootTargetRef = rootRef || listRef;
    setAttrs(ui, rootTargetRef, {
      "data-tabs-root": "true",
      "data-orientation": orientation,
      "data-activation-direction": activationDirection,
      "data-disabled": tabsDisabled ? "true" : undefined,
    });
    if (rootTargetRef !== listRef) {
      setAttrs(ui, listRef, {
        "data-tabs-root": "true",
        "data-orientation": orientation,
        "data-activation-direction": activationDirection,
        "data-disabled": tabsDisabled ? "true" : undefined,
      });
    }
    tabRefs.forEach((tabRef, index) => {
      const selected = selectedIndex !== null && index === selectedIndex;
      const disabled = tabsDisabled || disabledRefs.has(tabRef);
      const current = ui.get(tabRef) || {};
      ui.update(tabRef, { ...current, selected, disabled });
      setAttrs(ui, tabRef, {
        "aria-selected": selected ? "true" : "false",
        "data-state": selected ? "active" : "inactive",
        "data-value": values[index],
        "data-index": String(index),
        "data-orientation": orientation,
        "data-disabled": disabled ? "true" : undefined,
      });
    });
    // The tab stop belongs to the SELECTED tab (WAI-ARIA APG tabs pattern):
    // Tab into the list lands on the open tab, not the first one. The runtime's
    // roving group re-syncs tabindex on every member render and falls back to
    // index 0 when nothing in the group has focus, so this pass runs after the
    // renders above and writes the live attribute directly (no re-render).
    // While focus is inside the list the roving group owns the tab stop.
    if (selectedRef) {
      const active = globalThis.document?.activeElement;
      const focusInside = !!active && tabRefs.some((tabRef) => ui.getElement(tabRef) === active);
      if (!focusInside) tabRefs.forEach((tabRef) => setLiveAttr(ui, tabRef, "tabindex", tabRef === selectedRef ? "0" : "-1"));
    }
    panelRefs.forEach((panelRef, index) => {
      const selected = selectedIndex !== null && index === selectedIndex;
      const current = ui.get(panelRef) || {};
      ui.update(panelRef, { ...current, hidden: !selected });
      setAttrs(ui, panelRef, {
        "data-state": selected ? "active" : "inactive",
        "data-value": values[index],
        "data-index": String(index),
        "data-orientation": orientation,
        hidden: !selected ? "true" : undefined,
      });
    });
    if (indicatorRef) {
      const indicatorState = ui.get(indicatorRef) || {};
      ui.update(indicatorRef, { ...indicatorState, hidden: selectedIndex === null });
      setAttrs(ui, indicatorRef, {
        "data-state": selectedIndex === null ? "inactive" : "active",
        "data-value": selectedValue,
        "data-index": selectedIndex === null ? undefined : String(selectedIndex),
        "data-orientation": orientation,
      });
      if (selectedIndex !== null) {
        const listRect = ui.getElement(listRef)?.getBoundingClientRect?.();
        const tabRect = ui.getElement(tabRefs[selectedIndex])?.getBoundingClientRect?.();
        if (listRect && tabRect) {
          if (orientation === "horizontal") {
            ui.style(indicatorRef, {
              width: `${tabRect.width}px`,
              transform: `translateX(${tabRect.left - listRect.left}px)`,
            }, { mode: "merge" });
          } else {
            ui.style(indicatorRef, {
              height: `${tabRect.height}px`,
              transform: `translateY(${tabRect.top - listRect.top}px)`,
            }, { mode: "merge" });
          }
        }
      }
    }
    syncingStateRef = true;
    syncModelRef(ui, stateRef, {
      value: selectedValue ?? null,
      selectedValue,
      selectedRef,
      selectedPanelRef,
      selectedIndex: selectedIndex ?? -1,
      previousValue,
      previousRef,
      previousPanelRef,
      previousIndex: previousIndex ?? -1,
      tabRefs: [...tabRefs],
      panelRefs: [...panelRefs],
      values: [...values],
      disabled: tabsDisabled,
      disabledTabRefs: [...disabledRefs],
      orientation,
      activationMode,
      activationDirection,
      loopFocus,
      controlled,
      indicatorRef,
    });
    syncingStateRef = false;
    if (selectedRef && selectedIndex !== null) options.onSelectedChange?.(selectedRef, selectedIndex);
    options.onValueChange?.(selectedValue, details);
  };

  const applySelection = (nextIndex, source = "local") => {
    const previousIndex = selectedIndex;
    const normalized = normalizeIndex(nextIndex, nextIndex === null);
    if (normalized === selectedIndex) return;
    if (normalized === null || previousIndex === null) activationDirection = "none";
    else activationDirection = normalized > previousIndex ? "end" : normalized < previousIndex ? "start" : "none";
    selectedIndex = normalized;
    syncState(previousIndex);
    if (source === "external") return;
  };

  if (tabRefs.length === 0 || panelRefs.length === 0) {
    throw new Error("createArkTabs requires tab/panel refs or a rootRef with inferable TABS parts.");
  }
  ui.configureRef(listRef, { role: "tablist", orientation });
  if (indicatorRef) ui.configureRef(indicatorRef, { part: "tabs-indicator" });
  tabRefs.forEach((tabRef, index) => {
    const panelRef = panelRefs[index];
    ui.configureRef(tabRef, {
      role: "tab",
      controls: panelRef,
      collection: collectionId,
    });
    if (disabledRefs.has(tabRef) || tabsDisabled) ui.update(tabRef, { disabled: true });
    if (panelRef) {
      ui.configureRef(panelRef, {
        role: "tabpanel",
        labelledBy: tabRef,
      });
    }
  });
  configureStripFocusGroup(ui, collectionId, tabRefs, { orientation, loop: loopFocus, typeahead: false });
  tabRefs.forEach((tabRef, index) => {
    ui.onAction(tabRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      if (tabsDisabled || disabledRefs.has(tabRef)) return;
      applySelection(index);
    });
    if (activationMode === "automatic") ui.bindRefEvent(tabRef, "focus", () => {
      if (tabsDisabled || disabledRefs.has(tabRef)) return;
      applySelection(index);
    });
  });
  if (controlled && stateRef && typeof ui.observe === "function") {
    ui.observe(stateRef, (value) => {
      if (syncingStateRef) return;
      const nextIndex = tabsIndexFromStateValue(value, values, tabRefs);
      if (nextIndex === undefined) return;
      applySelection(nextIndex, "external");
    });
  }
  syncState(selectedIndex);
  return {
    select: (refOrIndex) => applySelection(typeof refOrIndex === "number" ? refOrIndex : tabRefs.indexOf(ref(refOrIndex))),
    setValue: (value) => applySelection(value == null ? null : (indexByValue.get(value) ?? null)),
    getState: () => ({
      selectedRef: selectedIndex === null ? undefined : tabRefs[selectedIndex],
      selectedPanelRef: selectedIndex === null ? undefined : panelRefs[selectedIndex],
      selectedIndex: selectedIndex ?? -1,
      selectedValue: selectedIndex === null ? undefined : values[selectedIndex],
      orientation,
      activationMode,
      activationDirection,
      disabled: tabsDisabled,
    }),
  };
}

export function createArkNavigationMenu(ui, options) {
  const listRef = ref(options.listRef);
  ui.configureRef(listRef, { part: "navigation-menu", role: "navigation" });
  const handle = createArkTabs(ui, {
    listRef,
    tabRefs: options.triggerRefs,
    panelRefs: options.contentRefs,
    selectedRef: options.activeRef,
    orientation: options.orientation ?? "horizontal",
    stateRef: options.stateRef,
    onSelectedChange: (selectedRef, index) => options.onValueChange?.(selectedRef, index),
  });
  return {
    select: handle.select,
    getState: () => {
      const state = handle.getState();
      return {
        selectedRef: state.selectedRef || "",
        selectedIndex: state.selectedIndex,
      };
    },
  };
}
