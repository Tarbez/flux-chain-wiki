import type { ArkA11yHost } from "@fxn/ui-a11y/dom";
import type { ArkA11yOverlayHost } from "@fxn/ui-a11y/overlay";
import type { ArkA11yLiveRegionHost } from "@fxn/ui-a11y/live-region";
import type { ArkA11yCollectionHost } from "@fxn/ui-a11y/collection";

/** Mirrors the runtime's recursive `StyleObject`. */
export type ArkPrimitiveStyleObject = { [prop: string]: string | ArkPrimitiveStyleObject };

/** Mirrors the runtime's `ActionDetail` as seen by an `onAction` handler. */
export interface ArkPrimitiveActionDetail {
  action: string;
  value?: unknown;
  event?: Event;
}

/**
 * The full runtime surface the primitive factories in this package compose
 * against, on top of what `@fxn/ui-a11y` already declares. Structural,
 * not imported from `@fxn/ui` — the real `ArkUIInstance` returned by
 * `createArkUI()` satisfies this shape today without any adapter code, and
 * declaring it here is what keeps the dependency arrow pointing
 * `ark-primitives -> ark-a11y` rather than back at `ark-ui`.
 */
export interface ArkPrimitiveRuntime
  extends ArkA11yHost, ArkA11yOverlayHost, ArkA11yLiveRegionHost, ArkA11yCollectionHost {
  bindRefEvent(ref: string, eventName: string, handler: (event: Event, el: HTMLElement) => void): void;
  onAction(ref: string, handler: (ref: string, detail: ArkPrimitiveActionDetail) => void): void;
  observe(ref: string, handler: (value: unknown) => void): () => void;
  style(ref: string, styles: ArkPrimitiveStyleObject | null, options?: { mode?: "replace" | "merge" | "clear" }): void;
}
