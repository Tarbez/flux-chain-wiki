/**
 * The select family — `createArkNativeSelect()` and `createArkSelect()` —
 * moved out of `ark-ui.components.ts` verbatim (same logic, same call order,
 * same observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * Two different tradeoffs, not two implementations of the same thing:
 *
 *  - `createArkNativeSelect()` wraps a real `<select>` for forms that want
 *    native mobile pickers, zero JS bundle for the dropdown itself, and
 *    SSR/no-JS resilience. Options are populated imperatively onto the live
 *    element once at setup (this runtime's declarative pattern grammar has
 *    no way to spread a JS array into markup), and every value change after
 *    that writes `.value` directly rather than through `ui.update()`, which
 *    would replace the element and wipe the `<option>`s it just got.
 *  - `createArkSelect()` is a fully custom listbox — the overlay/roving-focus/
 *    dismissable-layer machinery every other popup primitive here uses.
 *
 * Built on `@fxn/ui-a11y` for ref normalization, attribute wiring, and
 * overlay open/close sequencing — the plan's dependency direction:
 * `ark-primitives -> ark-a11y`.
 */
import { configureMenuFocusGroup } from "@fxn/ui-a11y/collection";
import { normalizeRef, syncModelRef, textOf } from "@fxn/ui-a11y/dom";
import { setOverlayOpen } from "@fxn/ui-a11y/overlay";

function ref(value) {
  return normalizeRef(value);
}

export function createArkNativeSelect(ui, options) {
  const selectRef = ref(options.selectRef);
  let value = options.value ?? "";

  ui.configureRef(selectRef, {
    part: "native-select",
    attrs: { disabled: options.disabled ? "true" : undefined },
  });

  const populate = () => {
    const el = ui.getElement(selectRef);
    if (!el || typeof document === "undefined") return;
    el.innerHTML = "";
    if (options.placeholder) {
      const placeholderOption = document.createElement("option");
      placeholderOption.value = "";
      placeholderOption.textContent = options.placeholder;
      placeholderOption.disabled = true;
      placeholderOption.hidden = true;
      el.appendChild(placeholderOption);
    }
    options.options.forEach((entry) => {
      const optionEl = document.createElement("option");
      optionEl.value = entry.value;
      optionEl.textContent = entry.label;
      if (entry.disabled) optionEl.disabled = true;
      el.appendChild(optionEl);
    });
    el.value = value;
  };

  const setValue = (nextValue) => {
    value = nextValue;
    const el = ui.getElement(selectRef);
    if (el) el.value = value;
    syncModelRef(ui, ref(options.stateRef), { value });
    options.onValueChange?.(value);
  };

  populate();
  syncModelRef(ui, ref(options.stateRef), { value });
  ui.bindRefEvent(selectRef, "change", (_event, el) => {
    setValue(el.value);
  });

  return {
    setValue,
    getState: () => ({ value }),
  };
}

export function createArkSelect(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const contentRef = ref(options.contentRef);
  const valueRef = ref(options.valueRef);
  const labelRef = ref(options.labelRef);
  const descriptionRef = ref(options.descriptionRef);
  const stateRef = ref(options.stateRef);
  const optionRefs = options.optionRefs.map((value) => ref(value));
  const disabledRefs = new Set((options.disabledOptionRefs || []).map((value) => ref(value)));
  const focusScope = `${contentRef}-scope`;
  const collectionId = `${contentRef}-collection`;
  let committedRef = ref(options.selectedRef) || optionRefs.find((optionRef) => !disabledRefs.has(optionRef)) || optionRefs[0];
  let pendingRef = committedRef;
  const initialFocusRef = ref(options.initialFocusRef) || committedRef;

  const notifyOpen = (open) => options.onOpenChange?.(open);
  const syncState = (open) => syncModelRef(ui, stateRef, {
    open,
    selectedRef: committedRef,
    selectedText: textOf(ui, committedRef),
    highlightedRef: pendingRef,
    optionRefs: [...optionRefs],
    disabledOptionRefs: [...disabledRefs],
  });
  const setHighlighted = (nextRef) => {
    if (!nextRef || disabledRefs.has(nextRef)) return;
    pendingRef = nextRef;
    syncState(ui.get(contentRef)?.open === true);
    options.onHighlightChange?.(nextRef);
  };

  const syncSelection = (selectedRef) => {
    if (disabledRefs.has(selectedRef)) return;
    committedRef = selectedRef;
    pendingRef = selectedRef;
    optionRefs.forEach((optionRef) => {
      const selected = optionRef === committedRef;
      const current = ui.get(optionRef) || {};
      ui.update(optionRef, { ...current, selected, disabled: disabledRefs.has(optionRef) });
    });
    if (valueRef) {
      const current = ui.get(valueRef) || {};
      ui.update(valueRef, { ...current, text: textOf(ui, committedRef) });
    }
    syncState(ui.get(contentRef)?.open === true);
    options.onValueChange?.(committedRef, textOf(ui, committedRef));
  };

  ui.configureRef(triggerRef, {
    role: "button",
    controls: contentRef,
    hasPopup: "listbox",
    labelledBy: labelRef,
    describedBy: descriptionRef,
  });
  if (valueRef) ui.configureRef(valueRef, { part: "value" });
  ui.configureRef(contentRef, {
    role: "listbox",
    labelledBy: labelRef,
    describedBy: descriptionRef,
    overlay: {
      anchorRef: triggerRef,
      portal: options.portal ?? "layers",
      placement: options.placement ?? "bottom",
      fallbackPlacements: options.placement === "left" || options.placement === "right" ? ["bottom", "top"] : ["top", "right", "left"],
      align: options.align ?? "start",
      offset: 8,
      collisionPadding: 12,
      focusScope,
      sameWidth: true,
      sticky: true,
    },
  });
  optionRefs.forEach((optionRef) => {
    ui.configureRef(optionRef, { role: "option", collection: collectionId });
    if (disabledRefs.has(optionRef)) ui.update(optionRef, { disabled: true });
    ui.bindRefEvent(optionRef, "focus", () => setHighlighted(optionRef));
  });
  configureMenuFocusGroup(ui, collectionId, optionRefs);
  ui.createFocusScope(focusScope, { containerRef: contentRef, initialFocusRef, trap: false, restore: true });
  ui.createDismissableLayer(contentRef, {
    containerRef: contentRef,
    branchRefs: [triggerRef],
    restoreFocusRef: triggerRef,
    outsidePointer: true,
    outsideFocus: true,
    escapeKey: true,
  });
  ui.createPresence(contentRef, { unmountOnExit: true });
  ui.onAction(triggerRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    const current = ui.get(contentRef);
    const nextOpen = !current?.open;
    pendingRef = committedRef;
    setOverlayOpen(ui, triggerRef, contentRef, nextOpen);
    if (nextOpen) {
      ui.activateFocusScope(focusScope);
      ui.getElement(pendingRef)?.focus?.();
    }
    syncState(nextOpen);
    notifyOpen(nextOpen);
  });
  optionRefs.forEach((optionRef) => ui.onAction(optionRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    if (disabledRefs.has(optionRef)) return;
    pendingRef = optionRef;
    syncSelection(optionRef);
    setOverlayOpen(ui, triggerRef, contentRef, false);
    syncState(false);
    notifyOpen(false);
  }));
  optionRefs.forEach((optionRef) => ui.bindRefEvent(optionRef, "keydown", (rawEvent) => {
    const event = rawEvent;
    if ((event.key === "Enter" || event.key === " ") && !(ui.get(optionRef)?.disabled)) {
      event.preventDefault();
      pendingRef = optionRef;
      syncSelection(optionRef);
      setOverlayOpen(ui, triggerRef, contentRef, false);
      syncState(false);
      notifyOpen(false);
    } else if (event.key === "Escape") {
      event.preventDefault();
      pendingRef = committedRef;
      syncSelection(committedRef);
      setOverlayOpen(ui, triggerRef, contentRef, false);
      syncState(false);
      notifyOpen(false);
    }
  }));
  ui.bindRefEvent(triggerRef, "keydown", (rawEvent) => {
    const event = rawEvent;
    if (event.key !== "ArrowDown" && event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    pendingRef = committedRef;
    setOverlayOpen(ui, triggerRef, contentRef, true);
    ui.activateFocusScope(focusScope);
    ui.getElement(pendingRef)?.focus?.();
    syncState(true);
    notifyOpen(true);
  });
  ui.onAction(contentRef, () => {
    pendingRef = committedRef;
    setOverlayOpen(ui, triggerRef, contentRef, false);
    syncState(false);
    notifyOpen(false);
  });
  syncSelection(committedRef);
  syncState(false);
  return {
    open: () => {
      pendingRef = committedRef;
      setOverlayOpen(ui, triggerRef, contentRef, true);
      ui.activateFocusScope(focusScope);
      ui.getElement(pendingRef)?.focus?.();
      syncState(true);
      notifyOpen(true);
    },
    close: () => {
      pendingRef = committedRef;
      setOverlayOpen(ui, triggerRef, contentRef, false);
      syncState(false);
      notifyOpen(false);
    },
    highlight: (nextRef) => {
      const normalized = ref(nextRef);
      if (!normalized) return;
      setHighlighted(normalized);
      ui.getElement(normalized)?.focus?.();
    },
    select: (nextRef) => {
      const normalized = ref(nextRef);
      if (!normalized) return;
      syncSelection(normalized);
    },
    getState: () => ({
      open: ui.get(contentRef)?.open === true,
      selectedRef: committedRef,
      selectedText: textOf(ui, committedRef),
      highlightedRef: pendingRef,
    }),
  };
}
