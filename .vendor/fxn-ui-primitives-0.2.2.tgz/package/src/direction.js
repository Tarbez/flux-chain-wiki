/**
 * `createArkDirection` — moved out of `ark-ui.components.ts` verbatim. See
 * ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * The provider half of RTL support: setting `dir` here is what
 * `isRtlContext()` (ark-ui.runtime.ts) walks up to via `closest('[dir]')`
 * when it flips Arrow-key direction for every horizontal collection nested
 * underneath — accordion, tabs, menubar, carousel, and so on all inherit
 * this for free. This primitive's own job is just to own that one attribute
 * and expose it as live state, not to re-derive the RTL behavior itself.
 */
import { normalizeRef } from "@fxn/ui-a11y/dom";

export function createArkDirection(ui, options) {
  const rootRef = normalizeRef(options.rootRef);
  let dir = options.dir;

  const sync = () => {
    ui.configureRef(rootRef, { attrs: { dir } });
  };
  sync();

  return {
    setDirection: (next) => { dir = next; sync(); },
    getState: () => ({ dir }),
  };
}
