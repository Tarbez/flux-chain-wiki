/**
 * `createArkCarousel` — moved out of `ark-ui.components.ts` verbatim (same
 * logic, same call order, same observable behavior). See
 * ARK_UI_EVOLUTION_PLAN.md Batch 3.
 */
import { normalizeRef, normalizeRefs, setAttrs, syncModelRef } from "@fxn/ui-a11y/dom";
import { clampNumber } from "@fxn/ui-a11y/value";

function ref(value) {
  return normalizeRef(value);
}

export function createArkCarousel(ui, options) {
  const viewportRef = ref(options.viewportRef);
  const trackRef = ref(options.trackRef);
  const slideRefs = normalizeRefs(options.slideRefs);
  const dotRefs = normalizeRefs(options.dotRefs || []);
  const prevRef = ref(options.prevRef);
  const nextRef = ref(options.nextRef);
  const stateRef = ref(options.stateRef);
  const loop = options.loop ?? false;
  let index = 0;

  const sync = () => {
    const percent = index * 100;
    ui.style(trackRef, {
      display: "flex",
      flexDirection: options.orientation === "vertical" ? "column" : "row",
      width: "100%",
      transition: "transform 220ms ease",
      transform: options.orientation === "vertical" ? `translateY(-${percent}%)` : `translateX(-${percent}%)`,
    }, { mode: "merge" });
    slideRefs.forEach((slideRef, slideIndex) => {
      const current = ui.get(slideRef) || {};
      ui.update(slideRef, { ...current, selected: slideIndex === index });
      ui.style(slideRef, { flex: "0 0 100%" }, { mode: "merge" });
    });
    dotRefs.forEach((dotRef, dotIndex) => {
      const current = ui.get(dotRef) || {};
      ui.update(dotRef, { ...current, selected: dotIndex === index });
    });
    syncModelRef(ui, stateRef, { index, count: slideRefs.length });
    options.onSlideChange?.(index);
  };

  const scrollTo = (nextIndex) => {
    if (slideRefs.length === 0) return;
    if (loop) {
      index = (nextIndex + slideRefs.length) % slideRefs.length;
    } else {
      index = clampNumber(nextIndex, 0, slideRefs.length - 1);
    }
    sync();
  };

  if (prevRef) ui.onAction(prevRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    scrollTo(index - 1);
  });
  if (nextRef) ui.onAction(nextRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    scrollTo(index + 1);
  });
  dotRefs.forEach((dotRef, dotIndex) => ui.onAction(dotRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    scrollTo(dotIndex);
  }));
  ui.configureRef(viewportRef, { role: "region", label: options.label ?? "Carousel", part: "carousel-viewport" });
  setAttrs(ui, viewportRef, { "aria-roledescription": "carousel" });
  ui.style(viewportRef, { overflow: "hidden", width: "100%" }, { mode: "merge" });
  slideRefs.forEach((slideRef, slideIndex) => {
    ui.configureRef(slideRef, { role: "group", label: `Slide ${slideIndex + 1} of ${slideRefs.length}` });
    setAttrs(ui, slideRef, { "aria-roledescription": "slide" });
  });
  // Arrow keys advance/retreat when focus is anywhere inside the viewport —
  // every production carousel (Embla, shadcn's) supports this, and it's the
  // one piece a plain click-only prev/next pair can't give you for free.
  ui.bindRefEvent(viewportRef, "keydown", (rawEvent) => {
    const event = rawEvent;
    const vertical = options.orientation === "vertical";
    const forwardKey = vertical ? "ArrowDown" : "ArrowRight";
    const backwardKey = vertical ? "ArrowUp" : "ArrowLeft";
    if (event.key === forwardKey) { event.preventDefault(); scrollTo(index + 1); }
    else if (event.key === backwardKey) { event.preventDefault(); scrollTo(index - 1); }
  });

  let autoplayTimer;
  const stopAutoplay = () => { if (autoplayTimer) clearInterval(autoplayTimer); autoplayTimer = undefined; };
  const startAutoplay = () => {
    if (!options.autoplay || slideRefs.length <= 1) return;
    stopAutoplay();
    autoplayTimer = setInterval(() => scrollTo(index + 1), options.autoplay);
  };
  if (options.autoplay) {
    ui.bindRefEvent(viewportRef, "pointerenter", stopAutoplay);
    ui.bindRefEvent(viewportRef, "pointerleave", startAutoplay);
    ui.bindRefEvent(viewportRef, "focusin", stopAutoplay);
    ui.bindRefEvent(viewportRef, "focusout", startAutoplay);
    startAutoplay();
  }

  sync();
  return {
    scrollTo,
    scrollNext: () => scrollTo(index + 1),
    scrollPrev: () => scrollTo(index - 1),
    pauseAutoplay: stopAutoplay,
    resumeAutoplay: startAutoplay,
    getState: () => ({ index, count: slideRefs.length }),
  };
}
