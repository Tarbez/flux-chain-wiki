/**
 * `createArkSheet` and `createArkDrawer` — moved out of
 * `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * A sheet is a side-anchored modal dialog (the overlay/focus-scope/
 * dismissable-layer/presence composition matches `createArkDialog`), so it
 * builds on `@fxn/ui-a11y` directly. `createArkDrawer` is a thin
 * `createArkSheet` wrapper with a `part: "drawer"` marker, not a separate
 * mechanism.
 */
import { normalizeRef, setLiveAttr, setAttrs, syncModelRef } from "@fxn/ui-a11y/dom";
import { configureFocusScope, configureDismissableLayer, configurePresence } from "@fxn/ui-a11y/overlay";

function ref(value) {
  return normalizeRef(value);
}

function uniqueRefs(values) {
  return [...new Set(values.map((value) => ref(value)))];
}

function setSheetStyles(ui, contentRef, side, size) {
  const horizontal = side === "left" || side === "right";
  const resolvedSize = size || (horizontal ? "420px" : "40vh");
  ui.style(contentRef, {
    position: "fixed",
    top: side === "bottom" ? "auto" : "0",
    right: side === "left" ? "auto" : "0",
    bottom: side === "top" ? "auto" : "0",
    left: side === "right" ? "auto" : "0",
    width: horizontal ? resolvedSize : "100vw",
    height: horizontal ? "100vh" : resolvedSize,
    maxWidth: "100vw",
    maxHeight: "100vh",
    borderRadius: side === "left" ? "0 24px 24px 0" : side === "right" ? "24px 0 0 24px" : side === "top" ? "0 0 24px 24px" : "24px 24px 0 0",
    boxSizing: "border-box",
    overflow: "auto",
  }, { mode: "merge" });
}

export function createArkSheet(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const triggerRefs = uniqueRefs([triggerRef, ...(options.triggerRefs || [])]);
  const contentRef = ref(options.contentRef);
  const closeRefs = uniqueRefs([...(options.closeRef ? [options.closeRef] : []), ...(options.closeRefs || [])]);
  const side = options.side ?? "right";
  const stateRef = ref(options.stateRef);
  const viewportRef = ref(options.viewportRef);
  const focusScope = `${contentRef}-scope`;
  const restoreFocusRef = options.finalFocus === false ? undefined : (ref(options.restoreFocusRef) || triggerRef);
  const controlled = options.controlled === true || options.open !== undefined;
  let open = options.open ?? options.defaultOpen ?? false;
  let mounted = options.keepMounted === true || open;
  let activeTriggerRef = triggerRef;
  let reason = "none";

  const placementForSide = { left: "right", right: "left", top: "bottom", bottom: "top" };
  triggerRefs.forEach((currentTriggerRef) => {
    ui.configureRef(currentTriggerRef, {
      role: "button",
      controls: contentRef,
      hasPopup: "dialog",
    });
    ui.bindRefEvent(currentTriggerRef, "pointerdown", () => setLiveAttr(ui, currentTriggerRef, "data-pressed", "true"));
    ["pointerup", "pointerleave", "pointercancel"].forEach((eventName) =>
      ui.bindRefEvent(currentTriggerRef, eventName, () => setLiveAttr(ui, currentTriggerRef, "data-pressed", undefined)));
  });
  ui.configureRef(contentRef, {
    role: "dialog",
    modal: true,
    labelledBy: ref(options.labelRef),
    describedBy: ref(options.descriptionRef),
    part: "sheet",
    overlay: {
      anchorRef: triggerRef,
      portal: options.portal ?? "layers",
      placement: side,
      fallbackPlacements: [placementForSide[side]],
      align: "start",
      offset: 0,
      collisionPadding: 0,
      focusScope,
      modal: true,
      backdrop: true,
      sticky: false,
    },
  });
  if (viewportRef) ui.configureRef(viewportRef, { part: "sheet-viewport" });
  configureFocusScope(ui, focusScope, {
    containerRef: contentRef,
    initialFocusRef: options.initialFocus === false ? false : ref(options.initialFocusRef),
    trap: true,
    restore: options.finalFocus !== false,
  });
  configureDismissableLayer(ui, contentRef, {
    containerRef: contentRef,
    dismissRef: contentRef,
    branchRefs: triggerRefs,
    restoreFocusRef,
    outsidePointer: options.closeOnOutsidePress !== false,
    outsideFocus: false,
    escapeKey: false,
  });
  configurePresence(ui, contentRef, { unmountOnExit: options.keepMounted !== true, ariaHidden: true });

  const detailsFor = (nextReason, event, nextTriggerRef = activeTriggerRef) => {
    const details = {
      reason: nextReason,
      triggerRef: nextTriggerRef,
      event,
      isCanceled: false,
      cancel() { details.isCanceled = true; },
    };
    return details;
  };
  const syncState = () => {
    triggerRefs.forEach((currentTriggerRef) => {
      const current = ui.get(currentTriggerRef) || {};
      ui.update(currentTriggerRef, { ...current, open, disabled: options.disabled === true });
      setAttrs(ui, currentTriggerRef, {
        "data-popup-open": open ? "true" : undefined,
        "data-active-trigger": currentTriggerRef === activeTriggerRef ? "true" : undefined,
      });
    });
    const current = ui.get(contentRef) || {};
    ui.update(contentRef, { ...current, open, hidden: !open });
    setAttrs(ui, contentRef, {
      "data-open": open ? "true" : undefined,
      "data-closed": !open ? "true" : undefined,
      "data-state": open ? "open" : "closed",
      "data-side": side,
    });
    syncModelRef(ui, stateRef, { open, activeTriggerRef, reason, controlled, mounted, side, size: options.size });
  };
  const applyOpen = (nextOpen, details, force = false, notify = true) => {
    if (notify) options.onOpenChange?.(nextOpen, details);
    if (details.isCanceled || (controlled && !force)) return;
    open = nextOpen;
    reason = details.reason;
    activeTriggerRef = details.triggerRef;
    mounted = options.keepMounted === true || nextOpen;
    syncState();
    if (nextOpen) {
      ui.openOverlay(contentRef);
      setSheetStyles(ui, contentRef, side, options.size);
      ui.activateFocusScope(focusScope);
    } else {
      ui.closeOverlay(contentRef);
    }
    options.onOpenChangeComplete?.(nextOpen, details);
  };
  const requestOpen = (nextOpen, nextReason, event, nextTriggerRef = activeTriggerRef, force = false, notify = true) => {
    const details = detailsFor(nextReason, event, nextTriggerRef);
    applyOpen(nextOpen, details, force, notify);
  };

  triggerRefs.forEach((currentTriggerRef) => ui.onAction(currentTriggerRef, (_ref, detail) => {
    if (detail.action !== "CLICK" || options.disabled) return;
    requestOpen(!open, "trigger-press", undefined, currentTriggerRef);
  }));
  closeRefs.forEach((closeRef) => {
    ui.configureRef(closeRef, { part: "sheet-close" });
    ui.onAction(closeRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      requestOpen(false, "close-press");
    });
  });
  ui.onAction(contentRef, (_ref, detail) => {
    if (detail.action !== "DISMISS" || options.closeOnOutsidePress === false) return;
    const details = detailsFor("outside-press");
    if (options.onOutsidePress?.(details) === false || details.isCanceled) return;
    applyOpen(false, details);
  });
  ui.bindRefEvent(contentRef, "keydown", (rawEvent) => {
    const event = rawEvent;
    if (event.key !== "Escape" || options.escapeKey === false) return;
    const details = detailsFor("escape-key", event);
    if (options.onEscapeKeyDown?.(event, details) === false || details.isCanceled) return;
    event.preventDefault();
    applyOpen(false, details);
  });
  syncState();
  if (open) { ui.openOverlay(contentRef); setSheetStyles(ui, contentRef, side, options.size); }
  return {
    open: (nextTriggerRef = triggerRef) => requestOpen(true, "imperative-action", undefined, ref(nextTriggerRef), true),
    close: () => requestOpen(false, "imperative-action", undefined, activeTriggerRef, true),
    toggle: (nextTriggerRef = triggerRef) => requestOpen(!open, "imperative-action", undefined, ref(nextTriggerRef), true),
    setOpen: (nextOpen, nextTriggerRef = triggerRef) => requestOpen(nextOpen, "imperative-action", undefined, ref(nextTriggerRef), true),
    syncControlled: (nextOpen, nextTriggerRef = triggerRef) => requestOpen(nextOpen, "controlled-sync", undefined, ref(nextTriggerRef), true, false),
    getState: () => ({ open, activeTriggerRef, reason, controlled, mounted, side, size: options.size }),
  };
}

export function createArkDrawer(ui, options) {
  const handle = createArkSheet(ui, { side: options.side ?? "right", ...options });
  ui.configureRef(ref(options.contentRef), { part: "drawer" });
  return handle;
}
