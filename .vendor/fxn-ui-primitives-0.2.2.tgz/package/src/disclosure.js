/**
 * The disclosure family — `createArkDisclosure`, `createArkCollapsible`, and
 * `createArkCodeBlock` — moved out of `ark-ui.components.ts` verbatim (same
 * logic, same call order, same observable behavior). See
 * ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * One family because the other two are literally built on the first:
 * collapsible adds the title/labelling parts and delegates, code block adds
 * the copy affordance and the "View code"/"Hide code" trigger label and
 * delegates. All three share one accessibility contract — a `role="button"`
 * trigger whose `aria-expanded` and `aria-controls` point at a `role="region"`
 * panel labelled back by the trigger, kept in lockstep so a screen reader
 * never reads "collapsed" over content that is on screen.
 *
 * Unlike dialog/popover this is *not* an overlay: nothing portals, nothing
 * traps focus, and Escape does not close it — the panel is in the normal flow
 * and the trigger stays where the user left it. That is exactly why the
 * runtime's overlay machinery does not appear below.
 *
 * Built on `@fxn/ui-a11y` for ref normalization, attribute wiring, and
 * text reads — the plan's dependency direction: `ark-primitives -> ark-a11y`.
 */
import { normalizeRef, setAttrs, syncModelRef, textOf } from "@fxn/ui-a11y/dom";

function ref(value) {
  return normalizeRef(value);
}

export function createArkDisclosure(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const contentRef = ref(options.contentRef);
  const controlled = options.controlled === true || options.open !== undefined;
  let open = options.open ?? !!options.defaultOpen;
  let mounted = options.keepMounted === true || options.hiddenUntilFound === true || open;
  const stateRef = ref(options.stateRef);

  const sync = () => {
    const triggerState = ui.get(triggerRef) || {};
    const contentState = ui.get(contentRef) || {};
    ui.configureRef(triggerRef, { role: "button", controls: contentRef });
    ui.configureRef(contentRef, { role: "region", labelledBy: triggerRef });
    ui.update(triggerRef, { ...triggerState, expanded: open, open, disabled: !!options.disabled });
    ui.update(contentRef, { ...contentState, hidden: !open, open });
    setAttrs(ui, triggerRef, { "data-panel-open": open ? "true" : undefined });
    setAttrs(ui, contentRef, {
      "data-open": open ? "true" : undefined,
      "data-closed": !open ? "true" : undefined,
      "data-state": open ? "open" : "closed",
      hidden: !open && options.hiddenUntilFound ? "until-found" : undefined,
    });
    const element = ui.getElement(contentRef);
    const rect = element?.getBoundingClientRect?.();
    ui.style(contentRef, {
      "--collapsible-panel-height": `${element?.scrollHeight || rect?.height || 0}px`,
      "--collapsible-panel-width": `${element?.scrollWidth || rect?.width || 0}px`,
    }, { mode: "merge" });
    syncModelRef(ui, stateRef, { open, controlled, mounted });
  };

  const request = (nextOpen, reason, event, force = false, notify = true) => {
    if (options.disabled) return;
    const details = { reason, event, isCanceled: false, cancel: () => { details.isCanceled = true; } };
    if (notify) options.onOpenChange?.(nextOpen, details);
    if (details.isCanceled || (controlled && !force)) return;
    open = nextOpen;
    mounted = options.keepMounted === true || options.hiddenUntilFound === true || open;
    sync();
    options.onOpenChangeComplete?.(open);
  };
  const toggle = () => request(!open, "imperative-action", undefined, true);

  ui.onAction(triggerRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    request(!open, "trigger-press", undefined);
  });
  ui.bindRefEvent(triggerRef, "keydown", (rawEvent) => {
    const event = rawEvent;
    if (event.key !== "Enter" && event.key !== " ") return;
    event.preventDefault();
    request(!open, "trigger-press", event);
  });
  sync();
  return {
    open: () => request(true, "imperative-action", undefined, true),
    close: () => request(false, "imperative-action", undefined, true),
    toggle,
    setOpen: (nextOpen) => request(nextOpen, "imperative-action", undefined, true),
    syncControlled: (nextOpen) => request(nextOpen, "controlled-sync", undefined, true, false),
    getState: () => ({ open, controlled, mounted }),
  };
}

export function createArkCollapsible(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const contentRef = ref(options.contentRef);
  const titleRef = ref(options.titleRef);
  ui.configureRef(contentRef, { part: "collapsible-content", labelledBy: titleRef || triggerRef });
  if (titleRef) ui.configureRef(titleRef, { part: "collapsible-title" });
  return createArkDisclosure(ui, options);
}

export function createArkCodeBlock(ui, options) {
  const triggerRef = ref(options.triggerRef);
  const contentRef = ref(options.contentRef);
  const codeRef = ref(options.codeRef);
  const labelRef = ref(options.labelRef);
  const copyTriggerRef = ref(options.copyTriggerRef);
  const collapsedLabel = options.collapsedLabel ?? "View code";
  const expandedLabel = options.expandedLabel ?? "Hide code";
  const copyLabel = options.copyLabel ?? "Copy";
  const copiedLabel = options.copiedLabel ?? "Copied";
  const copyUnavailableLabel = options.copyUnavailableLabel ?? "Copy unavailable";
  const resetCopyLabelDelay = typeof options.resetCopyLabelDelay === "number" ? options.resetCopyLabelDelay : 1600;
  let copyResetTimer;
  const syncCopyLabel = (label) => {
    if (!copyTriggerRef)
      return;
    const current = ui.get(copyTriggerRef) || {};
    ui.update(copyTriggerRef, { ...current, text: label });
  };
  const resetCopyFeedback = () => {
    if (copyResetTimer)
      clearTimeout(copyResetTimer);
    copyResetTimer = setTimeout(() => syncCopyLabel(copyLabel), resetCopyLabelDelay);
  };
  if (labelRef) ui.configureRef(labelRef, { part: "codeblock-label" });
  ui.configureRef(contentRef, { part: "codeblock-content", labelledBy: labelRef || triggerRef });
  ui.configureRef(codeRef, { part: "codeblock-code" });
  if (copyTriggerRef) {
    ui.configureRef(copyTriggerRef, { role: "button", part: "codeblock-copy" });
    syncCopyLabel(copyLabel);
    const copyCode = async () => {
      const text = textOf(ui, codeRef);
      const clipboard = typeof globalThis !== "undefined" ? globalThis.navigator?.clipboard : undefined;
      if (!text || !clipboard?.writeText || globalThis.isSecureContext === false) {
        syncCopyLabel(copyUnavailableLabel);
        resetCopyFeedback();
        options.onCopy?.({ ok: false, text });
        return;
      }
      try {
        await clipboard.writeText(text);
        syncCopyLabel(copiedLabel);
        options.onCopy?.({ ok: true, text });
      }
      catch {
        syncCopyLabel(copyUnavailableLabel);
        options.onCopy?.({ ok: false, text });
      }
      resetCopyFeedback();
    };
    ui.onAction(copyTriggerRef, (_ref, detail) => {
      if (detail.action !== "CLICK")
        return;
      void copyCode();
    });
    ui.bindRefEvent(copyTriggerRef, "keydown", (rawEvent) => {
      const event = rawEvent;
      if (event.key !== "Enter" && event.key !== " ")
        return;
      event.preventDefault();
      void copyCode();
    });
  }
  if (typeof options.code === "string") ui.update(codeRef, { text: options.code });
  return createArkDisclosure(ui, {
    ...options,
    onOpenChange: (open) => {
      const current = ui.get(triggerRef) || {};
      ui.update(triggerRef, { ...current, text: open ? expandedLabel : collapsedLabel });
      options.onOpenChange?.(open);
    },
  });
}
