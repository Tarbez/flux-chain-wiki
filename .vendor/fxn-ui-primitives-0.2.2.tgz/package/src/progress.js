/**
 * The progress / loading family — `createArkProgress`, `createArkSkeleton`,
 * `createArkSpinner`, and `createArkLoadingMark` — moved out of
 * `ark-ui.components.ts` verbatim (same logic, same call order, same
 * observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * They are one family because they share a single accessibility contract:
 * "work is in flight, here is how far along it is, and here is how a screen
 * reader finds that out". Progress owns the determinate case
 * (`role="progressbar"` plus the `aria-valuemin`/`aria-valuemax`/
 * `aria-valuenow` triple), the other three own the indeterminate case
 * (a polite `role="status"` live region plus `aria-busy`), and skeleton
 * additionally hides its own placeholder geometry from assistive tech so the
 * shimmer boxes are never read out as content.
 *
 * Built on `@fxn/ui-a11y` for ref normalization, attribute wiring, value
 * clamping, and live-region composition — the plan's dependency direction:
 * `ark-primitives -> ark-a11y`.
 */
import { normalizeRef, setAttrs, syncModelRef, setHidden } from "@fxn/ui-a11y/dom";
import { clampNumber } from "@fxn/ui-a11y/value";
import { configureStatusRegion } from "@fxn/ui-a11y/live-region";

function ref(value) {
  return normalizeRef(value);
}

export function createArkProgress(ui, options) {
  const rootRef = ref(options.rootRef);
  const indicatorRef = ref(options.indicatorRef);
  const valueRef = ref(options.valueRef);
  const min = options.min ?? 0;
  const max = options.max ?? 100;
  let value = clampNumber(options.value ?? min, min, max);
  let indeterminate = !!options.indeterminate;
  const sync = () => {
    const percent = max === min ? 0 : ((value - min) / (max - min)) * 100;
    ui.configureRef(rootRef, { role: "progressbar", labelledBy: ref(options.labelRef), part: "progress" });
    ui.configureRef(indicatorRef, { part: "progress-indicator" });
    setAttrs(ui, rootRef, {
      "aria-valuemin": String(min),
      "aria-valuemax": String(max),
      "aria-valuenow": indeterminate ? undefined : String(value),
      "aria-valuetext": indeterminate ? "Loading" : `${Math.round(percent)}%`,
      "data-indeterminate": indeterminate ? "true" : undefined,
    });
    ui.style(indicatorRef, {
      width: indeterminate ? "40%" : `${percent}%`,
      minHeight: "100%",
    }, { mode: "merge" });
    const rootState = ui.get(rootRef) || {};
    ui.update(rootRef, { ...rootState });
    if (valueRef) {
      const current = ui.get(valueRef) || {};
      ui.update(valueRef, { ...current, text: indeterminate ? "Loading" : `${Math.round(percent)}%` });
    }
    syncModelRef(ui, ref(options.stateRef), { value, min, max, indeterminate });
    options.onValueChange?.(value);
  };
  sync();
  return {
    setValue: (nextValue) => { value = clampNumber(nextValue, min, max); indeterminate = false; sync(); },
    setIndeterminate: (nextIndeterminate) => { indeterminate = nextIndeterminate; sync(); },
    getState: () => ({ value, min, max, indeterminate }),
  };
}

export function createArkSkeleton(ui, options) {
  const rootRefs = [...new Set([ref(options.rootRef), ...(options.rootRefs || []).map((value) => ref(value))])];
  const containerRef = ref(options.containerRef);
  const stateRef = ref(options.stateRef);
  const animation = options.animation ?? "pulse";
  let loading = options.loading !== false;
  const sync = () => {
    rootRefs.forEach((rootRef) => {
      ui.configureRef(rootRef, { part: "skeleton" });
      setAttrs(ui, rootRef, {
        "aria-hidden": options.decorative !== false ? "true" : undefined,
        "data-animation": animation,
        "data-loading": loading ? "true" : undefined,
      });
      setHidden(ui, rootRef, !loading);
    });
    if (containerRef) {
      ui.configureRef(containerRef, { attrs: { "aria-busy": loading ? "true" : "false", "aria-label": options.label } });
    }
    syncModelRef(ui, stateRef, { loading, animation });
  };
  sync();
  return {
    setLoading: (nextLoading) => { loading = nextLoading; sync(); },
    complete: () => { loading = false; sync(); },
    getState: () => ({ loading, animation }),
  };
}

export function createArkSpinner(ui, options) {
  const rootRef = ref(options.rootRef);
  ui.configureRef(rootRef, { part: "spinner" });
  configureStatusRegion(ui, rootRef);
  if (options.labelRef) ui.configureRef(ref(options.labelRef), { part: "spinner-label" });
  syncModelRef(ui, ref(options.stateRef), { spinning: true });
}

export function createArkLoadingMark(ui, options) {
  const rootRef = ref(options.rootRef);
  const logoRef = ref(options.logoRef);
  const labelRef = ref(options.labelRef);
  const descriptionRef = ref(options.descriptionRef);
  let spinning = options.spinning !== false;

  const sync = () => {
    ui.configureRef(rootRef, { part: "loading-mark" });
    configureStatusRegion(ui, rootRef);
    if (logoRef) ui.configureRef(logoRef, { part: "loading-mark-logo" });
    if (labelRef) ui.configureRef(labelRef, { part: "loading-mark-label" });
    if (descriptionRef) ui.configureRef(descriptionRef, { part: "loading-mark-description" });
    setAttrs(ui, rootRef, {
      "aria-busy": spinning ? "true" : "false",
      "data-loading": spinning ? "true" : "false",
    });
    syncModelRef(ui, ref(options.stateRef), { spinning });
  };

  const setSpinning = (nextSpinning) => {
    spinning = nextSpinning;
    sync();
  };

  const setTextRef = (targetRef, text) => {
    if (!targetRef) return;
    const current = ui.get(targetRef) || {};
    ui.update(targetRef, { ...current, text });
  };

  sync();

  return {
    start: () => setSpinning(true),
    stop: () => setSpinning(false),
    setSpinning,
    setLabel: (text) => setTextRef(labelRef, text),
    setDescription: (text) => setTextRef(descriptionRef, text),
    getState: () => ({ spinning }),
  };
}
