/**
 * `createArkItem`, `createArkMarker`, `createArkCollection`, `createArkTable`,
 * and `createArkDataTable` — moved out of `ark-ui.components.ts` verbatim
 * (same logic, same call order, same observable behavior). See
 * ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * One module, not five, because three of them chain by direct call:
 * `createArkDataTable` calls `createArkTable`, which calls
 * `createArkCollection` — a data table is a table with column management on
 * top, and a table is a collection with sortable headers on top, not three
 * independent reimplementations of "a set of selectable rows." `createArkItem`
 * and `createArkMarker` are the two small standalone building blocks the
 * original file grouped alongside them (a generic clickable row, and a
 * positioned marker over a map/canvas surface) — not part of that chain, but
 * with nowhere more specific to live.
 *
 * Built on `@fxn/ui-a11y` for ref normalization, attribute wiring, roving
 * focus, and numeric clamping — the plan's dependency direction:
 * `ark-primitives -> ark-a11y`.
 */
import { configureRovingFocusGroup } from "@fxn/ui-a11y/collection";
import { normalizeRef, normalizeRefs, setAttrs, setHidden, syncModelRef } from "@fxn/ui-a11y/dom";
import { clampNumber } from "@fxn/ui-a11y/value";

function ref(value) {
  return normalizeRef(value);
}

export function createArkItem(ui, options) {
  const itemRef = ref(options.itemRef);
  let selected = !!options.selected;

  const sync = () => {
    ui.configureRef(itemRef, { role: "button", part: "item", collection: options.collection });
    const current = ui.get(itemRef) || {};
    ui.update(itemRef, { ...current, selected, disabled: !!options.disabled });
    syncModelRef(ui, ref(options.stateRef), { selected });
  };

  const select = () => {
    if (options.disabled) return;
    selected = true;
    sync();
    options.onSelect?.();
  };

  ui.onAction(itemRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    select();
  });
  sync();

  return {
    select,
    getState: () => ({ selected, disabled: !!options.disabled }),
  };
}

export function createArkMarker(ui, options) {
  const containerRef = ref(options.containerRef);
  const markerRef = ref(options.markerRef);
  const unit = options.unit ?? "percent";
  let x = options.x;
  let y = options.y;

  const sync = () => {
    ui.configureRef(markerRef, { part: "marker", role: options.onSelect ? "button" : undefined, label: options.label });
    ui.style(markerRef, {
      position: "absolute",
      left: unit === "percent" ? `${x}%` : `${x}px`,
      top: unit === "percent" ? `${y}%` : `${y}px`,
      // Anchors the pin's *tip* to the coordinate, not its bounding-box
      // corner — the usual expectation for a map/canvas marker glyph.
      transform: "translate(-50%, -100%)",
    }, { mode: "merge" });
  };

  ui.style(containerRef, { position: "relative" }, { mode: "merge" });
  if (options.onSelect) {
    ui.onAction(markerRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      options.onSelect?.();
    });
  }
  sync();

  return {
    setPosition: (nextX, nextY) => { x = nextX; y = nextY; sync(); },
    getState: () => ({ x, y }),
  };
}

export function createArkCollection(ui, options) {
  const containerRef = ref(options.containerRef);
  const itemRefs = normalizeRefs(options.itemRefs);
  const emptyRef = ref(options.emptyRef);
  const loadingRef = ref(options.loadingRef);
  const detailRef = ref(options.detailRef);
  const collectionId = `${containerRef}-collection`;
  const selectionMode = options.selectionMode ?? "single";
  const selectedRefs = new Set(normalizeRefs(options.selectedRefs || []));
  let loading = !!options.loading;

  const sync = () => {
    const visibleItems = itemRefs.filter((itemRef) => !ui.get(itemRef)?.hidden);
    ui.configureRef(containerRef, { part: "collection", orientation: options.orientation ?? "vertical" });
    itemRefs.forEach((itemRef) => {
      const selected = selectedRefs.has(itemRef);
      const current = ui.get(itemRef) || {};
      ui.configureRef(itemRef, { collection: collectionId });
      ui.update(itemRef, { ...current, selected });
    });
    setHidden(ui, loadingRef, !loading);
    setHidden(ui, emptyRef, loading || visibleItems.length > 0);
    if (detailRef) setHidden(ui, detailRef, selectedRefs.size === 0);
    options.onSelectionChange?.([...selectedRefs]);
  };

  const toggle = (itemRef) => {
    if (selectionMode === "none") return;
    if (selectionMode === "single") {
      selectedRefs.clear();
      selectedRefs.add(itemRef);
    } else if (selectedRefs.has(itemRef)) {
      selectedRefs.delete(itemRef);
    } else {
      selectedRefs.add(itemRef);
    }
    sync();
  };

  configureRovingFocusGroup(ui, collectionId, { refs: itemRefs, orientation: options.orientation ?? "vertical", loop: options.loop ?? true, typeahead: true });
  itemRefs.forEach((itemRef) => {
    ui.onAction(itemRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      toggle(itemRef);
    });
    ui.bindRefEvent(itemRef, "keydown", (rawEvent) => {
      const event = rawEvent;
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      toggle(itemRef);
    });
  });
  sync();
}

export function createArkTable(ui, options) {
  const tableRef = ref(options.tableRef);
  const captionRef = ref(options.captionRef);
  const theadRef = ref(options.theadRef);
  const footerRef = ref(options.footerRef);
  const sortableHeaderRefs = normalizeRefs(options.sortableHeaderRefs || []);
  const stickyColumnRefs = normalizeRefs(options.stickyFirstColumnRefs || []);
  let sortRef;
  let sortDirection;

  ui.configureRef(tableRef, { part: "table" });
  if (captionRef) ui.configureRef(captionRef, { part: "table-caption" });
  if (footerRef) ui.configureRef(footerRef, { part: "table-footer" });
  if (theadRef) {
    ui.configureRef(theadRef, { part: "table-head" });
    if (options.stickyHeader) ui.style(theadRef, { position: "sticky", top: "0", zIndex: "1" }, { mode: "merge" });
  }
  stickyColumnRefs.forEach((cellRef) => {
    ui.style(cellRef, { position: "sticky", left: "0", zIndex: "1" }, { mode: "merge" });
  });

  const applySort = (headerRef, direction) => {
    sortRef = direction ? headerRef : undefined;
    sortDirection = direction;
    sortableHeaderRefs.forEach((candidate) => {
      setAttrs(ui, candidate, {
        "aria-sort": candidate === headerRef && direction ? (direction === "asc" ? "ascending" : "descending") : "none",
      });
    });
    options.onSortChange?.(headerRef, direction);
  };

  sortableHeaderRefs.forEach((headerRef) => {
    ui.configureRef(headerRef, { attrs: { "aria-sort": "none", "data-sortable": "true" } });
    ui.onAction(headerRef, (_ref, detail) => {
      if (detail.action !== "CLICK") return;
      const next = sortRef !== headerRef ? "asc" : sortDirection === "asc" ? "desc" : undefined;
      applySort(headerRef, next);
    });
  });

  createArkCollection(ui, {
    containerRef: tableRef,
    itemRefs: options.itemRefs,
    emptyRef: options.emptyRef,
    loadingRef: options.loadingRef,
    detailRef: options.detailRef,
    selectedRefs: options.selectedRefs,
    selectionMode: options.selectionMode,
    orientation: options.orientation ?? "vertical",
    loop: options.loop,
    loading: options.loading,
    onSelectionChange: options.onSelectionChange,
  });

  return {
    sortBy: (headerRefInput, direction) => {
      const resolvedRef = ref(headerRefInput);
      if (!resolvedRef || !sortableHeaderRefs.includes(resolvedRef)) return;
      const next = direction !== undefined
        ? direction
        : sortRef !== resolvedRef ? "asc" : sortDirection === "asc" ? "desc" : undefined;
      applySort(resolvedRef, next);
    },
    getState: () => ({ sortRef, sortDirection }),
  };
}

export function createArkDataTable(ui, options) {
  const headerRefs = normalizeRefs(options.headerRefs || options.columns?.map((column) => column.headerRef) || []);
  const rowRefs = normalizeRefs(options.itemRefs);
  const prevRef = ref(options.prevRef);
  const nextRef = ref(options.nextRef);
  const stateRef = ref(options.stateRef);
  const pageSize = Math.max(1, options.pageSize ?? (rowRefs.length || 1));
  let page = 0;
  let sortRef;
  let sortDirection = "asc";

  const columnsByHeader = new Map(
    (options.columns || []).map((column) => [ref(column.headerRef), column]),
  );
  const hiddenHeaders = new Set(normalizeRefs(options.hiddenColumnRefs || []));
  const pinnedHeaders = normalizeRefs(options.pinnedColumnRefs || []);
  const widths = new Map(
    (options.columns || []).filter((column) => column.width).map((column) => [ref(column.headerRef), column.width]),
  );

  createArkTable(ui, options);

  const columnCellRefs = (headerRef) => normalizeRefs(columnsByHeader.get(headerRef)?.cellRefs || []);

  // Pinned-column left offsets are measured, not declared: each column's
  // stacking offset is the sum of the *rendered* width of the pinned
  // columns before it, so resizing an earlier pinned column keeps every
  // later one correctly aligned instead of drifting out of sync.
  const syncColumns = () => {
    let leftOffset = 0;
    headerRefs.forEach((headerRef) => {
      const hidden = hiddenHeaders.has(headerRef);
      const pinned = pinnedHeaders.includes(headerRef);
      const width = widths.get(headerRef);
      const cellRefs = columnCellRefs(headerRef);
      const styles = {};
      if (width) styles.width = `${width}px`;
      if (pinned) { styles.position = "sticky"; styles.left = `${leftOffset}px`; styles.zIndex = "1"; }
      if (Object.keys(styles).length > 0) ui.style(headerRef, styles, { mode: "merge" });
      const headerCurrent = ui.get(headerRef) || {};
      ui.update(headerRef, { ...headerCurrent, hidden });
      cellRefs.forEach((cellRef) => {
        if (Object.keys(styles).length > 0) ui.style(cellRef, styles, { mode: "merge" });
        const cellCurrent = ui.get(cellRef) || {};
        ui.update(cellRef, { ...cellCurrent, hidden });
      });
      if (pinned && !hidden) leftOffset += ui.getElement(headerRef)?.getBoundingClientRect().width || width || 0;
    });
    options.onColumnsChange?.({ hiddenColumnRefs: [...hiddenHeaders], widths: Object.fromEntries(widths) });
  };

  const showColumn = (headerRefInput) => {
    const resolved = ref(headerRefInput);
    if (resolved && hiddenHeaders.delete(resolved)) syncColumns();
  };
  const hideColumn = (headerRefInput) => {
    const resolved = ref(headerRefInput);
    if (resolved && !hiddenHeaders.has(resolved)) { hiddenHeaders.add(resolved); syncColumns(); }
  };
  const setColumnWidth = (headerRefInput, width) => {
    const resolved = ref(headerRefInput);
    if (!resolved) return;
    const minWidth = columnsByHeader.get(resolved)?.minWidth ?? 40;
    widths.set(resolved, Math.max(minWidth, width));
    syncColumns();
  };

  const resizeHandleRefs = normalizeRefs(options.resizeHandleRefs || []);
  resizeHandleRefs.forEach((handleRef, index) => {
    const headerRef = headerRefs[index];
    if (!headerRef) return;
    ui.bindRefEvent(handleRef, "pointerdown", (rawEvent) => {
      if (typeof document === "undefined") return;
      const event = rawEvent;
      const startWidth = widths.get(headerRef) ?? ui.getElement(headerRef)?.getBoundingClientRect().width ?? 120;
      const startX = event.clientX;
      const onPointerMove = (moveEvent) => {
        setColumnWidth(headerRef, startWidth + (moveEvent.clientX - startX));
      };
      const onPointerUp = () => {
        document.removeEventListener("pointermove", onPointerMove);
        document.removeEventListener("pointerup", onPointerUp);
      };
      document.addEventListener("pointermove", onPointerMove);
      document.addEventListener("pointerup", onPointerUp);
    });
  });

  const syncPage = () => {
    const pageCount = Math.max(1, Math.ceil(rowRefs.length / pageSize));
    rowRefs.forEach((rowRef, index) => {
      const hidden = index < page * pageSize || index >= (page + 1) * pageSize;
      const current = ui.get(rowRef) || {};
      ui.update(rowRef, { ...current, hidden });
    });
    syncModelRef(ui, stateRef, { page, pageCount, sortRef, sortDirection });
  };

  const sortBy = (headerRefInput) => {
    // Normalized here (unlike the original ark-ui.components.ts source),
    // so the exposed handle.sortBy() accepts a raw ref name the same way
    // createArkTable's handle.sortBy() already does — ref() is idempotent,
    // so the already-normalized calls below (from the header click
    // listeners) are unaffected.
    const headerRef = ref(headerRefInput);
    const column = options.columns?.find((entry) => ref(entry.headerRef) === headerRef);
    if (!column) return;
    sortDirection = sortRef === headerRef && sortDirection === "asc" ? "desc" : "asc";
    sortRef = headerRef;
    const sorted = [...rowRefs].sort((left, right) => {
      const leftValue = column.accessor(left);
      const rightValue = column.accessor(right);
      const comparison = leftValue < rightValue ? -1 : leftValue > rightValue ? 1 : 0;
      return sortDirection === "asc" ? comparison : -comparison;
    });
    rowRefs.splice(0, rowRefs.length, ...sorted);
    const parent = ui.getElement(rowRefs[0])?.parentElement;
    if (parent) rowRefs.forEach((rowRef) => {
      const rowEl = ui.getElement(rowRef);
      if (rowEl) parent.appendChild(rowEl);
    });
    syncPage();
  };

  headerRefs.forEach((headerRef) => ui.onAction(headerRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    sortBy(headerRef);
  }));
  if (prevRef) ui.onAction(prevRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    page = Math.max(0, page - 1);
    syncPage();
  });
  if (nextRef) ui.onAction(nextRef, (_ref, detail) => {
    if (detail.action !== "CLICK") return;
    const pageCount = Math.max(1, Math.ceil(rowRefs.length / pageSize));
    page = Math.min(pageCount - 1, page + 1);
    syncPage();
  });
  syncPage();
  syncColumns();
  return {
    sortBy,
    pageTo: (nextPage) => {
      const pageCount = Math.max(1, Math.ceil(rowRefs.length / pageSize));
      page = clampNumber(nextPage, 0, pageCount - 1);
      syncPage();
    },
    showColumn,
    hideColumn,
    setColumnWidth,
    getState: () => ({
      page,
      pageCount: Math.max(1, Math.ceil(rowRefs.length / pageSize)),
      sortRef,
      sortDirection,
      hiddenColumnRefs: [...hiddenHeaders],
      widths: Object.fromEntries(widths),
    }),
  };
}
