/**
 * `createArkField` and `createArkForm` — moved out of `ark-ui.components.ts`
 * verbatim (same logic, same call order, same observable behavior). See
 * ARK_UI_EVOLUTION_PLAN.md Batch 3.
 *
 * One module, not two, because `createArkForm` calls `createArkField` for
 * every field it owns — the label/helper/error wiring a form field needs is
 * exactly what a standalone field already does, so a form is a thin
 * orchestration layer (validation, submit lifecycle, status/summary
 * messaging) on top of it rather than a reimplementation.
 *
 * Built on `@fxn/ui-a11y` for ref normalization, control-value reading,
 * and live-region wiring — the plan's dependency direction:
 * `ark-primitives -> ark-a11y`.
 */
import { normalizeRef, setHidden, textOf, getControlValue } from "@fxn/ui-a11y/dom";

function ref(value) {
  return normalizeRef(value);
}

export function createArkField(ui, options) {
  const fieldRef = ref(options.fieldRef);
  const labelRef = ref(options.labelRef);
  const controlRef = ref(options.controlRef);
  const helperRef = ref(options.helperRef);
  const errorRef = ref(options.errorRef);
  const describedBy = [helperRef, errorRef].filter(Boolean).join(" ") || undefined;

  ui.configureRef(fieldRef, { part: "field" });
  ui.configureRef(labelRef, { part: "label" });
  ui.configureRef(controlRef, {
    labelledBy: labelRef,
    describedBy,
  });
  if (helperRef) ui.configureRef(helperRef, { part: "helper" });
  if (errorRef) {
    ui.configureRef(errorRef, { part: "error" });
    ui.createLiveRegion(errorRef, { politeness: "polite", role: "status" });
  }
  if (options.invalid) {
    ui.configureRef(controlRef, { attrs: { "aria-invalid": "true" } });
  }
  if (options.required) {
    const labelCurrent = ui.get(labelRef) || {};
    if (labelCurrent.text && !labelCurrent.text.includes("*")) ui.update(labelRef, { ...labelCurrent, text: `${labelCurrent.text} *` });
  }
}

export function createArkForm(ui, options) {
  const formRef = ref(options.formRef);
  const submitRef = ref(options.submitRef);
  const statusRef = ref(options.statusRef);
  const errorSummaryRef = ref(options.errorSummaryRef);
  const successRef = ref(options.successRef);
  const fields = options.fields.map((field) => ({
    ...field,
    fieldRef: ref(field.fieldRef),
    labelRef: ref(field.labelRef),
    controlRef: ref(field.controlRef),
    helperRef: ref(field.helperRef),
    errorRef: ref(field.errorRef),
  }));
  const validateOn = options.validateOn ?? "submit";

  const applyFieldError = (field, message) => {
    const invalid = !!message;
    ui.configureRef(field.controlRef, { attrs: { "aria-invalid": invalid ? "true" : "false" } });
    if (field.errorRef) {
      const current = ui.get(field.errorRef) || {};
      ui.update(field.errorRef, { ...current, text: message || "", hidden: !message });
    }
    const current = ui.get(field.fieldRef) || {};
    ui.update(field.fieldRef, { ...current, invalid });
  };

  const values = () => {
    const rawValues = Object.fromEntries(fields.map((field) => [field.name, getControlValue(ui, field.controlRef)]));
    return Object.fromEntries(fields.map((field) => [field.name, field.serialize ? field.serialize(rawValues[field.name], rawValues) : rawValues[field.name]]));
  };

  const validateField = (field, allValues) => {
    const value = allValues[field.name];
    if (field.required) {
      const empty = value === undefined || value === null || value === "" || value === false || (Array.isArray(value) && value.length === 0);
      if (empty) return field.requiredMessage || `${textOf(ui, field.labelRef).replace(/\s+\*$/, "") || field.name} is required`;
    }
    return field.validate?.(value, allValues);
  };

  let lastErrors = {};
  const syncSummary = (errors) => {
    lastErrors = errors;
    const entries = Object.values(errors).filter(Boolean);
    if (errorSummaryRef) {
      const current = ui.get(errorSummaryRef) || {};
      ui.update(errorSummaryRef, { ...current, text: entries.join(" "), hidden: entries.length === 0 });
      ui.createLiveRegion(errorSummaryRef, { politeness: "assertive", role: "alert" });
    }
    options.onValidationChange?.(errors);
  };

  const runValidation = (focusFirstInvalid = false) => {
    const nextValues = values();
    const errors = {};
    fields.forEach((field) => {
      const message = validateField(field, nextValues);
      if (message) errors[field.name] = message;
      applyFieldError(field, message);
    });
    syncSummary(errors);
    if (focusFirstInvalid) {
      const firstInvalid = fields.find((field) => errors[field.name]);
      if (firstInvalid) ui.getElement(firstInvalid.controlRef)?.focus?.();
    }
    return errors;
  };

  const setSubmitting = (submitting, message) => {
    if (submitRef) {
      const current = ui.get(submitRef) || {};
      ui.update(submitRef, { ...current, disabled: submitting, loading: submitting });
    }
    if (statusRef) {
      const current = ui.get(statusRef) || {};
      ui.update(statusRef, { ...current, text: message || (submitting ? "Submitting..." : ""), hidden: !message && !submitting });
      ui.createLiveRegion(statusRef, { politeness: "polite", role: "status" });
    }
  };

  const showSuccess = (visible, message) => {
    if (!successRef) return;
    const current = ui.get(successRef) || {};
    const currentText = typeof current.text === "string" ? current.text : undefined;
    ui.update(successRef, { ...current, hidden: !visible, text: message || currentText || "Saved" });
  };

  const submit = () => {
    const errors = runValidation(true);
    if (Object.keys(errors).length > 0) {
      showSuccess(false);
      setSubmitting(false, "Please fix the highlighted fields.");
      return;
    }
    const nextValues = values();
    showSuccess(false);
    setSubmitting(true);
    try {
      const result = options.onSubmit?.(nextValues);
      if (result && typeof result.then === "function") {
        Promise.resolve(result).then(() => {
          setSubmitting(false, "Saved");
          showSuccess(true, "Saved");
        }).catch((error) => {
          setSubmitting(false, error instanceof Error ? error.message : "Submission failed");
          showSuccess(false);
        });
      } else {
        setSubmitting(false, "Saved");
        showSuccess(true, "Saved");
      }
    } catch (error) {
      setSubmitting(false, error instanceof Error ? error.message : "Submission failed");
      showSuccess(false);
    }
  };

  ui.configureRef(formRef, { part: "form" });
  fields.forEach((field) => {
    createArkField(ui, field);
    if (field.errorRef) setHidden(ui, field.errorRef, true);
    const eventName = validateOn === "input" ? "input" : validateOn === "blur" ? "blur" : undefined;
    if (eventName) ui.bindRefEvent(field.controlRef, eventName, () => {
      const nextValues = values();
      const message = validateField(field, nextValues);
      applyFieldError(field, message);
      const errors = Object.fromEntries(fields.map((entry) => [entry.name, entry === field ? message : (ui.get(entry.errorRef || "")?.text || "")]).filter(([, value]) => value));
      syncSummary(errors);
    });
  });
  if (submitRef) {
    ui.bindRefEvent(submitRef, "click", (rawEvent) => {
      rawEvent.preventDefault();
      submit();
    });
  }
  ui.bindRefEvent(formRef, "submit", (rawEvent) => {
    rawEvent.preventDefault();
    submit();
  });
  if (errorSummaryRef) {
    ui.configureRef(errorSummaryRef, { part: "error-summary" });
    ui.createLiveRegion(errorSummaryRef, { politeness: "assertive", role: "alert" });
    setHidden(ui, errorSummaryRef, true);
  }
  if (statusRef) ui.createLiveRegion(statusRef, { politeness: "polite", role: "status" });
  if (successRef) {
    ui.configureRef(successRef, { part: "success" });
    setHidden(ui, successRef, true);
  }
  // Additive (ARK_UI_EVOLUTION_PLAN.md Batch 6 / Page Builders): previously
  // this function had no return value, so nothing outside a click on its
  // own submitRef could read current values, trigger a submit, or see the
  // last validation result. Every existing caller that ignores the return
  // value keeps working unchanged -- this is what `createArkCoreSettingsForm()`
  // needs for dirty-state tracking (baseline vs. current values() calls).
  return { values, submit, getErrors: () => lastErrors };
}
