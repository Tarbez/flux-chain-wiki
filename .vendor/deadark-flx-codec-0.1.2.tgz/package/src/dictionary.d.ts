export declare const FLX_ARCHIVE_MAGIC = "FLX2";
export declare const FLX_ARCHIVE_FORMAT = "flx-archive";
export declare const FLX_ARCHIVE_MAJOR_VERSION = 2;
export declare const FLX_ARCHIVE_MINOR_VERSION = 2;
export declare const FLX_DEFAULT_CONTENT_TYPES: readonly ["text/html", "text/css", "application/javascript", "application/json", "image/svg+xml", "font/woff2"];
export declare const FLX_CANONICAL_KEYS: readonly ["path", "entry", "routes", "files", "contentType", "size", "payload", "hash", "scope", "guards", "restorePaths", "title", "description", "routeId", "stateId", "layout", "schema", "rootPath", "snapshotVersion", "generatedBy", "sourceFormat", "rawByteLength", "compressedByteLength", "parentArchiveId", "operations", "op", "blockId", "blockType", "deltaKind", "chunkIndex", "chunkCount", "byteOffset", "totalBytes", "resumeToken", "chunkChecksum", "dependencyGraph", "route", "relation", "phase", "required", "receivedBlocks", "receiptState"];
export interface FlxStringRef {
    kind: "string";
    index: number;
}
export interface FlxContentTypeRef {
    kind: "contentType";
    index: number;
}
export interface FlxRouteIdRef {
    kind: "routeId";
    index: number;
}
export interface FlxStateScopeRef {
    kind: "stateScope";
    index: number;
}
export interface FlxKeyRef {
    kind: "key";
    index: number;
}
export interface FlxTokenSegmentRef {
    kind: "token";
    index: number;
}
export interface FlxLiteralSegmentRef {
    kind: "literal";
    value: string;
}
export type FlxSegmentRef = FlxTokenSegmentRef | FlxLiteralSegmentRef;
export interface FlxPathRef {
    kind: "path";
    segments: FlxSegmentRef[];
}
export interface FlxRouteRef {
    kind: "route";
    segments: FlxSegmentRef[];
}
export interface FlxEncodedArray {
    kind: "array";
    items: FlxEncodedValue[];
}
export interface FlxEncodedObject {
    kind: "object";
    entries: Array<[FlxKeyRef | string, FlxEncodedValue]>;
}
export type FlxEncodedValue = null | boolean | number | string | FlxStringRef | FlxContentTypeRef | FlxRouteIdRef | FlxStateScopeRef | FlxPathRef | FlxRouteRef | FlxEncodedArray | FlxEncodedObject;
export interface FlxArchiveDictionary {
    strings: string[];
    paths: string[];
    contentTypes: string[];
    routeIds: string[];
    stateScopes: string[];
    routeTokens: string[];
    keys: string[];
}
export interface FlxDictionaryState {
    dictionary: FlxArchiveDictionary;
    stringIndex: Map<string, number>;
    pathIndex: Map<string, number>;
    contentTypeIndex: Map<string, number>;
    routeIdIndex: Map<string, number>;
    stateScopeIndex: Map<string, number>;
    routeIndex: Map<string, number>;
    keyIndex: Map<string, number>;
}
export interface FlxArchiveDictionaryInput {
    entry: string;
    baseDictionary?: Partial<FlxArchiveDictionary> | null;
    routes?: Array<{
        routeId: string;
        path: string;
        title?: string;
        description?: string;
        guards?: string[];
        restorePaths?: string[];
        dependencyGraph?: Array<{
            route: string;
            relation?: string;
            phase?: string;
            required?: boolean;
        }>;
        layout?: string;
        payload: unknown;
    }>;
    assets?: Array<{
        path: string;
        contentType: string;
        payload: unknown;
        hash?: string;
    }>;
    states?: Array<{
        stateId: string;
        scope: string;
        payload: unknown;
        schema?: string;
        rootPath?: string;
        snapshotVersion?: number;
    }>;
    generatedBy?: string;
    sourceFormat?: string;
    purpose?: string;
    delta?: {
        parentArchiveId: string;
        operations: unknown[];
        baseIntegrity?: string;
        deltaKind?: string;
    } | null;
    continuation?: {
        parentArchiveId: string;
        chunkIndex: number;
        chunkCount: number;
        byteOffset: number;
        totalBytes: number;
        resumeToken?: string;
        chunkChecksum?: string;
        receivedBlocks?: string[];
        receiptState?: string;
    } | null;
}
export declare function createFlxDictionaryState(dictionary?: Partial<FlxArchiveDictionary>): FlxDictionaryState;
export declare function mergeFlxArchiveDictionaries(dictionaries: Array<Partial<FlxArchiveDictionary> | null | undefined>): FlxArchiveDictionary;
export declare const FLX_ARCHIVE_DICTIONARY_LIMIT: number;
export declare function buildFlxArchiveDictionary(input: FlxArchiveDictionaryInput): FlxDictionaryState;
export declare function internString(state: FlxDictionaryState, value: string): FlxStringRef | string;
export declare function internContentType(state: FlxDictionaryState, value: string): FlxContentTypeRef | string;
export declare function internRouteId(state: FlxDictionaryState, value: string): FlxRouteIdRef | string;
export declare function internStateScope(state: FlxDictionaryState, value: string): FlxStateScopeRef | string;
export declare function internKey(state: FlxDictionaryState, value: string): FlxKeyRef | string;
export declare function encodePath(value: string, state: FlxDictionaryState): FlxPathRef;
export declare function decodePath(value: FlxPathRef, dictionary: FlxArchiveDictionary): string;
export declare function encodeRoutePath(value: string, state: FlxDictionaryState): FlxRouteRef;
export declare function decodeRoutePath(value: FlxRouteRef, dictionary: FlxArchiveDictionary): string;
export declare function encodeStructuredValue(value: unknown, state: FlxDictionaryState, hint?: "string" | "path" | "route" | "contentType" | "routeId" | "stateScope"): FlxEncodedValue;
export declare function decodeStructuredValue(value: FlxEncodedValue, dictionary: FlxArchiveDictionary): unknown;
