export declare function blake3(bytes: Uint8Array, outLen?: number): Uint8Array;
/** Bitcoin-alphabet base58, matching the Rust `base58` crate's default encoding used by `flx-engine::hasher`. */
export declare function toBase58(bytes: Uint8Array): string;
/**
 * Content-addresses arbitrary bytes exactly like `flx-engine::hasher::cid_for_bytes`:
 * domain-separation tag `0xff`, 8-byte little-endian length prefix, then the
 * bytes themselves, formatted `flx:<base58_digest>:1`. Two implementations
 * (this one and the Rust one) hashing the same bytes produce the same CID.
 */
export declare function cidForBytes(bytes: Uint8Array): string;
/** Install a native BLAKE3 digest (for example @deadark/flux-core-native blake3Digest); null restores pure JS. */
export declare function useNativeBlake3(digest: ((bytes: Uint8Array, outLen?: number) => Uint8Array) | null): void;
