/**
 * `@deadark/ark-elements` — browser-native Flux custom elements: the
 * hand-authored-HTML, zero-framework, zero-runtime consumption mode for ARK
 * UI. Moved out of `ark-ui.elements.ts` verbatim (same logic, same call
 * order, same observable behavior). See ARK_UI_EVOLUTION_PLAN.md Batch 4.
 *
 * This is a genuinely separate concern from `@deadark/ark-primitives`, not a
 * duplicate of it: a `createArk*()` primitive wires ARIA/keyboard behavior
 * onto DOM the ARK runtime's `ui.render()` pattern-grammar produced, and
 * assumes an `ArkUIInstance` exists. A `Flux*Element` custom element wires
 * the *same kind* of behavior onto hand-authored `<flux-menu>`/`<flux-tabs>`/
 * etc. tags with no runtime present at all — `defineFluxElements()` is often
 * the only ARK import a page using these makes. The two paths never touch
 * the same DOM node (the runtime never emits a `flux-*` tag name), so there
 * is no double-wiring; this package exists because that no-runtime path
 * needs a fully self-contained implementation of its own.
 *
 * This module holds the shared descendant-walking helpers and the
 * `FluxElement` base class every `Flux*Element` in `./elements.js` extends.
 * Only two real dependencies, both already-sibling packages, matching the
 * plan's dependency direction (`ark-elements` never imports `@deadark/ark-ui`
 * itself): a type-only import from `@deadark/flux-dom` for the store
 * adapter shape, and `setArkElementStyle` from `@deadark/ark-a11y` for the
 * same CSP-safe style-writing path every other extracted concern uses.
 */
import { setArkElementStyle } from "@deadark/ark-a11y/element-style";

export function getCustomElementsRegistry() {
  return globalThis.customElements;
}

export function isElementDisabled(el) {
  return el.hasAttribute("disabled") || el.getAttribute("aria-disabled") === "true";
}

export function walkDescendants(root, visit) {
  for (const child of Array.from(root.children || [])) {
    const el = child;
    if (visit(el) === true) return true;
    if (walkDescendants(el, visit)) return true;
  }
  return false;
}

export function isFocusable(el) {
  const tag = el.tagName.toLowerCase();
  if (el.hasAttribute("disabled") || el.getAttribute("aria-disabled") === "true" || el.hasAttribute("hidden")) return false;
  if (tag === "button" || tag === "input" || tag === "textarea" || tag === "select" || tag === "a") return true;
  return typeof el.tabIndex === "number" && (el.tabIndex ?? -1) >= 0;
}

export function collectMenuItems(root) {
  const items = [];
  walkDescendants(root, (el) => {
    if (
      el.getAttribute("role") === "menuitem"
      || el.getAttribute("data-flux-menuitem") === "true"
      || isFocusable(el)
    ) items.push(el);
    return false;
  });
  return items.filter((item) => !item.hasAttribute("disabled") && item.getAttribute("aria-disabled") !== "true" && !item.hasAttribute("hidden"));
}

// Panel contents and nested tab sets belong to their own interaction scopes.
// In particular, a search input inside a panel must never become a tab.
function visitTabScope(root, visit) {
  for (const el of Array.from(root.children || [])) {
    if (el.tagName.toLowerCase() === "flux-tabs") continue;
    const panel = el.getAttribute("role") === "tabpanel" || el.getAttribute("data-flux-panel") === "true";
    visit(el, panel);
    if (!panel) visitTabScope(el, visit);
  }
}

export function collectTabs(root) {
  const items = [];
  visitTabScope(root, (el, panel) => {
    if (!panel && (el.getAttribute("role") === "tab"
      || el.getAttribute("data-flux-tab") === "true" || isFocusable(el))) items.push(el);
  });
  return items.filter((item) => !item.hasAttribute("disabled") && item.getAttribute("aria-disabled") !== "true" && !item.hasAttribute("hidden"));
}

export function collectTabPanels(root) {
  const panels = [];
  visitTabScope(root, (el, panel) => { if (panel) panels.push(el); });
  return panels;
}

export function collectSelectOptions(root) {
  const items = [];
  walkDescendants(root, (el) => {
    if (
      el.getAttribute("data-flux-select-option") === "true"
      || el.getAttribute("role") === "option"
      || (el.getAttribute("data-flux-value") != null && el.getAttribute("data-flux-select-trigger") !== "true")
      || (
        isFocusable(el)
        && el.getAttribute("data-flux-select-trigger") !== "true"
        && el.getAttribute("data-flux-select-value") !== "true"
        && el.getAttribute("data-flux-select-content") !== "true"
      )
    ) items.push(el);
    return false;
  });
  return items;
}

export function collectComboboxOptions(root) {
  const items = [];
  walkDescendants(root, (el) => {
    if (
      el.getAttribute("data-flux-combobox-option") === "true"
      || (el.getAttribute("role") === "option" && el.getAttribute("data-flux-empty") !== "true")
      || (
        el.getAttribute("data-flux-value") != null
        && el.getAttribute("data-flux-combobox-input") !== "true"
        && el.getAttribute("data-flux-empty") !== "true"
      )
      || (
        isFocusable(el)
        && el.getAttribute("data-flux-combobox-input") !== "true"
        && el.getAttribute("data-flux-combobox-content") !== "true"
        && el.getAttribute("data-flux-empty") !== "true"
      )
    ) items.push(el);
    return false;
  });
  return items;
}

export function optionText(option) {
  return String(option.getAttribute("data-flux-label") || option.textContent || "").trim();
}

export function visibleOptions(options) {
  return options.filter((option) => !option.hasAttribute("hidden") && option.getAttribute("aria-disabled") !== "true" && !option.hasAttribute("disabled"));
}

export function parseFluxDate(value) {
  if (!value) return null;
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) return null;
  const year = Number(match[1]);
  const month = Number(match[2]) - 1;
  const day = Number(match[3]);
  const date = new Date(year, month, day);
  if (Number.isNaN(date.getTime())) return null;
  return date;
}

export function formatFluxDate(date) {
  const year = String(date.getFullYear());
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function sameDay(left, right) {
  return !!left && !!right
    && left.getFullYear() === right.getFullYear()
    && left.getMonth() === right.getMonth()
    && left.getDate() === right.getDate();
}

export function formatCalendarLabel(month, year) {
  return new Date(year, month, 1).toLocaleDateString("en-US", { month: "long", year: "numeric" });
}

export function findMarkedDescendant(root, marker) {
  let match = null;
  walkDescendants(root, (el) => {
    if (el.getAttribute(marker) === "true") {
      match = el;
      return true;
    }
    return false;
  });
  return match;
}

export function findFocusableDescendants(root) {
  const items = [];
  walkDescendants(root, (el) => {
    if (isFocusable(el)) items.push(el);
    return false;
  });
  return items;
}

export function textLabelForDate(value) {
  const date = parseFluxDate(value);
  if (!date) return "";
  return date.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

export function eventSurfaceFor(el) {
  const doc = el.ownerDocument;
  if (doc && typeof doc.addEventListener === "function" && typeof doc.removeEventListener === "function") return doc;
  const win = doc?.defaultView || globalThis.window;
  if (win && typeof win.addEventListener === "function" && typeof win.removeEventListener === "function") return win;
  return null;
}

/**
 * Base class for browser-native Flux components.
 *
 * This first pass keeps the contract intentionally small:
 * - platform semantics live on the element itself
 * - `flux-dom` can bind against its attributes/properties directly
 * - subclasses own only behavior, not external framework contracts
 */
export class FluxElement extends HTMLElement {
  static observedAttributes = ["disabled", "aria-disabled"];

  connected = false;
  store;
  syncing = false;

  connectedCallback() {
    if (this.connected) return;
    this.connected = true;
    this.syncBaseSemantics();
  }

  disconnectedCallback() {
    this.connected = false;
  }

  attributeChangedCallback(_name, oldValue, newValue) {
    if (this.syncing) return;
    if (oldValue === newValue) return;
    this.syncBaseSemantics();
  }

  setFluxStore(store) {
    this.store = store;
  }

  defaultRole() {
    return null;
  }

  syncBaseSemantics() {
    if (this.syncing) return;
    this.syncing = true;
    const role = this.defaultRole();
    if (role && !this.getAttribute("role")) this.setAttribute("role", role);
    this.syncing = false;
  }
}
