import type { FluxStoreAdapter } from "@deadark/flux-state/store";

export type { FluxStoreAdapter };

export interface FluxCustomElementsRegistry {
  define(name: string, ctor: CustomElementConstructor): void;
  get(name: string): CustomElementConstructor | undefined;
}

export declare function getCustomElementsRegistry(): FluxCustomElementsRegistry | undefined;
export declare function isElementDisabled(el: HTMLElement): boolean;
export declare function walkDescendants(root: HTMLElement, visit: (el: HTMLElement) => boolean | void): boolean;
export declare function isFocusable(el: HTMLElement): boolean;
export declare function collectMenuItems(root: HTMLElement): HTMLElement[];
export declare function collectTabs(root: HTMLElement): HTMLElement[];
export declare function collectTabPanels(root: HTMLElement): HTMLElement[];
export declare function collectSelectOptions(root: HTMLElement): HTMLElement[];
export declare function collectComboboxOptions(root: HTMLElement): HTMLElement[];
export declare function optionText(option: HTMLElement): string;
export declare function visibleOptions(options: HTMLElement[]): HTMLElement[];
export declare function parseFluxDate(value: string | null): Date | null;
export declare function formatFluxDate(date: Date): string;
export declare function sameDay(left: Date | null, right: Date | null): boolean;
export declare function formatCalendarLabel(month: number, year: number): string;
export declare function findMarkedDescendant(root: HTMLElement, marker: string): HTMLElement | null;
export declare function findFocusableDescendants(root: HTMLElement): HTMLElement[];
export declare function textLabelForDate(value: string): string;

export interface FluxEventSurface {
  addEventListener(type: string, listener: EventListener): void;
  removeEventListener(type: string, listener: EventListener): void;
}

export declare function eventSurfaceFor(el: HTMLElement): FluxEventSurface | null;

/**
 * Base class for browser-native Flux components.
 *
 * This first pass keeps the contract intentionally small:
 * - platform semantics live on the element itself
 * - `flux-dom` can bind against its attributes/properties directly
 * - subclasses own only behavior, not external framework contracts
 */
export declare class FluxElement extends HTMLElement {
  static observedAttributes: string[];
  protected connected: boolean;
  protected store?: FluxStoreAdapter;
  private syncing;
  connectedCallback(): void;
  disconnectedCallback(): void;
  attributeChangedCallback(_name?: string, oldValue?: string | null, newValue?: string | null): void;
  setFluxStore(store: FluxStoreAdapter): void;
  protected defaultRole(): string | null;
  protected syncBaseSemantics(): void;
}
