/**
 * The `Flux*Element` custom-element classes and their `defineFluxXxx()`
 * opt-in registration functions — moved out of `ark-ui.elements.ts`
 * verbatim (same logic, same call order, same observable behavior). See
 * base.js's header for why this package exists as a separate concern from
 * `@deadark/ark-primitives`.
 *
 * Registration is deliberately never a side effect of importing this module:
 * each `defineFluxXxx()` call is what actually calls `customElements.define()`,
 * so a consumer that only calls `defineFluxButton()` registers exactly one
 * tag, and a bundler with `sideEffects: false` (this package declares it)
 * can tree-shake the rest.
 */
import {
  getCustomElementsRegistry,
  isElementDisabled,
  walkDescendants,
  isFocusable,
  collectMenuItems,
  collectTabs,
  collectTabPanels,
  collectSelectOptions,
  collectComboboxOptions,
  optionText,
  visibleOptions,
  parseFluxDate,
  formatFluxDate,
  sameDay,
  formatCalendarLabel,
  findMarkedDescendant,
  findFocusableDescendants,
  textLabelForDate,
  eventSurfaceFor,
  FluxElement,
} from "./base.js";
import { setArkElementStyle } from "@deadark/ark-a11y/element-style";
import { createArkGeneratedId } from "@deadark/ark-a11y/ids";

export class FluxButtonElement extends FluxElement {
  static observedAttributes = ["disabled", "aria-disabled"];

  wired = false;
  enabledTabIndex = 0;
  wasDisabled = false;

  get disabled() {
    return isElementDisabled(this);
  }

  set disabled(value) {
    if (value) {
      this.setAttribute("disabled", "");
      this.setAttribute("aria-disabled", "true");
    } else {
      this.removeAttribute("disabled");
      this.removeAttribute("aria-disabled");
    }
    this.syncBaseSemantics();
  }

  defaultRole() {
    return "button";
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.wired) {
      this.wired = true;
      this.addEventListener("keydown", this.handleKeydown);
      this.addEventListener("click", this.handleClick);
    }
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "button");
    this.syncBaseSemantics();
  }

  disconnectedCallback() {
    if (this.wired) {
      this.removeEventListener("keydown", this.handleKeydown);
      this.removeEventListener("click", this.handleClick);
      this.wired = false;
    }
    super.disconnectedCallback();
  }

  syncBaseSemantics() {
    super.syncBaseSemantics();
    if (this.disabled) {
      this.setAttribute("aria-disabled", "true");
      if (!this.wasDisabled) this.enabledTabIndex = this.hasAttribute("tabindex") ? this.tabIndex : 0;
      this.wasDisabled = true;
      this.tabIndex = -1;
    } else {
      this.removeAttribute("aria-disabled");
      if (this.wasDisabled) { this.tabIndex = this.enabledTabIndex; this.wasDisabled = false; }
      else if (!this.hasAttribute("tabindex")) this.tabIndex = 0;
    }
  }

  handleClick = (event) => {
    if (!this.disabled) return;
    event.preventDefault?.();
    event.stopPropagation?.();
  };

  handleKeydown = (event) => {
    if (this.disabled) {
      event.preventDefault();
      return;
    }
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      this.dispatchEvent(new Event("click", { bubbles: true }));
    }
  };
}

export class FluxDialogElement extends FluxElement {
  static observedAttributes = ["open", "hidden", "aria-labelledby", "aria-describedby"];

  wired = false;
  previousFocus = null;

  get open() {
    return this.hasAttribute("open");
  }

  set open(value) {
    if (value) this.setAttribute("open", "");
    else this.removeAttribute("open");
    this.syncBaseSemantics();
  }

  defaultRole() {
    return "dialog";
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.wired) {
      this.wired = true;
      this.addEventListener("keydown", this.handleKeydown);
      this.addEventListener("click", this.handleClick);
    }
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "dialog");
    this.syncBaseSemantics();
  }

  disconnectedCallback() {
    if (this.wired) {
      this.removeEventListener("keydown", this.handleKeydown);
      this.removeEventListener("click", this.handleClick);
      this.wired = false;
    }
    if (this.open && this.previousFocus && !this.contains(this.previousFocus)) this.previousFocus.focus?.();
    super.disconnectedCallback();
  }

  syncBaseSemantics() {
    const wasOpen = this.getAttribute("data-open-state") === "true";
    super.syncBaseSemantics();
    this.setAttribute("aria-modal", "true");
    this.setAttribute("data-open-state", this.open ? "true" : "false");
    if (this.open) {
      this.removeAttribute("hidden");
      setArkElementStyle(this, "display", "");
      if (!wasOpen) {
        this.previousFocus = this.ownerDocument?.activeElement ?? null;
        this.focusInitialTarget();
      }
    } else {
      this.setAttribute("hidden", "");
      setArkElementStyle(this, "display", "none");
      if (wasOpen) this.previousFocus?.focus?.();
    }
  }

  close() {
    this.open = false;
    this.dispatchEvent(new Event("flux-dismiss", { bubbles: true }));
  }

  focusInitialTarget() {
    let target = null;
    walkDescendants(this, (el) => {
      if (el.getAttribute("data-autofocus") === "true") {
        target = el;
        return true;
      }
      if (!target && isFocusable(el)) target = el;
      return false;
    });
    if (target) target.focus();
  }

  handleKeydown = (event) => {
    if (event.key === "Escape" && this.open) {
      event.preventDefault();
      this.close();
      return;
    }
    if (event.key === "Tab" && this.open) {
      const targets = [];
      walkDescendants(this, (el) => { if (isFocusable(el)) targets.push(el); return false; });
      if (!targets.length) { event.preventDefault(); this.focus(); return; }
      const first = targets[0], last = targets[targets.length - 1];
      const active = this.ownerDocument?.activeElement;
      if (event.shiftKey && (active === first || !this.contains(active))) {
        event.preventDefault(); last.focus();
      } else if (!event.shiftKey && (active === last || !this.contains(active))) {
        event.preventDefault(); first.focus();
      }
    }
  };

  handleClick = (event) => {
    let target = event.target;
    while (target && target !== this) {
      if (target.getAttribute("data-flux-dismiss") === "true") {
        this.close();
        return;
      }
      target = target.parentNode;
    }
  };
}

export class FluxAuthorizationDialogElement extends FluxDialogElement {
  static observedAttributes = [...FluxDialogElement.observedAttributes, "state", "action", "capability"];

  get state() {
    return this.getAttribute("state") || "review";
  }

  set state(value) {
    if (value) this.setAttribute("state", value);
    else this.removeAttribute("state");
  }

  get action() {
    return this.getAttribute("action") || "";
  }

  set action(value) {
    if (value) this.setAttribute("action", value);
    else this.removeAttribute("action");
  }

  get capability() {
    return this.getAttribute("capability") || "";
  }

  set capability(value) {
    if (value) this.setAttribute("capability", value);
    else this.removeAttribute("capability");
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "authorization-dialog");
    this.syncAuthorizationSemantics();
  }

  attributeChangedCallback(name, oldValue, newValue) {
    super.attributeChangedCallback(name, oldValue, newValue);
    this.syncAuthorizationSemantics();
  }

  syncAuthorizationSemantics() {
    this.setAttribute("data-ark-part", "authorization-dialog");
    this.setAttribute("data-state", this.state);
    this.setAttribute("aria-busy", ["signing", "sending"].includes(this.state) ? "true" : "false");
    const action = this.getAttribute("action");
    const capability = this.getAttribute("capability");
    if (action) this.setAttribute("data-action", action); else this.removeAttribute("data-action");
    if (capability) this.setAttribute("data-capability", capability); else this.removeAttribute("data-capability");
  }
}

export class FluxMenuElement extends FluxElement {
  static observedAttributes = ["open", "hidden", "aria-labelledby", "aria-describedby"];

  wired = false;
  previousFocus = null;

  get open() {
    return this.hasAttribute("open");
  }

  set open(value) {
    if (value) this.setAttribute("open", "");
    else this.removeAttribute("open");
    this.syncBaseSemantics();
  }

  defaultRole() {
    return "menu";
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.wired) {
      this.wired = true;
      this.addEventListener("keydown", this.handleKeydown);
      this.addEventListener("click", this.handleClick);
    }
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "menu");
    this.syncItems();
    this.syncBaseSemantics();
  }

  disconnectedCallback() {
    if (this.wired) {
      this.removeEventListener("keydown", this.handleKeydown);
      this.removeEventListener("click", this.handleClick);
      this.wired = false;
    }
    super.disconnectedCallback();
  }

  syncBaseSemantics() {
    const wasOpen = this.getAttribute("data-open-state") === "true";
    super.syncBaseSemantics();
    this.setAttribute("data-open-state", this.open ? "true" : "false");
    this.syncItems();
    if (this.open) {
      this.removeAttribute("hidden");
      setArkElementStyle(this, "display", "");
      if (!wasOpen) {
        this.previousFocus = this.ownerDocument?.activeElement ?? null;
        this.focusItem(0);
      }
    } else {
      this.setAttribute("hidden", "");
      setArkElementStyle(this, "display", "none");
      if (wasOpen) this.previousFocus?.focus?.();
    }
  }

  close() {
    this.open = false;
    this.dispatchEvent(new Event("flux-dismiss", { bubbles: true }));
  }

  syncItems() {
    const items = collectMenuItems(this);
    items.forEach((item, index) => {
      if (!item.getAttribute("role")) item.setAttribute("role", "menuitem");
      if (!item.hasAttribute("data-flux-menuitem")) item.setAttribute("data-flux-menuitem", "true");
      if (document.activeElement === item) item.tabIndex = 0;
      else if (!item.hasAttribute("tabindex")) item.tabIndex = index === 0 && this.open ? 0 : -1;
    });
  }

  focusItem(index) {
    const items = collectMenuItems(this);
    if (items.length === 0) return;
    const nextIndex = (index + items.length) % items.length;
    items.forEach((item, itemIndex) => { item.tabIndex = itemIndex === nextIndex ? 0 : -1; });
    items[nextIndex].focus();
  }

  moveFocus(delta) {
    const items = collectMenuItems(this);
    if (items.length === 0) return;
    const currentIndex = Math.max(0, items.findIndex((item) => item === document.activeElement));
    this.focusItem(currentIndex + delta);
  }

  handleKeydown = (event) => {
    if (!this.open) return;
    if (event.key === "Escape") {
      event.preventDefault();
      this.close();
      return;
    }
    if (event.key === "ArrowDown") {
      event.preventDefault();
      this.moveFocus(1);
      return;
    }
    if (event.key === "ArrowUp") {
      event.preventDefault();
      this.moveFocus(-1);
      return;
    }
    if (event.key === "Home") {
      event.preventDefault();
      this.focusItem(0);
      return;
    }
    if (event.key === "End") {
      event.preventDefault();
      const items = collectMenuItems(this);
      this.focusItem(items.length - 1);
    }
  };

  handleClick = (event) => {
    let target = event.target;
    while (target && target !== this) {
      if (target.getAttribute("data-flux-dismiss") === "true" || target.getAttribute("role") === "menuitem" || target.getAttribute("data-flux-menuitem") === "true") {
        this.close();
        return;
      }
      target = target.parentNode;
    }
  };
}

export class FluxTabsElement extends FluxElement {
  // Generated ids carry the one reserved prefix (`ark-r-`, @deadark/ark-a11y/ids)
  // so a CMS never keys saved edits by a mount-order counter. Explicit ids win.
  tabIdPrefix = createArkGeneratedId("flux-tabs");
  static observedAttributes = ["data-flux-selected-index", "aria-orientation"];

  wired = false;

  get selectedIndex() {
    const raw = this.getAttribute("data-flux-selected-index");
    const parsed = raw == null ? 0 : Number(raw);
    return Number.isFinite(parsed) ? Math.max(0, parsed) : 0;
  }

  set selectedIndex(value) {
    this.setAttribute("data-flux-selected-index", String(Math.max(0, value)));
    this.syncBaseSemantics();
  }

  defaultRole() {
    return "tablist";
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.wired) {
      this.wired = true;
      this.addEventListener("keydown", this.handleKeydown);
      this.addEventListener("click", this.handleClick);
    }
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "tabs");
    if (!this.getAttribute("aria-orientation")) this.setAttribute("aria-orientation", "horizontal");
    this.syncBaseSemantics();
  }

  disconnectedCallback() {
    if (this.wired) {
      this.removeEventListener("keydown", this.handleKeydown);
      this.removeEventListener("click", this.handleClick);
      this.wired = false;
    }
    super.disconnectedCallback();
  }

  syncBaseSemantics() {
    super.syncBaseSemantics();
    const tabs = collectTabs(this);
    const panels = collectTabPanels(this);
    const selectedIndex = Math.min(this.selectedIndex, Math.max(0, tabs.length - 1));
    tabs.forEach((tab, index) => {
      if (!tab.getAttribute("role")) tab.setAttribute("role", "tab");
      if (!tab.hasAttribute("data-flux-tab")) tab.setAttribute("data-flux-tab", "true");
      const selected = index === selectedIndex;
      tab.setAttribute("aria-selected", selected ? "true" : "false");
      tab.tabIndex = selected ? 0 : -1;
      const panel = panels[index];
      if (panel) {
        if (!panel.getAttribute("role")) panel.setAttribute("role", "tabpanel");
        if (!panel.hasAttribute("data-flux-panel")) panel.setAttribute("data-flux-panel", "true");
        if (!tab.id) tab.setAttribute("id", `${this.tabIdPrefix}-tab-${index + 1}`);
        if (!panel.id) panel.setAttribute("id", `${this.tabIdPrefix}-panel-${index + 1}`);
        tab.setAttribute("aria-controls", panel.getAttribute("id"));
        panel.setAttribute("aria-labelledby", tab.getAttribute("id") || "");
        if (selected) {
          panel.removeAttribute("hidden");
          setArkElementStyle(panel, "display", "");
        } else {
          panel.setAttribute("hidden", "");
          setArkElementStyle(panel, "display", "none");
        }
      }
    });
  }

  selectIndex(index, focus = true) {
    const tabs = collectTabs(this);
    if (tabs.length === 0) return;
    const nextIndex = (index + tabs.length) % tabs.length;
    this.selectedIndex = nextIndex;
    if (focus) tabs[nextIndex].focus();
  }

  handleClick = (event) => {
    let target = event.target;
    const tabs = collectTabs(this);
    while (target && target !== this) {
      const index = tabs.indexOf(target);
      if (index !== -1) {
        this.selectIndex(index, false);
        return;
      }
      target = target.parentNode;
    }
  };

  handleKeydown = (event) => {
    const tabs = collectTabs(this);
    if (tabs.length === 0) return;
    // Tabs own navigation only while focus is on a tab trigger. Inputs,
    // selectable text, and nested tab sets inside panels keep their keys.
    const currentIndex = tabs.findIndex((tab) => tab === event.target);
    if (currentIndex < 0 || event.altKey || event.ctrlKey || event.metaKey) return;
    const orientation = this.getAttribute("aria-orientation") || "horizontal";
    if ((orientation === "horizontal" && event.key === "ArrowRight") || (orientation === "vertical" && event.key === "ArrowDown")) {
      event.preventDefault();
      this.selectIndex(currentIndex + 1);
      return;
    }
    if ((orientation === "horizontal" && event.key === "ArrowLeft") || (orientation === "vertical" && event.key === "ArrowUp")) {
      event.preventDefault();
      this.selectIndex(currentIndex - 1);
      return;
    }
    if (event.key === "Home") {
      event.preventDefault();
      this.selectIndex(0);
      return;
    }
    if (event.key === "End") {
      event.preventDefault();
      this.selectIndex(tabs.length - 1);
    }
  };
}

export class FluxSelectElement extends FluxElement {
  static observedAttributes = ["open", "hidden", "aria-labelledby", "aria-describedby", "data-flux-selected"];

  wired = false;
  previousFocus = null;
  highlightedIndex = 0;

  get open() {
    return this.hasAttribute("open");
  }

  set open(value) {
    if (value) this.setAttribute("open", "");
    else this.removeAttribute("open");
    this.syncBaseSemantics();
  }

  get selectedValue() {
    return this.getAttribute("data-flux-selected") || "";
  }

  set selectedValue(value) {
    if (value == null || value === "undefined") this.removeAttribute("data-flux-selected");
    else this.setAttribute("data-flux-selected", value);
    this.syncBaseSemantics();
  }

  defaultRole() {
    return "group";
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.wired) {
      this.wired = true;
      this.addEventListener("keydown", this.handleKeydown);
      this.addEventListener("click", this.handleClick);
      const surface = eventSurfaceFor(this);
      surface?.addEventListener("click", this.handleOutsideClick);
      surface?.addEventListener("focusin", this.handleOutsideFocus);
    }
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "select");
    this.syncBaseSemantics();
  }

  disconnectedCallback() {
    if (this.wired) {
      this.removeEventListener("keydown", this.handleKeydown);
      this.removeEventListener("click", this.handleClick);
      const surface = eventSurfaceFor(this);
      surface?.removeEventListener("click", this.handleOutsideClick);
      surface?.removeEventListener("focusin", this.handleOutsideFocus);
      this.wired = false;
    }
    super.disconnectedCallback();
  }

  syncBaseSemantics() {
    const wasOpen = this.getAttribute("data-open-state") === "true";
    super.syncBaseSemantics();
    const trigger = this.trigger();
    const value = this.valueNode();
    const content = this.contentNode();
    const options = collectSelectOptions(this);
    const selectedIndex = this.resolveSelectedIndex(options);
    this.highlightedIndex = Math.max(0, Math.min(this.highlightedIndex, Math.max(0, options.length - 1)));

    if (trigger) {
      trigger.setAttribute("role", "button");
      trigger.setAttribute("aria-haspopup", "listbox");
      trigger.setAttribute("aria-expanded", this.open ? "true" : "false");
      if (!trigger.hasAttribute("tabindex")) trigger.tabIndex = 0;
    }
    if (content) {
      content.setAttribute("role", "listbox");
      if (this.open) {
        content.removeAttribute("hidden");
        setArkElementStyle(content, "display", "");
      } else {
        content.setAttribute("hidden", "");
        setArkElementStyle(content, "display", "none");
      }
    }

    options.forEach((option, index) => {
      option.setAttribute("role", "option");
      option.setAttribute("data-flux-select-option", "true");
      const selected = index === selectedIndex;
      option.setAttribute("aria-selected", selected ? "true" : "false");
      option.tabIndex = this.open && index === this.highlightedIndex ? 0 : -1;
    });

    const selectedOption = options[selectedIndex];
    if (value && selectedOption) value.textContent = optionText(selectedOption);
    this.setAttribute("data-open-state", this.open ? "true" : "false");

    if (this.open && !wasOpen) {
      this.previousFocus = this.ownerDocument?.activeElement ?? null;
      this.highlightedIndex = selectedIndex;
      options[this.highlightedIndex]?.focus?.();
    }
    if (!this.open && wasOpen) this.previousFocus?.focus?.();
  }

  trigger() {
    let match = null;
    walkDescendants(this, (el) => {
      if (el.getAttribute("data-flux-select-trigger") === "true") {
        match = el;
        return true;
      }
      return false;
    });
    return match;
  }

  valueNode() {
    let match = null;
    walkDescendants(this, (el) => {
      if (el.getAttribute("data-flux-select-value") === "true") {
        match = el;
        return true;
      }
      return false;
    });
    return match;
  }

  contentNode() {
    let match = null;
    walkDescendants(this, (el) => {
      if (el.getAttribute("data-flux-select-content") === "true") {
        match = el;
        return true;
      }
      return false;
    });
    return match;
  }

  resolveSelectedIndex(options) {
    const selected = this.selectedValue;
    if (!selected) return 0;
    const index = options.findIndex((option) => (option.getAttribute("data-flux-value") || optionText(option)) === selected);
    return index === -1 ? 0 : index;
  }

  toggle() {
    this.open = !this.open;
  }

  focusIndex(index) {
    const options = visibleOptions(collectSelectOptions(this));
    if (options.length === 0) return;
    this.highlightedIndex = (index + options.length) % options.length;
    options.forEach((option, optionIndex) => { option.tabIndex = optionIndex === this.highlightedIndex ? 0 : -1; });
    options[this.highlightedIndex].focus();
  }

  commit(option) {
    const nextValue = option.getAttribute("data-flux-value") || optionText(option);
    this.selectedValue = nextValue;
    this.open = false;
    this.dispatchEvent(new Event("change", { bubbles: true }));
  }

  handleClick = (event) => {
    let target = event.target;
    while (target && target !== this) {
      if (target.getAttribute("data-flux-select-trigger") === "true") {
        this.toggle();
        return;
      }
      if (target.getAttribute("data-flux-select-option") === "true" || target.getAttribute("role") === "option") {
        this.commit(target);
        return;
      }
      target = target.parentNode;
    }
  };

  handleKeydown = (event) => {
    const target = event.target;
    const isTrigger = target?.getAttribute("data-flux-select-trigger") === "true";
    const options = visibleOptions(collectSelectOptions(this));
    if (isTrigger && (event.key === "ArrowDown" || event.key === "Enter" || event.key === " ")) {
      event.preventDefault();
      this.open = true;
      this.focusIndex(this.resolveSelectedIndex(options));
      return;
    }
    if (!this.open) return;
    if (event.key === "Escape") {
      event.preventDefault();
      this.open = false;
      return;
    }
    if (event.key === "ArrowDown") {
      event.preventDefault();
      this.focusIndex(this.highlightedIndex + 1);
      return;
    }
    if (event.key === "ArrowUp") {
      event.preventDefault();
      this.focusIndex(this.highlightedIndex - 1);
      return;
    }
    if (event.key === "Home") {
      event.preventDefault();
      this.focusIndex(0);
      return;
    }
    if (event.key === "End") {
      event.preventDefault();
      this.focusIndex(options.length - 1);
      return;
    }
    if ((event.key === "Enter" || event.key === " ") && target && (target.getAttribute("data-flux-select-option") === "true" || target.getAttribute("role") === "option")) {
      event.preventDefault();
      this.commit(target);
    }
  };

  handleOutsideClick = (event) => {
    const target = event.target;
    if (!this.open || !target || this.contains(target)) return;
    this.open = false;
  };

  handleOutsideFocus = (event) => {
    const target = event.target;
    if (!this.open || !target || this.contains(target)) return;
    this.open = false;
  };
}

export class FluxComboboxElement extends FluxElement {
  static observedAttributes = ["open", "hidden", "aria-labelledby", "aria-describedby", "data-flux-selected"];

  wired = false;
  activeIndex = 0;
  committedText = "";

  get open() {
    return this.hasAttribute("open");
  }

  set open(value) {
    if (value) this.setAttribute("open", "");
    else this.removeAttribute("open");
    this.syncBaseSemantics();
  }

  get selectedValue() {
    return this.getAttribute("data-flux-selected") || "";
  }

  set selectedValue(value) {
    if (value == null || value === "undefined") this.removeAttribute("data-flux-selected");
    else this.setAttribute("data-flux-selected", value);
    this.syncBaseSemantics();
  }

  defaultRole() {
    return "group";
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.wired) {
      this.wired = true;
      this.addEventListener("keydown", this.handleKeydown);
      this.addEventListener("click", this.handleClick);
      this.addEventListener("input", this.handleInput);
      this.addEventListener("focus", this.handleFocus);
      const surface = eventSurfaceFor(this);
      surface?.addEventListener("click", this.handleOutsideClick);
      surface?.addEventListener("focusin", this.handleOutsideFocus);
    }
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "combobox");
    this.syncBaseSemantics();
  }

  disconnectedCallback() {
    if (this.wired) {
      this.removeEventListener("keydown", this.handleKeydown);
      this.removeEventListener("click", this.handleClick);
      this.removeEventListener("input", this.handleInput);
      this.removeEventListener("focus", this.handleFocus);
      const surface = eventSurfaceFor(this);
      surface?.removeEventListener("click", this.handleOutsideClick);
      surface?.removeEventListener("focusin", this.handleOutsideFocus);
      this.wired = false;
    }
    super.disconnectedCallback();
  }

  syncBaseSemantics() {
    super.syncBaseSemantics();
    const input = this.inputNode();
    const content = this.contentNode();
    const empty = this.emptyNode();
    const options = collectComboboxOptions(this);
    const visible = visibleOptions(options);
    const committed = this.resolveCommittedOption(options);

    if (input) {
      input.setAttribute("role", "combobox");
      input.setAttribute("aria-haspopup", "listbox");
      input.setAttribute("aria-expanded", this.open ? "true" : "false");
      if (content?.id) input.setAttribute("aria-controls", content.id);
      const nextCommittedText = committed ? optionText(committed) : "";
      if (nextCommittedText && (!this.committedText || input.value === this.committedText || !input.value)) {
        this.committedText = nextCommittedText;
        input.value = nextCommittedText;
      }
    }
    if (content) {
      content.setAttribute("role", "listbox");
      if (this.open && visible.length > 0) {
        content.removeAttribute("hidden");
        setArkElementStyle(content, "display", "");
      } else {
        content.setAttribute("hidden", "");
        setArkElementStyle(content, "display", "none");
      }
    }

    const active = visible[this.activeIndex] || visible[0];
    options.forEach((option) => {
      option.setAttribute("role", "option");
      option.setAttribute("data-flux-combobox-option", "true");
      option.setAttribute("aria-selected", option === active ? "true" : "false");
      option.tabIndex = -1;
    });

    if (empty) {
      empty.setAttribute("data-flux-empty", "true");
      if (visible.length === 0) empty.removeAttribute("hidden");
      else empty.setAttribute("hidden", "");
    }

    if (input && active) {
      // One fresh id per option, never derived from activeIndex: an index-based id
      // was repeated across instances and, after filtering, inside one instance.
      if (!active.id) active.setAttribute("id", createArkGeneratedId("flux-combobox-option"));
      input.setAttribute("aria-activedescendant", active.id);
    }
  }

  inputNode() {
    let match = null;
    walkDescendants(this, (el) => {
      if (el.getAttribute("data-flux-combobox-input") === "true") {
        match = el;
        return true;
      }
      return false;
    });
    return match;
  }

  contentNode() {
    let match = null;
    walkDescendants(this, (el) => {
      if (el.getAttribute("data-flux-combobox-content") === "true") {
        match = el;
        return true;
      }
      return false;
    });
    return match;
  }

  emptyNode() {
    let match = null;
    walkDescendants(this, (el) => {
      if (el.getAttribute("data-flux-empty") === "true") {
        match = el;
        return true;
      }
      return false;
    });
    return match;
  }

  resolveCommittedOption(options) {
    const selected = this.selectedValue;
    if (!selected) return options[0] || null;
    return options.find((option) => (option.getAttribute("data-flux-value") || optionText(option)) === selected) || options[0] || null;
  }

  filter(query) {
    const options = collectComboboxOptions(this);
    const normalized = query.trim().toLowerCase();
    options.forEach((option) => {
      const matches = normalized.length === 0 || optionText(option).toLowerCase().includes(normalized);
      if (matches) option.removeAttribute("hidden");
      else option.setAttribute("hidden", "");
    });
    this.activeIndex = 0;
    this.open = visibleOptions(options).length > 0;
    this.syncBaseSemantics();
  }

  commit(option) {
    const label = optionText(option);
    const value = option.getAttribute("data-flux-value") || label;
    this.selectedValue = value;
    this.committedText = label;
    const input = this.inputNode();
    if (input) input.value = label;
    this.open = false;
    this.dispatchEvent(new Event("change", { bubbles: true }));
  }

  moveActive(delta) {
    const options = visibleOptions(collectComboboxOptions(this));
    if (options.length === 0) return;
    this.activeIndex = (this.activeIndex + delta + options.length) % options.length;
    this.syncBaseSemantics();
  }

  handleInput = (event) => {
    const target = event.target;
    if (!target || target.getAttribute("data-flux-combobox-input") !== "true") return;
    this.filter(target.value);
  };

  handleFocus = (event) => {
    const target = event.target;
    if (target?.getAttribute("data-flux-combobox-input") !== "true") return;
    this.open = visibleOptions(collectComboboxOptions(this)).length > 0;
  };

  handleClick = (event) => {
    let target = event.target;
    while (target && target !== this) {
      if (target.getAttribute("data-flux-combobox-option") === "true" || target.getAttribute("role") === "option") {
        this.commit(target);
        return;
      }
      target = target.parentNode;
    }
  };

  handleKeydown = (event) => {
    const input = this.inputNode();
    const target = event.target;
    if (!input || target !== input) return;
    const options = visibleOptions(collectComboboxOptions(this));
    if (options.length === 0 && event.key !== "Escape") return;
    if (event.key === "ArrowDown") {
      event.preventDefault();
      this.open = true;
      this.moveActive(1);
      return;
    }
    if (event.key === "ArrowUp") {
      event.preventDefault();
      this.open = true;
      this.moveActive(-1);
      return;
    }
    if (event.key === "Enter") {
      const active = options[this.activeIndex] || options[0];
      if (!active) return;
      event.preventDefault();
      this.commit(active);
      return;
    }
    if (event.key === "Escape") {
      event.preventDefault();
      const committed = this.resolveCommittedOption(collectComboboxOptions(this));
      input.value = this.committedText || optionText(committed || input);
      this.filter(input.value);
      this.open = false;
    }
  };

  handleOutsideClick = (event) => {
    const target = event.target;
    if (!this.open || !target || this.contains(target)) return;
    const input = this.inputNode();
    const committed = this.resolveCommittedOption(collectComboboxOptions(this));
    if (input) input.value = this.committedText || optionText(committed || input);
    this.filter(input?.value || "");
    this.open = false;
  };

  handleOutsideFocus = (event) => {
    const target = event.target;
    if (!this.open || !target || this.contains(target)) return;
    this.open = false;
  };
}

export class FluxPopoverElement extends FluxElement {
  static observedAttributes = ["open", "hidden", "aria-labelledby", "aria-describedby"];

  wired = false;
  previousFocus = null;

  get open() {
    return this.hasAttribute("open");
  }

  set open(value) {
    if (value) this.setAttribute("open", "");
    else this.removeAttribute("open");
    this.syncBaseSemantics();
  }

  defaultRole() {
    return "group";
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.wired) {
      this.wired = true;
      this.addEventListener("click", this.handleClick);
      this.addEventListener("keydown", this.handleKeydown);
      const surface = eventSurfaceFor(this);
      surface?.addEventListener("click", this.handleOutsideClick);
      surface?.addEventListener("focusin", this.handleOutsideFocus);
    }
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "popover");
    this.syncBaseSemantics();
  }

  disconnectedCallback() {
    if (this.wired) {
      this.removeEventListener("click", this.handleClick);
      this.removeEventListener("keydown", this.handleKeydown);
      const surface = eventSurfaceFor(this);
      surface?.removeEventListener("click", this.handleOutsideClick);
      surface?.removeEventListener("focusin", this.handleOutsideFocus);
      this.wired = false;
    }
    super.disconnectedCallback();
  }

  syncBaseSemantics() {
    const wasOpen = this.getAttribute("data-open-state") === "true";
    super.syncBaseSemantics();
    const trigger = findMarkedDescendant(this, "data-flux-popover-trigger");
    const content = findMarkedDescendant(this, "data-flux-popover-content");
    if (trigger) {
      trigger.setAttribute("role", "button");
      trigger.setAttribute("aria-haspopup", "dialog");
      trigger.setAttribute("aria-expanded", this.open ? "true" : "false");
      if (!trigger.hasAttribute("tabindex")) trigger.tabIndex = 0;
    }
    if (content) {
      content.setAttribute("role", "dialog");
      if (this.open) {
        content.removeAttribute("hidden");
        setArkElementStyle(content, "display", "");
      } else {
        content.setAttribute("hidden", "");
        setArkElementStyle(content, "display", "none");
      }
    }
    this.setAttribute("data-open-state", this.open ? "true" : "false");
    if (this.open && !wasOpen) {
      this.previousFocus = this.ownerDocument?.activeElement ?? null;
      const first = content ? findFocusableDescendants(content)[0] : null;
      first?.focus?.();
    }
    if (!this.open && wasOpen) this.previousFocus?.focus?.();
  }

  close() {
    this.open = false;
    this.dispatchEvent(new Event("flux-dismiss", { bubbles: true }));
  }

  handleClick = (event) => {
    let target = event.target;
    while (target && target !== this) {
      if (target.getAttribute("data-flux-popover-trigger") === "true") {
        this.open = !this.open;
        return;
      }
      if (target.getAttribute("data-flux-dismiss") === "true") {
        this.close();
        return;
      }
      target = target.parentNode;
    }
  };

  handleKeydown = (event) => {
    if (event.key === "Escape" && this.open) {
      event.preventDefault();
      this.close();
    }
  };

  handleOutsideClick = (event) => {
    const target = event.target;
    if (!this.open || !target || this.contains(target)) return;
    this.close();
  };

  handleOutsideFocus = (event) => {
    const target = event.target;
    if (!this.open || !target || this.contains(target)) return;
    this.close();
  };
}

export class FluxSheetElement extends FluxDialogElement {
  static observedAttributes = [...FluxDialogElement.observedAttributes, "data-flux-side"];

  connectedCallback() {
    super.connectedCallback();
    this.setAttribute("data-ark-part", "sheet");
    if (!this.getAttribute("data-flux-side")) this.setAttribute("data-flux-side", "right");
  }
}

export class FluxDrawerElement extends FluxSheetElement {
  connectedCallback() {
    super.connectedCallback();
    this.setAttribute("data-ark-part", "drawer");
    this.setAttribute("data-flux-side", "bottom");
  }
}

export class FluxCommandElement extends FluxElement {
  static observedAttributes = ["open", "hidden", "data-flux-selected"];

  wired = false;
  activeIndex = 0;

  get open() {
    return this.hasAttribute("open");
  }

  set open(value) {
    if (value) this.setAttribute("open", "");
    else this.removeAttribute("open");
    this.syncBaseSemantics();
  }

  get selectedValue() {
    return this.getAttribute("data-flux-selected") || "";
  }

  set selectedValue(value) {
    if (value == null || value === "undefined") this.removeAttribute("data-flux-selected");
    else this.setAttribute("data-flux-selected", value);
    this.syncBaseSemantics();
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.wired) {
      this.wired = true;
      this.addEventListener("keydown", this.handleKeydown);
      this.addEventListener("click", this.handleClick);
      this.addEventListener("input", this.handleInput);
      this.addEventListener("focus", this.handleFocus);
      const surface = eventSurfaceFor(this);
      surface?.addEventListener("click", this.handleOutsideClick);
      surface?.addEventListener("focusin", this.handleOutsideFocus);
    }
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "command");
    this.syncBaseSemantics();
  }

  disconnectedCallback() {
    if (this.wired) {
      this.removeEventListener("keydown", this.handleKeydown);
      this.removeEventListener("click", this.handleClick);
      this.removeEventListener("input", this.handleInput);
      this.removeEventListener("focus", this.handleFocus);
      const surface = eventSurfaceFor(this);
      surface?.removeEventListener("click", this.handleOutsideClick);
      surface?.removeEventListener("focusin", this.handleOutsideFocus);
      this.wired = false;
    }
    super.disconnectedCallback();
  }

  syncBaseSemantics() {
    super.syncBaseSemantics();
    const input = findMarkedDescendant(this, "data-flux-command-input");
    const content = findMarkedDescendant(this, "data-flux-command-content");
    const empty = findMarkedDescendant(this, "data-flux-empty");
    const options = this.options();
    const visible = visibleOptions(options);
    const active = visible[this.activeIndex] || visible[0];

    if (input) {
      input.setAttribute("role", "combobox");
      input.setAttribute("aria-expanded", this.open ? "true" : "false");
      input.setAttribute("aria-haspopup", "listbox");
      if (!input.value && this.selectedValue) input.value = this.selectedValue;
    }
    if (content) {
      content.setAttribute("role", "listbox");
      if (this.open && visible.length > 0) {
        content.removeAttribute("hidden");
        setArkElementStyle(content, "display", "");
      } else {
        content.setAttribute("hidden", "");
        setArkElementStyle(content, "display", "none");
      }
    }

    options.forEach((option) => {
      option.setAttribute("role", "option");
      option.setAttribute("data-flux-command-option", "true");
      option.setAttribute("aria-selected", option === active ? "true" : "false");
    });

    if (empty) {
      if (visible.length === 0) empty.removeAttribute("hidden");
      else empty.setAttribute("hidden", "");
    }

    if (input && active) {
      // Same rule as flux-combobox: one fresh, prefixed id per option.
      if (!active.id) active.setAttribute("id", createArkGeneratedId("flux-command-option"));
      input.setAttribute("aria-activedescendant", active.id);
    }
  }

  options() {
    const items = [];
    walkDescendants(this, (el) => {
      if (
        el.getAttribute("data-flux-command-option") === "true"
        || (
          isFocusable(el)
          && el.getAttribute("data-flux-command-input") !== "true"
          && el.getAttribute("data-flux-command-content") !== "true"
          && el.getAttribute("data-flux-empty") !== "true"
        )
      ) items.push(el);
      return false;
    });
    return items;
  }

  filter(query) {
    const normalized = query.trim().toLowerCase();
    this.options().forEach((option) => {
      const matches = normalized.length === 0 || optionText(option).toLowerCase().includes(normalized);
      if (matches) option.removeAttribute("hidden");
      else option.setAttribute("hidden", "");
    });
    this.activeIndex = 0;
    this.open = visibleOptions(this.options()).length > 0;
    this.syncBaseSemantics();
  }

  commit(option) {
    const value = optionText(option);
    this.selectedValue = value;
    const input = findMarkedDescendant(this, "data-flux-command-input");
    if (input) input.value = value;
    this.open = false;
    this.dispatchEvent(new Event("change", { bubbles: true }));
  }

  handleInput = (event) => {
    const target = event.target;
    if (!target || target.getAttribute("data-flux-command-input") !== "true") return;
    this.filter(target.value);
  };

  handleFocus = (event) => {
    const target = event.target;
    if (!target || target.getAttribute("data-flux-command-input") !== "true") return;
    this.open = visibleOptions(this.options()).length > 0;
  };

  handleClick = (event) => {
    let target = event.target;
    while (target && target !== this) {
      if (target.getAttribute("data-flux-command-option") === "true" || target.getAttribute("role") === "option") {
        this.commit(target);
        return;
      }
      target = target.parentNode;
    }
  };

  handleKeydown = (event) => {
    const input = findMarkedDescendant(this, "data-flux-command-input");
    const target = event.target;
    if (!input || target !== input) return;
    const options = visibleOptions(this.options());
    if (options.length === 0 && event.key !== "Escape") return;
    if (event.key === "ArrowDown") {
      event.preventDefault();
      this.open = true;
      this.activeIndex = (this.activeIndex + 1 + options.length) % options.length;
      this.syncBaseSemantics();
      return;
    }
    if (event.key === "ArrowUp") {
      event.preventDefault();
      this.open = true;
      this.activeIndex = (this.activeIndex - 1 + options.length) % options.length;
      this.syncBaseSemantics();
      return;
    }
    if (event.key === "Enter") {
      event.preventDefault();
      this.commit(options[this.activeIndex] || options[0]);
      return;
    }
    if (event.key === "Escape") {
      event.preventDefault();
      input.value = this.selectedValue;
      this.open = false;
      this.syncBaseSemantics();
    }
  };

  handleOutsideClick = (event) => {
    const target = event.target;
    if (!this.open || !target || this.contains(target)) return;
    const input = findMarkedDescendant(this, "data-flux-command-input");
    if (input) input.value = this.selectedValue;
    this.open = false;
    this.syncBaseSemantics();
  };

  handleOutsideFocus = (event) => {
    const target = event.target;
    if (!this.open || !target || this.contains(target)) return;
    this.open = false;
    this.syncBaseSemantics();
  };
}

export class FluxDatePickerElement extends FluxElement {
  static observedAttributes = ["open", "hidden", "data-flux-selected"];

  wired = false;
  previousFocus = null;

  get open() {
    return this.hasAttribute("open");
  }

  set open(value) {
    if (value) this.setAttribute("open", "");
    else this.removeAttribute("open");
    this.syncBaseSemantics();
  }

  get selectedValue() {
    return this.getAttribute("data-flux-selected") || "";
  }

  set selectedValue(value) {
    if (value == null || value === "undefined") this.removeAttribute("data-flux-selected");
    else this.setAttribute("data-flux-selected", value);
    this.syncBaseSemantics();
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.wired) {
      this.wired = true;
      this.addEventListener("click", this.handleClick);
      this.addEventListener("keydown", this.handleKeydown);
      this.addEventListener("change", this.handleCalendarChange, { capture: true });
      const surface = eventSurfaceFor(this);
      surface?.addEventListener("click", this.handleOutsideClick);
      surface?.addEventListener("focusin", this.handleOutsideFocus);
    }
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "datepicker");
    this.syncBaseSemantics();
  }

  disconnectedCallback() {
    if (this.wired) {
      this.removeEventListener("click", this.handleClick);
      this.removeEventListener("keydown", this.handleKeydown);
      this.removeEventListener("change", this.handleCalendarChange, { capture: true });
      const surface = eventSurfaceFor(this);
      surface?.removeEventListener("click", this.handleOutsideClick);
      surface?.removeEventListener("focusin", this.handleOutsideFocus);
      this.wired = false;
    }
    super.disconnectedCallback();
  }

  syncBaseSemantics() {
    const wasOpen = this.getAttribute("data-open-state") === "true";
    super.syncBaseSemantics();
    const trigger = findMarkedDescendant(this, "data-flux-datepicker-trigger");
    const value = findMarkedDescendant(this, "data-flux-datepicker-value");
    const content = findMarkedDescendant(this, "data-flux-datepicker-content");
    const calendar = this.calendar();
    if (trigger) {
      trigger.setAttribute("role", "button");
      trigger.setAttribute("aria-haspopup", "dialog");
      trigger.setAttribute("aria-expanded", this.open ? "true" : "false");
      if (!trigger.hasAttribute("tabindex")) trigger.tabIndex = 0;
    }
    if (value) value.textContent = textLabelForDate(this.selectedValue) || "Pick date";
    if (content) {
      if (this.open) {
        content.removeAttribute("hidden");
        setArkElementStyle(content, "display", "");
      } else {
        content.setAttribute("hidden", "");
        setArkElementStyle(content, "display", "none");
      }
    }
    if (calendar) calendar.selectedValue = this.selectedValue;
    this.setAttribute("data-open-state", this.open ? "true" : "false");
    if (this.open && !wasOpen) {
      this.previousFocus = this.ownerDocument?.activeElement ?? null;
      const focusable = content ? findFocusableDescendants(content)[0] : null;
      focusable?.focus?.();
    }
    if (!this.open && wasOpen) this.previousFocus?.focus?.();
  }

  calendar() {
    let match = null;
    walkDescendants(this, (el) => {
      if (el.tagName.toLowerCase() === "flux-calendar") {
        match = el;
        return true;
      }
      return false;
    });
    return match;
  }

  handleCalendarChange = (event) => {
    const target = event.target;
    if (target?.tagName.toLowerCase() !== "flux-calendar") return;
    event.stopPropagation?.();
    this.selectedValue = target.selectedValue;
    this.open = false;
    this.dispatchEvent(new Event("change", { bubbles: true }));
  };

  handleClick = (event) => {
    let target = event.target;
    while (target && target !== this) {
      if (target.getAttribute("data-flux-datepicker-trigger") === "true") {
        this.open = !this.open;
        return;
      }
      if (target.getAttribute("data-flux-dismiss") === "true") {
        this.open = false;
        return;
      }
      target = target.parentNode;
    }
  };

  handleKeydown = (event) => {
    const target = event.target;
    const isTrigger = target?.getAttribute("data-flux-datepicker-trigger") === "true";
    if (isTrigger && (event.key === "Enter" || event.key === " " || event.key === "ArrowDown")) {
      event.preventDefault();
      this.open = true;
      return;
    }
    if (event.key === "Escape" && this.open) {
      event.preventDefault();
      this.open = false;
    }
  };

  handleOutsideClick = (event) => {
    const target = event.target;
    if (!this.open || !target || this.contains(target)) return;
    this.open = false;
  };

  handleOutsideFocus = (event) => {
    const target = event.target;
    if (!this.open || !target || this.contains(target)) return;
    this.open = false;
  };
}

export class FluxCalendarElement extends FluxElement {
  static observedAttributes = ["data-flux-selected", "data-flux-month", "data-flux-year"];

  wired = false;

  get selectedValue() {
    return this.getAttribute("data-flux-selected") || "";
  }

  set selectedValue(value) {
    if (value == null || value === "undefined") this.removeAttribute("data-flux-selected");
    else this.setAttribute("data-flux-selected", value);
    this.syncBaseSemantics();
  }

  get month() {
    const raw = this.getAttribute("data-flux-month");
    const parsed = raw == null ? Number.NaN : Number(raw);
    if (Number.isFinite(parsed)) return Math.max(0, Math.min(11, parsed));
    const selected = parseFluxDate(this.selectedValue);
    return selected ? selected.getMonth() : new Date().getMonth();
  }

  set month(value) {
    this.setAttribute("data-flux-month", String(Math.max(0, Math.min(11, value))));
    this.syncBaseSemantics();
  }

  get year() {
    const raw = this.getAttribute("data-flux-year");
    const parsed = raw == null ? Number.NaN : Number(raw);
    if (Number.isFinite(parsed)) return parsed;
    const selected = parseFluxDate(this.selectedValue);
    return selected ? selected.getFullYear() : new Date().getFullYear();
  }

  set year(value) {
    this.setAttribute("data-flux-year", String(value));
    this.syncBaseSemantics();
  }

  defaultRole() {
    return "group";
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.wired) {
      this.wired = true;
      this.addEventListener("click", this.handleClick);
      this.addEventListener("keydown", this.handleKeydown);
    }
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "calendar");
    this.syncBaseSemantics();
  }

  disconnectedCallback() {
    if (this.wired) {
      this.removeEventListener("click", this.handleClick);
      this.removeEventListener("keydown", this.handleKeydown);
      this.wired = false;
    }
    super.disconnectedCallback();
  }

  syncBaseSemantics() {
    super.syncBaseSemantics();
    const grid = this.gridNode();
    const label = this.labelNode();
    const days = this.dayNodes();
    const selected = parseFluxDate(this.selectedValue);
    const currentMonth = this.month;
    const currentYear = this.year;
    if (grid) grid.setAttribute("role", "grid");
    if (label) label.textContent = formatCalendarLabel(currentMonth, currentYear);
    const firstDay = new Date(currentYear, currentMonth, 1);
    const weekdayOffset = firstDay.getDay();
    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    days.forEach((day, index) => {
      const dateNumber = index - weekdayOffset + 1;
      const inMonth = dateNumber >= 1 && dateNumber <= daysInMonth;
      day.setAttribute("role", "gridcell");
      day.setAttribute("data-flux-day", "true");
      if (!inMonth) {
        day.textContent = "";
        day.setAttribute("hidden", "");
        day.removeAttribute("data-flux-date");
        day.setAttribute("aria-selected", "false");
        day.tabIndex = -1;
        return;
      }
      const date = new Date(currentYear, currentMonth, dateNumber);
      const dateValue = formatFluxDate(date);
      const isSelected = sameDay(selected, date);
      day.textContent = String(dateNumber);
      day.removeAttribute("hidden");
      day.setAttribute("data-flux-date", dateValue);
      day.setAttribute("aria-selected", isSelected ? "true" : "false");
      day.tabIndex = isSelected || (!selected && dateNumber === 1) ? 0 : -1;
    });
  }

  gridNode() {
    let match = null;
    walkDescendants(this, (el) => {
      if (el.getAttribute("data-flux-calendar-grid") === "true") {
        match = el;
        return true;
      }
      return false;
    });
    return match;
  }

  labelNode() {
    let match = null;
    walkDescendants(this, (el) => {
      if (el.getAttribute("data-flux-calendar-label") === "true") {
        match = el;
        return true;
      }
      return false;
    });
    return match;
  }

  dayNodes() {
    const items = [];
    walkDescendants(this, (el) => {
      if (
        el.getAttribute("data-flux-day") === "true"
        || (
          isFocusable(el)
          && el.getAttribute("data-flux-calendar-prev") !== "true"
          && el.getAttribute("data-flux-calendar-next") !== "true"
          && el.getAttribute("data-flux-calendar-label") !== "true"
        )
      ) items.push(el);
      return false;
    });
    return items.slice(0, 42);
  }

  moveMonth(delta) {
    let nextMonth = this.month + delta;
    let nextYear = this.year;
    while (nextMonth < 0) {
      nextMonth += 12;
      nextYear -= 1;
    }
    while (nextMonth > 11) {
      nextMonth -= 12;
      nextYear += 1;
    }
    this.setAttribute("data-flux-month", String(nextMonth));
    this.setAttribute("data-flux-year", String(nextYear));
    this.syncBaseSemantics();
  }

  selectDate(dateValue) {
    this.selectedValue = dateValue;
    this.dispatchEvent(new Event("change", { bubbles: true }));
  }

  focusDate(dateValue) {
    const days = this.dayNodes();
    const index = days.findIndex((day) => day.getAttribute("data-flux-date") === dateValue);
    if (index === -1) return;
    days.forEach((day, dayIndex) => { day.tabIndex = dayIndex === index ? 0 : -1; });
    days[index].focus();
  }

  handleClick = (event) => {
    let target = event.target;
    while (target && target !== this) {
      if (target.getAttribute("data-flux-calendar-prev") === "true") {
        this.moveMonth(-1);
        return;
      }
      if (target.getAttribute("data-flux-calendar-next") === "true") {
        this.moveMonth(1);
        return;
      }
      const dateValue = target.getAttribute("data-flux-date");
      if (dateValue) {
        this.selectDate(dateValue);
        return;
      }
      target = target.parentNode;
    }
  };

  handleKeydown = (event) => {
    const target = event.target;
    const dateValue = target?.getAttribute("data-flux-date");
    if (!dateValue) return;
    const current = parseFluxDate(dateValue);
    if (!current) return;
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      this.selectDate(dateValue);
      return;
    }
    const deltaByKey = {
      ArrowRight: 1,
      ArrowLeft: -1,
      ArrowDown: 7,
      ArrowUp: -7,
    };
    const delta = deltaByKey[event.key];
    if (delta == null) return;
    event.preventDefault();
    const next = new Date(current.getFullYear(), current.getMonth(), current.getDate() + delta);
    if (next.getMonth() !== this.month || next.getFullYear() !== this.year) {
      this.setAttribute("data-flux-month", String(next.getMonth()));
      this.setAttribute("data-flux-year", String(next.getFullYear()));
      this.syncBaseSemantics();
    }
    this.focusDate(formatFluxDate(next));
  };
}

/** Browser-native OTP field. Supply input children marked with
 * `data-flux-otp-input`; the element owns normalization, navigation, paste,
 * completion events, form value, and optional Flux-store writeback. */
export class FluxOtpFieldElement extends FluxElement {
  static observedAttributes = ["value", "length", "min-length", "max-length", "validation-type", "mask", "reveal", "disabled", "readonly", "required", "name", "form", "data-flux-path"];

  wired = false;
  unsubscribe;

  defaultRole() { return "group"; }

  get value() { return this.getAttribute("value") || ""; }
  set value(next) { this.setAttribute("value", this.normalizeOtpValue(next)); }

  get length() {
    const declared = Number(this.getAttribute("max-length") || this.getAttribute("length"));
    if (declared > 0) return Math.floor(declared);
    let count = 0;
    walkDescendants(this, (el) => {
      if (el.tagName.toLowerCase() === "input" && el.getAttribute("type") !== "hidden") count += 1;
      return false;
    });
    return Math.max(1, count || 6);
  }

  set length(next) { this.setAttribute("length", String(Math.max(1, Math.floor(Number(next) || 1)))); }

  get minLength() {
    const declared = Number(this.getAttribute("min-length"));
    return declared > 0 ? Math.min(this.length, Math.floor(declared)) : this.length;
  }

  clear() { this.value = ""; this.inputs()[0]?.focus(); }

  focus(options) { this.inputs()[0]?.focus(options); }

  setFluxStore(store) {
    super.setFluxStore(store);
    this.unsubscribe?.();
    const path = this.getAttribute("data-flux-path");
    if (!path) return;
    const stored = store.get(path);
    if (typeof stored === "string") this.value = stored;
    this.unsubscribe = store.subscribe(path, (next) => {
      if (typeof next === "string" && next !== this.value) this.value = next;
    });
  }

  connectedCallback() {
    super.connectedCallback();
    if (!this.wired) {
      this.wired = true;
      this.addEventListener("input", this.handleInput);
      this.addEventListener("keydown", this.handleKeydown);
      this.addEventListener("paste", this.handlePaste);
    }
    if (!this.getAttribute("data-ark-part")) this.setAttribute("data-ark-part", "otp-field");
    this.syncOtp();
  }

  disconnectedCallback() {
    if (this.wired) {
      this.removeEventListener("input", this.handleInput);
      this.removeEventListener("keydown", this.handleKeydown);
      this.removeEventListener("paste", this.handlePaste);
      this.wired = false;
    }
    this.unsubscribe?.();
    super.disconnectedCallback();
  }

  attributeChangedCallback(name, oldValue, nextValue) {
    super.attributeChangedCallback(name, oldValue, nextValue);
    if (oldValue !== nextValue && this.connected) this.syncOtp();
  }

  inputs() {
    const result = [];
    walkDescendants(this, (el) => {
      if (el.tagName.toLowerCase() === "input" && el.getAttribute("type") !== "hidden") result.push(el);
      return false;
    });
    const declared = Number(this.getAttribute("max-length") || this.getAttribute("length"));
    return declared > 0 ? result.slice(0, Math.floor(declared)) : result;
  }

  visibleLength(valueLength = this.value.length) {
    if (this.minLength >= this.length) return this.length;
    return Math.min(this.length, Math.max(this.minLength, valueLength + 1));
  }

  normalizeOtpValue(raw) {
    const compact = String(raw || "").replace(/\s/g, "");
    const type = this.getAttribute("validation-type") || "numeric";
    const filtered = type === "numeric" ? compact.replace(/[^0-9]/g, "") : type === "alpha" ? compact.replace(/[^a-zA-Z]/g, "") : type === "alphanumeric" ? compact.replace(/[^0-9a-zA-Z]/g, "") : compact;
    return filtered.slice(0, this.length);
  }

  commit(next, reason) {
    const normalized = this.normalizeOtpValue(next);
    const changed = normalized !== this.value;
    if (changed) this.setAttribute("value", normalized);
    this.syncOtp();
    const path = this.getAttribute("data-flux-path");
    if (path) this.store?.set(path, normalized);
    if (changed) this.dispatchEvent(new Event("valuechange", { bubbles: true }));
    if (normalized.length === this.length) {
      this.setAttribute("data-complete-reason", reason);
      this.dispatchEvent(new Event("complete", { bubbles: true }));
      if (this.hasAttribute("auto-submit")) this.formInput()?.form?.requestSubmit?.();
    }
  }

  formInput() {
    let result = null;
    walkDescendants(this, (el) => {
      if (el.tagName.toLowerCase() === "input" && el.getAttribute("type") === "hidden") {
        result = el;
        return true;
      }
      return false;
    });
    return result;
  }

  syncOtp() {
    const value = this.normalizeOtpValue(this.value);
    const inputs = this.inputs();
    const visibleLength = this.visibleLength(value.length);
    inputs.forEach((input, index) => {
      input.setAttribute("data-ark-part", "otp-slot");
      input.setAttribute("maxlength", "1");
      input.setAttribute("inputmode", this.getAttribute("inputmode") || (this.getAttribute("validation-type") === "numeric" || !this.hasAttribute("validation-type") ? "numeric" : "text"));
      input.setAttribute("autocomplete", index === 0 ? (this.getAttribute("autocomplete") || "one-time-code") : "off");
      input.setAttribute("aria-label", `Character ${index + 1} of ${inputs.length}`);
      const visible = index < visibleLength;
      if (visible) input.removeAttribute("hidden");
      else input.setAttribute("hidden", "");
      input.disabled = this.hasAttribute("disabled") || !visible;
      input.readOnly = this.hasAttribute("readonly");
      input.required = this.hasAttribute("required") && visible;
      const revealed = this.hasAttribute("reveal");
      input.type = revealed ? "text" : "password";
      input.value = revealed ? (value[index] || "") : "";
      input.placeholder = !revealed && value[index] ? "•" : "";
      input.setAttribute("aria-label", `Character ${index + 1} of ${inputs.length}${value[index] ? ", filled" : ""}`);
      if (input.value) input.setAttribute("data-filled", "");
      else input.removeAttribute("data-filled");
    });
    const hidden = this.formInput();
    if (hidden) {
      hidden.value = value;
      hidden.name = this.getAttribute("name") || "";
      if (this.getAttribute("form")) hidden.setAttribute("form", this.getAttribute("form"));
    }
    if (value) this.setAttribute("data-filled", "");
    else this.removeAttribute("data-filled");
    if (value.length >= this.minLength) this.setAttribute("data-min-complete", "");
    else this.removeAttribute("data-min-complete");
    this.setAttribute("data-visible-length", String(visibleLength));
    if (value.length === inputs.length && inputs.length > 0) this.setAttribute("data-complete", "");
    else this.removeAttribute("data-complete");
  }

  handleInput = (event) => {
    if (this.hasAttribute("disabled") || this.hasAttribute("readonly")) return;
    const input = event.target;
    const inputs = this.inputs();
    const index = inputs.indexOf(input);
    if (index < 0) return;
    const chars = this.value.split("");
    chars[index] = this.normalizeOtpValue(input.value).slice(-1);
    this.commit(chars.join(""), "input-change");
    if (chars[index]) inputs[index + 1]?.focus();
  };

  handleKeydown = (event) => {
    const inputs = this.inputs();
    const index = inputs.indexOf(event.target);
    if (index < 0) return;
    if (event.key === "ArrowLeft") {
      event.preventDefault();
      inputs[Math.max(0, index - 1)]?.focus();
    } else if (event.key === "ArrowRight") {
      event.preventDefault();
      inputs[Math.min(inputs.length - 1, index + 1)]?.focus();
    } else if (event.key === "Backspace" && !this.value[index] && index > 0) {
      event.preventDefault();
      this.commit(this.value.slice(0, index - 1) + this.value.slice(index), "keyboard");
      inputs[index - 1]?.focus();
    }
  };

  handlePaste = (event) => {
    const inputs = this.inputs();
    const index = inputs.indexOf(event.target);
    if (index < 0) return;
    const pasted = this.normalizeOtpValue(event.clipboardData?.getData("text") || "");
    if (!pasted) return;
    event.preventDefault();
    this.commit((this.value.slice(0, index) + pasted + this.value.slice(index + pasted.length)).slice(0, inputs.length), "input-paste");
    inputs[Math.min(inputs.length - 1, index + pasted.length)]?.focus();
  };
}

export function defineFluxButton(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-button")) return;
  registry.define("flux-button", FluxButtonElement);
}

export function defineFluxDialog(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-dialog")) return;
  registry.define("flux-dialog", FluxDialogElement);
}

export function defineFluxAuthorizationDialog(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-authorization-dialog")) return;
  registry.define("flux-authorization-dialog", FluxAuthorizationDialogElement);
}

export function defineFluxMenu(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-menu")) return;
  registry.define("flux-menu", FluxMenuElement);
}

export function defineFluxTabs(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-tabs")) return;
  registry.define("flux-tabs", FluxTabsElement);
}

export function defineFluxSelect(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-select")) return;
  registry.define("flux-select", FluxSelectElement);
}

export function defineFluxCombobox(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-combobox")) return;
  registry.define("flux-combobox", FluxComboboxElement);
}

export function defineFluxPopover(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-popover")) return;
  registry.define("flux-popover", FluxPopoverElement);
}

export function defineFluxSheet(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-sheet")) return;
  registry.define("flux-sheet", FluxSheetElement);
}

export function defineFluxDrawer(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-drawer")) return;
  registry.define("flux-drawer", FluxDrawerElement);
}

export function defineFluxCommand(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-command")) return;
  registry.define("flux-command", FluxCommandElement);
}

export function defineFluxDatePicker(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-datepicker")) return;
  registry.define("flux-datepicker", FluxDatePickerElement);
}

export function defineFluxCalendar(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-calendar")) return;
  registry.define("flux-calendar", FluxCalendarElement);
}

export function defineFluxOtpField(options = {}) {
  const registry = getCustomElementsRegistry();
  if (!registry) return;
  if (!options.force && registry.get("flux-otp-field")) return;
  registry.define("flux-otp-field", FluxOtpFieldElement);
}

export function defineFluxElements(options = {}) {
  defineFluxButton(options);
  defineFluxDialog(options);
  defineFluxAuthorizationDialog(options);
  defineFluxMenu(options);
  defineFluxTabs(options);
  defineFluxSelect(options);
  defineFluxCombobox(options);
  defineFluxPopover(options);
  defineFluxSheet(options);
  defineFluxDrawer(options);
  defineFluxCommand(options);
  defineFluxDatePicker(options);
  defineFluxCalendar(options);
  defineFluxOtpField(options);
}
