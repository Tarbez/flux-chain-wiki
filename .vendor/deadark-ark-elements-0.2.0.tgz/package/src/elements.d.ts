import type { FluxElement } from "./base.js";

export declare class FluxButtonElement extends FluxElement {
  private enabledTabIndex;
  private wasDisabled;
  static observedAttributes: string[];
  private wired;
  get disabled(): boolean;
  set disabled(value: boolean);
  protected defaultRole(): string | null;
  connectedCallback(): void;
  disconnectedCallback(): void;
  protected syncBaseSemantics(): void;
  private handleClick;
  private handleKeydown;
}

export declare class FluxDialogElement extends FluxElement {
  static observedAttributes: string[];
  private wired;
  private previousFocus;
  get open(): boolean;
  set open(value: boolean);
  protected defaultRole(): string | null;
  connectedCallback(): void;
  disconnectedCallback(): void;
  protected syncBaseSemantics(): void;
  close(): void;
  private focusInitialTarget;
  private handleKeydown;
  private handleClick;
}

export declare class FluxAuthorizationDialogElement extends FluxDialogElement {
  static observedAttributes: string[];
  get state(): string;
  set state(value: string);
  get action(): string;
  set action(value: string);
  get capability(): string;
  set capability(value: string);
  connectedCallback(): void;
  attributeChangedCallback(name: string, oldValue: string | null, newValue: string | null): void;
  private syncAuthorizationSemantics;
}

export declare class FluxMenuElement extends FluxElement {
  static observedAttributes: string[];
  private wired;
  private previousFocus;
  get open(): boolean;
  set open(value: boolean);
  protected defaultRole(): string | null;
  connectedCallback(): void;
  disconnectedCallback(): void;
  protected syncBaseSemantics(): void;
  close(): void;
  private syncItems;
  private focusItem;
  private moveFocus;
  private handleKeydown;
  private handleClick;
}

export declare class FluxTabsElement extends FluxElement {
  private tabIdPrefix;
  static observedAttributes: string[];
  private wired;
  get selectedIndex(): number;
  set selectedIndex(value: number);
  protected defaultRole(): string | null;
  connectedCallback(): void;
  disconnectedCallback(): void;
  protected syncBaseSemantics(): void;
  private selectIndex;
  private handleClick;
  private handleKeydown;
}

export declare class FluxSelectElement extends FluxElement {
  static observedAttributes: string[];
  private wired;
  private previousFocus;
  private highlightedIndex;
  get open(): boolean;
  set open(value: boolean);
  get selectedValue(): string;
  set selectedValue(value: string);
  protected defaultRole(): string | null;
  connectedCallback(): void;
  disconnectedCallback(): void;
  protected syncBaseSemantics(): void;
  private trigger;
  private valueNode;
  private contentNode;
  private resolveSelectedIndex;
  private toggle;
  private focusIndex;
  private commit;
  private handleClick;
  private handleKeydown;
  private handleOutsideClick;
  private handleOutsideFocus;
}

export declare class FluxComboboxElement extends FluxElement {
  static observedAttributes: string[];
  private wired;
  private activeIndex;
  private committedText;
  get open(): boolean;
  set open(value: boolean);
  get selectedValue(): string;
  set selectedValue(value: string);
  protected defaultRole(): string | null;
  connectedCallback(): void;
  disconnectedCallback(): void;
  protected syncBaseSemantics(): void;
  private inputNode;
  private contentNode;
  private emptyNode;
  private resolveCommittedOption;
  private filter;
  private commit;
  private moveActive;
  private handleInput;
  private handleFocus;
  private handleClick;
  private handleKeydown;
  private handleOutsideClick;
  private handleOutsideFocus;
}

export declare class FluxPopoverElement extends FluxElement {
  static observedAttributes: string[];
  private wired;
  private previousFocus;
  get open(): boolean;
  set open(value: boolean);
  protected defaultRole(): string | null;
  connectedCallback(): void;
  disconnectedCallback(): void;
  protected syncBaseSemantics(): void;
  close(): void;
  private handleClick;
  private handleKeydown;
  private handleOutsideClick;
  private handleOutsideFocus;
}

export declare class FluxSheetElement extends FluxDialogElement {
  static observedAttributes: string[];
  connectedCallback(): void;
}

export declare class FluxDrawerElement extends FluxSheetElement {
  connectedCallback(): void;
}

export declare class FluxCommandElement extends FluxElement {
  static observedAttributes: string[];
  private wired;
  private activeIndex;
  get open(): boolean;
  set open(value: boolean);
  get selectedValue(): string;
  set selectedValue(value: string);
  connectedCallback(): void;
  disconnectedCallback(): void;
  protected syncBaseSemantics(): void;
  private options;
  private filter;
  private commit;
  private handleInput;
  private handleFocus;
  private handleClick;
  private handleKeydown;
  private handleOutsideClick;
  private handleOutsideFocus;
}

export declare class FluxDatePickerElement extends FluxElement {
  static observedAttributes: string[];
  private wired;
  private previousFocus;
  get open(): boolean;
  set open(value: boolean);
  get selectedValue(): string;
  set selectedValue(value: string);
  connectedCallback(): void;
  disconnectedCallback(): void;
  protected syncBaseSemantics(): void;
  private calendar;
  private handleCalendarChange;
  private handleClick;
  private handleKeydown;
  private handleOutsideClick;
  private handleOutsideFocus;
}

export declare class FluxCalendarElement extends FluxElement {
  static observedAttributes: string[];
  private wired;
  get selectedValue(): string;
  set selectedValue(value: string);
  get month(): number;
  set month(value: number);
  get year(): number;
  set year(value: number);
  protected defaultRole(): string | null;
  connectedCallback(): void;
  disconnectedCallback(): void;
  protected syncBaseSemantics(): void;
  private gridNode;
  private labelNode;
  private dayNodes;
  private moveMonth;
  private selectDate;
  private focusDate;
  private handleClick;
  private handleKeydown;
}

export interface DefineFluxElementsOptions {
  force?: boolean;
}

/** Browser-native OTP field. Supply input children marked with
 * `data-flux-otp-input`; the element owns normalization, navigation, paste,
 * completion events, form value, and optional Flux-store writeback. */
export declare class FluxOtpFieldElement extends FluxElement {
  static observedAttributes: string[];
  private wired;
  private unsubscribe?;
  protected defaultRole(): string | null;
  get value(): string;
  set value(next: string);
  get length(): number;
  set length(next: number);
  get minLength(): number;
  clear(): void;
  focus(options?: FocusOptions): void;
  connectedCallback(): void;
  disconnectedCallback(): void;
  attributeChangedCallback(name?: string, oldValue?: string | null, nextValue?: string | null): void;
  private inputs;
  private visibleLength;
  private normalizeOtpValue;
  private commit;
  private formInput;
  private syncOtp;
  private handleInput;
  private handleKeydown;
  private handlePaste;
}

export declare function defineFluxButton(options?: DefineFluxElementsOptions): void;
export declare function defineFluxDialog(options?: DefineFluxElementsOptions): void;
export declare function defineFluxAuthorizationDialog(options?: DefineFluxElementsOptions): void;
export declare function defineFluxMenu(options?: DefineFluxElementsOptions): void;
export declare function defineFluxTabs(options?: DefineFluxElementsOptions): void;
export declare function defineFluxSelect(options?: DefineFluxElementsOptions): void;
export declare function defineFluxCombobox(options?: DefineFluxElementsOptions): void;
export declare function defineFluxPopover(options?: DefineFluxElementsOptions): void;
export declare function defineFluxSheet(options?: DefineFluxElementsOptions): void;
export declare function defineFluxDrawer(options?: DefineFluxElementsOptions): void;
export declare function defineFluxCommand(options?: DefineFluxElementsOptions): void;
export declare function defineFluxDatePicker(options?: DefineFluxElementsOptions): void;
export declare function defineFluxCalendar(options?: DefineFluxElementsOptions): void;
export declare function defineFluxOtpField(options?: DefineFluxElementsOptions): void;
export declare function defineFluxElements(options?: DefineFluxElementsOptions): void;
